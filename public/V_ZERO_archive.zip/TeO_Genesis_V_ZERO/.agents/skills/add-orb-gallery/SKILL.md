---
name: add-orb-gallery
description: "Build Orb Gallery from its verified authored source using Three.js r149 + embedded WebP atlas + DOM/CSS, including the complete renderer, interactions, and required assets. Use when Codex needs to implement, port, or adapt this effect without requiring the ThreeUI package or reconstructing the visual from an approximation."
---

> ## ⚠️ Stan w Katedrze OtakOS
>
> Ten skill mówi: *„Copy the exact code from the verified source files"* — i wymienia
> pliki w rodzaju `src/shaders/.../*.tsx`. **Tych plików w Katedrze NIE MA** i nie ma
> pakietu `@designcodeio/threeui`. Sprawdzone: `node_modules/@designcodeio` nie istnieje.
>
> Dlatego, zanim zaczniesz:
> 1. Ustal, czy źródło jest dostępne (pakiet, klon repo, katalog wskazany przez Suwerena).
> 2. **Jeśli źródła nie ma — powiedz to wprost i zatrzymaj się.** Ten skill wprost
>    zakazuje odtwarzania efektu z przybliżenia; zbudowanie „czegoś podobnego"
>    złamałoby jego własny kontrakt i dałoby atrapę zamiast efektu.
> 3. Fragmenty kodu w tym pliku to *orchestration only* — szkic wywołań, nie implementacja.


# Build Orb Gallery

## Description

A slowly turning sphere of interface references, built from 190 non-overlapping gallery plates with hover lift, focus dimming, and inertial drag rotation.

Recreate the authored behavior from the verified source, not from screenshots or the abbreviated orchestration sample in this skill. The implementation may live directly in the target project and does not require `@designcodeio/threeui`.

## Technologies

- React sandbox host
- Byte-exact authored HTML
- Three.js r149
- Embedded 96-tile WebP atlas
- Cell-safe rounded gallery geometry
- Raycast hover focus
- Visibility-aware lifecycle

## Verified source material

- `src/shaders/orb-gallery/sources/orb-gallery.html — byte-exact complete interaction`
- `src/shaders/orb-gallery/OrbGallery.tsx`

Source revision: `SHA-256 fff1d451248b`

## Implementation steps

1. Open every verified source file listed above and identify the renderer, host lifecycle, styles, and assets before editing.
2. Keep orb-gallery.html byte-for-byte as the canonical source, including its navigation, bottom-corner copy, 96 inline interface tiles, five avatar portraits, sphere lattice, and responsive layout.
3. Mount the document in an opaque allow-scripts-only sandbox so the authored Three.js r149 and Google Fonts URLs load without exposing the host.
4. Preserve the automatic rotation, raycast plate picking, hover lift, focus dimming, grab-and-drag rotation, inertial release, responsive framing, and reduced-motion behavior.
5. Retain the 190 non-overlapping rounded plates and packed CanvasTexture atlas rather than flattening the gallery into a static hero image.
6. Unmount the iframe whenever its host or document is hidden so route changes release the renderer and animation loop.
7. Give the local component a sized, overflow-controlled parent and verify desktop, mobile, reduced-motion, and context-loss behavior.

Asset handling: This effect has no required external assets.

## Local component example

Import the copied local component rather than a package entrypoint:

```tsx
import { OrbGallery } from "./effects/orb-gallery/OrbGallery";
import "./effects/orb-gallery/styles.css";

export function Scene() {
  return <div className="effect-frame"><OrbGallery /></div>;
}
```

## Core renderer pattern

This excerpt documents orchestration only. Copy the exact shader, geometry, pass, and interaction code from the verified source files.

```tsx
<OrbGallery />
```

## Behavior contract

- Runtime: Three.js r149 + embedded WebP atlas + DOM/CSS
- Passes: 1 WebGL gallery-sphere pass with 190 rounded plates sampled from a 96-tile interface atlas
- Interaction: Automatic rotation, pointer picking, card lift and focus dimming, grab-and-drag rotation, inertial release, responsive framing, and reduced-motion support
- Assets: 96 embedded WebP interface tiles + 5 embedded WebP avatar portraits; Three.js r149 and Google Fonts load from their authored URLs
- **document** (fixed): Complete original orb-gallery.html, byte-for-byte
- **renderer** (sandbox): Opaque allow-scripts-only HTML document
- **geometry** (original): 190 cell-safe rounded gallery plates on one rotating sphere
- **interaction** (original): Hover lift + focus dimming + grab drag + inertial release
- **lifecycle** (adaptive): Iframe mounts only while its host and document are visible
- **assets** (embedded + remote runtime): 96 inline interface WebPs + 5 inline avatar WebPs + authored Three.js and font URLs

## Verification

1. Compare the rendered composition, animation timing, pointer behavior, and state transitions with the source implementation.
2. Exercise resize, high-DPI, mobile/coarse-pointer, reduced-motion, tab visibility, and WebGL context-loss paths where applicable.
3. Confirm every animation frame, observer, listener, geometry, buffer, texture, framebuffer, material, and renderer is released on teardown.
4. Check the browser console and confirm the effect renders at native-or-better backing resolution.

## Guardrails

- Do not substitute a visually similar package, demo, shader, or runtime.
- Do not approximate, reconstruct, or simplify the authored GLSL, render passes, geometry, interaction state, or assets.
- Keep exact source and asset hashes under regression tests when the source project provides them.
- Adapt only the surrounding host boundary needed by the target project; keep renderer behavior intact.
