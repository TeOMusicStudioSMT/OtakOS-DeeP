/**
 * 🧩🎬🗣️🧊 Panele Świata Katedry — to, co się dzieje, gdy Suweren nie tylko patrzy:
 *
 *  · ROZMOWA   — w katalogu każdego TeOgochi: Delegat z jego kartą roli (POST /api/delegat/rozmowa, SSE).
 *  · SILNIK    — na jakim modelu pracuje; na maszynie Suwerena można go zmienić (POST /api/stado/model).
 *  · PROJEKTY  — wspólna praca stada nad wizją Suwerena (uniwersum: film, gra, moda, muzyka, merch).
 *  · FILM      — „film klockowy": odtworzenie dnia z szyny jako dymki nad płytkami.
 *  · POWITANIE — film dnia od stada (sentencje TeOgochi w kadrach); sam się pokazuje raz dziennie.
 *  · RZEŹBA    — nowy klocek 3D z Assety3D (opis → bryła GLB na płytce Palety), tylko na maszynie.
 *
 * Zmiany (projekt, silnik, rzeźba) są tylko na maszynie Suwerena — Straż Mostu i tak odrzuci
 * je z telefonu; przyciski się wtedy nie pokazują zamiast udawać, że zadziałają.
 */
(() => {
  'use strict';
  const S = window.SwiatKatedry;
  // Suweren (2026-09-27): na telefonie „kliknę 🌅 i nic się nie dzieje". Błąd strony nie może
  // być niemy — pokazujemy go w podpisie pod tytułem (widać na zrzucie ekranu z telefonu).
  const zglos = (tekst) => { const p = document.getElementById('podpis'); if (p) p.textContent = `⚠️ ${String(tekst).slice(0, 160)}`; };
  window.addEventListener('error', (e) => zglos(e.message || 'błąd strony'));
  window.addEventListener('unhandledrejection', (e) => zglos(e.reason?.message || e.reason || 'błąd strony'));
  /** Zapytanie do mostu, które nie wisi w nieskończoność (tunel bywa wolny albo zerwany). */
  const zCzasem = (ms = 15_000) => (typeof AbortSignal !== 'undefined' && AbortSignal.timeout ? { signal: AbortSignal.timeout(ms) } : {});
  const bogaty = (s) => (window.TekstStada ? window.TekstStada.bogaty(s) : S.esc(s));
  const $ = (id) => document.getElementById(id);
  const esc = S.esc;
  const lokalne = () => !!S.dane?.lokalne;
  /** Projekt zakłada Suweren przy Katedrze albo ze sparowanego telefonu (most sprawdza token). */
  const mozeZakladac = () => lokalne() || !!S.dane?.urzadzenie;
  const json = (body) => ({ method: 'POST', headers: { ...S.naglowki, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const STAN = { czeka: '○', trwa: '◐', gotowe: '●', blad: '✕', przerwane: '◌', przerwany: '◌' };
  const MODUL = { merch: '🛒 Marketplace', muzyka: '🎵 Muzyka', model3d: '🧊 Assety3D', wideo: '🎬 Wideo', gra: '🎮 Studio' };

  // ── Rozmowa + silnik + rzeźba: sekcje w katalogu agenta ────────────────────
  const rozmowy = new Map();   // id gatunku → { rozmowaId, tury: [{kto, tresc}] }
  let modeleLokalne = null;

  async function listaModeli() {
    if (modeleLokalne) return modeleLokalne;
    try {
      const d = await fetch('/api/ollama/models', { headers: S.naglowki }).then((r) => r.json());
      modeleLokalne = (d.models ?? d.modele ?? []).map((m) => (typeof m === 'string' ? m : m.name)).filter(Boolean);
    } catch { modeleLokalne = []; }
    return modeleLokalne;
  }

  S.rozszerzKatalog((g, kontener) => {
    const d = S.dane ?? {};
    const silnik = d.modele?.[g.id] || d.domyslnyModel || 'domyślny';
    const s = document.createElement('div');
    const r = rozmowy.get(g.id) ?? { rozmowaId: null, tury: [] };
    s.innerHTML = `
      <div class="sekcja">
        <h3>Silnik</h3>
        <p class="meta">${esc(g.imie)} myśli na: <b>${esc(silnik)}</b>${d.modele?.[g.id] ? '' : ' (domyślny Katedry)'}</p>
        ${lokalne() ? `<select id="silnik" aria-label="Model dla ${esc(g.imie)}"><option value="">— domyślny (${esc(d.domyslnyModel || '')}) —</option></select>` : ''}
      </div>
      ${g.wyklute ? `<div class="sekcja">
        <h3>Porozmawiaj z ${esc(g.imie)}</h3>
        <div id="rozmowa">${r.tury.map((t) => `<div class="odpowiedz ${t.kto}">${t.kto === 'suweren' ? esc(t.tresc) : bogaty(t.tresc)}</div>`).join('')}</div>
        <textarea id="pytanie" placeholder="Napisz do ${esc(g.imie)}…"></textarea>
        <button class="guzik" id="wyslij" type="button">Wyślij</button>
      </div>` : ''}
      ${g.id === 'paleta' && lokalne() ? `<div class="sekcja">
        <h3>🧊 Wyrzeźbij nowy klocek</h3>
        <p class="meta">Opis → Assety3D (FLUX.2 → TRELLIS.2) → bryła GLB stanie na tej płytce. Kilka minut pracy karty graficznej.</p>
        <input type="text" id="rzezba" placeholder="np. tron z kości słoniowej ze złotymi okuciami">
        <button class="guzik" id="rzezbij" type="button">Wyrzeźbij</button>
        <p class="meta" id="rzezba-stan"></p>
      </div>` : ''}`;
    kontener.appendChild(s);

    if (lokalne()) {
      listaModeli().then((lista) => {
        const sel = s.querySelector('#silnik'); if (!sel) return;
        for (const m of [...new Set([...lista, d.modele?.[g.id]].filter(Boolean))]) sel.add(new Option(m, m, false, m === d.modele?.[g.id]));
        sel.addEventListener('change', async () => {
          const w = await fetch('/api/stado/model', json({ agent: g.id, model: sel.value })).then((x) => x.json()).catch((e) => ({ message: e.message }));
          if (w.success) { S.dane.modele = w.modele; s.querySelector('.meta b').textContent = sel.value || w.domyslnyModel; }
          else alertNaStronie(s, w.message || 'Nie udało się zmienić modelu.');
        });
      });
    }
    s.querySelector('#wyslij')?.addEventListener('click', () => rozmawiaj(g, s, r));
    s.querySelector('#rzezbij')?.addEventListener('click', () => rzezbij(s.querySelector('#rzezba').value, s.querySelector('#rzezba-stan')));
  });

  function alertNaStronie(kontener, tekst) {
    const p = document.createElement('p'); p.className = 'meta'; p.style.color = 'var(--blad)'; p.textContent = tekst;
    kontener.appendChild(p);
  }

  async function rozmawiaj(g, s, r) {
    const pole = s.querySelector('#pytanie'), guzik = s.querySelector('#wyslij'), okno = s.querySelector('#rozmowa');
    const tekst = pole.value.trim(); if (!tekst) return;
    pole.value = ''; guzik.disabled = true;
    r.tury.push({ kto: 'suweren', tresc: tekst });
    okno.insertAdjacentHTML('beforeend', `<div class="odpowiedz suweren">${esc(tekst)}</div><div class="odpowiedz">…</div>`);
    const odp = okno.lastElementChild;
    let calosc = '';
    try {
      const res = await fetch('/api/delegat/rozmowa', json({ delegat: g.id, tekst, rozmowaId: r.rozmowaId, strumien: true }));
      if (!res.ok || !res.body) throw new Error((await res.json().catch(() => ({}))).message || `HTTP ${res.status}`);
      const czytnik = res.body.getReader(), dek = new TextDecoder();
      let bufor = '';
      for (;;) {
        const { value, done } = await czytnik.read(); if (done) break;
        bufor += dek.decode(value, { stream: true });
        let i;
        while ((i = bufor.indexOf('\n\n')) >= 0) {
          const ramka = bufor.slice(0, i); bufor = bufor.slice(i + 2);
          const dane = ramka.split('\n').filter((l) => l.startsWith('data:')).map((l) => l.slice(5).trim()).join('');
          if (!dane) continue;
          const z = JSON.parse(dane);
          if (z.typ === 'token') { calosc += z.tekst ?? z.token ?? ''; odp.innerHTML = bogaty(calosc); }
          else if (z.typ === 'narzedzie') odp.textContent = `${calosc}\n⚙️ ${z.narzedzie}…`;
          else if (z.typ === 'koniec') { calosc = z.odpowiedz ?? calosc; r.rozmowaId = z.rozmowaId ?? r.rozmowaId; odp.innerHTML = bogaty(calosc); }
          else if (z.typ === 'blad') throw new Error(z.message);
        }
      }
      r.tury.push({ kto: '', tresc: calosc || '(cisza)' });
    } catch (e) {
      odp.textContent = `⚠️ ${e.message}`;
      r.tury.push({ kto: '', tresc: `⚠️ ${e.message}` });
    } finally {
      rozmowy.set(g.id, r); guzik.disabled = false;
    }
  }

  async function rzezbij(opis, stan) {
    const tekst = String(opis || '').trim(); if (!tekst) return;
    stan.textContent = 'Zlecam Assety3D…';
    const w = await fetch('/api/assety3d/generuj', json({ tekst, nazwa: tekst.slice(0, 40) })).then((r) => r.json()).catch((e) => ({ message: e.message }));
    stan.textContent = w.success
      ? `Zlecone (${w.zadanie?.id ?? w.id ?? 'zadanie'}). Bryła stanie na płytce Palety, gdy TRELLIS.2 skończy — śledź dymki.`
      : `Assety3D odmówił: ${w.message}`;
  }

  // ── Projekty stada ─────────────────────────────────────────────────────────
  let otwartyProjekt = null;

  /** Szuflada projektów zajmuje dół ekranu — pasek filmu chowa się pod nią (CSS: body[data-panel="projekty"]), a film staje. */
  function panelProjektu(html) {
    stop();
    return S.pokazPanel(html, 'projekty');
  }

  function krokiHtml(p) {
    return `<div class="kroki">${p.kroki.map((k) => `<span class="krok ${k.stan}" title="${esc(k.zadanie)}">${STAN[k.stan] || ''} ${esc(k.imie)}${k.fala === 4 ? ' · scala' : ''}</span>`).join('')}</div>`;
  }

  async function pokazProjekty() {
    otwartyProjekt = null;
    let lista = S.dane?.projekty ?? [];
    if (document.body.dataset.panel !== 'projekty') panelProjektu('<p class="cisza">Wczytuję projekty stada…</p>');   // od razu widać, że klik zadziałał
    try { lista = (await fetch('/api/stado/projekty', { headers: S.naglowki, ...zCzasem() }).then((r) => r.json())).projekty ?? lista; } catch { /* zostaje to, co w świecie */ }
    const wyklute = (S.dane?.gatunki ?? []).filter((g) => g.wyklute);
    const k = panelProjektu(`
      <div class="glowa"><div class="forma">🧩</div><div><h2>Wspólne projekty stada</h2>
        <div class="meta">Każdy TeOgochi wnosi swoją dziedzinę, na swoim modelu. Na końcu scalenie w Biblię projektu.</div></div></div>
      ${mozeZakladac() ? `<div class="sekcja">
        <h3>Nowy projekt</h3>
        <input type="text" id="p-nazwa" placeholder="Nazwa, np. Uniwersum Teterhia">
        <textarea id="p-wizja" placeholder="Twoja wizja: świat, klimat, co ma powstać — film, gra, moda, muzyka, merch…"></textarea>
        <div class="uczestnicy">${wyklute.map((g) => `<label><input type="checkbox" value="${esc(g.id)}" checked> ${esc(g.forma)} ${esc(g.imie)}</label>`).join('') || '<span class="meta">Najpierw musi się ktoś wykluć.</span>'}</div>
        <div class="rundy">
          <label title="Po każdej rundzie Sędzia ocenia Biblię względem wizji; stado dokłada cegiełki na jego brakach. Ocena ≥ 9/10 kończy wcześniej.">Rundy doskonalenia <input type="number" id="p-rundy" min="1" max="5" value="1"></label>
          <label title="Każdy punkt planu: autor czyta swój szkic krytycznie i oddaje lepszą wersję — tyle razy, zanim pójdzie dalej.">Pętla kreatywna na punkt <input type="number" id="p-petla" min="0" max="3" value="0"></label>
        </div>
        <label class="meta"><input type="checkbox" id="p-zlecaj" checked> Wkłady same zlecają moduły Katedry (merch, muzyka, 3D, wideo, 🎮 Studio Gier)</label>
        <label class="meta" title="Dyrygent przydzieli każdemu TeOgochi model z Katedry do TEGO projektu (stałe silniki zostają)"><input type="checkbox" id="p-dyrygent"> 🎼 Dyrygent dobierze modele do zadania</label>
        <button class="guzik" id="p-start" type="button" ${wyklute.length < 2 ? 'disabled' : ''}>Zacznijcie razem</button>
        <p class="meta" id="p-stan"></p>
      </div>` : '<p class="meta">Nowy projekt zakłada się przy Katedrze albo ze sparowanego telefonu — tu widać postęp.</p>'}
      <h3>Projekty</h3>
      <div class="sekcja">${lista.length ? lista.map((p) => `<button class="projekt" data-id="${esc(p.id)}"><b>${esc(p.nazwa)}</b> <span class="meta">· ${p.gotowe}/${p.razem} · ${esc(p.stan)}${rundaTekst(p)}${p.zlecenia?.length ? ` · zlecenia ${p.zlecenia.filter((z) => z.stan === 'gotowe').length}/${p.zlecenia.length}` : ''}</span>${krokiHtml(p)}</button>`).join('') : '<p class="cisza">Jeszcze żadnego.</p>'}</div>`);
    k.querySelectorAll('.projekt').forEach((b) => b.addEventListener('click', () => pokazProjekt(b.dataset.id)));
    k.querySelector('#p-start')?.addEventListener('click', async () => {
      const uczestnicy = [...k.querySelectorAll('.uczestnicy input:checked')].map((i) => i.value);
      const st = k.querySelector('#p-stan');
      const w = await fetch('/api/stado/projekt/nowy', json({ nazwa: k.querySelector('#p-nazwa').value, wizja: k.querySelector('#p-wizja').value, uczestnicy, samoZlecanie: k.querySelector('#p-zlecaj').checked, rundy: Number(k.querySelector('#p-rundy').value) || 1, petla: Number(k.querySelector('#p-petla').value) || 0, dyrygent: k.querySelector('#p-dyrygent').checked }))
        .then((r) => r.json()).catch((e) => ({ message: e.message }));
      if (!w.success) { st.textContent = `⚠️ ${w.message}`; return; }
      pokazProjekt(w.projekt.id);
    });
  }

  async function pokazProjekt(id) {
    otwartyProjekt = id;
    const d = await fetch(`/api/stado/projekty/${encodeURIComponent(id)}`, { headers: S.naglowki }).then((r) => r.json()).catch(() => null);
    if (!d?.success) { panelProjektu(`<p class="cisza">Nie udało się wczytać projektu.</p>`); return; }
    const p = d.projekt;
    const k = panelProjektu(`
      <div class="glowa"><div class="forma">🧩</div><div><h2>${esc(p.nazwa)}</h2>
        <div class="meta">${esc(p.stan)}${rundaTekst(p)} · od ${esc(S.kiedyTekst(p.od))}${p.zalozyl ? ` · z urządzenia „${esc(p.zalozyl)}"` : ''}</div></div></div>
      <p class="teraz">${esc(p.wizja)}</p>
      ${krokiHtml(p)}
      ${ocenyHtml(p)}
      ${p.przydzial ? `<div class="sekcja"><h3>🎼 Dyrygent</h3>${p.przydzial.blad ? `<p class="meta" style="color:var(--blad)">${esc(p.przydzial.blad)} — każdy grał na swoim.</p>` : `<p class="meta">${(p.przydzial.przydzial ?? []).map((x) => `${esc(x.agent)} → ${esc(x.model)}${x.powod ? ` (${esc(x.powod)})` : ''}`).join('<br>') || 'bez zmian'}</p>`}</div>` : ''}
      ${p.kroki.map((kr) => `<div class="sekcja"><h3>${STAN[kr.stan] || ''} ${esc(kr.imie)} · ${esc(kr.zadanie.split(':')[0])} <span class="meta">· ${esc(kr.model)}</span></h3>
        ${kr.petle ? `<p class="meta">🔁 po ${kr.petle} ${kr.petle === 1 ? 'pętli' : 'pętlach'} kreatywnych${kr.runda > 1 ? ` · runda ${kr.runda}` : ''}</p>` : kr.runda > 1 ? `<p class="meta">runda ${kr.runda}</p>` : ''}
        ${kr.wklad ? `<div class="wklad">${bogaty(kr.wklad)}</div>` : kr.stan === 'blad' ? `<p class="meta" style="color:var(--blad)">${esc(kr.blad || 'błąd')}</p>` : `<p class="cisza">${kr.stan === 'trwa' ? 'Pracuje…' : 'Czeka na swoją kolej.'}</p>`}</div>`).join('')}
      ${doskonalHtml(p)}
      ${zleceniaHtml(p)}
      ${d.obiekty3d?.length ? `<div class="sekcja"><h3>🧊 Obiekty Palety do wyrzeźbienia</h3>
        ${d.obiekty3d.map((o, i) => `<div><span>${esc(o)}</span> ${lokalne() ? `<button class="guzik maly" data-o="${i}" type="button">Wyrzeźbij</button>` : ''}</div>`).join('')}
        <p class="meta" id="o-stan"></p></div>` : ''}
      <button class="guzik maly" id="p-wstecz" type="button">← Wszystkie projekty</button>`);
    k.querySelector('#p-wstecz').addEventListener('click', pokazProjekty);
    k.querySelector('#d-start')?.addEventListener('click', async () => {
      const st = k.querySelector('#d-stan');
      st.textContent = 'Odsyłam na warsztat…';
      const w = await fetch(`/api/stado/projekt/${encodeURIComponent(p.id)}/runda`, json({ rundy: Number(k.querySelector('#d-rundy').value) || 1, petla: Number(k.querySelector('#d-petla').value) || 0 }))
        .then((r) => r.json()).catch((e) => ({ message: e.message }));
      if (!w.success) { st.textContent = `⚠️ ${w.message}`; return; }
      pokazProjekt(p.id);
    });
    k.querySelector('#z-zlec')?.addEventListener('click', async () => {
      const st = k.querySelector('#z-stan');
      st.textContent = 'Zlecam…';
      const w = await fetch(`/api/stado/projekt/${encodeURIComponent(p.id)}/zlec`, json({})).then((r) => r.json()).catch((e) => ({ message: e.message }));
      if (!w.success) { st.textContent = `⚠️ ${w.message}`; return; }
      w.ile ? pokazProjekt(p.id) : (st.textContent = 'Wkłady nie mają linii dla modułów (PRODUKT:, MUZYKA:, OBIEKT:, UJĘCIE:).');
    });
    k.querySelectorAll('[data-glb]').forEach((b) => b.addEventListener('click', () => {
      const url = S.zKluczem(`/api/assety3d/${encodeURIComponent(b.dataset.glb)}/plik/model.glb`);
      if (!S.podglad3d) { window.open(url, '_blank'); return; }
      const miejsce = document.createElement('div'); miejsce.className = 'model3d';
      b.replaceWith(miejsce); S.podglad3d(miejsce, url);
    }));
    k.querySelectorAll('[data-o]').forEach((b) => b.addEventListener('click', () => rzezbij(d.obiekty3d[Number(b.dataset.o)], k.querySelector('#o-stan'))));
    // 📦 Bryła → Składnica Katedry (_OtakOs_Assety/bryly) — tylko przy Katedrze (Straż: /api/skladnica).
    k.querySelectorAll('[data-do-skladnicy]').forEach((b) => b.addEventListener('click', async () => {
      b.disabled = true; b.textContent = '📦 …';
      const w = await fetch(`/api/assety3d/${encodeURIComponent(b.dataset.doSkladnicy)}/do-skladnicy`, json({})).then((r) => r.json()).catch((e) => ({ message: e.message }));
      b.textContent = w.success ? (w.nowy ? '📦 w Składnicy ✓' : '📦 już była ✓') : `⚠️ ${w.message}`;
    }));
  }

  /** „· runda 2/3 · 7/10" — gdzie projekt jest w rundach doskonalenia i co ostatnio powiedział Sędzia. */
  function rundaTekst(p) {
    const o = (p.oceny ?? []).at(-1)?.ocena;
    return `${(p.rundy ?? 1) > 1 ? ` · runda ${p.runda ?? 1}/${p.rundy}` : ''}${o != null ? ` · ${o}/10` : ''}`;
  }

  /** Oceny Sędziego po każdej rundzie: zgodność z wizją i braki, na których stado buduje dalej. */
  function ocenyHtml(p) {
    const oceny = p.oceny ?? [];
    if (!oceny.length) return '';
    return `<div class="sekcja"><h3>⚖️ Sędzia: zgodność z wizją</h3>
      ${oceny.map((o) => `<div class="ocena">Runda ${o.runda}: <b>${o.ocena != null ? `${o.ocena}/10` : 'bez oceny'}</b> <span class="meta">· ${esc(o.kto || '')}</span>
        ${o.braki?.length ? `<div class="meta">${o.braki.map((b) => `· ${esc(b)}`).join('<br>')}</div>` : ''}</div>`).join('')}</div>`;
  }

  /** Skończony projekt można odesłać na kolejne rundy (tylko przy maszynie — to godziny pracy karty). */
  function doskonalHtml(p) {
    if (p.stan === 'trwa' || !lokalne()) return '';
    return `<div class="sekcja"><h3>🔁 Doskonal dalej</h3>
      <p class="meta">Stado dołoży kolejne cegiełki na brakach Sędziego — każdy na swoim poprzednim wkładzie. Na noc: Nocna Zmiana → „Projekt Stada: rundy doskonalenia" ×N.</p>
      <div class="rundy">
        <label>Rund <input type="number" id="d-rundy" min="1" max="5" value="1"></label>
        <label>Pętla kreatywna <input type="number" id="d-petla" min="0" max="3" value="${p.petla ?? 0}"></label>
        <button class="guzik maly" id="d-start" type="button">Doskonal</button>
      </div>
      <p class="meta" id="d-stan"></p></div>`;
  }

  /** Co wkłady zleciły modułom Katedry i co z tego wyszło — wynik albo prawdziwy błąd modułu. */
  function zleceniaHtml(p) {
    const z = p.zlecenia ?? [];
    const koniec = p.stan !== 'trwa';
    const doPonowienia = koniec && (!z.length || z.some((x) => x.stan === 'blad' || x.stan === 'przerwane'));
    if (!z.length && !(koniec && lokalne())) return '';
    const wynik = (x) => {
      if (x.stan === 'blad' || x.stan === 'przerwane') return `<div class="meta" style="color:var(--blad)">${esc(x.blad || 'przerwane (restart mostu) — można ponowić')}</div>`;
      if (x.stan !== 'gotowe' || !x.wynik) return '';
      const w = x.wynik;
      if (w.asset) return `<div class="meta">bryła: ${esc(w.asset)} <button class="guzik maly" data-glb="${esc(w.asset)}" type="button">Obejrzyj</button>${lokalne() ? ` <button class="guzik maly" data-do-skladnicy="${esc(w.asset)}" type="button" title="Wspólna Składnica Katedry — bryła dla gier, Story i innych modułów">📦 do Składnicy</button>` : ''}</div>`;
      if (w.produkt) return `<div class="meta">w Marketplace: ${esc(w.produkt)} · ${esc(w.cenaGrv)} GRV</div>`;
      if (w.studio) return `<div class="meta">${w.typ === 'gra' ? 'TeO Games Studio' : 'TeO App Studio'}: „${esc(w.studio)}" · ${esc(w.kamieni)} kamieni milowych · produkcja ${esc(w.produkcja)}</div>`;
      return w.plik ? `<div class="meta">plik: ${esc(String(w.plik).split(/[\\/]/).pop())}</div>` : '';
    };
    return `<div class="sekcja"><h3>🏭 Zlecenia dla modułów Katedry</h3>
      ${z.map((x) => `<div class="zlecenie ${esc(x.stan)}"><span class="krok ${esc(x.stan)}">${STAN[x.stan] || ''} ${MODUL[x.modul] || esc(x.modul)}</span> <b>${esc(x.imie)}</b>: ${bogaty(x.opis)}${wynik(x)}</div>`).join('') || '<p class="cisza">Nic jeszcze nie zlecono.</p>'}
      ${doPonowienia && lokalne() ? `<button class="guzik maly" id="z-zlec" type="button">${z.length ? 'Ponów, co nie wyszło' : 'Zleć moduły z wkładów'}</button>` : ''}
      <p class="meta" id="z-stan"></p></div>`;
  }

  $('projekty').addEventListener('click', pokazProjekty);
  $('zamknij').addEventListener('click', () => { otwartyProjekt = null; });

  // Projekt idzie naprzód → odśwież otwarty panel i klocki (nowy wkład = nowy klocek).
  let odswiezanie = 0;
  S.sluchaj((co, z) => {
    if (co !== 'szyna' || z?.rodzaj !== 'projekt') return;
    clearTimeout(odswiezanie);
    odswiezanie = setTimeout(() => {
      S.odswiez();
      if (document.body.dataset.panel === 'projekty') (otwartyProjekt ? pokazProjekt(otwartyProjekt) : pokazProjekty());
    }, 400);
  });

  // ── Film klockowy ──────────────────────────────────────────────────────────
  const tasma = $('tasma'), graj = $('tasma-graj'), postep = $('tasma-postep'), czas = $('tasma-czas'), dzien = $('tasma-dzien');
  let klatki = [], i = 0, zegar = 0, gra = false;

  async function wczytajFilm() {
    stop(); czas.textContent = 'Wczytuję dzień…';
    const d = await fetch(`/api/stado/film?dzien=${encodeURIComponent(dzien.value)}`, { headers: S.naglowki }).then((r) => r.json()).catch(() => null);
    const znani = new Set((S.dane?.gatunki ?? []).flatMap((g) => [g.imie.toLowerCase(), g.id]));
    klatki = (d?.zdarzenia ?? []).filter((z) => znani.has(String(z.agent).toLowerCase()));
    i = 0; postep.max = String(Math.max(0, klatki.length - 1)); postep.value = '0';
    czas.textContent = klatki.length ? `${klatki.length} scen` : 'Tego dnia stado milczało.';
  }
  function scena() {
    const z = klatki[i]; if (!z) return;
    S.pokazDymek(z);
    postep.value = String(i);
    czas.textContent = `${new Date(z.kiedy).toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' })} · ${i + 1}/${klatki.length}`;
  }
  function krok() {
    if (!gra) return;
    scena();
    const teraz = Date.parse(klatki[i]?.kiedy), dalej = Date.parse(klatki[i + 1]?.kiedy);
    i++;
    if (i >= klatki.length) { stop(); return; }
    // Czas dnia ściśnięty: przerwa między scenami ∝ realnej, ale 0,7–2,5 s — żeby film się oglądało.
    const przerwa = Math.min(2500, Math.max(700, (dalej - teraz) / 120));
    zegar = setTimeout(krok, Number.isFinite(przerwa) ? przerwa : 1200);
  }
  function stop() { gra = false; clearTimeout(zegar); graj.textContent = '▶'; graj.setAttribute('aria-label', 'Odtwarzaj'); }
  graj.addEventListener('click', () => {
    if (gra) return stop();
    if (!klatki.length) return;
    if (i >= klatki.length) i = 0;
    gra = true; graj.textContent = '⏸'; graj.setAttribute('aria-label', 'Pauza'); krok();
  });
  postep.addEventListener('input', () => { i = Number(postep.value); scena(); });
  dzien.addEventListener('change', wczytajFilm);
  $('film').addEventListener('click', () => {
    if (!tasma.hidden) { stop(); tasma.hidden = true; return; }
    dzien.value ||= new Date().toISOString().slice(0, 10);
    tasma.hidden = false; wczytajFilm();
  });
  $('tasma-zamknij').addEventListener('click', () => { stop(); tasma.hidden = true; });

  // ── Powitanie dnia ─────────────────────────────────────────────────────────
  // Film od stada (services/PowitanieDnia.js). Dzisiejszy pokazuje się sam RAZ na urządzeniu —
  // StoL startuje w tym świecie, więc telefon wita Suwerena filmem, potem są klocki.
  const TLO = { ujecie: 'ujęcie z ComfyUI', dzielo: 'kadr z własnego dzieła', kolor: 'własna barwa' };
  const WIDZIANE = 'swiat_powitanie_widziane';
  /** <video> nie doda nagłówka — klucz Straży i token telefonu jadą w adresie. */
  const zDostepem = (url) => {
    const u = S.zKluczem(url), t = S.naglowki['X-Stado-Token'];
    return t ? `${u}${u.includes('?') ? '&' : '?'}token=${encodeURIComponent(t)}` : u;
  };
  const pamietaj = (klucz, wartosc) => { try { if (wartosc === undefined) return localStorage.getItem(klucz); localStorage.setItem(klucz, wartosc); } catch { /* bez pamięci: pokaże się znowu */ } return null; };
  const pobierzPowitanie = () => fetch('/api/stado/powitanie', { headers: S.naglowki, ...zCzasem() })
    .then(async (r) => { try { return await r.json(); } catch { return { success: false, message: `most odpowiedział ${r.status} — czy Katedra po git pull została uruchomiona od nowa?` }; } })
    .catch((e) => ({ success: false, message: e.name === 'TimeoutError' ? 'most nie odpowiedział w 15 s' : e.message }));

  function dataLadnie(d) {
    try { return new Date(`${d}T12:00:00`).toLocaleDateString('pl-PL', { weekday: 'long', day: 'numeric', month: 'long' }); } catch { return d; }
  }

  async function pokazPowitanie({ sam = false } = {}) {
    if (!sam && document.body.dataset.panel !== 'powitanie') S.pokazPanel('<p class="cisza">🌅 Wczytuję powitanie dnia…</p>', 'powitanie');   // od razu widać, że klik zadziałał
    const d = await pobierzPowitanie();
    if (!d?.success) { if (!sam) S.pokazPanel(`<p class="cisza">Most nie oddał powitania${d?.message ? `: ${esc(d.message)}` : ''}${/[.?!]$/.test(d?.message ?? '') ? '' : '.'}</p>`, 'powitanie'); return; }
    const m = d.gotowe, dzis = d.dzisiejsze;
    stop();
    const stanDzis = d.trwa ? `◐ Stado pisze dzisiejsze powitanie — ${esc(d.trwa.etap)}.`
      : dzis?.stan === 'blad' ? `✕ Dzisiejsze nie wyszło: ${esc(dzis.blad)}`
        : dzis?.stan === 'przerwane' ? '◌ Dzisiejsze przerwał restart mostu.'
          : !dzis ? 'Dzisiejsze jeszcze nie powstało — stado nagrywa je raz dziennie, od rana.' : '';
    const k = S.pokazPanel(`
      <div class="glowa"><div class="forma">🌅</div><div><h2>Powitanie dnia</h2>
        <div class="meta">${m ? `${esc(dataLadnie(m.data))}${m.data !== d.dzis ? ' · ostatnie gotowe' : ''} · ${m.sceny.filter((x) => x.sentencja).length} sentencji${m.muzyka ? ` · muzyka „${esc(m.muzyka)}"` : ''}` : 'Jeszcze nie było powitania.'}</div></div></div>
      ${m ? `<video class="powitanie-film" src="${esc(zDostepem(m.film))}" controls playsinline preload="auto"></video>
        <p class="meta" id="pw-dzwiek" hidden><button class="guzik maly" type="button" id="pw-glos">🔊 Włącz dźwięk</button></p>
        <div class="sekcja"><h3>Sentencje</h3>${m.sceny.filter((x) => x.sentencja).map((x) => `
          <p class="sentencja"><b style="color:${/^#[0-9a-f]{3,8}$/i.test(x.kolor ?? '') ? x.kolor : 'var(--zloto)'}">${esc(x.imie)}</b> ${esc(x.sentencja)}
          <span class="meta">· ${esc(TLO[x.tlo] || x.tlo)} · ${esc(x.model || '')}</span></p>`).join('')}
          ${m.comfy ? `<p class="meta">ComfyUI tego ranka nie liczyło (${esc(m.comfy)}) — kadry z dzieł i barw.</p>` : ''}</div>` : ''}
      ${stanDzis || d.lokalne ? `<div class="sekcja">${stanDzis ? `<p class="meta">${stanDzis}</p>` : ''}
        ${d.lokalne && !d.trwa ? `<button class="guzik maly" id="pw-zrob" type="button">${dzis ? 'Nagraj dzisiejsze od nowa' : 'Nagraj dzisiejsze teraz'}</button><p class="meta" id="pw-stan"></p>` : ''}</div>` : ''}`, 'powitanie');
    if (m) pamietaj(WIDZIANE, m.data);
    const v = k.querySelector('video');
    if (v) {
      // Przeglądarka nie gra z dźwiękiem bez dotknięcia — wtedy po cichu i guzik „włącz dźwięk".
      v.play().catch(() => { v.muted = true; $('pw-dzwiek').hidden = false; v.play().catch(() => {}); });
      $('pw-glos')?.addEventListener('click', () => { v.muted = false; $('pw-dzwiek').hidden = true; v.play().catch(() => {}); });
    }
    $('pw-zrob')?.addEventListener('click', async (e) => {
      e.target.disabled = true;
      const w = await fetch('/api/stado/powitanie/zrob', json({ data: d.dzis })).then((r) => r.json()).catch((er) => ({ message: er.message }));
      $('pw-stan').textContent = w.success ? w.message : `Nie ruszyło: ${w.message}`;
    });
  }
  $('powitanie').addEventListener('click', () => pokazPowitanie());

  // Sam raz dziennie: dzisiejszy film, jeszcze niewidziany na tym urządzeniu, i nic innego nie jest otwarte.
  async function samoPowitanie() {
    if (document.body.dataset.panel || !$('katalog').hidden) return;
    const d = await pobierzPowitanie();
    if (d?.gotowe?.data === d?.dzis && pamietaj(WIDZIANE) !== d.dzis) pokazPowitanie({ sam: true });
  }
  let pierwszeDane = true;
  S.sluchaj((co, z) => {
    if (co === 'dane' && pierwszeDane) { pierwszeDane = false; samoPowitanie(); }
    if (co === 'szyna' && z?.rodzaj === 'powitanie') {
      if (document.body.dataset.panel === 'powitanie') setTimeout(() => pokazPowitanie(), 400);
      else samoPowitanie();
    }
  });
})();
