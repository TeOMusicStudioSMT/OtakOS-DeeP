/**
 * 🎙️ ImpresarioDashboard — Panel Agenta Medialnego
 *
 * Trzy sekcje:
 *   A. Kontrola Stacji API (Vault) — karty platform z togglem połączenia
 *   B. Nowe Zlecenie (Enqueue) — formularz publikacji
 *   C. Kolejka Wydawnicza (Live) — polling co 5s z paskami postępu
 *
 * Estetyka: Cyberpunk / Neon — Tailwind CSS + Framer Motion
 * Brak zewnętrznych paczek (styled-components, redux etc.)
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PolaczYouTube, PublikacjeYouTubePanel } from './YouTubeStudio';
import { GameShowPanel } from './GameShowPanel';
import { WieczorTancaPanel } from './WieczorTancaPanel';
import { FormatyPanel } from './FormatyPanel';
import { otworzApke } from '../../lib/pierscien';

// ─── Stałe ────────────────────────────────────────────────────────────────────

const BRIDGE_URL = 'http://127.0.0.1:3001';

const PLATFORM_META: Record<string, { label: string; icon: string; accent: string; glow: string }> = {
    youtube: {
        label:  'YouTube',
        icon:   '📺',
        accent: 'border-red-500/60',
        glow:   'rgba(239,68,68,0.15)',
    },
    spotify: {
        label:  'Spotify',
        icon:   '🎵',
        accent: 'border-green-500/60',
        glow:   'rgba(34,197,94,0.15)',
    },
    soundcloud: {
        label:  'SoundCloud',
        icon:   '🌊',
        accent: 'border-orange-500/60',
        glow:   'rgba(249,115,22,0.15)',
    },
};

const STATUS_META: Record<string, { label: string; color: string; bar: string }> = {
    PENDING:    { label: 'OCZEKUJE',     color: 'text-slate-400',  bar: 'bg-slate-600'  },
    PROCESSING: { label: 'W REALIZACJI', color: 'text-cyan-400',   bar: 'bg-cyan-500'   },
    COMPLETE:   { label: 'UKOŃCZONE',    color: 'text-green-400',  bar: 'bg-green-500'  },
    FAILED:     { label: 'BŁĄD',         color: 'text-red-400',    bar: 'bg-red-500'    },
};

// ─── Typy ─────────────────────────────────────────────────────────────────────

interface PlatformVault {
    connected:       boolean;
    last_updated:    string;
    gemini_auth?:    boolean;
    auth_method?:    string;
    auth_timestamp?: string;
    [key: string]: unknown;
}

interface VaultData {
    [platform: string]: PlatformVault;
}

interface QueueJob {
    id:               string;
    title:            string;
    album?:           string | null;
    status:           'PENDING' | 'PROCESSING' | 'COMPLETE' | 'FAILED';
    platforms:        string[];
    progress_percent: number;
    last_updated:     string;
    createdAt?:       string;
    filePath?:        string | null;
    error?:           string;
    // Pola wyników — wypełniane po zakończeniu
    note?:            string;   // "Wyeksportowano paczkę dla DistroKid!" itp.
    exportPath?:      string;   // Ścieżka do folderu paczki Spotify
    youtubeUrl?:      string;   // "https://youtu.be/..."
    youtubeVideoId?:  string;
}

// ─── ImpresarioDashboard ──────────────────────────────────────────────────────

const ImpresarioDashboard: React.FC = () => {

    // ── State ─────────────────────────────────────────────────────────────────
    const [vault,        setVault]        = useState<VaultData>({});
    const [queue,        setQueue]        = useState<QueueJob[]>([]);
    const [statusLoaded, setStatusLoaded] = useState(false);
    const [vaultUpdating, setVaultUpdating] = useState<string | null>(null);

    // Formularz nowego zlecenia
    const [formTitle,     setFormTitle]     = useState('');
    const [formAlbum,     setFormAlbum]     = useState('');
    const [formFilePath,  setFormFilePath]  = useState('');
    const [formPlatforms, setFormPlatforms] = useState<Set<string>>(new Set());
    const [submitting,    setSubmitting]    = useState(false);
    const [submitMsg,     setSubmitMsg]     = useState<{ ok: boolean; text: string } | null>(null);

    // Instrukcja Konfiguracji YouTube V0 — expandable panel
    const [ytGuideOpen,    setYtGuideOpen]    = useState(false);
    const [ytKeyForm,      setYtKeyForm]      = useState({ clientId: '', clientSecret: '' });
    const [ytKeySubmitting, setYtKeySubmitting] = useState(false);
    const [ytKeyMsg,       setYtKeyMsg]       = useState<{ ok: boolean; text: string } | null>(null);
    const [ytKluczePoz,    setYtKluczePoz]    = useState(0);   // odświeża kartę „Połącz z YouTube” po zapisie klienta


    const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

    // ── Fetch status ──────────────────────────────────────────────────────────
    const fetchStatus = useCallback(async () => {
        try {
            const res  = await fetch(`${BRIDGE_URL}/api/impresario/status`);
            if (!res.ok) return;
            const data = await res.json();
            if (data.success) {
                setVault(data.vault  ?? {});
                setQueue(data.queue  ?? []);
                setStatusLoaded(true);
            }
        } catch (_) { /* bridge offline */ }
    }, []);

    useEffect(() => {
        fetchStatus();
        pollRef.current = setInterval(fetchStatus, 5_000);
        return () => { if (pollRef.current) clearInterval(pollRef.current); };
    }, [fetchStatus]);

    // ── Toggle połączenia platformy ────────────────────────────────────────────
    const togglePlatform = useCallback(async (platform: string) => {
        if (vaultUpdating) return;
        const current   = vault[platform]?.connected ?? false;
        const newStatus = !current;

        setVaultUpdating(platform);
        try {
            await fetch(`${BRIDGE_URL}/api/impresario/vault/update`, {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify({ platform, isConnected: newStatus }),
            });
            setVault(prev => ({
                ...prev,
                [platform]: { ...(prev[platform] ?? {}), connected: newStatus, last_updated: new Date().toISOString() },
            }));
        } catch (_) { /* network error */ } finally {
            setVaultUpdating(null);
        }
    }, [vault, vaultUpdating]);

    // ── Checkbox platform w formularzu ────────────────────────────────────────
    const toggleFormPlatform = (p: string) => {
        setFormPlatforms(prev => {
            const s = new Set(prev);
            s.has(p) ? s.delete(p) : s.add(p);
            return s;
        });
    };

    // ── Zapis kluczy YouTube API ze skarbca ────────────────────────────────────
    const handleSaveYouTubeKeys = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        if (!ytKeyForm.clientId.trim() || !ytKeyForm.clientSecret.trim()) {
            setYtKeyMsg({ ok: false, text: 'Wklej CLIENT_ID i CLIENT_SECRET.' });
            return;
        }
        setYtKeySubmitting(true);
        setYtKeyMsg(null);
        try {
            const res  = await fetch(`${BRIDGE_URL}/api/impresario/youtube/klient`, {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify({ clientId: ytKeyForm.clientId.trim(), clientSecret: ytKeyForm.clientSecret.trim() }),
            });
            const data = await res.json();
            if (data.success) {
                setYtKeyMsg({ ok: true, text: 'Klient OAuth zapisany. Teraz „🔗 Połącz z YouTube” poniżej.' });
                setYtKeyForm({ clientId: '', clientSecret: '' });
                setYtKluczePoz((n) => n + 1);
                setTimeout(fetchStatus, 600);
            } else {
                setYtKeyMsg({ ok: false, text: data.message ?? 'Nieznany błąd.' });
            }
        } catch (err: any) {
            setYtKeyMsg({ ok: false, text: `Bridge offline: ${err.message}` });
        } finally {
            setYtKeySubmitting(false);
        }
    }, [ytKeyForm, fetchStatus]);

    const handleEnqueue = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formTitle.trim() || formPlatforms.size === 0) {
            setSubmitMsg({ ok: false, text: 'Wpisz tytuł i wybierz przynajmniej jedną platformę.' });
            return;
        }
        if (!formFilePath.trim()) {
            setSubmitMsg({ ok: false, text: '📁 Ścieżka do pliku jest wymagana (np. C:\\muzyka\\utwor.wav).' });
            return;
        }
        setSubmitting(true);
        setSubmitMsg(null);
        try {
            const res  = await fetch(`${BRIDGE_URL}/api/impresario/enqueue`, {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify({
                    title:     formTitle.trim(),
                    album:     formAlbum.trim() || null,
                    platforms: [...formPlatforms],
                    filePath:  formFilePath.trim(),
                }),
            });
            const data = await res.json();
            if (data.success) {
                setSubmitMsg({ ok: true, text: `✅ Zlecenie "${formTitle}" przyjęte do Katedry!` });
                setFormTitle('');
                setFormAlbum('');
                setFormFilePath('');
                setFormPlatforms(new Set());
                setTimeout(fetchStatus, 600);
            } else {
                setSubmitMsg({ ok: false, text: data.message ?? 'Nieznany błąd.' });
            }
        } catch (err: any) {
            setSubmitMsg({ ok: false, text: `Bridge offline: ${err.message}` });
        } finally {
            setSubmitting(false);
        }
    };

    // ─────────────────────────────────────────────────────────────────────────
    return (
        <div
            className="flex flex-col w-full text-[#E6F7FF] overflow-y-auto"
            style={{ backgroundColor: 'rgba(3, 4, 14, 0.97)', minHeight: '420px' }}
        >
            {/* ══ Nagłówek ══ */}
            <div className="flex items-center justify-between px-5 pt-4 pb-3"
                 style={{ borderBottom: '1px solid rgba(0,229,255,0.1)' }}
            >
                <div>
                    <span className="text-[10px] font-mono text-cyan-600 uppercase tracking-[0.3em]">
                        🎙️ Impresario — Agent Medialny Katedry
                    </span>
                    <p className="text-[8px] text-slate-600 mt-0.5 font-mono">
                        Publikacje · YouTube (prawdziwa wysyłka) · Spotify (paczka DistroKid) · SoundCloud (niepodłączony)
                    </p>
                </div>
                {!statusLoaded && (
                    <motion.span
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ repeat: Infinity, duration: 1.2 }}
                        className="text-[9px] font-mono text-cyan-700"
                    >
                        ⏳ Łączę z Agencją…
                    </motion.span>
                )}
            </div>

            <div className="flex flex-col gap-0 p-4">

                {/* ══ SEKCJA A: Vault — Karty Platform ══ */}
                <section className="mb-5">
                    <h2 className="text-[10px] font-mono text-cyan-500 uppercase tracking-widest mb-3">
                        A. Kontrola Stacji API
                    </h2>

                    <div className="grid grid-cols-3 gap-3">
                        {Object.entries(PLATFORM_META).map(([key, meta]) => {
                            const isConn    = vault[key]?.connected ?? false;
                            const isUpdating = vaultUpdating === key;

                            return (
                                <motion.div
                                    key={key}
                                    whileHover={{ scale: 1.02 }}
                                    className={`relative p-4 rounded-lg border ${meta.accent} transition-all duration-300`}
                                    style={{
                                        background:   `rgba(5, 5, 20, 0.9)`,
                                        boxShadow:    isConn ? `0 0 16px ${meta.glow}` : '0 0 6px rgba(0,0,0,0.4)',
                                    }}
                                >
                                    {/* Status dot */}
                                    <div className="flex items-center gap-2 mb-3">
                                        <motion.div
                                            animate={isConn ? { scale: [1, 1.3, 1], opacity: [1, 0.6, 1] } : {}}
                                            transition={{ repeat: Infinity, duration: 2 }}
                                            className={`w-2.5 h-2.5 rounded-full shrink-0 ${isConn ? 'bg-green-400' : 'bg-red-600'}`}
                                        />
                                        <span className="text-[9px] font-mono font-bold tracking-widest">
                                            {meta.icon} {meta.label}
                                        </span>
                                    </div>

                                    <p className={`text-[9px] font-mono mb-3 uppercase tracking-widest ${isConn ? 'text-green-500' : 'text-red-500'}`}>
                                        {isConn ? '● POŁĄCZONO' : '○ ODŁĄCZONO'}
                                    </p>

                                    <p className="text-[8px] text-slate-600 font-mono mb-3">
                                        {vault[key]?.last_updated
                                            ? new Date(vault[key].last_updated).toLocaleTimeString('pl-PL')
                                            : '—'}
                                    </p>

                                    <button
                                        onClick={() => togglePlatform(key)}
                                        disabled={!!vaultUpdating}
                                        className={`w-full py-1.5 text-[9px] font-mono uppercase tracking-widest rounded transition-all duration-200
                                            ${isConn
                                                ? 'bg-red-900/60 hover:bg-red-800 border border-red-600/50 text-red-300'
                                                : 'bg-green-900/60 hover:bg-green-800 border border-green-600/50 text-green-300'
                                            }
                                            ${vaultUpdating ? 'opacity-50 cursor-not-allowed' : ''}
                                        `}
                                    >
                                        {isUpdating ? '...' : isConn ? '⏏ Odłącz' : '⚡ Połącz'}
                                    </button>
                                </motion.div>
                            );
                        })}
                    </div>

                    {/* ══ Instrukcja Konfiguracji YouTube V0 ══ */}
                    {!(vault['youtube']?.connected) && (
                        <div className="mt-4">
                            <button
                                onClick={() => setYtGuideOpen(prev => !prev)}
                                className="flex items-center gap-2 group"
                            >
                                <motion.span
                                    animate={{ rotate: ytGuideOpen ? 90 : 0 }}
                                    transition={{ duration: 0.2 }}
                                    className="text-[9px] text-cyan-700 group-hover:text-cyan-500"
                                >▶</motion.span>
                                <span className="text-[9px] font-mono text-cyan-700 group-hover:text-cyan-400 uppercase tracking-widest transition-colors">
                                    📘 Instrukcja Konfiguracji Wersji Zero
                                </span>
                            </button>

                            <AnimatePresence>
                                {ytGuideOpen && (
                                    <motion.div
                                        initial={{ opacity: 0, height: 0 }}
                                        animate={{ opacity: 1, height: 'auto' }}
                                        exit={{ opacity: 0, height: 0 }}
                                        transition={{ duration: 0.3, ease: 'easeInOut' }}
                                        className="overflow-hidden"
                                    >
                                        <div
                                            className="mt-3 rounded-lg p-4"
                                            style={{
                                                background: 'rgba(0,30,60,0.7)',
                                                border:     '1px solid rgba(0,229,255,0.15)',
                                                boxShadow:  '0 0 20px rgba(0,100,200,0.08)',
                                            }}
                                        >
                                            <p className="text-[9px] font-mono text-cyan-500 uppercase tracking-widest mb-3">
                                                🎙️ Konfiguracja YouTube API — Wersja Zero
                                            </p>

                                            {/* Kroki konfiguracji */}
                                            <ol className="space-y-2 mb-4">
                                                {[
                                                    {
                                                        n: '01',
                                                        title: 'Google Cloud Console',
                                                        desc:  'Wejdź na console.cloud.google.com → Utwórz nowy projekt (np. "Katedra OtakOS").',
                                                        link:  'https://console.cloud.google.com',
                                                        linkLabel: '↗ Otwórz Console',
                                                    },
                                                    {
                                                        n: '02',
                                                        title: 'Włącz YouTube Data API v3',
                                                        desc:  'Biblioteka APIs & Services → Wyszukaj "YouTube Data API v3" → Włącz.',
                                                        link:  'https://console.cloud.google.com/apis/library/youtube.googleapis.com',
                                                        linkLabel: '↗ Włącz API',
                                                    },
                                                    {
                                                        n: '03',
                                                        title: 'Utwórz OAuth 2.0 Client ID',
                                                        desc:  'Credentials → Create Credentials → OAuth 2.0 Client ID → Typ: Desktop App. Skopiuj CLIENT_ID i CLIENT_SECRET.',
                                                        link:  'https://console.cloud.google.com/apis/credentials',
                                                        linkLabel: '↗ Credentials',
                                                    },
                                                    {
                                                        n: '04',
                                                        title: 'Ekran zgody OAuth → „W produkcji”',
                                                        desc:  'OAuth consent screen: typ Zewnętrzny, dodaj swój e-mail, potem „Opublikuj aplikację” (W produkcji). W „Testowaniu” token YouTube wygasa po 7 dniach. Google pokaże ostrzeżenie „niezweryfikowana aplikacja” — dla własnego kanału kliknij „Zaawansowane → Przejdź”.',
                                                        link:  'https://console.cloud.google.com/apis/credentials/consent',
                                                        linkLabel: '↗ Ekran zgody',
                                                    },
                                                    {
                                                        n: '05',
                                                        title: 'Wklej klienta i kliknij „Połącz z YouTube”',
                                                        desc:  'CLIENT_ID i CLIENT_SECRET do formularza niżej → „Połącz z YouTube” → zgoda Google w okienku → Katedra sama zapisze token. Bez OAuth Playground i kopiowania tokenów.',
                                                        link:  'https://myaccount.google.com/permissions',
                                                        linkLabel: '↗ Twoje zgody Google (tu cofniesz dostęp)',
                                                    },
                                                ].map(step => (
                                                    <li
                                                        key={step.n}
                                                        className="flex gap-3 items-start"
                                                    >
                                                        <span
                                                            className="shrink-0 w-6 h-6 rounded-sm flex items-center justify-center text-[8px] font-mono font-bold text-cyan-400"
                                                            style={{ background: 'rgba(0,229,255,0.08)', border: '1px solid rgba(0,229,255,0.2)' }}
                                                        >
                                                            {step.n}
                                                        </span>
                                                        <div className="min-w-0">
                                                            <p className="text-[9px] font-mono text-white/80 font-bold mb-0.5">{step.title}</p>
                                                            <p className="text-[8px] font-mono text-slate-500 leading-relaxed">{step.desc}</p>
                                                            <a
                                                                href={step.link}
                                                                target="_blank"
                                                                rel="noreferrer"
                                                                className="text-[8px] font-mono text-cyan-600 hover:text-cyan-400 transition-colors"
                                                            >
                                                                {step.linkLabel}
                                                            </a>
                                                        </div>
                                                    </li>
                                                ))}
                                            </ol>

                                            {/* Mini-formularz kluczy */}
                                            <div
                                                className="rounded-lg p-3 mt-2"
                                                style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(0,229,255,0.1)' }}
                                            >
                                                <p className="text-[9px] font-mono text-cyan-600 uppercase tracking-widest mb-2">
                                                    ⚡ Klient OAuth (typ: Aplikacja komputerowa)
                                                </p>
                                                <form onSubmit={handleSaveYouTubeKeys} className="space-y-2">
                                                    {[
                                                        { key: 'clientId',     label: 'CLIENT_ID',     placeholder: '123456789-abc.apps.googleusercontent.com' },
                                                        { key: 'clientSecret', label: 'CLIENT_SECRET', placeholder: 'GOCSPX-...' },
                                                    ].map(field => (
                                                        <div key={field.key}>
                                                            <label className="text-[8px] font-mono text-slate-600 block mb-0.5 uppercase tracking-widest">
                                                                {field.label}
                                                            </label>
                                                            <input
                                                                type="text"
                                                                value={ytKeyForm[field.key as keyof typeof ytKeyForm]}
                                                                onChange={e => setYtKeyForm(prev => ({ ...prev, [field.key]: e.target.value }))}
                                                                placeholder={field.placeholder}
                                                                spellCheck={false}
                                                                className="w-full bg-black/60 border border-slate-800 focus:border-cyan-600/60 text-white text-[10px] font-mono rounded-sm px-2.5 py-1.5 outline-hidden transition-colors placeholder-slate-700"
                                                            />
                                                        </div>
                                                    ))}

                                                    <motion.button
                                                        type="submit"
                                                        disabled={ytKeySubmitting}
                                                        whileHover={{ scale: ytKeySubmitting ? 1 : 1.01 }}
                                                        whileTap={{ scale: 0.98 }}
                                                        className={`w-full py-1.5 text-[9px] font-mono uppercase tracking-widest rounded transition-all
                                                            ${ytKeySubmitting
                                                                ? 'bg-slate-900 border border-slate-700 text-slate-600 cursor-not-allowed'
                                                                : 'bg-cyan-900/40 hover:bg-cyan-800/50 border border-cyan-700/50 text-cyan-400'
                                                            }`}
                                                    >
                                                        {ytKeySubmitting ? '⏳ Zapisuję...' : '💾 ZAPISZ KLIENTA OAUTH'}
                                                    </motion.button>

                                                    <AnimatePresence>
                                                        {ytKeyMsg && (
                                                            <motion.p
                                                                initial={{ opacity: 0, y: -3 }}
                                                                animate={{ opacity: 1, y: 0 }}
                                                                exit={{ opacity: 0 }}
                                                                className={`text-[8px] font-mono rounded-sm px-2 py-1 ${ytKeyMsg.ok ? 'text-green-400 bg-green-900/20' : 'text-orange-400 bg-orange-900/20'}`}
                                                            >
                                                                {ytKeyMsg.text}
                                                            </motion.p>
                                                        )}
                                                    </AnimatePresence>
                                                </form>
                                            </div>
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    )}

                    {/* ══ 📺 Połącz z YouTube (prawdziwy OAuth) + publikacje stada do ✓ ══ */}
                    <div className="mt-4 flex flex-col gap-3">
                        <PolaczYouTube key={ytKluczePoz} onZmiana={fetchStatus} />
                        <PublikacjeYouTubePanel />
                        <GameShowPanel />
                        <WieczorTancaPanel />
                        <FormatyPanel />
                        {/* ⚽ Gol Dnia przeniesiony do Studia Zebrra Football jako zakładka (Suweren 2026-10-15) */}
                        <button onClick={() => otworzApke({ id: 'studio-zebrra', tytul: 'Studio Zebrra Sports', url: 'http://127.0.0.1:3001/apki/studio-zebrra/?zakladka=gol-dnia', znak: '🦓', kolor: '#22c55e' })}
                            className="rounded-2xl border border-emerald-500/30 bg-emerald-950/10 p-3 text-left text-xs text-emerald-100 hover:bg-emerald-900/20">
                            <b className="text-sm">🦓 Otwórz Studio Zebrra Sports — ⚽ Gol Dnia · 🩰 Taniec</b>
                            <span className="block text-[11px] text-slate-400">Mecze i fakty bramek albo występy z Tanecznego Starcia (ocena mostu, klip na ekranie LED), prowadzący i do trzech współprowadzących, głosy, nagranie — zakładki „⚽ Gol Dnia” i „🩰 Taniec”.</span>
                        </button>
                        {/* 🦎 Mame Leon Show — nocny talk-show (services/MameLeonShow.js, strona mame-leon.html apki Studia) */}
                        <button onClick={() => otworzApke({ id: 'mame-leon', tytul: 'Mame Leon Show', url: 'http://127.0.0.1:3001/apki/studio-zebrra/mame-leon.html', znak: '🦎', kolor: '#e879f9' })}
                            className="rounded-2xl border border-fuchsia-500/30 bg-fuchsia-950/10 p-3 text-left text-xs text-fuchsia-100 hover:bg-fuchsia-900/20">
                            <b className="text-sm">🦎 Otwórz Mame Leon Show</b>
                            <span className="block text-[11px] text-slate-400">Talk-show: temat, do trzech gości na kanapie (TeOgochi ze stada albo bryły z Assetów 3D), rozmowa z faktów, głosy Stada, nagranie → Kronikarz → ✓ w Izbie.</span>
                        </button>
                        {/* 📰 Zebrra News — dzienny serwis z publicznych nagłówków (services/ZebrraNews.js, strona news.html apki Studia) */}
                        <button onClick={() => otworzApke({ id: 'zebrra-news', tytul: 'Zebrra News', url: 'http://127.0.0.1:3001/apki/studio-zebrra/news.html', znak: '📰', kolor: '#67e8f9' })}
                            className="rounded-2xl border border-cyan-500/30 bg-cyan-950/10 p-3 text-left text-xs text-cyan-100 hover:bg-cyan-900/20">
                            <b className="text-sm">📰 Otwórz Zebrra News</b>
                            <span className="block text-[11px] text-slate-400">Dzienny serwis z publicznych RSS świata: 5–8 tematów, własne streszczenia ze źródłem, ilustracje symboliczne (AI), Gol Donna i Zlat w newsroomie, automat dnia (domyślnie wył.) → ✓ w Izbie.</span>
                        </button>
                    </div>
                </section>

                {/* ══ Dolny rząd: B + C ══ */}
                <div className="grid grid-cols-2 gap-4">

                    {/* ══ SEKCJA B: Formularz Nowego Zlecenia ══ */}
                    <section>
                        <h2 className="text-[10px] font-mono text-cyan-500 uppercase tracking-widest mb-3">
                            B. Nowe Zlecenie Wydawnicze
                        </h2>

                        <form
                            onSubmit={handleEnqueue}
                            className="rounded-lg p-4 space-y-3"
                            style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(0,229,255,0.08)' }}
                        >
                            {/* Tytuł */}
                            <div>
                                <label className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block mb-1">
                                    Tytuł Utworu *
                                </label>
                                <input
                                    type="text"
                                    value={formTitle}
                                    onChange={e => setFormTitle(e.target.value)}
                                    placeholder="np. Echoes of the Void"
                                    className="w-full bg-black/60 border border-slate-700 focus:border-cyan-500 text-white text-xs font-mono rounded-sm px-3 py-2 outline-hidden transition-colors placeholder-slate-600"
                                    required
                                />
                            </div>

                            {/* Album */}
                            <div>
                                <label className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block mb-1">
                                    Album (opcjonalnie)
                                </label>
                                <input
                                    type="text"
                                    value={formAlbum}
                                    onChange={e => setFormAlbum(e.target.value)}
                                    placeholder="np. Cycles"
                                    className="w-full bg-black/60 border border-slate-700 focus:border-cyan-500 text-white text-xs font-mono rounded-sm px-3 py-2 outline-hidden transition-colors placeholder-slate-600"
                                />
                            </div>

                            {/* Ścieżka do pliku */}
                            <div>
                                <label className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block mb-1">
                                    📁 Ścieżka do pliku na dysku (filePath) *
                                </label>
                                <input
                                    type="text"
                                    value={formFilePath}
                                    onChange={e => setFormFilePath(e.target.value)}
                                    placeholder="np. C:\muzyka\moj_utwór.wav lub /home/teo/tracks/song.mp4"
                                    className="w-full bg-black/60 border border-slate-700 focus:border-yellow-500/70 text-white text-xs font-mono rounded-sm px-3 py-2 outline-hidden transition-colors placeholder-slate-600"
                                    required
                                    spellCheck={false}
                                />
                                <p className="text-[8px] font-mono text-slate-600 mt-1">
                                    Akceptowane: .mp4 .mov .wav .mp3 .flac .m4a .webm
                                </p>
                            </div>

                            {/* Platformy */}
                            <div>
                                <label className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block mb-2">
                                    Platformy Docelowe *
                                </label>
                                <div className="flex flex-wrap gap-2">
                                    {Object.entries(PLATFORM_META).map(([key, meta]) => (
                                        <label
                                            key={key}
                                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded cursor-pointer text-[9px] font-mono uppercase tracking-widest transition-all duration-200 border
                                                ${formPlatforms.has(key)
                                                    ? `${meta.accent} text-white bg-white/5`
                                                    : 'border-slate-700 text-slate-500 hover:border-slate-500'
                                                }`}
                                        >
                                            <input
                                                type="checkbox"
                                                className="sr-only"
                                                checked={formPlatforms.has(key)}
                                                onChange={() => toggleFormPlatform(key)}
                                            />
                                            {meta.icon} {meta.label}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Submit */}
                            <motion.button
                                type="submit"
                                disabled={submitting}
                                whileHover={{ scale: submitting ? 1 : 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                className={`w-full py-2.5 text-[10px] font-mono uppercase tracking-widest rounded transition-all duration-200 border
                                    ${submitting
                                        ? 'bg-cyan-900/30 border-cyan-700/30 text-cyan-700 cursor-not-allowed'
                                        : 'bg-cyan-900/50 hover:bg-cyan-800/60 border-cyan-600/50 text-cyan-300'
                                    }`}
                                style={{ boxShadow: submitting ? 'none' : '0 0 12px rgba(0,229,255,0.15)' }}
                            >
                                {submitting ? '⏳ Wysyłam...' : '🚀 ZLEĆ PUBLIKACJĘ W KATEDRZE'}
                            </motion.button>

                            {/* Feedback */}
                            <AnimatePresence>
                                {submitMsg && (
                                    <motion.p
                                        initial={{ opacity: 0, y: -4 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0 }}
                                        className={`text-[9px] font-mono rounded-sm px-2 py-1 ${submitMsg.ok ? 'text-green-400 bg-green-900/20' : 'text-orange-400 bg-orange-900/20'}`}
                                    >
                                        {submitMsg.text}
                                    </motion.p>
                                )}
                            </AnimatePresence>
                        </form>
                    </section>

                    {/* ══ SEKCJA C: Kolejka Live ══ */}
                    <section>
                        <div className="flex items-center justify-between mb-3">
                            <h2 className="text-[10px] font-mono text-cyan-500 uppercase tracking-widest">
                                C. Kolejka Wydawnicza
                            </h2>
                            <span className="text-[8px] font-mono text-slate-600">
                                {queue.length} zadań · poll 5s
                            </span>
                        </div>

                        <div
                            className="rounded-lg overflow-hidden"
                            style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(0,229,255,0.08)', minHeight: '180px' }}
                        >
                            {!statusLoaded ? (
                                <div className="flex items-center justify-center h-full py-10">
                                    <motion.div
                                        animate={{ rotate: 360 }}
                                        transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
                                        className="w-5 h-5 rounded-full border-2 border-cyan-700 border-t-transparent"
                                    />
                                </div>
                            ) : queue.length === 0 ? (
                                <div className="flex flex-col items-center justify-center py-10 gap-2">
                                    <span className="text-3xl opacity-20">🎙️</span>
                                    <p className="text-[9px] font-mono text-slate-600 text-center">
                                        Kolejka pusta.<br />
                                        <span className="text-slate-700">Zleć nową publikację w sekcji B.</span>
                                    </p>
                                </div>
                            ) : (
                                <div className="overflow-y-auto max-h-[320px] p-3 space-y-3">
                                    <AnimatePresence>
                                        {queue.map(job => {
                                            const meta = STATUS_META[job.status] ?? STATUS_META['PENDING'];
                                            return (
                                                <motion.div
                                                    key={job.id}
                                                    layout
                                                    initial={{ opacity: 0, x: 10 }}
                                                    animate={{ opacity: 1,  x:  0 }}
                                                    exit={{ opacity: 0, x: -10 }}
                                                    transition={{ duration: 0.22 }}
                                                    className="rounded-lg p-3"
                                                    style={{
                                                        background: 'rgba(5,5,20,0.8)',
                                                        border:     job.status === 'PROCESSING'
                                                            ? '1px solid rgba(0,229,255,0.25)'
                                                            : job.status === 'COMPLETE'
                                                            ? '1px solid rgba(34,197,94,0.2)'
                                                            : job.status === 'FAILED'
                                                            ? '1px solid rgba(239,68,68,0.2)'
                                                            : '1px solid rgba(100,100,100,0.2)',
                                                    }}
                                                >
                                                    {/* Nagłówek joba */}
                                                    <div className="flex items-start justify-between gap-2 mb-2">
                                                        <div className="min-w-0">
                                                            <p className="text-xs font-mono text-cyan-300 truncate font-bold">
                                                                {job.title}
                                                            </p>
                                                            {job.album && (
                                                                <p className="text-[8px] text-slate-500 font-mono">
                                                                    {job.album}
                                                                </p>
                                                            )}
                                                        </div>
                                                        <span className={`shrink-0 text-[8px] font-mono font-bold uppercase tracking-widest ${meta.color}`}>
                                                            {meta.label}
                                                        </span>
                                                    </div>

                                                    {/* Platformy */}
                                                    <div className="flex flex-wrap gap-1 mb-2">
                                                        {job.platforms.map(p => (
                                                            <span
                                                                key={p}
                                                                className="text-[7px] font-mono px-1.5 py-0.5 rounded-sm"
                                                                style={{ background: 'rgba(0,229,255,0.06)', border: '1px solid rgba(0,229,255,0.15)' }}
                                                            >
                                                                {PLATFORM_META[p]?.icon} {p}
                                                            </span>
                                                        ))}
                                                    </div>

                                                    {/* Pasek postępu */}
                                                    <div className="h-1.5 rounded-full overflow-hidden bg-slate-900">
                                                        <motion.div
                                                            className={`h-full rounded-full ${meta.bar}`}
                                                            initial={{ width: 0 }}
                                                            animate={{ width: `${job.progress_percent}%` }}
                                                            transition={{ duration: 0.6, ease: 'easeOut' }}
                                                        />
                                                    </div>
                                                    <div className="flex items-center justify-between mt-1">
                                                        <span className="text-[7px] font-mono text-slate-600">
                                                            {job.progress_percent}%
                                                        </span>
                                                        {job.status === 'PROCESSING' && (
                                                            <motion.span
                                                                animate={{ opacity: [0.4, 1, 0.4] }}
                                                                transition={{ repeat: Infinity, duration: 0.9 }}
                                                                className="text-[7px] font-mono text-cyan-600"
                                                            >
                                                                ⚙️ PUBLISHING...
                                                            </motion.span>
                                                        )}
                                                        {job.status === 'COMPLETE' && (
                                                            <span className="text-[7px] font-mono text-green-600">
                                                                ✓ DONE
                                                            </span>
                                                        )}
                                                        {job.status === 'FAILED' && (
                                                            <span className="text-[7px] font-mono text-red-500">
                                                                ✗ FAILED
                                                            </span>
                                                        )}
                                                    </div>

                                                    {/* Log błędu */}
                                                    {job.error && (
                                                        <div
                                                            className="mt-2 rounded-sm px-2 py-1.5"
                                                            style={{ background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.2)' }}
                                                        >
                                                            <p className="text-[8px] font-mono text-red-400 leading-relaxed break-all">
                                                                ✗ {job.error}
                                                            </p>
                                                        </div>
                                                    )}

                                                    {/* Log sukcesu / wyniki */}
                                                    {job.status === 'COMPLETE' && (job.note || job.exportPath || job.youtubeUrl) && (
                                                        <div
                                                            className="mt-2 rounded-sm px-2 py-1.5 space-y-0.5"
                                                            style={{ background: 'rgba(34,197,94,0.06)', border: '1px solid rgba(34,197,94,0.18)' }}
                                                        >
                                                            {job.note && (
                                                                <p className="text-[8px] font-mono text-green-400 leading-relaxed">
                                                                    ✓ {job.note}
                                                                </p>
                                                            )}
                                                            {job.exportPath && (
                                                                <p
                                                                    className="text-[7px] font-mono text-yellow-400/70 truncate leading-relaxed"
                                                                    title={job.exportPath}
                                                                >
                                                                    📁 {job.exportPath}
                                                                </p>
                                                            )}
                                                            {job.youtubeUrl && (
                                                                <a
                                                                    href={job.youtubeUrl}
                                                                    target="_blank"
                                                                    rel="noreferrer"
                                                                    className="text-[7px] font-mono text-red-400/80 hover:text-red-300 block truncate leading-relaxed transition-colors"
                                                                    title={job.youtubeUrl}
                                                                >
                                                                    ▶ {job.youtubeUrl}
                                                                </a>
                                                            )}
                                                        </div>
                                                    )}
                                                </motion.div>
                                            );
                                        })}
                                    </AnimatePresence>
                                </div>
                            )}
                        </div>
                    </section>
                </div>
            </div>
        </div>
    );
};

export default ImpresarioDashboard;
