/**
 * 🌌 ProjectsView — Universa: mapa Katedry, wrota, rejestr modułów, wyprawy.
 *
 * ⚠️ CO TU BYŁO MAKIETĄ DO 2026-08-15 (i zostało zastąpione czymś działającym):
 *  · Kafle wrót były ZABLOKOWANE progiem `wallet.tier`, którego w praktyce nikt
 *    nie ustawiał — więc trzy z czterech świeciły kłódką na zawsze.
 *  · Kafel „TeO Music Studio" prowadził na `teostomusic.studio` — domenę,
 *    która NIE ISTNIEJE (zmierzone: ENOTFOUND). Poprawna to `teomusic.studio`.
 *  · Wyprawy miały liczniki wpisane na sztywno (1 875 000 / 5 000 000 GRV),
 *    zdjęcia ze stocka i przycisk „Contribute GRAV" BEZ obsługi kliknięcia.
 *  · Subskrypcje działały na lokalnej liście, bez związku z księgą GRV.
 *
 * Teraz wszystko idzie przez rejestr w moście i księgę GRV z pieczęcią łańcucha.
 */
import React, { useState, useEffect, useCallback } from 'react';
import DashboardCard from './DashboardCard';
import { AppIcon } from './icons';
import toast from 'react-hot-toast';
import { NetworkOfLoci } from './NetworkOfLoci';
import { UniverseCard } from './dashboard/UniverseCard';
import { WarpTransition } from './effects/WarpTransition';
import { FiMusic, FiPackage, FiShield, FiFeather, FiCpu, FiScissors } from 'react-icons/fi';
import { STUDIA, otworzNaMoscie, type IdStudia } from '../lib/wrota';
import { getBridgeBase } from '../lib/bridgeService';
import {
    pobierzModuly, dodajModul, usunModul, subskrybuj, anuluj,
    pobierzWyprawy, dodajWyprawe, wplac, saldoWezla, mojWezel,
    type Modul, type Wyprawa,
} from '../lib/universa';

export const ProjectsView: React.FC = () => {
    const [moduly, setModuly] = useState<Modul[]>([]);
    const [wyprawy, setWyprawy] = useState<Wyprawa[]>([]);
    const [grv, setGrv] = useState<number | 'INFINITE' | null>(null);
    const [blad, setBlad] = useState('');
    const [zajety, setZajety] = useState(false);

    const [pokazFormModulu, setPokazFormModulu] = useState(false);
    const [nowyModul, setNowyModul] = useState({ nazwa: '', opis: '', url: '', ikona: '🧩', cenaGRV: 0, kategoria: 'narzedzie' as Modul['kategoria'] });

    const [pokazFormWyprawy, setPokazFormWyprawy] = useState(false);
    const [nowaWyprawa, setNowaWyprawa] = useState({ nazwa: '', opis: '', ikona: '🚀', celGRV: 10000 });

    const [isWarping, setIsWarping] = useState(false);

    const odswiez = useCallback(async () => {
        try {
            setBlad('');
            const [m, w, s] = await Promise.all([
                pobierzModuly(mojWezel()),
                pobierzWyprawy(),
                saldoWezla(mojWezel()).catch(() => null),
            ]);
            setModuly(m.moduly); setWyprawy(w); setGrv(s?.grv ?? null);
        } catch (e) { setBlad(e instanceof Error ? e.message : String(e)); }
    }, []);

    useEffect(() => { void odswiez(); }, [odswiez]);

    /**
     * 🚪 Teleport do substrony serwowanej przez WŁASNY Most.
     *
     * ⚠️ DLACZEGO NIE ZEWNĘTRZNE DOMENY: kafle prowadziły na `teostory.studio`,
     * `teoapp.studio` i — co gorsza — `teostomusic.studio`, która NIE ISTNIEJE.
     * Tymczasem Most serwuje te same aplikacje lokalnie pod `/apps/{story,music,app}`
     * i robi to Z DOWOLNEJ LITERY DYSKU: adres liczy się z `getBridgeBase()`,
     * więc na pendrivie I: działa tak samo jak na F:, bez jednej linijki zmiany.
     * To jest ten wzorzec, o którym Suweren napisał „perfekt".
     *
     * KLUCZE: substrony to inny origin niż Hub, więc nie widzą jego localStorage.
     * Klucz Gemini dokładamy w adresie — Story V2 czyta go przy starcie
     * (`teo_gemini_key`) i zapisuje u siebie. Bez tego LaB i Rada w substronie
     * milczą, a Suweren nie wie dlaczego.
     */
    /**
     * Wrota otwierają studio w NOWEJ KARCIE (Suweren: „ustaw tym z Universe,
     * by się otwierały w nowym oknie"). Warp zostaje jako mrugnięcie, ale musi
     * ZGASNĄĆ — poprzednia wersja nawigowała w miejscu, więc nigdy nie musiała
     * go wyłączać; teraz Hub zostaje na ekranie.
     */
    const wejdz = (s: (typeof STUDIA)[number]) => {
        setIsWarping(true);
        setTimeout(() => { otworzNaMoscie(s); setIsWarping(false); }, 600);
    };

    const IKONA: Record<IdStudia, React.ReactNode> = {
        story: <FiFeather className="w-8 h-8" />, music: <FiMusic className="w-8 h-8" />,
        app: <FiPackage className="w-8 h-8" />, games: <FiCpu className="w-8 h-8" />,
        fashion: <FiScissors className="w-8 h-8" />, lab: <FiShield className="w-8 h-8" />,
    };

    const zmienSubskrypcje = async (m: Modul) => {
        setZajety(true);
        try {
            if (m.subskrybowany) {
                const r = await anuluj(m.id, mojWezel());
                toast(r.uwaga, { icon: 'ℹ️', duration: 6000 });
            } else {
                const r = await subskrybuj(m.id, mojWezel());
                toast.success(r.zaplacono > 0 ? `Zapłacono ${r.zaplacono} GRV za „${m.nazwa}".` : `„${m.nazwa}" włączony (bez opłat).`);
            }
            await odswiez();
        } catch (e) { toast.error(e instanceof Error ? e.message : String(e)); }
        finally { setZajety(false); }
    };

    const wyslijModul = async () => {
        setZajety(true);
        try {
            await dodajModul({ ...nowyModul, autor: mojWezel() });
            setNowyModul({ nazwa: '', opis: '', url: '', ikona: '🧩', cenaGRV: 0, kategoria: 'narzedzie' });
            setPokazFormModulu(false);
            toast.success('Moduł w rejestrze.');
            await odswiez();
        } catch (e) { toast.error(e instanceof Error ? e.message : String(e)); }
        finally { setZajety(false); }
    };

    const wyslijWyprawe = async () => {
        setZajety(true);
        try {
            await dodajWyprawe({ ...nowaWyprawa, autor: mojWezel() });
            setNowaWyprawa({ nazwa: '', opis: '', ikona: '🚀', celGRV: 10000 });
            setPokazFormWyprawy(false);
            toast.success('Wyprawa otwarta. Licznik startuje od zera.');
            await odswiez();
        } catch (e) { toast.error(e instanceof Error ? e.message : String(e)); }
        finally { setZajety(false); }
    };

    const wesprzyj = async (w: Wyprawa) => {
        const wpis = window.prompt(`Ile GRV wpłacasz na „${w.nazwa}"?\nMasz: ${grv === 'INFINITE' ? '∞' : grv} GRV`, '500');
        if (!wpis) return;
        const kwota = Math.floor(Number(wpis));
        if (!(kwota > 0)) { toast.error('Kwota musi być większa od zera.'); return; }
        setZajety(true);
        try {
            const r = await wplac(w.id, mojWezel(), kwota);
            toast.success(`Wpłacono ${kwota} GRV. Zebrane: ${r.wyprawa.zebraneGRV.toLocaleString('pl-PL')} / ${w.celGRV.toLocaleString('pl-PL')}.`);
            await odswiez();
        } catch (e) { toast.error(e instanceof Error ? e.message : String(e)); }
        finally { setZajety(false); }
    };

    const pole = 'w-full bg-black/40 border border-slate-600 rounded px-2 py-1.5 text-sm text-slate-200 outline-none focus:border-cyan-500';

    return (
        <div className="space-y-8">
            <WarpTransition isActive={isWarping} />

            <NetworkOfLoci />

            {blad && (
                <div className="rounded-xl border border-amber-500/30 bg-amber-900/20 p-4 text-sm text-amber-200">
                    {blad} — rejestr modułów i wyprawy żyją w Moście, więc bez niego ta strona pokazuje pustkę zamiast zmyślonych danych.
                </div>
            )}

            {/* ── WROTA ── */}
            <div>
                <div className="flex items-center gap-3 mb-6">
                    <div className="h-8 w-1 bg-gradient-to-b from-purple-500 to-blue-500 rounded-full" />
                    <h3 className="text-xl font-bold text-white tracking-wide">Wrota</h3>
                    <span className="text-xs text-slate-500">otwarte — bez progów</span>
                </div>

                {/* ⚠️ TA SAMA lista co na dashboardzie (lib/wrota.ts). Fashion nie ma buildu
                    na moście — chodzi na własnym Expressie — więc jego kafel odpala serwer
                    dev przez /api/launch; pozostałe otwierają statyczne buildy spod /apps/. */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {STUDIA.map((s) => (
                        <UniverseCard
                            key={s.id}
                            title={s.tytul}
                            subtitle={s.podtytul}
                            onClick={() => wejdz(s)}
                            icon={IKONA[s.id]}
                            colorTheme={s.kolor}
                            isLocked={false}
                        />
                    ))}
                </div>
                <p className="mt-3 text-[11px] text-slate-500 leading-relaxed max-w-3xl">
                    Wrota prowadzą do aplikacji serwowanych przez <b>Twój Most</b>, nie do zewnętrznych domen —
                    adres liczy się z bieżącej bazy, więc <b>na pendrivie I: działa tak samo jak na F:</b>.
                    Klucz Gemini jedzie w adresie, bo substrona ma inny origin i nie widzi pamięci Huba.
                </p>
            </div>

            {/* ── REJESTR MODUŁÓW ── */}
            <DashboardCard title="Rejestr Modułów — subskrypcje za GRV" icon={<AppIcon />}>
                <div className="p-3">
                    <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                        <span className="text-xs text-slate-400">
                            Twoje GRV: <b className="text-amber-300">{grv === 'INFINITE' ? '∞' : (grv ?? 0).toLocaleString('pl-PL')}</b>
                            {' '}· moduły wbudowane są bez opłat, cudze kosztują tyle, ile ustawił autor
                        </span>
                        <button onClick={() => setPokazFormModulu(v => !v)} className="capsule-button capsule-violet text-xs py-1 px-3">
                            {pokazFormModulu ? 'Zamknij' : '+ Dodaj moduł'}
                        </button>
                    </div>

                    {pokazFormModulu && (
                        <div className="mb-4 p-3 rounded-xl border border-violet-500/30 bg-violet-900/10 space-y-2">
                            <p className="text-[11px] text-slate-400">
                                Każdy węzeł może wystawić swój moduł. Cenę ustawiasz sam — GRV idzie do autora,
                                nie do skarbca.
                            </p>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                <input className={pole} placeholder="Nazwa modułu" value={nowyModul.nazwa} onChange={e => setNowyModul(s => ({ ...s, nazwa: e.target.value }))} />
                                <input className={pole} placeholder="Adres (https://… albo /ścieżka)" value={nowyModul.url} onChange={e => setNowyModul(s => ({ ...s, url: e.target.value }))} />
                                <input className={pole} placeholder="Krótki opis" value={nowyModul.opis} onChange={e => setNowyModul(s => ({ ...s, opis: e.target.value }))} />
                                <div className="flex gap-2">
                                    <input className={`${pole} w-16`} value={nowyModul.ikona} onChange={e => setNowyModul(s => ({ ...s, ikona: e.target.value }))} />
                                    <input className={pole} type="number" min={0} placeholder="cena GRV" value={nowyModul.cenaGRV} onChange={e => setNowyModul(s => ({ ...s, cenaGRV: Number(e.target.value) || 0 }))} />
                                    <select className={pole} value={nowyModul.kategoria} onChange={e => setNowyModul(s => ({ ...s, kategoria: e.target.value as Modul['kategoria'] }))}>
                                        <option value="kreacja">kreacja</option><option value="wiedza">wiedza</option>
                                        <option value="zabawa">zabawa</option><option value="narzedzie">narzędzie</option>
                                    </select>
                                </div>
                            </div>
                            <button onClick={() => void wyslijModul()} disabled={zajety} className="capsule-button capsule-green text-xs py-1 px-4">Wystaw w rejestrze</button>
                        </div>
                    )}

                    <div className="pr-2 overflow-y-auto max-h-[26rem]">
                        {moduly.map(m => (
                            <div key={m.id} className="flex items-center justify-between p-3 border-b border-slate-700/50 gap-3">
                                <div className="flex items-center flex-1 min-w-0 gap-3">
                                    <span className="text-xl shrink-0">{m.ikona}</span>
                                    <div className="min-w-0">
                                        <div className="font-semibold truncate text-slate-100">{m.nazwa}</div>
                                        <div className="text-[11px] text-slate-500 truncate">
                                            {m.opis || '—'} · {m.wbudowany ? 'część Katedry' : `od ${m.autor}`}
                                            {m.subskrybentow > 0 && ` · ${m.subskrybentow} subskrybentów`}
                                        </div>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                    <span className={`text-xs font-bold ${m.cenaGRV ? 'text-amber-300' : 'text-emerald-400'}`}>
                                        {m.cenaGRV ? `${m.cenaGRV} GRV` : 'bez opłat'}
                                    </span>
                                    <button onClick={() => void zmienSubskrypcje(m)} disabled={zajety}
                                        className={`w-28 capsule-button text-sm py-1 ${m.subskrybowany ? 'capsule-rose' : 'capsule-green'}`}>
                                        {m.subskrybowany ? 'Wyłącz' : 'Włącz'}
                                    </button>
                                    {!m.wbudowany && (
                                        <button onClick={async () => { await usunModul(m.id); await odswiez(); }}
                                            title="Usuń z rejestru" className="text-slate-600 hover:text-red-400 px-1">✕</button>
                                    )}
                                </div>
                            </div>
                        ))}
                        {!moduly.length && <div className="p-6 text-center text-sm text-slate-600">Rejestr pusty — odpal Most.</div>}
                    </div>
                </div>
            </DashboardCard>

            {/* ── WYPRAWY ── */}
            <div>
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                    <h2 className="text-3xl font-bold text-cyan-300 drop-shadow-[0_0_4px_rgba(0,255,255,0.5)]">
                        WYPRAWY / Wspólne przedsięwzięcia
                    </h2>
                    <button onClick={() => setPokazFormWyprawy(v => !v)} className="capsule-button capsule-violet text-xs py-1 px-3">
                        {pokazFormWyprawy ? 'Zamknij' : '+ Otwórz wyprawę'}
                    </button>
                </div>

                {/* Uczciwie o licznikach — to jest sedno różnicy wobec makiety. */}
                <p className="text-xs text-slate-500 mb-4 max-w-3xl leading-relaxed">
                    Liczniki nie są wpisane, tylko <b>sumowane z realnych wpłat GRV</b> zapisanych w księdze
                    z pieczęcią łańcucha. Nie da się ich ustawić — rosną wyłącznie wtedy, gdy ktoś faktycznie przeleje.
                    Dlatego każda nowa wyprawa startuje od zera i to zero jest prawdziwe.
                </p>

                {pokazFormWyprawy && (
                    <div className="mb-4 p-3 rounded-xl border border-cyan-500/30 bg-cyan-900/10 space-y-2">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            <input className={pole} placeholder="Nazwa wyprawy" value={nowaWyprawa.nazwa} onChange={e => setNowaWyprawa(s => ({ ...s, nazwa: e.target.value }))} />
                            <div className="flex gap-2">
                                <input className={`${pole} w-16`} value={nowaWyprawa.ikona} onChange={e => setNowaWyprawa(s => ({ ...s, ikona: e.target.value }))} />
                                <input className={pole} type="number" min={1} placeholder="cel w GRV" value={nowaWyprawa.celGRV} onChange={e => setNowaWyprawa(s => ({ ...s, celGRV: Number(e.target.value) || 0 }))} />
                            </div>
                            <input className={`${pole} md:col-span-2`} placeholder="O co chodzi w tej wyprawie" value={nowaWyprawa.opis} onChange={e => setNowaWyprawa(s => ({ ...s, opis: e.target.value }))} />
                        </div>
                        <button onClick={() => void wyslijWyprawe()} disabled={zajety} className="capsule-button capsule-green text-xs py-1 px-4">Otwórz</button>
                    </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {wyprawy.map(w => (
                        <div key={w.id} className="bg-slate-900/40 backdrop-blur-lg border border-slate-700/50 rounded-2xl p-4 flex flex-col">
                            <div className="text-3xl mb-2">{w.ikona}</div>
                            <h4 className="text-lg font-bold text-white mb-1">{w.nazwa}</h4>
                            <p className="text-slate-400 text-sm mb-4 flex-grow">{w.opis || '—'}</p>
                            <div className="mb-3">
                                <div className="flex justify-between items-end mb-1 text-xs">
                                    <span className="text-slate-300 font-semibold">
                                        {w.zebraneGRV.toLocaleString('pl-PL')} / {w.celGRV.toLocaleString('pl-PL')} GRV
                                    </span>
                                    <span className="font-bold text-cyan-300">{w.postep.toFixed(2)}%</span>
                                </div>
                                <div className="w-full bg-slate-700/50 rounded-full h-2.5">
                                    <div className="h-2.5 rounded-full bg-cyan-500 transition-all duration-500" style={{ width: `${Math.min(100, w.postep)}%` }} />
                                </div>
                                <div className="mt-1 text-[10px] text-slate-600">
                                    {w.wplat} wpłat · {w.wspierajacych} wspierających · otwarta przez {w.autor}
                                </div>
                            </div>
                            <button onClick={() => void wesprzyj(w)} disabled={zajety} className="capsule-button capsule-cyan w-full mt-auto">
                                Wesprzyj GRV
                            </button>
                        </div>
                    ))}
                    {!wyprawy.length && (
                        <div className="col-span-full rounded-2xl border border-dashed border-slate-700 p-8 text-center">
                            <p className="text-slate-400 text-sm">Żadna wyprawa nie jest otwarta.</p>
                            <p className="text-slate-600 text-xs mt-1">
                                Poprzednie były makietą z wymyślonymi licznikami — zniknęły razem z nią.
                                Otwórz własną, a licznik ruszy od prawdziwego zera.
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
