/**
 * 🔧 MechanicService — Agent Mechanik Katedry
 *
 * Odpowiada za cykl życia naprawy zadań z kolejki:
 *   PENDING → IN_PROGRESS → [Gemma4 generuje patch] → READY_FOR_REVIEW
 *   Na błąd AI: → FAILED + dead_letter_knowledge.json
 *
 * Zasady bezpieczeństwa:
 *   - Mechanik NIGDY nie modyfikuje plików źródłowych (.tsx, .ts)
 *   - Wynik AI trafia do _OtakOs_Wymiar/patches/patch_[TaskID].md (piaskownica)
 *   - Atomowy zapis kolejki: temp_queue.json → fs.rename → queue.json
 *   - Lock (_isRunning) zapobiega nakładaniu się wywołań setInterval
 *
 * Standard: ES Modules ("type": "module" w package.json)
 */

import os            from 'os';
import path          from 'path';
import { promises as fs } from 'fs';
import fsSync        from 'fs';
import { fileURLToPath } from 'url';
import TurbovecService from './TurbovecService.js';
import ShellSanitizer from './ShellSanitizer.js';

// ─── Ścieżki ──────────────────────────────────────────────────────────────────
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

const ANTIGRAVITY_DIR = path.join(process.cwd(), '_OtakOs_Wymiar');
const TASKS_DIR       = path.join(ANTIGRAVITY_DIR, 'tasks');
const PATCHES_DIR     = path.join(ANTIGRAVITY_DIR, 'patches');
const QUEUE_FILE      = path.join(TASKS_DIR,  'queue.json');
const QUEUE_TEMP      = path.join(TASKS_DIR,  'temp_queue.json');
const DEAD_LETTER_FILE = path.join(TASKS_DIR, 'dead_letter_mechanic.json');

// ─── Ollama ───────────────────────────────────────────────────────────────────
const OLLAMA_URL    = 'http://127.0.0.1:11434/api/generate';
/**
 * ⚠️ BYŁO `'gemma4'` — GOŁY TAG. Ollama rozwija go do `gemma4:latest`, a ten
 * na tej maszynie WYWALA SILNIK. Do tego gemma to model ogólny, a Mechanik ma
 * naprawiać KOD — stąd trzy próby z rzędu kończące się tym samym
 * `Expected ")" but found ":"`.
 *
 * Domyślnie bierzemy model kodowy. Suweren zmienia go w panelu Kodeksa
 * (zapis do _OtakOs_Wymiar/mechanik.json) albo przez OTAKOS_MECHANIK_MODEL.
 * Czytamy PRZY KAŻDYM ZADANIU, żeby zmiana działała bez restartu mostu.
 */
const MODEL_DOMYSLNY = process.env.OTAKOS_MECHANIK_MODEL || 'qwen2.5-coder:7b';
const PLIK_USTAWIEN  = () => path.join(process.cwd(), '_OtakOs_Wymiar', 'mechanik.json');

function modelMechanika() {
    try {
        const s = fsSync.readFileSync(PLIK_USTAWIEN(), 'utf8');
        const d = JSON.parse(s);
        if (d && typeof d.model === 'string' && d.model.trim()) return d.model.trim();
    } catch { /* brak pliku albo śmieć — lecimy domyślnym */ }
    return MODEL_DOMYSLNY;
}

export function ustawModelMechanika(model) {
    const czysty = String(model || '').trim();
    fsSync.mkdirSync(path.dirname(PLIK_USTAWIEN()), { recursive: true });
    fsSync.writeFileSync(PLIK_USTAWIEN(), JSON.stringify({ model: czysty }, null, 2), 'utf8');
    return czysty || MODEL_DOMYSLNY;
}

export { modelMechanika, MODEL_DOMYSLNY };
const AI_TIMEOUT_MS = 300_000;  // 300s (VRAM Breathing v2) — pełna swoboda alokacji VRAM przy zimnym starcie gemma4

// ─── Typy statusów ────────────────────────────────────────────────────────────
const STATUS = {
    PENDING:            'PENDING',
    IN_PROGRESS:        'IN_PROGRESS',
    READY_FOR_REVIEW:   'READY_FOR_REVIEW',
    FAILED:             'FAILED',
};

// ─── Klasa ────────────────────────────────────────────────────────────────────
class MechanicService {
    constructor() {
        this._isRunning = false;  // Lock — zapobiega nakładaniu się wywołań
        console.log('[MechanicService] 🔧 Agent Mechanik zainicjalizowany.');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: cykl przetwarzania kolejki
    // ─────────────────────────────────────────────────────────────────────────

    async processPendingTasks() {
        if (this._isRunning) {
            console.log('[Mechanik] ⏸️  Poprzedni cykl jeszcze trwa — pomijam.');
            return;
        }

        this._isRunning = true;
        console.log('[Mechanik] 🔄 Rozpoczynam skan kolejki zadań...');

        try {
            await this._ensureDirs();
            const tasks = await this._readQueue();

            const pending = tasks.filter(t => t.status === STATUS.PENDING);
            console.log(`[Mechanik] 📋 Kolejka: ${tasks.length} łącznie, ${pending.length} PENDING.`);

            if (pending.length === 0) {
                console.log('[Mechanik] ✅ Kolejka pusta — brak pracy.');
                return;
            }

            // Przetwarzamy jedno zadanie na raz (FIFO)
            const task = pending[0];
            await this._processTask(task, tasks);

        } catch (err) {
            console.error(`[Mechanik] ❌ processPendingTasks: ${err.message}`);
        } finally {
            this._isRunning = false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: odczyt aktualnej kolejki (dla endpointu GET)
    // ─────────────────────────────────────────────────────────────────────────

    async getQueue() {
        await this._ensureDirs();
        return this._readQueue();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: WYCZYŚĆ WSZYSTKO — zresetuj kolejkę zadań do zera
    // ─────────────────────────────────────────────────────────────────────────
    /**
     * Usuwa WSZYSTKIE zadania z kolejki (wiszące, nieaktualne procesy) i zapisuje
     * pustą tablicę. Zwraca liczbę usuniętych zadań.
     */
    async clearQueue() {
        await this._ensureDirs();
        const tasks = await this._readQueue();
        const count = tasks.length;
        await this._saveQueue([]);
        console.log(`[Mechanik] 🧹 WYCZYŚĆ WSZYSTKO — usunięto ${count} zadań, kolejka zresetowana do zera.`);
        return count;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: FIFO Queue Clearer — usuwa zakleszczone zadania (zombie / aborted)
    // ─────────────────────────────────────────────────────────────────────────
    /**
     * Usuwa z kolejki FIFO zadania zakleszczone, aby zatory (np. po timeout/abort
     * Ollamy) nie blokowały kolejnych operacji. Cele:
     *   - IN_PROGRESS starsze niż próg (zombie po crashu / abort'cie),
     *   - FAILED z flagą vramStall starsze niż próg.
     * Świeże wpisy (< staleMinutes) zostają — Suweren widzi ostatnią awarię.
     * @param {{ staleMinutes?: number }} [opts]
     * @returns {Promise<number>} liczba usuniętych zadań.
     */
    async purgeStalledTasks({ staleMinutes = 5 } = {}) {
        await this._ensureDirs();
        const tasks  = await this._readQueue();
        const cutoff = Date.now() - staleMinutes * 60_000;
        const isStalled = (t) => {
            const ts  = Date.parse(t.updatedAt || t.startedAt || t.createdAt || '') || 0;
            const old = ts < cutoff;
            return old && (t.status === STATUS.IN_PROGRESS || (t.status === STATUS.FAILED && t.vramStall));
        };
        const kept    = tasks.filter(t => !isStalled(t));
        const removed = tasks.length - kept.length;
        if (removed > 0) {
            await this._saveQueue(kept);
            console.log(`[Mechanik] 🧹 FIFO Clearer: usunięto ${removed} zakleszczonych zadań (>${staleMinutes}min).`);
        }
        return removed;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: Otak-Sync Watchdog — odkażanie komend powłoki dla zadań shell
    // ─────────────────────────────────────────────────────────────────────────
    /**
     * Hook Strażnika Powłoki: każda komenda, którą agent Mechanik miałby przekazać
     * do powłoki Windows (cmd/PowerShell), przechodzi przez ten filtr — usuwa
     * znaczniki promptu "$", /dev/null i Linux-izmy. UWAGA: NIE stosujemy tego do
     * treści patchy/kodu (kod TS używa `${...}`); wyłącznie do komend shell.
     * @param {string} rawCommand
     * @returns {string} bezpieczna komenda pod powłokę Windows
     */
    sanitizeShellCommand(rawCommand) {
        const { command, changed, notes } = ShellSanitizer.sanitizeShellCommand(rawCommand);
        if (changed) console.log(`[Mechanik·Otak-Sync] 🧯 Komenda odkażona: ${notes.join(' ')}`);
        return command;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: odrzucenie zadania (READY_FOR_REVIEW → REJECTED)
    // ─────────────────────────────────────────────────────────────────────────

    async rejectTask(id) {
        if (!id) return null;
        await this._ensureDirs();
        const tasks = await this._readQueue();
        if (!tasks.some(t => t.id === id)) {
            console.warn(`[Mechanik] ⚠️  rejectTask: zadanie ${id} nie istnieje.`);
            return null;
        }
        await this._updateStatus(id, tasks, 'REJECTED', { rejectedAt: new Date().toISOString() });
        console.log(`[Mechanik] 🚫 Zadanie ${id} → REJECTED.`);
        return id;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: oznacz jako wdrożone (READY_FOR_REVIEW → DONE)
    // ─────────────────────────────────────────────────────────────────────────

    async doneTask(id) {
        if (!id) return null;
        await this._ensureDirs();
        const tasks = await this._readQueue();
        if (!tasks.some(t => t.id === id)) {
            console.warn(`[Mechanik] ⚠️  doneTask: zadanie ${id} nie istnieje.`);
            return null;
        }
        await this._updateStatus(id, tasks, 'DONE', { doneAt: new Date().toISOString() });
        console.log(`[Mechanik] ✅ Zadanie ${id} → DONE (patch wdrożony).`);
        return id;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: ręczne dodanie zadania do kolejki (dla /api/chaos/inject etc.)
    // ─────────────────────────────────────────────────────────────────────────

    async enqueueTask(task) {
        if (!task?.id || !task?.title) {
            console.warn('[Mechanik] ⚠️  enqueueTask: brak id lub title.');
            return null;
        }

        await this._ensureDirs();
        const tasks = await this._readQueue();

        // Deduplikacja po id
        if (tasks.some(t => t.id === task.id)) {
            console.log(`[Mechanik] 🔁 Zadanie ${task.id} już w kolejce — pomijam.`);
            return null;
        }

        const entry = {
            id:          task.id,
            title:       task.title,
            description: task.description || '',
            priority:    task.priority    || 'LOW',
            targetFiles: task.targetFiles || [],
            status:      STATUS.PENDING,
            createdAt:   new Date().toISOString(),
            updatedAt:   new Date().toISOString(),
        };

        tasks.push(entry);
        await this._saveQueue(tasks);

        console.log(`[Mechanik] ➕ Zadanie ${entry.id} dodane do kolejki (${tasks.length} łącznie).`);
        return entry;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE: przetwarzanie jednego zadania
    // ─────────────────────────────────────────────────────────────────────────

    async _processTask(task, allTasks) {
        console.log(`[Mechanik] 🛠️  Przetwarzam: [${task.priority}] ${task.id} — "${task.title}"`);

        // 1. Zablokuj zadanie: PENDING → IN_PROGRESS
        await this._updateStatus(task.id, allTasks, STATUS.IN_PROGRESS, {
            startedAt: new Date().toISOString(),
        });

        // 1b. [🔍 SKANOWANIE STRUKTURY] TurbovecService wzbogaca opis o kontekst plików
        await this._setStage(task.id, allTasks, 'SCANNING');
        try {
            const enriched = await TurbovecService.getInstance().enrichTaskDescription(task);
            if (enriched !== task.description) {
                task = { ...task, description: enriched };
                console.log(`[Mechanik·Turbovec] 🔮 Opis zadania ${task.id} wzbogacony (${enriched.length} znaków).`);
            }
        } catch (tvErr) {
            console.warn(`[Mechanik·Turbovec] ⚠️ Enrichment skipped: ${tvErr.message}`);
        }

        let patchContent = null;

        // 2. [🛠️ GENEROWANIE ŁATKI] Wyślij do Gemma4 (z kontekstem Turboveca)
        await this._setStage(task.id, allTasks, 'GENERATING');
        const aiStartedAt = Date.now();
        try {
            patchContent = await this._callGemma(task);
        } catch (aiErr) {
            // ⚠️ PROTOKÓŁ RZETELNOŚCI (2026-07-30). Poprzednia wersja na KAŻDY abort
            // meldowała „Wykryto zator pamięci VRAM. Podnoszę limity magistrali
            // i restartuję nasłuch rdzenia..." — dwa grzechy naraz:
            //   1. „Wykryto" było zgadywaniem podanym jako fakt (abort ma wiele przyczyn:
            //      Ollama nie stoi, model niepobrany, zimny start, padł proces).
            //   2. Opisywało czynności, KTÓRYCH NIE WYKONUJE — nic tu nie podnosi limitów
            //      ani nie restartuje rdzenia; jedyna realna akcja to purgeStalledTasks.
            // Diagnoza podana pewnym tonem wysyła Suwerena w polowanie na zły trop.
            // Teraz: fakty → hipotezy jawnie oznaczone → co NAPRAWDĘ zrobiono → jak sprawdzić.
            const diag = this._opiszAwarieAI(aiErr, task, Date.now() - aiStartedAt);

            console.error(`[Mechanik] ❌ ${task.id}: ${diag.naglowek}`);
            console.error(`[Mechanik]    fakty: ${diag.fakty}`);

            await this._updateStatus(task.id, allTasks, STATUS.FAILED, {
                failedAt:   new Date().toISOString(),
                error:      diag.pelny,
                errorKind:  diag.rodzaj,          // 'TIMEOUT' | 'HTTP' | 'EMPTY' | 'UNKNOWN'
                hypothesis: true,                 // ⚠️ przyczyna NIE jest potwierdzona
                vramStall:  diag.rodzaj === 'TIMEOUT' ? undefined : undefined,
            });
            await this._writeDeadLetter({ task, error: diag.pelny });
            const aborted = diag.rodzaj === 'TIMEOUT';

            // FIFO Clearer: po wykryciu abortu usuń zakleszczone zombie, by nie blokowały kolejki.
            if (aborted) {
                try { await this.purgeStalledTasks({ staleMinutes: 5 }); }
                catch (pErr) { console.warn(`[Mechanik] ⚠️ purgeStalled: ${pErr.message}`); }
            }
            return;
        }

        // 2b. [🧪 WERYFIKACJA KOMPILACJI (Vite/esbuild)] — autonomiczny loop testowy
        await this._setStage(task.id, allTasks, 'VERIFYING');
        let verify = { ok: true, attempts: 0, planOnly: true };
        try {
            verify = await this._verifyAndRepair(task, patchContent);
            patchContent = verify.patch;   // pętla mogła poprawić kod
        } catch (vErr) {
            console.warn(`[Mechanik·Verify] ⚠️ Weryfikacja pominięta: ${vErr.message}`);
            verify = { ok: true, attempts: 0, skipped: true };
        }

        // 3. Zapisz patch do piaskownicy (NIE modyfikuj src!)
        const patchFile = path.join(PATCHES_DIR, `patch_${task.id}.md`);
        const patchBody = this._formatPatch(task, patchContent, verify);

        try {
            await fs.writeFile(patchFile, patchBody, 'utf8');
            console.log(`[Mechanik] 📄 Patch zapisany: ${patchFile}`);
        } catch (writeErr) {
            console.error(`[Mechanik] ❌ Zapis patcha: ${writeErr.message}`);
            await this._updateStatus(task.id, allTasks, STATUS.FAILED, {
                failedAt: new Date().toISOString(),
                error:    writeErr.message,
                stage:    'FAILED',
            });
            await this._writeDeadLetter({ task, error: writeErr.message });
            return;
        }

        // 4. [🟢 GOTOWE DO ZATWIERDZENIA] IN_PROGRESS → READY_FOR_REVIEW
        await this._updateStatus(task.id, allTasks, STATUS.READY_FOR_REVIEW, {
            completedAt:   new Date().toISOString(),
            patchFile:     `patches/patch_${task.id}.md`,
            stage:         'READY',
            verified:      verify.ok,
            verifyAttempts: verify.attempts,
            planOnly:      verify.planOnly || undefined,
            verifyError:   verify.ok ? undefined : verify.error,
        });

        const verdict = verify.planOnly ? 'plan (bez kodu)' : verify.ok
            ? `składnia OK${verify.attempts ? ` po ${verify.attempts} naprawach` : ''}`
            : `⚠️ nadal błąd po 3 próbach`;
        console.log(`[Mechanik] ✅ Zadanie ${task.id} → READY_FOR_REVIEW (${verdict}).`);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE: AI CALL — Gemma4 (ten sam wzorzec co KnowledgeGraphService)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * 🔍 Opis awarii wywołania AI — protokół rzetelności Mechanika.
     *
     * Zasada: NAJPIERW to, co zmierzone (typ błędu, endpoint, model, czas), POTEM
     * hipotezy — zawsze podpisane jako hipotezy, nigdy jako „wykryto". Mechanik nie
     * ma czym zmierzyć zajętości VRAM, więc nie wolno mu twierdzić, że ją wykrył.
     * Na końcu polecenie, którym Suweren sam sprawdzi, która hipoteza jest prawdziwa.
     */
    _opiszAwarieAI(err, task, elapsedMs) {
        const sek        = Math.max(1, Math.round(elapsedMs / 1000));
        const komunikat  = err?.message || String(err);
        const nazwa      = err?.name || 'Error';
        const czyTimeout = nazwa === 'AbortError' || /aborted|abort/i.test(komunikat);
        const httpKod    = (/Ollama HTTP (\d+)/.exec(komunikat) || [])[1];
        const czyPusta   = /pust[ąa]\s+odpowied/i.test(komunikat);

        let rodzaj, naglowek, hipotezy;
        if (czyTimeout) {
            rodzaj   = 'TIMEOUT';
            naglowek = `Zapytanie do modelu ${modelMechanika()} przerwane po ${sek}s (limit ${AI_TIMEOUT_MS / 1000}s).`;
            hipotezy = [
                `zimny start — ${modelMechanika()} ładuje się dłużej niż limit`,
                'Ollama nie nadąża lub padła w trakcie generowania',
                'za mało wolnej pamięci, by pomieścić model',
                'zadanie zbyt duże na jedno wywołanie',
            ];
        } else if (httpKod) {
            rodzaj   = 'HTTP';
            naglowek = `Ollama odrzuciła zapytanie: HTTP ${httpKod}.`;
            hipotezy = httpKod === '404'
                ? [`model "${modelMechanika()}" nie jest pobrany na tej maszynie`]
                : ['Ollama zwróciła błąd serwera — szczegóły w jej własnym logu'];
        } else if (czyPusta) {
            rodzaj   = 'EMPTY';
            naglowek = `Model ${modelMechanika()} odpowiedział, ale pustką.`;
            hipotezy = ['prompt odrzucony przez model', 'odpowiedź ucięta przez limit kontekstu'];
        } else {
            rodzaj   = 'UNKNOWN';
            naglowek = `Wywołanie AI nie powiodło się: ${nazwa}.`;
            hipotezy = ['przyczyna nierozpoznana — patrz surowy komunikat poniżej'];
        }

        const fakty = `${nazwa}: ${komunikat} · endpoint ${OLLAMA_URL} · model ${modelMechanika()} · ${sek}s · zadanie ${task.id}`;
        const pelny = [
            `[MECHANIK] ${naglowek}`,
            `FAKTY: ${fakty}`,
            `HIPOTEZY (niezweryfikowane, w kolejności prawdopodobieństwa): ${hipotezy.map((h, i) => `${i + 1}) ${h}`).join('; ')}`,
            `CO ZROBIONO: zadanie oznaczone jako FAILED i zapisane do dead-letter` +
                (czyTimeout ? '; wyczyszczono zakleszczone zadania starsze niż 5 min' : ''),
            `SPRAWDŹ SAM: "ollama ps" (czy model stoi) oraz "curl ${OLLAMA_URL.replace(/\/api\/.*$/, '/api/tags')}" (czy jest pobrany)`,
        ].join('\n');

        return { rodzaj, naglowek, fakty, hipotezy, pelny };
    }

    async _callGemma(task) {
        const prompt =
            `Jesteś głównym inżynierem Katedry. Napraw ten błąd:\n\n` +
            `ID zadania: ${task.id}\n` +
            `Tytuł: ${task.title}\n` +
            `Opis: ${task.description}\n` +
            `Priorytet: ${task.priority}\n` +
            (task.targetFiles?.length
                ? `Pliki docelowe: ${task.targetFiles.join(', ')}\n`
                : '') +
            `\nWygeneruj konkretny kod naprawczy lub instrukcję refaktoryzacji. ` +
            `Podaj kompletny kod w jednym bloku \`\`\`...\`\`\`. Ogranicz tekst poboczny. ` +
            `Jeśli nie ma wystarczającego kontekstu, opisz architektoniczny plan naprawy krok po kroku.`;
        return this._callGemmaRaw(prompt, task.id);
    }

    /**
     * ⚠️ STRAŻNIK PAMIĘCI — Mechanik nie ładuje modelu, który położy maszynę.
     *
     * Zmierzone 2026-09-11 ~01:45: w mechanik.json stał `qwen3.6:35b-a3b` (24,8 GB;
     * w VRAM mieści się 2 GB, reszta idzie do RAM). Jedno HTTP 500 → auto-panic →
     * Mechanik ładuje 35B → wolne RAM 3,7 GB z 39,7, plik wymiany 5,5 GB → most pada →
     * kolejne 500 → kolejne paniki. Diagnosta, który sam kładzie maszynę. A dead-letter
     * dowodził, że i tak nic z tego nie było: każde zapytanie padało po 300 s.
     *
     * Reguła: model już załadowany → OK (nic nowego nie zajmie). Inaczej rozmiar
     * modelu + 4 GB zapasu musi mieścić się w WOLNYM RAM. Zapas jest po to, żeby
     * po załadowaniu Windows nie wpadł w plik wymiany, bo wtedy Ollama i tak
     * nie zdąży w limicie. Gdy model nie mieści się, mówimy DLACZEGO i ILE brakuje —
     * zamiast abortu po 300 s z hipotezą „może VRAM".
     */
    async _sprawdzCzyModelSieZmiesci(model) {
        const ZAPAS_GB = 4;
        let zaladowane = [];
        let rozmiarGb = null;
        try {
            const ps = await fetch('http://127.0.0.1:11434/api/ps', { signal: AbortSignal.timeout(5000) }).then((r) => r.json());
            zaladowane = (ps.models ?? []).map((m) => m.name);
        } catch { /* Ollama milczy — dalej i tak wywali się z jasnym HTTP */ }
        if (zaladowane.includes(model)) return { ok: true, powod: 'model już w pamięci' };

        try {
            const tags = await fetch('http://127.0.0.1:11434/api/tags', { signal: AbortSignal.timeout(5000) }).then((r) => r.json());
            const wpis = (tags.models ?? []).find((m) => m.name === model);
            if (wpis) rozmiarGb = wpis.size / 1e9;
        } catch { /* bez rozmiaru nie ma jak ocenić — przepuszczamy z ostrzeżeniem */ }
        if (rozmiarGb === null) return { ok: true, powod: 'rozmiar modelu nieznany — nie blokuję' };

        const wolneGb = os.freemem() / 1e9;
        const potrzebaGb = rozmiarGb + ZAPAS_GB;
        if (wolneGb >= potrzebaGb) return { ok: true, powod: `${rozmiarGb.toFixed(1)} GB + ${ZAPAS_GB} GB zapasu ≤ ${wolneGb.toFixed(1)} GB wolnych` };
        return {
            ok: false,
            powod: `model ${model} ma ${rozmiarGb.toFixed(1)} GB, a wolnego RAM jest ${wolneGb.toFixed(1)} GB ` +
                   `(potrzeba ${potrzebaGb.toFixed(1)} GB z zapasem). NIE ŁADUJĘ — załadowanie położyłoby maszynę. ` +
                   `Wybierz mniejszy model w Kodeksie (POST /api/mechanic/model) albo zwolnij pamięć.`,
        };
    }

    /** Wspólny niski-poziom caller Gemma4 (reużywany przez napraw-loop i Git Assistant). */
    async _callGemmaRaw(prompt, tag = 'raw') {
        const model = modelMechanika();
        const miejsce = await this._sprawdzCzyModelSieZmiesci(model);
        if (!miejsce.ok) throw new Error(`[STRAŻNIK PAMIĘCI] ${miejsce.powod}`);

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);
        let raw = '';
        try {
            const resp = await fetch(OLLAMA_URL, {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                signal:  controller.signal,
                // ⚠️ think:false — modele qwen3.x myślą; bez tego przepalają budżet na blok
                // myślenia i oddają PUSTĄ treść (zmierzone: eval_count 60, response "").
                body: JSON.stringify({ model, prompt, stream: false, think: false }),
            });
            if (!resp.ok) throw new Error(`Ollama HTTP ${resp.status}`);
            const json = await resp.json();
            raw = (json.response || '').trim();
            console.log(`[Mechanik] ✅ Model odpowiedział (${raw.length} znaków) [${tag}].`);
        } finally {
            clearTimeout(timer);
        }
        if (!raw) throw new Error('Gemma4 zwróciła pustą odpowiedź.');
        return raw;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE: 🧪 AUTONOMICZNY LOOP TESTOWY (weryfikacja kompilacji + samonaprawa)
    // ─────────────────────────────────────────────────────────────────────────

    /** Wyciągnij pierwszy blok kodu z odpowiedzi Gemmy (```lang ... ```). */
    _extractCode(text) {
        const m = String(text || '').match(/```[a-zA-Z]*\n([\s\S]*?)```/);
        return m ? m[1].trim() : null;
    }

    /**
     * Cichy test syntaktyczny przez esbuild (ten sam silnik co Vite) — ms zamiast
     * pełnego npm run build. Wykrywa błędy składni TS/TSX/JS bez wdrażania patcha.
     */
    async _verifySyntax(code, targetFile = '') {
        const ext = (String(targetFile).match(/\.(\w+)$/) || [])[1]?.toLowerCase();
        const loader = ext === 'tsx' ? 'tsx' : ext === 'ts' ? 'ts' : ext === 'jsx' ? 'jsx' : 'js';
        try {
            const esbuild = await import('esbuild');
            await esbuild.transform(code, { loader, logLevel: 'silent' });
            return { ok: true, engine: 'esbuild', loader };
        } catch (e) {
            const msg = (e.errors?.map(x => x.text).join('; ')) || e.message;
            return { ok: false, error: msg, loader };
        }
    }

    /** Przeproś Gemmę o naprawę WYŁĄCZNIE błędu składni (faza pętli). */
    async _callGemmaFix(task, brokenCode, error, attempt) {
        const prompt =
            `Twój poprzedni patch dla "${task.title}" ma BŁĄD KOMPILACJI (próba ${attempt}/3).\n\n` +
            `BŁĄD KOMPILATORA:\n${error}\n\n` +
            `KOD:\n\`\`\`\n${String(brokenCode).slice(0, 2500)}\n\`\`\`\n\n` +
            `Napraw WYŁĄCZNIE błąd składni. Zwróć POPRAWIONY, kompletny kod w jednym bloku \`\`\`...\`\`\`. ` +
            `Bez wyjaśnień, bez tekstu poza blokiem kodu.`;
        return this._callGemmaRaw(prompt, `fix#${attempt}`);
    }

    /**
     * Pętla samonaprawy: generuj → testuj składnię → (jeśli błąd) popraw → powtórz (max 3).
     * @returns {Promise<{ok, patch, attempts, error?, planOnly?}>}
     */
    async _verifyAndRepair(task, patchContent) {
        const targetFile = task.targetFiles?.[0] || '';
        let patch = patchContent, attempts = 0, lastError = null;

        for (let i = 0; i < 3; i++) {
            const code = this._extractCode(patch);
            if (!code) {
                // Brak bloku kodu → plan architektoniczny, nie ma czego kompilować.
                return { ok: true, patch, attempts, planOnly: true };
            }
            const v = await this._verifySyntax(code, targetFile);
            if (v.ok) {
                console.log(`[Mechanik·Verify] 🟢 Składnia czysta (${v.loader}) po ${attempts} naprawach.`);
                return { ok: true, patch, attempts };
            }
            attempts++;
            lastError = v.error;
            console.warn(`[Mechanik·Verify] 🧪 Próba ${attempts}/3 — błąd: ${String(v.error).slice(0, 120)}`);
            if (i < 2) {
                try { patch = await this._callGemmaFix(task, code, v.error, attempts); }
                catch (e) { lastError = e.message; break; }
            }
        }
        return { ok: false, patch, attempts, error: lastError };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC: 🧠 CONTEXT-AWARE GIT ASSISTANT — Conventional Commits z git diff
    // ─────────────────────────────────────────────────────────────────────────
    /**
     * Generuje nagłówek commita w konwencji Conventional Commits na bazie diffu.
     * @param {string} diffText  surowy git diff (przycięty)
     * @returns {Promise<string>} np. "fix(mechanic): naprawa pętli weryfikacji"
     */
    async generateCommitMessage(diffText) {
        const prompt =
            `Na podstawie poniższego git diff wygeneruj DOKŁADNIE JEDEN nagłówek commita w konwencji ` +
            `Conventional Commits: "type(scope): opis".\n` +
            `Typy: feat, fix, refactor, docs, chore, perf, test, style.\n` +
            `Scope = obszar kodu (core, view, bridge, mechanic, vault, arcade, kibel, ui...).\n` +
            `Maks 72 znaki, bez kropki na końcu, bez markdown, bez cudzysłowów. Odpowiedz TYLKO nagłówkiem.\n\n` +
            `DIFF:\n${String(diffText).slice(0, 4000)}`;
        const raw = await this._callGemmaRaw(prompt, 'git-msg');
        // Pierwsza sensowna linia, oczyszczona z markdown/cudzysłowów.
        const line = raw.split('\n').map(l => l.trim()).find(l => /^[a-z]+(\(.+\))?:/i.test(l)) || raw.split('\n')[0];
        return line.replace(/^[`*>"'\s-]+/, '').replace(/["'`]+$/, '').slice(0, 100).trim();
    }

    /** Ustaw fazę operacyjną zadania (live-stepper na Szmaragdowym Terminalu). */
    async _setStage(taskId, allTasks, stage) {
        await this._updateStatus(taskId, allTasks, STATUS.IN_PROGRESS, { stage });
    }

    /** PUBLIC: weryfikacja składni dowolnego kodu (dla Katedralnego Klaudiusza w czacie). */
    async verifyCode(code, filename = '') {
        return this._verifySyntax(code, filename);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE: formatowanie pliku patch.md
    // ─────────────────────────────────────────────────────────────────────────

    _formatPatch(task, aiContent, verify = {}) {
        const ts = new Date().toISOString();
        const verifyLine = verify.planOnly
            ? `> **🧪 Weryfikacja:** plan architektoniczny (brak kodu do kompilacji)`
            : verify.skipped
            ? `> **🧪 Weryfikacja:** pominięta`
            : verify.ok
            ? `> **🧪 Weryfikacja:** 🟢 składnia OK (esbuild)${verify.attempts ? ` po ${verify.attempts} auto-naprawach` : ''}`
            : `> **🧪 Weryfikacja:** 🔴 błąd składni po 3 próbach — ${String(verify.error).slice(0, 160)}`;
        return [
            `# 🔧 Patch: ${task.title}`,
            ``,
            `> **ID zadania:** \`${task.id}\``,
            `> **Priorytet:** ${task.priority}`,
            `> **Status:** READY_FOR_REVIEW`,
            `> **Wygenerowano:** ${ts}`,
            verifyLine,
            (task.targetFiles?.length
                ? `> **Pliki docelowe:** ${task.targetFiles.map(f => `\`${f}\``).join(', ')}`
                : ''),
            ``,
            `---`,
            ``,
            `## Opis Incydentu`,
            ``,
            task.description || '(brak opisu)',
            ``,
            `---`,
            ``,
            `## Propozycja Naprawy (Gemma4)`,
            ``,
            aiContent,
            ``,
            `---`,
            ``,
            `*Wygenerowano automatycznie przez Agenta Mechanika Katedry.*`,
            `*Plik tylko do odczytu — nie modyfikuje źródeł projektu.*`,
        ].filter(line => line !== undefined).join('\n');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE: I/O kolejki
    // ─────────────────────────────────────────────────────────────────────────

    async _readQueue() {
        try {
            const raw = await fs.readFile(QUEUE_FILE, 'utf8');
            return JSON.parse(raw);
        } catch (_) {
            return [];  // plik nie istnieje — pusta kolejka
        }
    }

    async _saveQueue(tasks) {
        const payload = JSON.stringify(tasks, null, 2);
        await fs.writeFile(QUEUE_TEMP, payload, 'utf8');
        await fs.rename(QUEUE_TEMP, QUEUE_FILE);  // atomic
    }

    async _updateStatus(taskId, allTasks, newStatus, extra = {}) {
        const updated = allTasks.map(t =>
            t.id === taskId
                ? { ...t, status: newStatus, updatedAt: new Date().toISOString(), ...extra }
                : t
        );
        await this._saveQueue(updated);
        // Odbij zmiany w tablicy allTasks (in-place) by kolejne operacje w tym samym cyklu miały spójny stan
        const changed = updated.find(t => t.id === taskId);
        if (changed) Object.assign(allTasks.find(t => t.id === taskId) || {}, changed);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE: infrastruktura
    // ─────────────────────────────────────────────────────────────────────────

    async _ensureDirs() {
        await Promise.all([
            fs.mkdir(TASKS_DIR,   { recursive: true }),
            fs.mkdir(PATCHES_DIR, { recursive: true }),
        ]);
    }

    async _writeDeadLetter(entry) {
        try {
            let dlq = [];
            try {
                const raw = await fs.readFile(DEAD_LETTER_FILE, 'utf8');
                dlq = JSON.parse(raw);
            } catch (_) { /* plik nie istnieje */ }

            dlq.push({ ...entry, dlqAt: new Date().toISOString() });
            await fs.writeFile(DEAD_LETTER_FILE, JSON.stringify(dlq, null, 2), 'utf8');
            console.warn(`[Mechanik] 📮 Dead Letter: zapisano wpis (${dlq.length} łącznie).`);
        } catch (e) {
            console.error(`[Mechanik] 🔥 CRITICAL: nie można zapisać DLQ! ${e.message}`);
        }
    }
}

// ─── Singleton ────────────────────────────────────────────────────────────────
let _instance = null;

const mechanicServiceSingleton = {
    getInstance() {
        if (!_instance) _instance = new MechanicService();
        return _instance;
    }
};

export default mechanicServiceSingleton;
