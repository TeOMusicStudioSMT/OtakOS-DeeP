import express from 'express';
import cors from 'cors';
import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// NOWOŚĆ: Moduł do wykonywania komend w terminalu
import { exec, execFile, spawn } from 'child_process';
import { initTacosGuard, executeTacosGuard } from './core/tacos-guard.js';
import { runCodeReview } from './core/agents/ocr.js';
import { getAgentsList, getAgentPrompt, getMergedSystemPrompt } from './core/agents/index.js';
import { promisify } from 'util';
import crypto from 'crypto';
import os from 'os';
const execAsync = promisify(exec);
const execFileAsync = promisify(execFile);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// BRIDGE: Aby obsłużyć biblioteki CommonJS w środowisku ESM (jak youtube-transcript 1.0.6)
import { createRequire } from 'module';
const require = createRequire(import.meta.url);

// ── ARCHIWISTA WIEDZY (KnowledgeGraphService) ────────────────────────────────
import KnowledgeGraphService from './services/KnowledgeGraphService.js';
import {
    AKCJE_JOANNY,
    pamiec as joannaPamiec,
    zapiszUtwor as joannaZapiszUtwor,
    dopiszPlik as joannaDopiszPlik,
    ocenUtwor as joannaOcen,
    zapamietaj as joannaZapamietaj,
    zbudujKontekst as joannaKontekst,
    promptSystemowy as joannaPrompt,
    zdanieZWyniku as joannaZdanie,
} from './services/JoannaService.js';
import {
    SCIEZKI as BIT_SCIEZKI,
    parsujMatryce as bitParsujMatryce,
    listaWzorcow as bitListaWzorcow,
    wzorPoNazwie as bitWzorPoNazwie,
    renderujBit,
} from './services/BitService.js';
import {
    PASMA as RZEZBA_PASMA,
    dlugosc as audioDlugosc,
    tnij as audioTnij,
    petla as audioPetla,
    sklej as audioSklej,
    znormalizuj as audioNormalizuj,
    pasma as audioPasma,
} from './services/RzezbaAudioService.js';
import MechanicService, { modelMechanika, ustawModelMechanika, MODEL_DOMYSLNY } from './services/MechanicService.js';
import TurbovecService       from './services/TurbovecService.js';
import ShellSanitizer        from './services/ShellSanitizer.js';
import { glosyPiper, PIPER_GLOSY, PIPER_DOMYSLNY } from './services/PrzewodyGlosuService.js';
import { mcpPolaczenie }    from './services/McpStdioClient.js';
import * as Petla         from './services/PetlaNaprawcza.js';
import * as Szyna         from './services/SzynaZdarzen.js';
import * as Rangi         from './services/Rangi.js';
import * as Questy        from './services/Questy.js';
import * as Konta         from './services/Konta.js';
import * as PaneleTeogochi from './services/PaneleTeogochi.js';
import * as KuzniaModeli   from './services/KuzniaModeli.js';
import * as HistoriaCzatu  from './services/HistoriaCzatu.js';
import * as PamiecKodu     from './services/PamiecKodu.js';
import * as MostStada      from './services/MostStada.js';
import * as TeoSim         from './services/TeoSim.js';
import * as Wideo          from './services/Wideo.js';
import { wczytajKorpus, dopasuj, brief, SCIEZKA_KORPUSU } from './services/WiedzaDesign.js';
import { stanAnimacji, renderuj, KATALOG_PROJEKTOW } from './services/Animacje.js';
import { zProjektuAppV2 }   from './services/KompozytorUI.js';
import { stanMontazu, odpalBacklot, SCIEZKA_STUDIA } from './services/Montaz.js';
import ImpresarioService     from './services/ImpresarioService.js';
import TostService           from './services/TostService.js';
import LaundryService        from './services/LaundryService.js';
import VaultService          from './services/VaultService.js';
import ProfileScoutService   from './services/ProfileScoutService.js';
import {
    AKCJE_SLUZBY as BIZNES_AKCJE,
    dodaj as biznesDodaj, zaktualizuj as biznesZaktualizuj,
    usun as biznesUsun, znajdz as biznesZnajdz, zapiszZdarzenie as biznesZapiszZdarzenie,
    zdarzenia as biznesZdarzenia, stan as biznesStan,
} from './services/BiznesService.js';
import {
    przewod as glosPrzewod,
    statusPrzewodow as glosStatusPrzewodow, wczytajProfile as glosProfile,
    zapiszProfil as glosZapiszProfil, usunProfil as glosUsunProfil,
    nagrania as glosNagrania,
} from './services/GlosMcpService.js';
import {
    KOKORO_BASE_DOMYSLNY,
    BladPrzewodu, syntezuj as glosSyntezuj, glosyElevenLabs,
} from './services/PrzewodyGlosuService.js';
import {
    BladTelefonii, zadzwon as telefoniaZadzwon, stanKonta as telefoniaStanKonta,
    mozliwosci as telefoniaMozliwosci, zbudujTwimlStream, weryfikujPodpis as telefoniaPodpis,
} from './services/TelefoniaService.js';
import {
    BladTunelu, wczytaj as tunelWczytaj, ustaw as tunelUstaw, zdejmij as tunelZdejmij,
    czyZywy as tunelCzyZywy, nowyBilet, zuzyjBilet, biletowWObiegu,
} from './services/TunelService.js';
import {
    attachLiveAudio, zyweRozmowy, rozmowa as zywaRozmowa,
} from './services/LiveAudioStreamService.js';
import FlushService          from './services/FlushService.js';
import ApiLayerService       from './services/ApiLayerService.js';
import AlignmentShield       from './services/AlignmentShield.js';
import deepseekHarness      from './services/DeepseekHarnessService.js';
import { forecast as kronosForecast } from './services/KronosSeed.js';
import { zbierzWiadomosci, promptNastroju, SOURCES as RYNEK_SOURCES } from './services/RynekTunelService.js';
import {
    lista as dziennikLista, dodaj as dziennikDodaj,
    domknij as dziennikDomknij, podsumowanie as dziennikPodsumowanie,
} from './services/DziennikDecyzjiService.js';
import { zbudujMape } from './services/MapaSektorowService.js';
import {
    ETAPY as PRODUKCJA_ETAPY,
    lista as produkcjaLista, projekty as produkcjaProjekty, biblia as produkcjaBiblia,
    dodaj as produkcjaDodaj, zmien as produkcjaZmien, usun as produkcjaUsun,
    zbudujPrompt as produkcjaPrompt, statystyka as produkcjaStatystyka,
    promptSystemowyRozkladu, odczytajRozklad, znormalizujKwestie,
} from './services/ProdukcjaService.js';
import {
    listaPostaci, dodajPostac, usunPostac,
    pamiec as rezyserPamiec, listaSeriali, dodajFakt, usunFakt, dodajOdcinek, usunOdcinek,
    zmienOdcinek, dodajOdcinki, usunSerial, STATUSY as STATUSY_ODCINKA,
    zbudujKontekst, promptSystemowyRezysera, odczytajOdpowiedz, zdanieZWyniku, AKCJE_REZYSERA,
} from './services/RezyserService.js';
import {
    listaProjektow, utworzProjekt, usunProjekt, slug as slugProjektu,
    zapiszOdcinek, materialyOdcinka, katalogOdcinka,
} from './services/Produkcje.js';
import { promptUzupelnienia, oczysc as oczyscPoleAI } from './services/ProdukcjaAI.js';
import * as CiagDalszy from './services/CiagDalszy.js';
import * as Sekwencja from './services/Sekwencja.js';
import * as Realizacja from './services/RealizacjaOdcinka.js';
import * as MuzykaFilmowa from './services/MuzykaFilmowa.js';
import * as Biblioteka from './services/BibliotekaOdcinkow.js';
import * as Opowiesc from './services/PokojOpowiesci.js';
import * as PostProdukcja from './services/PostProdukcja.js';
import * as Blender from './services/Blender.js';
import * as Uniwersum from './services/Uniwersum.js';
import * as Scenografie from './services/Scenografie.js';
import * as Produkty from './services/Produkty.js';
import * as KolejkaKadrow from './services/KolejkaKadrow.js';
import * as Assety from './services/Assety.js';
import * as Oko from './services/Oko.js';
import * as Dialogi from './services/SciezkaDialogowa.js';
import * as Karta from './services/RuchNaKarcie.js';
import * as SilnikiObrazu from './services/SilnikiObrazu.js';
import * as Rezyserzy from './services/Rezyserzy.js';
import * as Rekopis from './services/Rekopis.js';
import * as Skryba from './services/Skryba.js';
import * as NocnaZmiana from './services/NocnaZmiana.js';
import * as Laboratorium from './services/Laboratorium.js';
import * as Delegat from './services/Delegat.js';
import * as Artemis from './services/Artemis.js';
import * as Tunel from './services/Tunel.js';
import * as Stado from './services/Stado.js';
import * as RealizacjaNocna from './services/RealizacjaNocna.js';
import * as TeledyskNowy from './services/TeledyskNowy.js';
import * as WarsztatUtworow from './services/WarsztatUtworow.js';
import * as Teterhia3D from './services/Teterhia3D.js';
import * as Wystawa from './services/Wystawa.js';
import * as GlosStudio from './services/GlosStudio.js';
import * as Montazownia from './services/Montazownia.js';
import * as MuzykaDoFilmu from './services/MuzykaDoFilmu.js';
import * as Arkusz from './services/ArkuszWielokat.js';
import * as Brief from './services/BriefOpowiesci.js';
import {
    strazMostu, wczytajLubUtworzKlucz, przekujKlucz, NAGLOWEK_KLUCZA,
} from './services/StrazMostu.js';
import CryptoAgility from './services/CryptoAgility.js';
import {
    katalogModeli as muzykaKatalogModeli,
    MANIFEST as MUZYKA_MANIFEST,
    status as muzykaModeleStatus,
    pull as muzykaModelePull,
    usun as muzykaModeleUsun,
    modelPoId as muzykaModelPoId,
} from './services/MuzykaModeleService.js';
import { buildDziennikHtml } from './services/dziennikTemplate.js';
import {
    attachStudioRelay,
    getStudioStatus,
    saveRtmpConfig,
    RECORDINGS_DIR,
} from './services/StudioRelayService.js';
import { attachGoscStudio, stanPokoi } from './services/GoscStudioService.js';
import {
    ZNANE_TOKENY, PLATFORMA_CG, saldaTokenow, cenyTokenow, cenyPoId,
} from './services/TokenyErc20Service.js';
import {
    SKARBIEC as SKARBIEC_GRV,
    listaModulow, dodajModul, usunModul, zapiszSubskrypcje, anulujSubskrypcje,
    listaWypraw, dodajWyprawe, usunWyprawe, zapiszWplate, stan as stanRejestru,
} from './services/ModulyService.js';
import {
    ocenPrace, zapiszWdech, stanOddechu, rejestrTrwalych,
} from './services/OddechService.js';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg';
import ffmpegPath from 'ffmpeg-static';
import ffprobeStatic from 'ffprobe-static';
import multer from 'multer';

const ffprobePath = ffprobeStatic.path;
ffmpeg.setFfmpegPath(ffmpegPath);
ffmpeg.setFfprobePath(ffprobePath);

// --- WEKTOROWE SOCZEWKI (EMBEDDINGS) ---
let wiesioBrain = null;

function calculateGravity(vecA, vecB) {
    let dotProduct = 0, normA = 0, normB = 0;
    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

(async () => {
    try {
        console.log('🧠 [Wiesio-Mózg] Budzę lokalne neurony... (To może potrwać chwilę przy pierwszym uruchomieniu)');
        const { pipeline } = await import('@xenova/transformers');

        // Ładujemy lekki, lokalny model do wektoryzacji tekstu
        wiesioBrain = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
        console.log('✨ [Wiesio-Mózg] Wektorowe Soczewki założone! Gotów do czytania Kronik!');
    } catch (err) {
        console.error('❌ [Wiesio-Mózg] Błąd przy zakładaniu soczewek:', err);
    }
})();

const app = express();
// Port z env — pozwala odpalic drugi most obok dzialajacego (testy) bez kolizji.
const PORT = Number(process.env.OTAKOS_BRIDGE_PORT) || 3001;

// 🐳 Docker/Live-USB: adres Ollamy z env (fallback lokalny IPv4 — dev bez zmian).
function normalizeOllamaBase(h) {
    let b = (h && String(h).trim()) || 'http://127.0.0.1:11434';
    if (!/^https?:\/\//i.test(b)) b = 'http://' + b;                       // brak protokołu
    b = b.replace('0.0.0.0', '127.0.0.1');                                 // 0.0.0.0 = nasłuch, nie klient
    const hostPort = b.replace(/^https?:\/\//i, '');
    if (!/:\d+/.test(hostPort)) b = b.replace(/\/+$/, '') + ':11434';      // brak portu
    return b.replace(/\/+$/, '');
}
const OLLAMA_BASE = normalizeOllamaBase(process.env.OLLAMA_HOST);

/**
 * 🧠 Domyślny rdzeń narracyjny — głos Joanny, Kronika, Dziennik, teledysk, storyboard.
 *
 * ⚠️ HISTORIA (naprawione 2026-07-30). Pięć endpointów miało wpisane na sztywno
 * `gemma3:4b` — model, którego NIE MA w instalacji Ollamy Suwerena, a `OTAKOS_MODEL`
 * nie było ustawione nigdzie. Każde wywołanie po cichu chybiało: Joanna spadała na
 * awaryjną `gemma3:1b` (0,8 GB) i mówiła łamaną polszczyzną („byntę słodki wiatr",
 * „Przeboowe dźwięki"), a Kronika/Dziennik/storyboard po prostu milczały.
 *
 * DLACZEGO `gemma4:e2b`, a nie `gemma4`: pełna `gemma4:latest` (9,6 GB) wywraca
 * backend na tej maszynie — `llama-server terminated: stack-based buffer overrun`.
 * Wariant `e2b` (7,2 GB) należy do tej samej rodziny, odpowiada poprawną polszczyzną
 * i nie wywala Ollamy. Zmierzone, nie założone.
 *
 * Podmiana bez ruszania kodu: zmienna środowiskowa `OTAKOS_MODEL`.
 */
const DEFAULT_LLM = process.env.OTAKOS_MODEL || 'gemma4:e2b';
/** Ostatnia deska ratunku — malutki model, byle kompan nie zamilkł całkiem. */
const FALLBACK_LLM = 'gemma3:1b';

// Ścieżki do folderów
const ANTIGRAVITY_DIR = path.join(process.cwd(), '_OtakOs_Wymiar');
const MUSIC_DIR = path.join(process.cwd(), '_OtakOs_Muzyka');
const MOVE_DIR = path.join(process.cwd(), '_OtakOs_Move');
const SONIC_DIR = path.join(process.cwd(), '_OtakOs_Sonic');
const BUILD_DIR = path.join(process.cwd(), '_OtakOs_Build');
const AI_DIR = path.join(process.cwd(), '_OtakOs_AI');
const MODELS_DIR = path.join(AI_DIR, 'models');
const TEMP_DIR = path.join(AI_DIR, 'temp');
const BIN_DIR = path.join(AI_DIR, 'bin');
const WHISPER_EXE = path.join(BIN_DIR, 'whisper-cli.exe');
const COMPONENTS_DIR = path.join(process.cwd(), '_OtakOs_Components'); // ← NOWOŚĆ od Klaudiusza
const AULA_DIR = path.join(process.cwd(), '_OtakOs_Aula'); // ← NOWOŚĆ od Suwerena
const RAFINERIA_TEMP_DIR = path.join(process.cwd(), '_temp'); // ← Rafineria: pliki tymczasowe webm/mp4


// Rozszerzenia audio
const AUDIO_EXTENSIONS = ['.mp3', '.wav', '.flac', '.m4a', '.ogg', '.opus'];

// Podstawowe middlewares
// 1. ROZBUDOWA OBSERWATORA PORTÓW W WIESIO-BRIDGE
const LOCAL_CHANNELS = {
  HUB: 'http://localhost:5176',
  MUSIC: 'http://localhost:5173',
  VIDEO: 'http://localhost:5174',
  NODES: 'http://localhost:5175',
  HUB_ALT: 'http://127.0.0.1:5176',
  MUSIC_ALT: 'http://127.0.0.1:5173',
  VIDEO_ALT: 'http://127.0.0.1:5174',
  NODES_ALT: 'http://127.0.0.1:5175'
};

// Kanały lokalne trzymamy dla czytelności (kto normalnie puka do Śluzy):
const KNOWN_ORIGINS = [
    LOCAL_CHANNELS.HUB,
    LOCAL_CHANNELS.MUSIC,
    LOCAL_CHANNELS.VIDEO,
    LOCAL_CHANNELS.NODES,
    LOCAL_CHANNELS.HUB_ALT,
    LOCAL_CHANNELS.MUSIC_ALT,
    LOCAL_CHANNELS.VIDEO_ALT,
    LOCAL_CHANNELS.NODES_ALT,
    'https://otakos.wtf',
    'http://localhost:3000',   // dev strony otakos.wtf (mapa AGI live)
    'http://127.0.0.1:3000'
];

app.use(cors({
    // 🛰️ Kwantowy Tunel (Cloudflare): smartfon puka z losowego origin
    // (*.trycloudflare.com), więc odbijamy KAŻDY origin — odpowiednik `origin: '*'`,
    // ale zgodny z `credentials: true` (przy gołej gwiazdce przeglądarka blokuje
    // żądania z ciasteczkami). Śluza i tak nasłuchuje tylko tam, gdzie Suweren ją wystawi.
    origin: true,
    // ⚠️ PATCH DOPISANY 2026-09-06. Bez niego przeglądarka odbijała żądanie już
    // na preflighcie, `fetch` rzucał wyjątek sieciowy, a klient meldował
    // „most milczy" — przy MOŚCIE, KTÓRY ODPOWIADAŁ. Objaw kłamał o przyczynie:
    // trasa PATCH istniała i działała z curla, blokada była po stronie CORS.
    methods:         ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    // ⚠️ 2026-09-17: brakowało tu nagłówka klucza Straży (x-teo-klucz). Skutek: gdy
    // Katedra miała zapisany klucz (po dispatchu na telefon), KAŻDE wywołanie z tym
    // nagłówkiem padało na preflighcie w 0,0 s — „Failed to fetch" przy moście, który
    // odpowiadał — a Auto-Panic robił z tego 32 zadania dla Mechanika.
    allowedHeaders:  ['Content-Type', 'Authorization', 'Accept', 'X-Requested-With', 'Cache-Control', 'x-teo-klucz'],
    exposedHeaders:  ['Content-Type', 'X-Error-Code', 'X-Przewod'],
    credentials:     true,
    maxAge:          86400,  // preflight cache 24h
}));

// Zwiększamy limit dla dużych plików video (Base64)
app.use(express.json({ limit: '2000mb' }));
app.use(express.urlencoded({ limit: '2000mb', extended: true }));

// ── STATYCZNY SERWER MUZYKI ──────────────────────────────────────────
// GET http://127.0.0.1:3001/music/nazwa.mp3  →  stream pliku
app.use('/music', cors({ origin: '*' }), express.static(MUSIC_DIR, {
    setHeaders: (res) => {
        res.setHeader('Accept-Ranges', 'bytes');  // seeking w przeglądarce
        res.setHeader('Cache-Control', 'no-cache');
    }
}));

const moveDir = path.join(__dirname, '_OtakOs_Move');
app.use('/move', express.static(moveDir));
app.use('/components', express.static(COMPONENTS_DIR));

// ── 🛰️ SUBSTRONY (Music V2 / Story V2 / App V2) — statycznie przez most ───────
// Na USB V_ZERO nie ma serwerów dev (5173/5174/5175), tylko most (3001) i Hub.
// Most zawsze żyje, więc serwuje zbudowane substrony pod /apps/{music,story,app}.
// express.static serwuje index.html dla katalogu (query params teleportu i hash
// routing działają po stronie klienta — fallback SPA zbędny). Buildy w public/apps/
// jadą z distro. UWAGA: Express 5 — żadnych gołych `*` w routach (crash boota).
const APPS_DIR = path.join(__dirname, 'public', 'apps');
for (const app_ of ['music', 'story', 'app', 'games', 'lab']) {
    const middlewares = [cors({ origin: '*' })];
    // 🎹 Teleport na Music V2 budzi ComfyUI. Suweren wchodzil do studia i dopiero
    // tam dowiadywal sie, ze silnik nie dziala — musial go odpalac recznie z .bat.
    // Hak siedzi po stronie SERWERA, wiec lapie kazda droge wejscia: kafel w
    // Projektach, dashboard, zakladke w przegladarce, Kwantowy Tunel z telefonu.
    // Nieblokujaco: strona laduje sie od razu, silnik wstaje w tle.
    if (app_ === 'music') {
        middlewares.push((req, res, next) => {
            zapewnijComfyUI('teleport na Music V2').catch(() => {});
            next();
        });
    }
    app.use(`/apps/${app_}`, ...middlewares, express.static(path.join(APPS_DIR, app_)));
}

// ── 📱 STRONA GOŚCIA (telefon jako kamera) ────────────────────────────────────
// Wpięta PRZED Strażą świadomie: telefon otwiera ją Kwantowym Tunelem, czyli
// jako żądanie ZDALNE, a kod QR nie niesie klucza sesji. Sama strona to statyczny
// HTML bez sekretów, więc wystawienie jej nic nie ujawnia.
// BRAMĄ JEST KOD POKOJU (6 znaków z 32-znakowego alfabetu). Najgorsze, co może
// zrobić ktoś obcy, kto zgadnie i adres, i kod, to WEPCHNĄĆ swój obraz do pokoju —
// a i tak nie trafi on na pulpit, dopóki Suweren świadomie nie kliknie „NA PULPIT".
// Odczytać stąd nie da się niczego.
app.use('/gosc', cors({ origin: '*' }), express.static(path.join(__dirname, 'public', 'gosc')));
// 📱 Delegat Mobilny — strona telefonu. Statyczna i bez klucza (to tylko HTML);
// klucz Straży telefon dostaje we fragmencie adresu (#k=…) i dokłada do każdego wywołania API.
app.use('/delegat', cors({ origin: '*' }), express.static(path.join(__dirname, 'public', 'delegat')));

// ── 🛡️ STRAŻ MOSTU ───────────────────────────────────────────────────────────
// Wpięta TUTAJ celowo: po trasach statycznych (żeby strumień muzyki i substrony
// działały na telefonie bez dokładania klucza do każdego <audio>), a PRZED całym
// API — bo to API potrafi uruchamiać komendy i zapisywać pliki.
//
// Maszyna Suwerena (localhost) przechodzi bez zmian. Żądanie z tunelu musi mieć
// klucz, a i tak nie uruchomi niczego, co zapisuje albo wykonuje. Ta druga
// warstwa jest ważniejsza od pierwszej: kod QR NIESIE klucz, więc zdjęcie ekranu
// znaczy wyciek klucza — ale nie przejęcie maszyny.
const KLUCZ_DIR = path.join(process.cwd(), '_OtakOs_Wymiar');
let KLUCZ_STRAZY = wczytajLubUtworzKlucz(KLUCZ_DIR);
const PELNY_TUNEL = process.env.OTAKOS_TUNEL_PELNY === '1';

app.use(strazMostu({ klucz: () => KLUCZ_STRAZY, pelnyTunel: PELNY_TUNEL }));

/** Klucz wydajemy WYŁĄCZNIE maszynie lokalnej — stąd trafia do linku QR. */
app.get('/api/straz/klucz', (req, res) => {
    if (!req.lokalny) return res.status(403).json({ success: false, message: 'Tylko z maszyny Suwerena.' });
    return res.json({ success: true, klucz: KLUCZ_STRAZY, naglowek: NAGLOWEK_KLUCZA, pelnyTunel: PELNY_TUNEL });
});

/** Przekucie klucza — ratunek, gdy kod QR wyciekł (zdjęcie, stream, cudze oko). */
app.post('/api/straz/przekuj', async (req, res) => {
    if (!req.lokalny) return res.status(403).json({ success: false, message: 'Tylko z maszyny Suwerena.' });
    try {
        KLUCZ_STRAZY = await przekujKlucz(KLUCZ_DIR);
        return res.json({ success: true, klucz: KLUCZ_STRAZY, message: 'Klucz przekuty — stare kody QR i linki są martwe.' });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

// Inicjalizacja folderów
async function initializeDimension() {
    for (const dir of [ANTIGRAVITY_DIR, path.join(ANTIGRAVITY_DIR, 'Arcade'), MUSIC_DIR, MOVE_DIR, SONIC_DIR, BUILD_DIR, AI_DIR, MODELS_DIR, TEMP_DIR, BIN_DIR, COMPONENTS_DIR, AULA_DIR, RAFINERIA_TEMP_DIR]) {
        try {
            await fs.mkdir(dir, { recursive: true });
        } catch (e) {
            console.error(`[Wiesio-Bridge] Błąd tworzenia folderu:`, e);
        }
    }


    console.log(`[Wiesio-Bridge] 📁 Dane:   ${ANTIGRAVITY_DIR}`);
    console.log(`[Wiesio-Bridge] 🕹️ Arcade: ${path.join(ANTIGRAVITY_DIR, 'Arcade')}`);
    console.log(`[Wiesio-Bridge] 🎵 Muzyka: ${MUSIC_DIR}`);
    console.log(`[Wiesio-Bridge] 🎬 Filmy:  ${MOVE_DIR}`);
    console.log(`[Wiesio-Bridge] 🔊 Sonic:  ${SONIC_DIR}`);
    console.log(`[Wiesio-Bridge] 🏗  Build:  ${BUILD_DIR}`);
    console.log(`[Wiesio-Bridge] 🎨 Komponenty : ${COMPONENTS_DIR}`);
    console.log(`[Wiesio-Bridge] 🏛️ Aula Budowy: ${AULA_DIR}`);
}
initializeDimension();

// ── FUNKCJA REKURENCYJNA ─────────────────────────────────────────────
async function getAudioFilesRecursive(dir) {
    let results = [];
    try {
        const list = await fs.readdir(dir, { withFileTypes: true });
        for (const file of list) {
            const fullPath = path.join(dir, file.name);
            if (file.isDirectory()) {
                results = results.concat(await getAudioFilesRecursive(fullPath));
            } else {
                const ext = path.extname(file.name).toLowerCase();
                if (AUDIO_EXTENSIONS.includes(ext)) {
                    results.push(fullPath);
                }
            }
        }
    } catch (e) {
        console.error(`[Wiesio-Bridge] Błąd skanowania folderu ${dir}:`, e);
    }
    return results;
}

// ── AUTOSYNC LRC (AI) ────────────────────────────────────────────────
app.post('/api/bridge/autosync', async (req, res) => {
    let { audioPath, text, model = 'small' } = req.body;

    if (!audioPath || !text) {
        return res.status(400).json({ success: false, message: 'Brak audioPath lub text' });
    }

    // [DEKODER URL]: Wiesio musi rozumieć fizyczne ścieżki (spacje), a nie %20 z frontendu
    audioPath = decodeURIComponent(audioPath);
    console.log(`[Wiesio-AI] 🔓 Zdekodowano ścieżkę dla Auto-Sync: ${audioPath}`);

    try {
        // 1. Znalezienie fizycznego pliku
        // NAPRAWA URL: obsługujemy localhost, 127.0.0.1 i bare filename (relatywny do muzyki)
        const MUSIC_URL_PATTERNS = [
            'http://127.0.0.1:3001/music/',
            'http://localhost:3001/music/',
        ];
        let resolvedPath = audioPath;
        for (const pattern of MUSIC_URL_PATTERNS) {
            if (resolvedPath.includes(pattern)) {
                resolvedPath = resolvedPath.replace(pattern, '_OtakOs_Muzyka/');
                break;
            }
        }
        // Jeśli to bare filename (np. "Artysta/Song.mp3") bez prefiksu muzyki — dodaj go
        if (!path.isAbsolute(resolvedPath) && !resolvedPath.startsWith('_OtakOs_Muzyka') && !resolvedPath.startsWith('http')) {
            resolvedPath = path.join('_OtakOs_Muzyka', resolvedPath);
        }
        const fullAudioPath = path.isAbsolute(resolvedPath)
            ? resolvedPath
            : path.join(process.cwd(), resolvedPath);

        if (!fsSync.existsSync(fullAudioPath)) {
            console.error(`[Wiesio-AI] ❌ Plik nie istnieje: ${fullAudioPath}`);
            return res.status(404).json({ success: false, message: `Plik audio nie został znaleziony: ${fullAudioPath}` });
        }

        // 2. Przygotowanie Audio (FFmpeg)
        const tempAudioPath = path.join(TEMP_DIR, `whisper_input_${Date.now()}.wav`);
        console.log(`[Wiesio-AI] 🏭 Przygotowuję audio (konwersja do 16kHz)...`);

        // REFAKTORYZACJA: Używamy execFileAsync + Tablica Argumentów (Koniec piekła cudzysłowów!)
        await execFileAsync(ffmpegPath, ['-i', fullAudioPath, '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', '-y', tempAudioPath]);

        // 3. Sprawdzenie modelu i silnika
        const modelPath = path.join(MODELS_DIR, `ggml-${model}.bin`);
        if (!fsSync.existsSync(modelPath)) {
            return res.status(400).json({
                success: false,
                message: `Brak modelu: ${model}. Pobierz go do folderu _OtakOs_AI/models/ jako ggml-${model}.bin`,
                hint: `https://huggingface.co/ggerganov/whisper.cpp/tree/main`
            });
        }

        if (!fsSync.existsSync(WHISPER_EXE)) {
            return res.status(400).json({
                success: false,
                message: "Brak silnika AI (whisper-cli.exe).",
                hint: "Pobierz whisper.cpp binarki i wypakuj do _OtakOs_AI/bin/."
            });
        }

        // 4. Odpalenie Silnika AI (Whisper.cpp)
        console.log(`[Wiesio-AI] 🤖 Odpalam silnik neuronowy (Whisper.cpp)...`);
        const outputBasePath = path.join(TEMP_DIR, 'whisper_output_' + Date.now());
        const jsonFilePath = outputBasePath + '.json';

        // REFAKTORYZACJA: execFileAsync dla Whispera (Ustawiamy cwd, aby binarka widziała swoje DLLe!)
        try {
            const { stderr } = await execFileAsync(
                WHISPER_EXE,
                ['-m', modelPath, '-f', tempAudioPath, '--output-json-full', '-p', '4', '-l', 'pl', '-of', outputBasePath],
                { cwd: BIN_DIR }
            );
            if (stderr) console.log(`[Wiesio-AI] 🤖 STDERR Whispera:\n${stderr}`);
        } catch (error) {
            console.error("❌ Błąd Fazy 3 (execFile):", error.message);
            console.error("Szczegóły błędu (stderr):", error.stderr || error.message);
            throw new Error(`Silnik AI (whisper.cpp) napotkał problem: ${error.message}`);
        }

        // 5. Odczyt i Parsowanie Wyników AI
        if (!fsSync.existsSync(jsonFilePath)) throw new Error("Silnik AI nie wygenerował pliku wynikowego.");
        const aiOutput = JSON.parse(fsSync.readFileSync(jsonFilePath, 'utf8'));

        // Helper do formatowania czasu LRC: [mm:ss.xx]
        // NAPRAWA NaN: explicit cast + guard przed NaN/Infinity
        const formatLRCTime = (seconds) => {
            const s = Number(seconds);
            if (!Number.isFinite(s) || s < 0) return '[00:00.00]';
            const mins = Math.floor(s / 60);
            const secs = Math.floor(s % 60);
            const ms   = Math.floor((s % 1) * 100);
            return `[${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}]`;
        };

        // 6. Algorytm Dopasowania — WHISPER daje oś czasu, JOANNA (LLM) przypina wersy.
        // Whisper.cpp zwraca 'transcription' -> segmenty {text, offsets:{from,to} w ms}.
        const segments = aiOutput.transcription || [];
        const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);

        // Oś czasu z audio (segment-level — dużo stabilniejsze niż pojedyncze tokeny).
        const timeline = segments
            .map(s => ({ t: (s.offsets?.from ?? 0) / 1000, text: String(s.text || '').trim() }))
            .filter(s => s.text)
            .sort((a, b) => a.t - b.t);
        const audioEnd = timeline.length ? timeline[timeline.length - 1].t + 3 : lines.length * 3;

        // Twardy bezpiecznik: czasy TYLKO rosną (koniec skoków w tył jak 49s->2s).
        const clampMonotonic = (arr) => {
            let prev = -0.001;
            return arr.map(v => { const t = Math.max(Number(v) || 0, prev + 0.25); prev = t; return t; });
        };

        // 6a. JOANNA (LLM) — rozumie SENS tekstu i dopasowuje wersy do osi czasu.
        let times = null;
        if (timeline.length >= 2) {
            const tlStr = timeline.map(s => `[${s.t.toFixed(1)}] ${s.text}`).join('\n').slice(0, 4000);
            const lyrStr = lines.map((l, i) => `${i + 1}: ${l}`).join('\n').slice(0, 4000);
            const prompt =
`Masz PRAWDZIWY tekst piosenki (ponumerowane wersy) i przybliżoną transkrypcję audio ze znacznikami czasu w sekundach (auto, słowa bywają błędne, ale CZASY są z nagrania). Przypisz każdemu wersowi moment, w którym jest śpiewany, wg osi czasu transkrypcji.
ZASADY: czasy TYLKO rosną (nigdy w tył); wers-pauza dostaje czas między sąsiadami; ostatni czas <= ${audioEnd.toFixed(0)}s.
Zwróć WYŁĄCZNIE tablicę JSON długości ${lines.length}: [{"i":1,"t":0.0},{"i":2,"t":3.4},...]. Bez komentarza.

TEKST (wersy):
${lyrStr}

TRANSKRYPCJA Z CZASAMI:
${tlStr}`;
            const model = process.env.OTAKOS_MODEL || 'gemma4';
            let raw = await genOllama(prompt, model, 60000);
            if (!raw) raw = await genOllama(prompt, 'gemma3:1b', 45000);
            const m = raw && raw.match(/\[[\s\S]*\]/);
            if (m) {
                try {
                    const parsed = JSON.parse(m[0]);
                    if (Array.isArray(parsed) && parsed.length >= Math.floor(lines.length * 0.6)) {
                        const byIdx = new Map(parsed.map(o => [Number(o.i), Number(o.t)]));
                        times = lines.map((_, i) => {
                            const t = byIdx.get(i + 1);
                            return Number.isFinite(t) ? t : NaN;
                        });
                        // Uzupełnij dziury interpolacją liniową między znanymi punktami.
                        for (let i = 0; i < times.length; i++) {
                            if (!Number.isFinite(times[i])) {
                                let a = i - 1; while (a >= 0 && !Number.isFinite(times[a])) a--;
                                let b = i + 1; while (b < times.length && !Number.isFinite(times[b])) b++;
                                const ta = a >= 0 ? times[a] : 0;
                                const tb = b < times.length ? times[b] : audioEnd;
                                times[i] = ta + (tb - ta) * ((i - a) / Math.max(1, b - a));
                            }
                        }
                        console.log(`[Wiesio-AI] 🐣 Joanna dopasowała ${parsed.length}/${lines.length} wersów (model: ${model}).`);
                    }
                } catch { /* zły JSON — spadamy na word-match */ }
            }
        }

        // 6b. Fallback: word-matching po pierwszym słowie wersu (gdy Joanna/LLM milczy).
        if (!times) {
            const allWords = segments.flatMap(seg => seg.tokens || []);
            let lastWordIdx = 0;
            times = lines.map(lineText => {
                const firstWord = lineText.toLowerCase().split(/\s+/)[0].replace(/[.,?!]/g, '');
                let foundIdx = -1;
                for (let i = lastWordIdx; i < allWords.length; i++) {
                    const w = allWords[i].text.toLowerCase().trim().replace(/[.,?!]/g, '');
                    if (w.length >= 2 && firstWord.length >= 2 && (w.includes(firstWord) || firstWord.includes(w))) { foundIdx = i; break; }
                }
                if (foundIdx !== -1) { lastWordIdx = foundIdx + 1; return (allWords[foundIdx].offsets?.from ?? 0) / 1000; }
                return NaN;
            });
            // dziury → interpolacja
            for (let i = 0; i < times.length; i++) if (!Number.isFinite(times[i])) {
                let a = i - 1; while (a >= 0 && !Number.isFinite(times[a])) a--;
                let b = i + 1; while (b < times.length && !Number.isFinite(times[b])) b++;
                const ta = a >= 0 ? times[a] : 0, tb = b < times.length ? times[b] : audioEnd;
                times[i] = ta + (tb - ta) * ((i - a) / Math.max(1, b - a));
            }
            console.log(`[Wiesio-AI] 🔤 Fallback word-match (LLM niedostępny).`);
        }

        // Bezpiecznik monotoniczności + zbudowanie wyniku.
        const safeTimes = clampMonotonic(times);
        const syncedLines = lines.map((lineText, i) => ({
            time: safeTimes[i],
            timestamp: formatLRCTime(safeTimes[i]),
            text: lineText,
        }));

        // 7. Finalizacja i Porządki
        try {
            fsSync.unlinkSync(tempAudioPath);
            fsSync.unlinkSync(jsonFilePath);
        } catch (_) { }

        console.log(`[Wiesio-AI] ✅ Synchronizacja zakończona! Zmapowano ${syncedLines.length} linii.`);
        return res.json({ success: true, syncedLines });

    } catch (e) {
        console.error(`[Wiesio-AI] ❌ Błąd Fazy 3:`, e.message);
        return res.status(500).json({ success: false, message: `Błąd AI Faza 3: ${e.message}` });
    }
});



// ── KLUCZ ANTHROPIC (Dla Klaudiusza) ──────────────────────────────────
// Kolejność priorytetów: req.body.apiKey → env → .anthropic_key → kibel_anthropic.txt
async function getAnthropicKey(reqApiKey) {
    if (reqApiKey && reqApiKey.startsWith('sk-ant-')) return reqApiKey;
    if (process.env.ANTHROPIC_API_KEY) return process.env.ANTHROPIC_API_KEY;
    try {
        const key = await fs.readFile(path.join(process.cwd(), '.anthropic_key'), 'utf8');
        const match = key.match(/(sk-ant-[a-zA-Z0-9-_]+)/);
        if (match) return match[1];
    } catch { }
    try {
        const key = await fs.readFile(path.join(ANTIGRAVITY_DIR, 'kibel_anthropic.txt'), 'utf8');
        const match = key.match(/(sk-ant-[a-zA-Z0-9-_]+)/);
        if (match) return match[1];
    } catch { }
    return null;
}

// ── KLUCZ GEMINI (Google) ──────────────────────────────────────────────
// Kolejność priorytetów: req.body.apiKey → env → .gemini_key → kibel_gemini.txt
async function getGeminiKey(reqApiKey) {
    if (reqApiKey && reqApiKey.startsWith('AIza')) return reqApiKey;
    if (process.env.GEMINI_API_KEY) return process.env.GEMINI_API_KEY;
    try {
        const key = await fs.readFile(path.join(process.cwd(), '.gemini_key'), 'utf8');
        const match = key.match(/(AIza[a-zA-Z0-9_-]+)/);
        if (match) return match[1];
    } catch { }
    try {
        const key = await fs.readFile(path.join(ANTIGRAVITY_DIR, 'kibel_gemini.txt'), 'utf8');
        const match = key.match(/(AIza[a-zA-Z0-9_-]+)/);
        if (match) return match[1];
    } catch { }
    return null;
}

// ══════════════════════════════════════════════════════════════════
//  KATEDRA TOOLS — narzędzia dla agentów (prywatny MCP Katedry)
// ══════════════════════════════════════════════════════════════════
const KATEDRA_TOOLS = [
    {
        name: 'list_files',
        description: 'Lista plików w _OtakOs_Wymiar/',
        input_schema: { type: 'object', properties: {}, required: [] },
    },
    {
        name: 'read_file',
        description: 'Odczytaj plik z _OtakOs_Wymiar/',
        input_schema: { type: 'object', properties: { filename: { type: 'string' } }, required: ['filename'] },
    },
    {
        name: 'write_file',
        description: 'Zapisz plik do _OtakOs_Build/',
        input_schema: { type: 'object', properties: { filename: { type: 'string' }, content: { type: 'string' } }, required: ['filename', 'content'] },
    },
    {
        name: 'list_components',
        description: 'Lista zbudowanych komponentów w _OtakOs_Components/',
        input_schema: { type: 'object', properties: {}, required: [] },
    },
    {
        name: 'save_component',
        description: 'Zapisz gotowy komponent React/TSX do biblioteki _OtakOs_Components/',
        input_schema: {
            type: 'object',
            properties: {
                filename: { type: 'string', description: 'np. PięknyPrzycisk.tsx' },
                content: { type: 'string', description: 'Pełny kod komponentu' },
                tags: { type: 'array', items: { type: 'string' }, description: 'Tagi np. ["button","animated","framer-motion"]' },
                description: { type: 'string', description: 'Krótki opis komponentu' },
            },
            required: ['filename', 'content'],
        },
    },
    {
        name: 'ollama_list',
        description: 'Lista lokalnych modeli Ollama',
        input_schema: { type: 'object', properties: {}, required: [] },
    },
    {
        name: 'ollama_chat',
        description: 'Wyślij prompt do lokalnego modelu Ollama i odbierz odpowiedź',
        input_schema: {
            type: 'object',
            properties: {
                model: { type: 'string' },
                prompt: { type: 'string' },
            },
            required: ['model', 'prompt'],
        },
    },
    {
        name: 'get_playlist',
        description: 'Lista plików muzycznych',
        input_schema: { type: 'object', properties: {}, required: [] },
    },
    {
        name: 'read_project_structure',
        description: 'Przeskanuj strukturę projektu Vite/React (src/) aby rozumieć istniejący kod',
        input_schema: {
            type: 'object',
            properties: {
                projectPath: { type: 'string', description: 'Ścieżka do projektu, domyślnie cwd' },
            },
            required: [],
        },
    },
];

async function executeTool(toolName, toolInput) {
    console.log(`[Wiesio-Bridge] 🔧 Tool: ${toolName}`, JSON.stringify(toolInput).substring(0, 100));

    switch (toolName) {
        case 'list_files': {
            try {
                const entries = await fs.readdir(ANTIGRAVITY_DIR, { withFileTypes: true });
                return { success: true, files: entries.map(e => ({ name: e.name, type: e.isDirectory() ? 'dir' : 'file' })) };
            } catch (e) { return { success: false, error: e.message }; }
        }

        case 'read_file': {
            try {
                const content = await fs.readFile(path.join(ANTIGRAVITY_DIR, toolInput.filename), 'utf8');
                return { success: true, content };
            } catch (e) { return { success: false, error: e.message }; }
        }

        case 'write_file': {
            try {
                const fp = path.join(BUILD_DIR, toolInput.filename);
                await fs.writeFile(fp, toolInput.content, 'utf8');
                return { success: true, path: fp, filename: toolInput.filename };
            } catch (e) { return { success: false, error: e.message }; }
        }

        case 'list_components': {
            try {
                const entries = await fs.readdir(COMPONENTS_DIR, { withFileTypes: true });
                const components = [];
                for (const e of entries) {
                    if (!e.isFile()) continue;
                    const metaFile = path.join(COMPONENTS_DIR, e.name + '.meta.json');
                    let meta = {};
                    try { meta = JSON.parse(await fs.readFile(metaFile, 'utf8')); } catch { }
                    components.push({ filename: e.name, ...meta });
                }
                return { success: true, components, count: components.length };
            } catch (e) { return { success: false, error: e.message }; }
        }

        case 'save_component': {
            try {
                const fp = path.join(COMPONENTS_DIR, toolInput.filename);
                await fs.writeFile(fp, toolInput.content, 'utf8');
                const meta = {
                    filename: toolInput.filename,
                    description: toolInput.description || '',
                    tags: toolInput.tags || [],
                    created: new Date().toISOString(),
                    size: toolInput.content.length,
                };
                await fs.writeFile(fp + '.meta.json', JSON.stringify(meta, null, 2), 'utf8');
                console.log(`[Wiesio-Bridge] 🎨 Komponent zapisany: ${fp}`);
                return { success: true, path: fp, filename: toolInput.filename, meta };
            } catch (e) { return { success: false, error: e.message }; }
        }

        case 'ollama_list': {
            try {
                const { stdout } = await execAsync('ollama list', { timeout: 8000 });
                const models = stdout.trim().split('\n').slice(1).filter(l => l.trim()).map(l => l.trim().split(/\s+/)[0]);
                return { success: true, models };
            } catch (e) { return { success: false, error: 'Ollama offline: ' + e.message }; }
        }

        case 'ollama_chat': {
            try {
                const esc = (toolInput.prompt || '').replace(/"/g, '\\"').replace(/\n/g, ' ');
                const { stdout } = await execAsync(`ollama run ${toolInput.model} "${esc}"`, {
                    timeout: 90000, maxBuffer: 5 * 1024 * 1024, shell: true,
                });
                return { success: true, response: stdout.trim(), model: toolInput.model };
            } catch (e) { return { success: false, error: e.message }; }
        }

        case 'get_playlist': {
            try {
                const entries = await fs.readdir(MUSIC_DIR, { withFileTypes: true });
                const tracks = entries
                    .filter(e => e.isFile() && AUDIO_EXTENSIONS.includes(path.extname(e.name).toLowerCase()))
                    .map(e => e.name);
                return { success: true, tracks, count: tracks.length };
            } catch (e) { return { success: false, error: e.message }; }
        }

        case 'read_project_structure': {
            try {
                const projectPath = toolInput.projectPath || process.cwd();
                const structure = await scanDirectory(projectPath, 3);
                return { success: true, structure, projectPath };
            } catch (e) { return { success: false, error: e.message }; }
        }

        default:
            return { success: false, error: `Nieznane narzędzie: ${toolName}` };
    }
}

async function scanDirectory(dirPath, maxDepth, currentDepth = 0) {
    if (currentDepth >= maxDepth) return '...';
    try {
        const entries = await fs.readdir(dirPath, { withFileTypes: true });
        const result = {};
        for (const entry of entries) {
            if (['node_modules', '.git', 'dist', '.next'].includes(entry.name)) continue;
            if (entry.isDirectory()) {
                result[entry.name + '/'] = await scanDirectory(
                    path.join(dirPath, entry.name), maxDepth, currentDepth + 1
                );
            } else {
                result[entry.name] = null;
            }
        }
        return result;
    } catch { return {}; }
}

// ── /api/ollama — Ollama proxy z SSE streamingiem ──────────────────────
//
// Diagnostyka błędów Ollamy:
//   ECONNREFUSED  — ollama serve nie działa (port 11434 zamknięty)
//   AbortError    — timeout 120s (zimny start VRAM gemma4)
//   HTTP 4xx/5xx  — model nie istnieje lub błąd Ollamy
//
// UWAGA: używamy 127.0.0.1 (IPv4) zamiast localhost — Node 18+ rozwiązuje
// localhost → ::1 (IPv6), co może failować gdy Ollama słucha tylko na IPv4.
app.post('/api/ollama', async (req, res) => {
    const { messages, system, model = 'gemma4' } = req.body;
    if (!messages?.length) return res.status(400).json({ error: 'Brak messages' });

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('X-Accel-Buffering', 'no');  // wyłącz buforowanie nginxa jeśli jest proxy

    const sendEvent = (data) => {
        try { res.write(`data: ${JSON.stringify(data)}\n\n`); } catch { /* client rozłączony */ }
    };

    const ollamaMessages = [
        ...(system ? [{ role: 'system', content: system }] : []),
        ...messages,
    ];

    // ── Timeout: 300s (VRAM Breathing v2) — pełna swoboda alokacji VRAM gemma4
    // przy zimnym starcie na obciążonej maszynie. Podniesione ze 120s po teście
    // bojowym, w którym Ollama przerywała operację podczas ładowania modelu.
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 300_000);

    try {
        const resp = await fetch(`${OLLAMA_BASE}/api/chat`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            signal:  controller.signal,
            body:    JSON.stringify({ model, messages: ollamaMessages, stream: true, options: { num_ctx: 8192 } }),
        });

        if (!resp.ok) {
            sendEvent({
                type:  'error',
                error: `Ollama HTTP ${resp.status} — model "${model}" istnieje? Sprawdź: ollama list`,
                code:  `HTTP_${resp.status}`,
            });
            return res.end();
        }

        const reader  = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() ?? '';
            for (const line of lines) {
                if (!line.trim()) continue;
                try {
                    const chunk = JSON.parse(line);
                    if (chunk.message?.content) sendEvent({ type: 'text', text: chunk.message.content });
                    if (chunk.done)             sendEvent({ type: 'done' });
                } catch { /* pomiń złośliwy JSON */ }
            }
        }
    } catch (e) {
        const isAbort = e.name === 'AbortError';
        // Wydobądź dokładny kod Node.js (ECONNREFUSED, ETIMEDOUT, itp.)
        const errCode = e.code || e.cause?.code || (isAbort ? 'ABORT' : 'UNKNOWN');
        const detail  = isAbort
            ? `TIMEOUT — Ollama milczy >120s. Czy gemma4 jest załadowany? (ollama pull gemma4)`
            : `${errCode}: ${e.message}`;

        console.error(`[/api/ollama] ❌ ${detail}`);
        sendEvent({ type: 'error', error: `Ollama niedostępna: ${detail}`, code: errCode });
    } finally {
        clearTimeout(timer);
    }

    res.end();
});

// ── /api/ollama/models — lista dostępnych modeli ────────────────────────
/**
 * POST /api/ollama/pisz — jedno wywolanie modelu BEZ strumienia.
 *
 * `/api/ollama` oddaje SSE, co jest dobre dla czatu, ale StoryLoom (Story V2)
 * chce calego fragmentu naraz. Parsowanie strumienia po stronie kazdej aplikacji
 * z osobna to trzy implementacje tego samego — lepiej jedna trasa.
 */
app.post('/api/ollama/pisz', async (req, res) => {
    const { model, system, prompt } = req.body ?? {};
    if (!prompt?.trim()) return res.status(400).json({ success: false, message: 'Brak "prompt".' });
    const silnik = model || process.env.OTAKOS_MODEL || 'gemma4:e2b';
    try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 300000);
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
            // ⚠️ think:false — modele qwen3.x bez tego przepalają budżet na myślenie i oddają
            // PUSTĄ treść (zmierzone: eval_count 60, response ""). Gemma to ignoruje.
            body: JSON.stringify({ model: silnik, system, prompt, stream: false, think: false }),
        });
        clearTimeout(t);
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
        const d = await r.json();
        res.json({
            success: true,
            tekst: String(d.response || '').trim(),
            model: silnik,
            tokeny: (Number(d.eval_count) || 0) + (Number(d.prompt_eval_count) || 0),
        });
    } catch (e) {
        const powod = e.name === 'AbortError' ? 'Ollama nie zdazyla (300 s).' : e.message;
        res.status(500).json({ success: false, message: powod });
    }
});

app.get('/api/ollama/models', async (req, res) => {
    try {
        const resp = await fetch(`${OLLAMA_BASE}/api/tags`);
        if (!resp.ok) return res.json({ models: [], error: `Ollama HTTP ${resp.status}` });
        const data = await resp.json();
        const models = (data.models || []).map(m => m.name);
        res.json({ models });
    } catch (e) {
        const code = e.code || e.cause?.code || 'UNKNOWN';
        res.json({ models: [], error: `${code}: ${e.message}` });
    }
});

// ── /api/ollama/diffusion — SZKIELET pod DiffusionGemma (26B MoE Text Diffusion) ──
//
// Status: PRZYGOTOWANIE PORTU. Silnik nieaktywny (DIFFUSION_ENGINE_ACTIVE: false
// w models_config.json). W przyszłości ten endpoint NIE pójdzie do standardowego
// /api/generate Ollamy, lecz do potoku odszumiania tekstu (text diffusion):
//
//   frontend → POST /api/ollama/diffusion
//            → Python bridge (HuggingFace Transformers, denoising loop)
//            → 4x szybsza generacja (równoległe odszumianie zamiast autoregresji)
//            → SSE stream z powrotem
//
// Dopóki backend Pythona nie jest wpięty, endpoint odpowiada 503 z czytelnym
// komunikatem — NIE crashuje mostu ani nie udaje że model działa.
app.post('/api/ollama/diffusion', async (req, res) => {
    const { messages, system, model = '__diffusion__' } = req.body ?? {};

    // Wczytaj flagę z models_config.json (single source of truth)
    let engineActive = false;
    try {
        const cfgRaw = await fs.readFile(path.join(__dirname, 'models_config.json'), 'utf8');
        engineActive = JSON.parse(cfgRaw)?.engines?.diffusion?.DIFFUSION_ENGINE_ACTIVE === true;
    } catch { /* brak configu → silnik traktujemy jako nieaktywny */ }

    if (!engineActive) {
        console.log('[Diffusion] 🧬 Zapytanie odrzucone — silnik nieaktywny (DIFFUSION_ENGINE_ACTIVE: false).');
        return res.status(503).json({
            success: false,
            code:    'DIFFUSION_ENGINE_INACTIVE',
            error:   'DiffusionGemma (26B MoE) jeszcze nie wpięty. Szkielet portu gotowy — ' +
                     'aktywuj DIFFUSION_ENGINE_ACTIVE w models_config.json po podłączeniu backendu Python.',
            engine:  'diffusion',
            model,
        });
    }

    // ── Przyszła implementacja (gdy backend Python wstanie) ──────────────────
    // const resp = await fetch('http://127.0.0.1:8000/diffusion/denoise', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify({ messages, system, model, steps: 8 }),
    // });
    // ... SSE streaming odszumionego tekstu ...
    void messages; void system;  // placeholder — sygnalizuje przyszłe użycie

    return res.status(501).json({
        success: false,
        code:    'NOT_IMPLEMENTED',
        error:   'Potok odszumiania tekstu nie jest jeszcze zaimplementowany (backend Python wymagany).',
    });
});

// ── /api/agents — Dynamiczny rejestr agentów z Agency 33 ───────────────
app.get('/api/agents', async (req, res) => {
    const agents = await getAgentsList();
    res.json({ success: true, agents });
});

// ── /api/ocr/review — Uruchomienie OpenCodeReview ─────────────────────
app.post('/api/ocr/review', async (req, res) => {
    const { from, to, commit, repo } = req.body;
    const result = await runCodeReview({ from, to, commit, repo });
    res.json(result);
});

// ── /v1/embeddings — OpenAI-compatible Embeddings zasilane Wiesio-Mózgiem ──
app.post('/v1/embeddings', async (req, res) => {
    if (!wiesioBrain) {
        return res.status(503).json({ error: { message: 'Mózg wektorowy (Wiesio-Brain) się jeszcze ładuje!' } });
    }

    const { input, model } = req.body;
    if (!input) {
        return res.status(400).json({ error: { message: 'Brak pola input.' } });
    }

    try {
        const inputs = Array.isArray(input) ? input : [input];
        const data = [];

        for (let i = 0; i < inputs.length; i++) {
            const text = inputs[i];
            const output = await wiesioBrain(text, { pooling: 'mean', normalize: true });
            data.push({
                object: 'embedding',
                index: i,
                embedding: Array.from(output.data)
            });
        }

        res.json({
            object: 'list',
            data,
            model: model || 'all-MiniLM-L6-v2'
        });
    } catch (e) {
        console.error('[Embeddings API] Błąd:', e.message);
        res.status(500).json({ error: { message: e.message } });
    }
});

// ── /api/open-notebook/* — Proxy do REST API Open Notebook ────────────
app.use('/api/open-notebook', cors({ origin: '*' }), async (req, res) => {
    const host = process.env.OPEN_NOTEBOOK_HOST || 'http://localhost:5055';
    const targetUrl = `${host}${req.url}`;
    
    try {
        const options = {
            method: req.method,
            headers: {
                ...req.headers,
                host: undefined
            }
        };

        if (req.method !== 'GET' && req.method !== 'HEAD') {
            options.body = JSON.stringify(req.body);
        }

        const resp = await fetch(targetUrl, options);
        
        res.status(resp.status);
        for (const [key, value] of resp.headers.entries()) {
            res.setHeader(key, value);
        }
        
        const text = await resp.text();
        res.send(text);
    } catch (e) {
        console.error(`[OpenNotebook Proxy] Błąd:`, e.message);
        res.status(502).json({ success: false, error: e.message });
    }
});

// ── /api/claude — Claude proxy z pełną pętlą agentyczną ────────────────
app.post('/api/claude', async (req, res) => {
    // 🛡️ Samoczyszczenie VRAM przed alokacją kontekstu modelu
    executeTacosGuard();

    const { messages, system, model = 'claude-sonnet-4-20250514', useTools = true, apiKey: reqApiKey, agent } = req.body;
    if (!messages?.length) return res.status(400).json({ error: 'Brak messages' });

    const apiKey = await getAnthropicKey(reqApiKey);
    if (!apiKey) return res.status(401).json({ error: 'Brak klucza Anthropic — dodaj go w TeO Kibel (sk-ant-...)' });

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', '*');

    const sendEvent = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    try {
        const finalSystem = await getMergedSystemPrompt(agent, system);

        let currentMessages = [...messages];
        let rounds = 0;
        const MAX_ROUNDS = 10;

        while (rounds < MAX_ROUNDS) {
            rounds++;
            const body = {
                model, max_tokens: 8096, stream: true,
                messages: currentMessages,
                ...(finalSystem ? { system: finalSystem } : {}),
                ...(useTools ? { tools: KATEDRA_TOOLS } : {}),
            };

            const resp = await fetch('https://api.anthropic.com/v1/messages', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
                body: JSON.stringify(body),
            });

            if (!resp.ok) {
                const err = await resp.json().catch(() => ({}));
                sendEvent({ type: 'error', error: err?.error?.message || `HTTP ${resp.status}` });
                break;
            }

            const reader = resp.body.getReader();
            const decoder = new TextDecoder();
            let buf = '', fullText = '', toolCalls = [], currentTool = null, stopReason = null;

            while (true) {
                const { value, done } = await reader.read();
                if (done) break;
                buf += decoder.decode(value, { stream: true });
                const lines = buf.split('\n');
                buf = lines.pop() ?? '';

                for (const line of lines) {
                    if (!line.startsWith('data: ')) continue;
                    const raw = line.slice(6).trim();
                    if (raw === '[DONE]') continue;
                    try {
                        const evt = JSON.parse(raw);
                        if (evt.type === 'content_block_start' && evt.content_block?.type === 'tool_use') {
                            currentTool = { id: evt.content_block.id, name: evt.content_block.name, input: '' };
                            sendEvent({ type: 'tool_start', tool: evt.content_block.name });
                        }
                        if (evt.type === 'content_block_delta') {
                            if (evt.delta?.type === 'text_delta') {
                                fullText += evt.delta.text;
                                sendEvent({ type: 'text', text: evt.delta.text });
                            }
                            if (evt.delta?.type === 'input_json_delta' && currentTool) {
                                currentTool.input += evt.delta.partial_json;
                            }
                        }
                        if (evt.type === 'content_block_stop' && currentTool) {
                            try { currentTool.input = JSON.parse(currentTool.input || '{}'); } catch { currentTool.input = {}; }
                            toolCalls.push({ ...currentTool });
                            currentTool = null;
                        }
                        if (evt.type === 'message_delta') stopReason = evt.delta?.stop_reason;
                    } catch { }
                }
            }

            if (stopReason === 'tool_use' && toolCalls.length > 0) {
                const assistantContent = [];
                if (fullText) assistantContent.push({ type: 'text', text: fullText });
                toolCalls.forEach(tc => assistantContent.push({ type: 'tool_use', id: tc.id, name: tc.name, input: tc.input }));
                currentMessages.push({ role: 'assistant', content: assistantContent });

                const toolResults = [];
                for (const tc of toolCalls) {
                    sendEvent({ type: 'tool_call', tool: tc.name, input: tc.input });
                    const result = await executeTool(tc.name, tc.input);
                    sendEvent({ type: 'tool_result', tool: tc.name, result });
                    toolResults.push({ type: 'tool_result', tool_use_id: tc.id, content: JSON.stringify(result) });
                }
                currentMessages.push({ role: 'user', content: toolResults });
                toolCalls = [];
                continue;
            }
            sendEvent({ type: 'done', fullText, stopReason });
            break;
        }
    } catch (e) {
        console.error('[Wiesio] Claude proxy error:', e);
        sendEvent({ type: 'error', error: e.message });
    }
    res.end();
});

// ── /api/gemini — Gemini proxy (Google Generative AI) ─────────────────
// SSE format identyczny jak /api/claude: {type:'text'} / {type:'done'} / {type:'error'}
app.post('/api/gemini', async (req, res) => {
    // 🛡️ Samoczyszczenie VRAM przed alokacją kontekstu modelu
    executeTacosGuard();

    const { messages, system, model = 'gemini-1.5-flash', apiKey: reqApiKey, agent } = req.body;
    if (!messages?.length) return res.status(400).json({ error: 'Brak messages' });

    const apiKey = await getGeminiKey(reqApiKey);
    if (!apiKey) return res.status(401).json({ error: 'Brak klucza Gemini — dodaj go w TeO Kibel (AIza...)' });

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', '*');

    const sendEvent = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    try {
        const finalSystem = await getMergedSystemPrompt(agent, system);

        // Konwersja messages → Gemini contents format
        // Gemini wymaga: role 'user'|'model' (nie 'assistant')
        // Obsługuje zarówno content: string JAK I content: parts[] (vision z inlineData)
        const contents = messages.map(m => {
            const role = m.role === 'assistant' ? 'model' : 'user';
            // Jeśli content to tablica parts (obrazy + tekst)
            if (Array.isArray(m.content)) {
                const parts = m.content.map(part => {
                    if (part.inlineData) return part; // gotowy format Gemini
                    if (part.text)       return { text: part.text };
                    // Konwersja z formatu Claude → Gemini
                    if (part.type === 'image' && part.source?.type === 'base64') {
                        return { inlineData: { mimeType: part.source.media_type, data: part.source.data } };
                    }
                    if (part.type === 'text') return { text: part.text || '' };
                    return { text: '' };
                });
                return { role, parts };
            }
            // Zwykły string
            return { role, parts: [{ text: String(m.content || '') }] };
        });

        const body = {
            contents,
            ...(finalSystem ? { systemInstruction: { parts: [{ text: finalSystem }] } } : {}),
            generationConfig: { maxOutputTokens: 8192, temperature: 0.7 },
        };

        const geminiModel = model || 'gemini-1.5-flash';
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${geminiModel}:streamGenerateContent?key=${apiKey}&alt=sse`;

        console.log(`[Wiesio-Gemini] 🔵 ${geminiModel} → streaming...`);

        const resp = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });

        if (!resp.ok) {
            const err = await resp.json().catch(() => ({}));
            const msg = err?.error?.message || `Gemini HTTP ${resp.status}`;
            console.error(`[Wiesio-Gemini] ❌ ${msg}`);
            sendEvent({ type: 'error', error: msg });
            return res.end();
        }

        const reader  = resp.body.getReader();
        const decoder = new TextDecoder();
        let buf = '', fullText = '';

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            buf += decoder.decode(value, { stream: true });
            const lines = buf.split('\n');
            buf = lines.pop() ?? '';

            for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                const raw = line.slice(6).trim();
                if (!raw || raw === '[DONE]') continue;
                try {
                    const evt = JSON.parse(raw);
                    // Gemini SSE: candidates[0].content.parts[0].text
                    const text = evt?.candidates?.[0]?.content?.parts?.[0]?.text;
                    if (text) {
                        fullText += text;
                        sendEvent({ type: 'text', text });
                    }
                    // Sprawdź finishReason
                    const finish = evt?.candidates?.[0]?.finishReason;
                    if (finish && finish !== 'STOP' && finish !== 'MAX_TOKENS') {
                        console.warn(`[Wiesio-Gemini] finishReason: ${finish}`);
                    }
                } catch { /* skip bad lines */ }
            }
        }

        console.log(`[Wiesio-Gemini] ✅ Done (${fullText.length} znaków)`);
        sendEvent({ type: 'done', fullText });

    } catch (e) {
        console.error('[Wiesio-Gemini] ❌ Proxy error:', e);
        sendEvent({ type: 'error', error: e.message });
    }
    res.end();
});

// ── GŁÓWNY ENDPOINT ──────────────────────────────────────────────────

app.post('/api/bridge/execute', async (req, res) => {
    // ⚠️ DWA KSZTAŁTY CIAŁA ŻĄDANIA. Most czytał pola z KORZENIA (`req.body.type`),
    // a Story V2 zagnieżdżał je w `payload: {...}` — każde zlecenie montażu wracało
    // z HTTP 400 „Brak type lub mainVideoFilename", mimo że oba pola były wysłane.
    // Zmierzone: to samo żądanie płasko przechodziło. Przyjmujemy OBA kształty,
    // bo most jest starszy i mają go inni klienci — łamanie ich byłoby gorsze.
    const payload = (req.body && typeof req.body.payload === 'object' && req.body.payload !== null)
        ? { ...req.body.payload, ...req.body }
        : req.body;
    // NAPRAWA: action ma wyższy priorytet niż command (command może być pełną komendą shellową)
    const action = payload.action || payload.command;

    // PING (Obsługa Desktopowa i Mobilna)
    if (action === 'PING') {
        console.log(`[Wiesio-Bridge] PING (Mobilny/Desktop)`);
        return res.json({
            success: true,
            status: 'AHOJ',
            message: 'Wiesio gotowy na odbiór mobilny!',
            timestamp: Date.now()
        });
    }

    const { filename, content } = payload;
    console.log(`[Wiesio-Bridge] Akcja: [${action}]`);

    // ── WRITE_FILE ───────────────────────────────────────────────────
    if (action === 'WRITE_FILE') {
        if (!filename || content === undefined || content === null) {
            return res.status(400).json({ success: false, message: 'Brak filename lub content' });
        }
        try {
            // Wyczyść ewentualny prefiks _OtakOs_Wymiar i leading slash
            const cleanFilename = filename
                .replace(/^[/\\]?_OtakOs_Wymiar[/\\]/i, '')
                .replace(/^[/\\]/, '');

            // ── ROUTING KATALOGÓW ─────────────────────────────────────
            // Pliki kodu źródłowego aplikacji → rdzeń projektu (__dirname)
            // Notatki, konwersacje, dane       → _OtakOs_Wymiar
            const SOURCE_PREFIXES = [
                'components/', 'lib/', 'store/', 'styles/',
                'context/', 'hooks/', 'services/', 'pages/',
            ];
            const isSourceCode = SOURCE_PREFIXES.some(p => cleanFilename.startsWith(p));
            const baseDir  = isSourceCode ? __dirname : ANTIGRAVITY_DIR;
            const filePath = path.join(baseDir, cleanFilename);

            console.log(`[Wiesio-Bridge] 📂 WRITE_FILE → ${isSourceCode ? 'SRC' : 'DATA'}: ${filePath}`);

            // Utwórz katalog docelowy (fs = fs/promises, await gwarantuje sekwencję)
            await fs.mkdir(path.dirname(filePath), { recursive: true });

            // Pobieramy kodowanie z payloadu (np. 'base64'), domyślnie 'utf8'
            const encoding = payload.encoding || 'utf8';

            await fs.writeFile(filePath, content, encoding);
            console.log(`[Wiesio-Bridge] ✅ Zmaterializowano: ${filePath}`);
            return res.json({ success: true, message: 'Zmaterializowano.', filePath, timestamp: Date.now() });
        } catch (e) {
            console.error(`[Wiesio-Bridge] ❌ Błąd zapisu:`, e);
            return res.status(500).json({ success: false, message: `Błąd zapisu: ${e.message}` });
        }
    }

    // ── EXTERNAL SKILL: Toobit (Ted The Trader) ───────────────────────
    if (action === 'PLACE_ORDER') {
        console.log(`[Wiesio-API] Wykonuję skill PLACE_ORDER dla pary ${payload.symbol}`);

        // Tutaj docelowo uderzamy do właściwego API Toobit używając zmiennych z procesu:
        // const toobitApiKey = process.env.TOOBIT_API_KEY;
        // const response = await fetch('https://api.toobit.com/api/v1/order', { ... });

        // Symulacja rynkowa dla Suwerena:
        setTimeout(() => {
            console.log(`[Wiesio-API] Zlecenie ${payload.side} na ${payload.quantity} ${payload.symbol} zmaterializowane w Katedrze!`);
        }, 1000);

        return res.json({ success: true, message: `Skutecznie wystawiono zlecenie: ${payload.side} dla ${payload.symbol}!` });
    }

    // ── READ_FILE ────────────────────────────────────────────────────
    if (action === 'READ_FILE') {
        if (!filename) {
            return res.status(400).json({ success: false, message: 'Brak filename' });
        }
        try {
            const filePath = path.join(ANTIGRAVITY_DIR, filename);
            const fileContent = await fs.readFile(filePath, 'utf8');
            console.log(`[Wiesio-Bridge] 📖 Odczytano: ${filePath}`);
            return res.json({ success: true, filename, content: fileContent, timestamp: Date.now() });
        } catch (e) {
            if (e.code === 'ENOENT') {
                return res.status(404).json({ success: false, message: `Plik "${filename}" nie istnieje.`, code: 'FILE_NOT_FOUND' });
            }
            return res.status(500).json({ success: false, message: `Błąd odczytu: ${e.message}` });
        }
    }

    // ── LIST_DIRECTORY (Obsługa _OtakOs_Wymiar / _OtakOs_Move) ───────────────────────
    if (action === 'LIST_DIRECTORY') {
        try {
            let scanDir = ANTIGRAVITY_DIR;
            let filterExtensions = null;

            if (payload.target === 'MOVE') {
                scanDir = MOVE_DIR;
                filterExtensions = ['.mp4', '.webm', '.mov'];
            } else if (payload.target === 'SONIC') {
                scanDir = SONIC_DIR;
                filterExtensions = ['.json'];
            }

            const entries = await fs.readdir(scanDir, { withFileTypes: true });
            let files = await Promise.all(
                entries.map(async (entry) => {
                    const entryPath = path.join(scanDir, entry.name);
                    try {
                        const stats = await fs.stat(entryPath);
                        return {
                            name: entry.name,
                            type: entry.isDirectory() ? 'directory' : 'file',
                            size: entry.isFile() ? stats.size : null,
                            modified: stats.mtime.toISOString(),
                        };
                    } catch (statErr) {
                        return null;
                    }
                })
            );

            // Filtrowanie nulli i rozszerzeń (jeśli dotyczy)
            files = files.filter(f => f !== null);
            if (filterExtensions) {
                files = files.filter(f => {
                    if (f.type === 'directory') return true;
                    const ext = path.extname(f.name).toLowerCase();
                    return filterExtensions.includes(ext);
                });
            }

            console.log(`[Wiesio-Bridge] 📂 Lista ${payload.target || 'Wymiar'} (${files.length} szt.)`);
            return res.json({ success: true, files, directory: scanDir, timestamp: Date.now() });
        } catch (e) {
            return res.status(500).json({ success: false, message: `Błąd skanowania: ${e.message}` });
        }
    }

    // ── LIST_MOVE (Obsługa mobilna _OtakOs_Move) ──────────────────────
    if (action === 'LIST_MOVE') {
        try {
            const moveFiles = await fs.readdir(moveDir);
            const files = await Promise.all(moveFiles.map(async f => {
                const stat = await fs.stat(path.join(moveDir, f));
                return { name: f, type: stat.isDirectory() ? 'directory' : 'file', size: stat.size };
            }));
            return res.status(200).json({ success: true, message: 'Zeskanowano Wymiar Move', files });
        } catch (e) {
            return res.status(500).json({ success: false, message: `Błąd skanowania Move: ${e.message}` });
        }
    }

    // ── GET_LOCAL_PLAYLIST ───────────────────────────────────────────
    // Sztuczka nr 4: skanuje _OtakOs_Muzyka/ i zwraca playlistę
    // z gotowymi URL-ami do streamowania przez Wiesia
    if (action === 'GET_LOCAL_PLAYLIST') {
        try {
            const allFiles = await getAudioFilesRecursive(MUSIC_DIR);

            const tracks = allFiles.map((fullPath, index) => {
                // Ścieżka względna np. "Album/Piosenka.wav"
                const relativePath = path.relative(MUSIC_DIR, fullPath).replace(/\\/g, '/');
                const filename = path.basename(fullPath);
                const ext = path.extname(filename);
                const title = path.basename(filename, ext)
                    .replace(/[-_]/g, ' ')
                    .replace(/^\d+[\s.\-]+/, '')
                    .trim() || filename;

                // Kodujemy każdy segment ścieżki osobno, aby '/' przetrwały
                const encodedPath = relativePath.split('/').map(encodeURIComponent).join('/');

                return {
                    id: `local-${index}-${filename}`,
                    title,
                    audio_url: `http://127.0.0.1:3001/music/${encodedPath}`,
                    filename: relativePath,
                    image_url: null,
                    duration: 0,
                    tags: 'local · 0.00G',
                };
            });

            console.log(`[Wiesio-Bridge] 🎵 Playlista: ${tracks.length} utworów`);

            return res.json({
                success: true,
                message: `DJ Wiesław przygotował ${tracks.length} utworów.`,
                tracks,
                musicDir: MUSIC_DIR,
                timestamp: Date.now()
            });
        } catch (e) {
            console.error(`[Wiesio-Bridge] ❌ Błąd playlisty:`, e);
            return res.status(500).json({ success: false, message: `Błąd playlisty: ${e.message}` });
        }
    }

    // ── SAVE_PODCAT ─────────────────────────────────────────────────
    if (action === 'SAVE_PODCAT') {
        const { videoData } = payload;
        if (!videoData) {
            return res.status(400).json({ success: false, message: 'Brak videoData' });
        }
        try {
            // videoData to string Base64: "data:video/webm;base64,..."
            let base64Data = videoData;
            if (base64Data.includes(',')) {
                base64Data = base64Data.split(',')[1];
            }
            const buffer = Buffer.from(base64Data, 'base64');
            const ts = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = `PodCaT_${ts}.webm`;
            const filePath = path.join(MOVE_DIR, filename);

            await fs.writeFile(filePath, buffer);
            console.log(`[Wiesio-Bridge] 🎬 Zapisano wideo (Single Shot): ${filePath}`);

            // ── Rafineria FFmpeg ─────────────────────────────────────────
            const mp4Path = filePath.replace('.webm', '.mp4');
            console.log(`[Wiesio-Rafineria] 🏭 Otrzymano surowiec. Rozpoczynam tytanową destylację do MP4...`);

            ffmpeg(filePath)
                .inputOptions([
                    '-analyzeduration 2147483647',
                    '-probesize 2147483647'
                ])
                .outputOptions([
                    '-pix_fmt yuv420p',                       // Standard kolorów dla YouTube/Adobe
                    '-r', '60',                               // Wymuszenie płynności 60 FPS
                    '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', // TARCZA: Wymuszenie parzystości wymiarów!
                    '-y'                                      // ZAKLĘCIE NADPISYWANIA
                ])
                .videoCodec('libx264')
                .audioCodec('aac')
                .on('error', (err, stdout, stderr) => {
                    console.error(`[Wiesio-Rafineria] ❌ Błąd destylacji: ${err.message}`);
                    console.error(`[LUPA DIAGNOSTYCZNA WIESŁAWA]:\n${stderr}`);
                })
                .on('end', () => {
                    console.log(`[Wiesio-Rafineria] ✨ Sukces! Eliksir MP4 gotowy: ${path.basename(mp4Path)}`);
                    try {
                        fsSync.unlinkSync(filePath);
                        console.log('[Wiesio-Rafineria] 🧹 Surowiec .webm zutylizowany.');
                    } catch (err) {
                        console.error('[Wiesio-Rafineria] ⚠️ Błąd utylizacji .webm:', err.message);
                    }
                })
                .save(mp4Path);

            return res.json({ success: true, message: 'Wideo zmaterializowane.', filename, timestamp: Date.now() });
        } catch (e) {
            console.error(`[Wiesio-Bridge] ❌ Błąd zapisu wideo:`, e);
            return res.status(500).json({ success: false, message: `Błąd zapisu wideo: ${e.message}` });
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  ── SZTUCZKA NR 5: OLLAMA_BUILD (TELEPATIA API) ──────────────
    // ══════════════════════════════════════════════════════════════
    if (action === 'OLLAMA_BUILD') {
        const { model, prompt: ollamaPrompt, outfile } = payload;

        if (!model || !ollamaPrompt) {
            return res.status(400).json({ success: false, message: 'Brak model lub prompt' });
        }

        console.log(`[Wiesio-Bridge] 🤖 OLLAMA_BUILD (API): model="${model}" → "${outfile || 'auto'}"`);
        console.log(`[Wiesio-Bridge] 📝 Prompt wysyłany bezpośrednio do API...`);

        try {
            // Omijamy terminal (CMD) całkowicie! Uderzamy prosto do lokalnego mózgu Ollamy.
            const response = await fetch(`${OLLAMA_BASE}/api/generate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: model,
                    prompt: ollamaPrompt,
                    stream: false // Chcemy od razu całą odpowiedź, bez strumieniowania
                })
            });

            if (!response.ok) {
                const errorDetails = await response.text();
                throw new Error(`Ollama odrzuciła zadanie (Status ${response.status}). Szczegóły: ${errorDetails}`);
            }

            const data = await response.json();
            const rawResponse = data.response || '';

            console.log(`[Wiesio-Bridge] ✅ Ollama odpowiedziała przez API (${rawResponse.length} znaków)`);

            // ── Wyciągnij blok kodu z odpowiedzi ──────────────────
            const extractedCode = extractCodeBlock(rawResponse);

            // ── Zapisz do pliku ───────────────────────────────────
            let savedPath = null;
            let savedFilename = outfile;

            if (extractedCode) {
                if (!savedFilename) {
                    const nameMatch = extractedCode.match(/(?:export\s+(?:default\s+)?(?:function|const|class)\s+(\w+)|\/\*\*?\s*@file\s+(\S+))/);
                    const detectedName = nameMatch?.[1] || nameMatch?.[2];
                    const ext = detectExtension(rawResponse);
                    savedFilename = detectedName ? `${detectedName}${ext}` : `ollama_build_${Date.now()}${ext}`;
                }

                savedPath = path.join(BUILD_DIR, savedFilename);
                await fs.writeFile(savedPath, extractedCode, 'utf8');
                console.log(`[Wiesio-Bridge] 💾 Zapisano kod: ${savedPath}`);
            } else {
                savedFilename = outfile || `ollama_response_${Date.now()}.txt`;
                savedPath = path.join(BUILD_DIR, savedFilename);
                await fs.writeFile(savedPath, rawResponse, 'utf8');
                console.log(`[Wiesio-Bridge] 📄 Zapisano odpowiedź tekstową: ${savedPath}`);
            }

            return res.json({
                success: true,
                message: extractedCode ? `Wiesław zmaterializował kod: ${savedFilename}` : `Wiesław zapisał odpowiedź: ${savedFilename}`,
                model,
                filename: savedFilename,
                filePath: savedPath,
                code: extractedCode || null,
                rawResponse: rawResponse.substring(0, 2000),
                hasCode: !!extractedCode,
                codeLength: extractedCode?.length || 0,
                timestamp: Date.now(),
            });

        } catch (e) {
            console.error(`[Wiesio-Bridge] ❌ OLLAMA_BUILD API error:`, e.message);
            return res.status(500).json({
                success: false,
                message: `Krytyczny błąd mózgu (API): ${e.message}`,
                hint: 'Upewnij się, że Ollama działa w tle (ikona lamy w zasobniku systemowym).',
                timestamp: Date.now(),
            });
        }
    }

    // ── OLLAMA_LIST — lista dostępnych modeli ────────────────────
    if (action === 'OLLAMA_LIST') {
        try {
            const { stdout } = await execFileAsync('ollama', ['list'], { timeout: 10000 });
            const lines = stdout.trim().split('\n').slice(1);
            const models = lines
                .filter(l => l.trim())
                .map(l => {
                    const parts = l.trim().split(/\s+/);
                    return { name: parts[0], id: parts[1], size: parts[2], modified: parts.slice(3).join(' ') };
                });
            console.log(`[Wiesio-Bridge] 🤖 Dostępne modele: ${models.length}`);
            return res.json({ success: true, models, timestamp: Date.now() });
        } catch (e) {
            return res.status(500).json({ success: false, message: `Błąd ollama list: ${e.message}`, hint: 'Czy Ollama jest uruchomiona?' });
        }
    }

    // ── OLLAMA_CHAT — szybkie zapytanie bez zapisu ───────────────
    if (action === 'OLLAMA_CHAT') {
        const { model, prompt: chatPrompt, timeout: timeoutMs = 60000 } = payload;
        if (!model || !chatPrompt) return res.status(400).json({ success: false, message: 'Brak model lub prompt' });

        try {
            const { stdout } = await execFileAsync('ollama', ['run', model, chatPrompt], {
                timeout: timeoutMs, maxBuffer: 5 * 1024 * 1024
            });
            console.log(`[Wiesio-Bridge] 💬 OLLAMA_CHAT: ${stdout.length} znaków`);
            return res.json({ success: true, response: stdout.trim(), model, timestamp: Date.now() });
        } catch (e) {
            return res.status(500).json({ success: false, message: `Błąd OLLAMA_CHAT: ${e.message}` });
        }
    }

    // ── EGZEKUCJA LOKALNEGO LLM PRZEZ CLI ─────────────────────────────
    if (action === 'EXEC_OLLAMA_CLI') {
        const prompt = payload.prompt;
        if (!prompt) return res.status(400).json({ error: 'Brak promptu' });
        const modelToUseCLI = payload.modelName || 'gemma4';
        console.log(`[Wiesio-Mózg] 🧠 Przekazuję myśl do modelu ${modelToUseCLI} (CLI): "${prompt.substring(0, 30)}..."`);

        execFile('ollama', ['run', modelToUseCLI, prompt], { maxBuffer: 1024 * 1024 * 10, encoding: 'utf8' }, (error, stdout, stderr) => {
            if (error) {
                console.error(`[Wiesio-Mózg] ❌ Błąd wywołania Ollamy z CLI: ${error.message}`);
                return res.status(500).json({ error: error.message, details: stderr });
            }
            // Ignorujemy standardowe logi ładowania Ollamy w stderr, szukamy tylko słowa "Error"
            if (stderr && stderr.toLowerCase().includes('error')) {
                console.error(`[Wiesio-Mózg] ❌ Błąd z terminala: ${stderr}`);
            }
            console.log(`[Wiesio-Mózg] ✨ Lokalny LLM (CLI) odpowiedział!`);
            return res.json({ success: true, response: stdout.trim() });
        });
        return; // Zakończ, odpowiedź wyślemy w callback
    }

    // ── POBIERANIE MODELI W TLE ─────────────────────────────────────
    if (action === 'PULL_MODEL') {
        const modelToPull = payload.modelName;
        if (!modelToPull) return res.status(400).json({ error: 'Brak nazwy modelu (modelName).' });

        console.log(`[Wiesio-Inżynier] ⬇️ Pobieram model z sieci: ${modelToPull}... (Proces w tle)`);

        // ⚠️ BYŁO: execFile(..., callback) — ta forma BUFORUJE stdout i stderr
        // z domyślnym limitem 1 MB. `ollama pull` sypie pasek postępu do stderr
        // bez końca, więc przy dużym modelu bufor pękał i Node ZABIJAŁ pobieranie:
        // „stderr maxBuffer length exceeded". Zmierzone na qwen3.6:35b-a3b.
        // Teraz spawn ze strumieniem — nic nie buforujemy, a postęp widać w konsoli.
        const pobieranie = spawn('ollama', ['pull', modelToPull], { windowsHide: true });
        let ostatniProcent = -1;
        const pokazPostep = (buf) => {
            const t = buf.toString();
            // Ollama nadpisuje linię CR-em; wyłuskujemy sam procent i logujemy co 10%.
            const linie = t.split(String.fromCharCode(13));
            const m = /(\d{1,3})%/.exec(linie[linie.length - 1] || '');
            if (!m) return;
            const proc = Number(m[1]);
            if (proc >= ostatniProcent + 10 || proc === 100) {
                ostatniProcent = proc;
                console.log(`[Wiesio-Inżynier] ⬇️ ${modelToPull}: ${proc}%`);
            }
        };
        pobieranie.stdout.on('data', pokazPostep);
        pobieranie.stderr.on('data', pokazPostep);
        pobieranie.on('error', (e) => {
            console.error(`[Wiesio-Inżynier] ❌ Nie udało się uruchomić ollama: ${e.message}`);
        });
        pobieranie.on('close', (kod) => {
            if (kod === 0) console.log(`[Wiesio-Inżynier] ✅ Model ${modelToPull} pobrany i gotowy do pracy!`);
            else console.error(`[Wiesio-Inżynier] ❌ Pobieranie ${modelToPull} zakończone kodem ${kod}.`);
        });

        return res.json({ success: true, message: `Rozpoczęto pobieranie ${modelToPull}. Sprawdź czarną konsolę Wiesia.` });
    }

    // ── TWORZENIE FIZYCZNYCH KOMPONENTÓW Z PLANU RADY ─────────────────────
    if (action === 'CREATE_COMPONENT') {
        const compName = payload.fileName || payload.componentName;
        const instructions = payload.instructions || payload.content || payload.code;

        if (!compName || !instructions) {
            return res.status(400).json({ error: 'Brak nazwy pliku (fileName) lub kodu (instructions).' });
        }

        // Określamy ścieżkę zapisu bezpośrednio w components/special/ (BEZ src, projekt tak funkcjonuje)
        const newFilePath = path.join(process.cwd(), 'components', 'special', compName);

        try {
            await fs.mkdir(path.dirname(newFilePath), { recursive: true });

            // Zapisujemy fizycznie plik
            await fs.writeFile(newFilePath, instructions, 'utf8');

            console.log(`[Wiesio-Kowal] 🔨 Zmaterializowano nowy moduł: ${compName} w ${newFilePath}`);
            return res.json({ success: true, message: `Utworzono i zapisano ${compName}!` });
        } catch (err) {
            console.error(`[Wiesio-Kowal] ❌ Błąd rzeźbienia pliku: ${err.message}`);
            return res.status(500).json({ error: err.message });
        }
    }

    // ── NOWOŚĆ: EGZEKUCJA CZYSTYCH KOMEND W TERMINALU ───────────────
    if (action === 'EXEC_COMMAND') {
        const rawCmd = payload.command;
        if (!rawCmd) return res.status(400).json({ error: 'Brak komendy' });

        // 🧯 Otak-Sync Watchdog: odkaź komendę pod powłokę Windows ($ prompt, Linux-izmy)
        const san = ShellSanitizer.sanitizeShellCommand(rawCmd);
        const cmd = san.command;
        if (san.changed) console.log(`[Otak-Sync] 🧯 EXEC_COMMAND odkażono: ${san.notes.join(' ')}`);

        console.log(`[Wiesio-Terminal] 💻 Wykonuję komendę: ${cmd}`);

        exec(cmd, { cwd: process.cwd(), maxBuffer: 1024 * 1024 * 10 }, (error, stdout, stderr) => {
            if (error) {
                console.error(`[Wiesio-Terminal] ❌ Błąd: ${error.message}`);
                return res.status(500).json({ error: error.message, details: stderr });
            }
            return res.json({ success: true, output: stdout || stderr });
        });
        return;
    }

    // ── NOWOŚĆ: WYCIĄGANIE TREŚCI ZE STRON (W.I.D.O.K. Crawler) ──────
    if (action === 'FETCH_URL_CONTENT') {
        const targetUrl = payload.url;
        if (!targetUrl) return res.status(400).json({ error: 'Brak URL' });

        console.log(`[Wiesio-Sieciarz] 🕸️ Wyrzucam sieć na: ${targetUrl}`);

        try {
            // Jeśli to YouTube, wyciągamy transkrypt
            if (targetUrl.includes('youtube.com') || targetUrl.includes('youtu.be')) {
                console.log(`[Wiesio-Sieciarz] 📺 Wykryto YouTube. Dekodowanie linku...`);
                try {
                    const { YoutubeTranscript } = require('youtube-transcript');

                    // NIEZAWODNY EKSTRAKTOR ID (obsługuje standard, youtu.be oraz shorts)
                    const videoIdMatch = targetUrl.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/i);

                    // Jeśli znajdzie ID (11 znaków), używa go. Jak nie, próbuje całym URLem ratunkowo.
                    const finalTarget = videoIdMatch ? videoIdMatch[1] : targetUrl;
                    console.log(`[Wiesio-Sieciarz] 🔍 Wyizolowano ID: ${finalTarget}`);

                    const transcript = await YoutubeTranscript.fetchTranscript(finalTarget);
                    if (!transcript || transcript.length === 0) throw new Error("Brak napisów nałożonych na film.");

                    let ytText = transcript.map(t => t.text).join(' ');
                    // Zabezpieczenie RAM
                    if (ytText.length > 15000) ytText = ytText.substring(0, 15000) + '... [Ucięto resztę, materiał zbyt długi]';

                    console.log(`[Wiesio-Sieciarz] ✅ Zassano transkrypt YT!`);
                    return res.json({ success: true, text: ytText });
                } catch (ytErr) {
                    console.error(`[Wiesio-Sieciarz] ❌ Błąd YT: ${ytErr.message}`);

                    // Tłumaczenie błędu dla Suwerena
                    let humanError = ytErr.message;
                    if (humanError.includes("Could not find captions") || humanError.includes("Brak napisów")) {
                        humanError = "Ten film fizycznie nie posiada wbudowanych napisów (CC). Wciągarka nie ma z czego czytać.";
                    }

                    return res.status(500).json({ error: humanError });
                }
            }            // Jeśli to zwykła strona (np. GitHub, artykuł)
            else {
                const { default: axios } = await import('axios');
                const cheerio = await import('cheerio');

                const response = await axios.get(targetUrl);
                const $ = cheerio.load(response.data);

                $('script, style, nav, footer, header, noscript, svg').remove();
                let rawText = $('body').text().replace(/\s+/g, ' ').trim();

                if (rawText.length > 15000) {
                    rawText = rawText.substring(0, 15000) + '... [Ucięto z powodu długości]';
                }

                console.log(`[Wiesio-Sieciarz] ✅ Zebrano ze strony.`);
                return res.json({ success: true, text: rawText });
            }
        } catch (err) {
            console.error(`[Wiesio-Sieciarz] ❌ Błąd pobierania: ${err.message}`);
            return res.status(500).json({ error: 'Nie udało się pobrać treści. ' + err.message });
        }
    }

    // ── 2. KUŹNIA AGENTÓW (Ollama Modelfile) ──────
    if (action === 'CREATE_CUSTOM_MODEL') {
        const { baseModel, newModelName, systemPrompt } = payload;
        if (!baseModel || !newModelName || !systemPrompt) return res.status(400).json({ error: 'Brak danych do kucia' });

        console.log(`[Wiesio-Kowal] 🔨 Kuję model: ${newModelName} na bazie ${baseModel}`);

        // Formatujemy prompt systemowy dla Ollamy
        const modelfileContent = `FROM ${baseModel}\nSYSTEM """\n${systemPrompt}\n"""\n`;
        const modelfilePath = path.join(process.cwd(), `Modelfile_${Date.now()}`);

        try {
            fsSync.writeFileSync(modelfilePath, modelfileContent, 'utf8');

            // Odpalamy komendę ollama create (execFile dla bezpieczeństwa ścieżek)
            execFile('ollama', ['create', newModelName, '-f', modelfilePath], (error, stdout, stderr) => {
                try { if (fsSync.existsSync(modelfilePath)) fsSync.unlinkSync(modelfilePath); } catch (_) { }
                if (error) {
                    console.error(`[Wiesio-Kowal] ❌ Błąd kucia: ${error.message}`);
                } else {
                    console.log(`[Wiesio-Kowal] ✅ Narodziny nowego bytu: ${newModelName}!`);
                }
            });
            return res.json({ success: true, message: `Rozpoczęto kucie ${newModelName} w tle. Zajrzyj do konsoli Wiesia.` });
        } catch (err) {
            return res.status(500).json({ error: err.message });
        }
    }

    // --- NOWE SKILLE (Superpowers) ---

    // 1. ODCZYT DOWOLNEGO PLIKU Z DYSKU (Skill: FILE)
    if (action === 'READ_FILE_CONTENT') {
        const filePath = payload.path;
        if (!filePath) return res.status(400).json({ error: 'Brak ścieżki do pliku (path).' });

        console.log(`[Wiesio-Skill] 📄 Odczytuję plik: ${filePath}`);
        try {
            // Podstawowe zabezpieczenie - czy plik istnieje
            if (!fsSync.existsSync(filePath)) {
                return res.status(404).json({ error: `Plik nie istnieje pod ścieżką: ${filePath}` });
            }
            const content = fsSync.readFileSync(filePath, 'utf8');
            // Zabezpieczenie przed gigantycznymi plikami
            const safeContent = content.length > 20000 ? content.substring(0, 20000) + '\n... [Ucięto ze względu na rozmiar]' : content;
            return res.json({ success: true, content: safeContent });
        } catch (err) {
            return res.status(500).json({ error: `Błąd odczytu pliku: ${err.message}` });
        }
    }

    // 2. TWORZENIE KATALOGU (Skill: DIR)
    if (action === 'CREATE_DIRECTORY') {
        const dirPath = payload.path;
        if (!dirPath) return res.status(400).json({ error: 'Brak ścieżki katalogu (path).' });

        console.log(`[Wiesio-Skill] 📁 Tworzę katalog: ${dirPath}`);
        try {
            await fs.mkdir(dirPath, { recursive: true });
            return res.json({ success: true, message: `Katalog utworzony: ${dirPath}` });
        } catch (err) {
            return res.status(500).json({ error: `Błąd tworzenia katalogu: ${err.message}` });
        }
    }

    // 3. WYSZUKIWANIE W SIECI (Skill: SEARCH)
    if (action === 'WEB_SEARCH') {
        const query = payload.query;
        if (!query) return res.status(400).json({ error: 'Brak zapytania (query).' });

        console.log(`[Wiesio-Sieciarz] 🔍 Przeszukuję sieć: "${query}"`);
        try {
            const { default: axios } = await import('axios');
            const cheerio = await import('cheerio');

            const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;

            const response = await axios.get(searchUrl, {
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Katedra 0.00G' }
            });

            const $ = cheerio.load(response.data);
            let results = [];

            $('.result__body').each((i, el) => {
                if (i < 5) { // Bierzemy top 5 wyników
                    const title = $(el).find('.result__title').text().trim();
                    const snippet = $(el).find('.result__snippet').text().trim();
                    const link = $(el).find('.result__url').text().trim();
                    if (title && snippet) results.push(`[${i + 1}] ${title}\nURL: ${link}\nOpis: ${snippet}\n`);
                }
            });

            if (results.length === 0) return res.json({ success: true, content: "Nie znaleziono wyników w sieci." });

            const finalOutput = `Wyniki z Pajęczyny Świata:\n\n${results.join('\n')}`;
            return res.json({ success: true, content: finalOutput });

        } catch (err) {
            console.error(`[Wiesio-Sieciarz] ❌ Błąd szukacza: ${err.message}`);
            return res.status(500).json({ error: `Błąd sieci Web: ${err.message}` });
        }
    }

    // 4. ZAPIS PLIKU Z BEZPIECZNIKIEM (Skill: WRITE)
    if (action === 'WRITE_FILE_CONTENT') {
        const writePath = payload.path;
        const writeData = payload.content;

        if (!writePath || !writeData) return res.status(400).json({ error: 'Brak ścieżki (path) lub treści (content).' });

        console.log(`[Wiesio-Skill] 💾 Inicjacja Taśmociągu zapisu dla: ${writePath}`);
        try {
            // Upewniamy się, że folder docelowy istnieje
            fsSync.mkdirSync(path.dirname(writePath), { recursive: true });

            // BEZPIECZNIK SUWERENA: Jeśli plik już istnieje, robimy "klatkę obok" (Kopia Zapasowa)
            if (fsSync.existsSync(writePath)) {
                const backupPath = `${writePath}.bak`;
                fsSync.copyFileSync(writePath, backupPath);
                console.log(`[Wiesio-Skill] 🛡️ Utworzono kopię zapasową: ${backupPath}`);
            }

            // Wdrażamy nową materię
            fsSync.writeFileSync(writePath, writeData, 'utf8');

            return res.json({ success: true, message: `Materia wdrożona! (Kopia zapasowa .bak zabezpieczona). Ścieżka: ${writePath}` });
        } catch (err) {
            return res.status(500).json({ error: `Błąd Taśmociągu zapisu: ${err.message}` });
        }
    }

    // 5. ODCZYT STRUKTURY KATALOGU (Skill: READ_DIR)
    if (action === 'READ_DIR') {
        const dirToRead = payload.path;
        if (!dirToRead) return res.status(400).json({ error: 'Brak ścieżki (path).' });

        console.log(`[Wiesio-Skill] 👁️ Skanuję archiwum: ${dirToRead}`);
        try {
            if (!fsSync.existsSync(dirToRead)) {
                return res.status(404).json({ error: `Katalog nie istnieje: ${dirToRead}` });
            }

            const stat = fsSync.statSync(dirToRead);
            if (!stat.isDirectory()) {
                return res.status(400).json({ error: `Podana ścieżka nie jest katalogiem: ${dirToRead}` });
            }

            // Pobieramy listę elementów
            const items = fsSync.readdirSync(dirToRead, { withFileTypes: true });
            const formattedItems = items.map(item => {
                const fullPath = path.join(dirToRead, item.name);
                try {
                    const itemStat = fsSync.statSync(fullPath);
                    return {
                        name: item.name,
                        path: fullPath,
                        isDirectory: item.isDirectory(),
                        size: itemStat.size,
                        modified: itemStat.mtime
                    };
                } catch (e) {
                    // Pomijamy pliki bez uprawnień systemowych
                    return null;
                }
            }).filter(i => i !== null);

            // Sortowanie: Foldery zawsze na górze, potem alfabetycznie
            formattedItems.sort((a, b) => {
                if (a.isDirectory && !b.isDirectory) return -1;
                if (!a.isDirectory && b.isDirectory) return 1;
                return a.name.localeCompare(b.name);
            });

            return res.json({ success: true, items: formattedItems, currentPath: dirToRead });
        } catch (err) {
            return res.status(500).json({ error: `Błąd skanowania katalogu: ${err.message}` });
        }
    }

    // --- WYKONYWANIE KOMEND SYSTEMOWYCH (Skill: CMD) ---
    if (action === 'EXEC_SYSTEM_CMD') {
        if (!payload.command) return res.status(400).json({ error: 'Brak komendy.' });

        // 🧯 Otak-Sync Watchdog: odkaź skrypt pod PowerShell ($ prompt, /dev/null, "\" → "`")
        const sanCmd = ShellSanitizer.sanitizeShellCommand(payload.command);
        let cmd = sanCmd.command;
        if (sanCmd.changed) console.log(`[Otak-Sync] 🧯 EXEC_SYSTEM_CMD odkażono: ${sanCmd.notes.join(' ')}`);

        console.log(`[Wiesio-Term] ⚡ Odpalam skrypt: ${cmd}`);

        // Wymuszamy uruchomienie przez PowerShell, co rozwiązuje problemy z uciekającymi znakami
        const execOptions = {
            cwd: process.cwd(),
            shell: 'powershell.exe'
        };

        exec(cmd, execOptions, (error, stdout, stderr) => {
            if (error) {
                // Jeśli to tylko ostrzeżenie na stderr (np. npm warn), a jest też stdout, to przepuszczamy
                if (stdout && !error.message.includes('Command failed')) {
                    console.log(`[Wiesio-Term] ⚠️ Skrypt wykonany z ostrzeżeniami.`);
                    return res.json({ success: true, content: stdout + (stderr ? `\n[Ostrzeżenia]: ${stderr}` : '') });
                }
                console.error(`[Wiesio-Term] ❌ Błąd skryptu: ${error.message}`);
                return res.status(500).json({ error: error.message || stderr });
            }
            console.log(`[Wiesio-Term] ✅ Skrypt wykonany pomyślnie.`);
            return res.json({ success: true, content: stdout || "[Brak zwrotu w konsoli - komenda wykonana w tle]" });
        });
        return;
    }

    // ── CONCATENATE_VIDEO (Sklejanie Klocków) ────────────────────────
    if (action === 'CONCATENATE_VIDEO') {
        const { type, mainVideoFilename, outputFilename } = payload;

        if (!type || !mainVideoFilename) {
            return res.status(400).json({ success: false, message: 'Brak type lub mainVideoFilename' });
        }

        console.log(`[Wiesio-Spawacz] 🎬 Sklejanie klocków. Typ: ${type}, Plik: ${mainVideoFilename}`);

        try {
            // Mapowanie typu na folder
            let klockiSubDir = type;
            if (type === 'YT') klockiSubDir = 'Klocki do YT';
            if (type === 'Podcat') klockiSubDir = 'Klocki do Podcatów';
            if (type === 'Kronika') klockiSubDir = 'Klocki do Kronik';
            if (type === 'Muzyka') klockiSubDir = 'Klocki do Muzyki';
            // 🎞️ Movie (2026-09-15): klocki filmowe Suwerena — `_OtakOs_Klocki/Klocki do Movie`.
            if (type === 'Movie') klockiSubDir = 'Klocki do Movie';

            const klockiDir = path.join(process.cwd(), '_OtakOs_Klocki', klockiSubDir);
            const mainVideoPath = path.join(MOVE_DIR, mainVideoFilename);

            if (!fsSync.existsSync(mainVideoPath)) {
                return res.status(404).json({ success: false, message: `Nie znaleziono głównego pliku wideo: ${mainVideoPath}` });
            }

            const getVideosFromDir = (dir) => {
                if (!fsSync.existsSync(dir)) return [];
                return fsSync.readdirSync(dir)
                    .filter(f => {
                        const lower = f.toLowerCase();
                        return lower.endsWith('.mp4') || lower.endsWith('.mov') || lower.endsWith('.webm');
                    })
                    .map(f => path.join(dir, f));
            };

            const introVideos = getVideosFromDir(path.join(klockiDir, 'Start'));
            // Katalog wstawek nazywa się „Adds" w starych zestawach i „Add" w Klockach do Movie — bierzemy oba.
            const addVideos = [...getVideosFromDir(path.join(klockiDir, 'Adds')), ...getVideosFromDir(path.join(klockiDir, 'Add'))];
            const outroVideos = getVideosFromDir(path.join(klockiDir, 'End'));

            const toPosix = (p) => p.replace(/\\/g, '/');
            let concatLines = [];

            // 1. INTRAs (Start)
            introVideos.forEach(v => concatLines.push(`file '${toPosix(v)}'`));

            // 2. ADDs (Sponsorships/Inserts)
            addVideos.forEach(v => concatLines.push(`file '${toPosix(v)}'`));

            // 3. MAIN VIDEO
            concatLines.push(`file '${toPosix(mainVideoPath)}'`);

            // 4. OUTRAs (End)
            outroVideos.forEach(v => concatLines.push(`file '${toPosix(v)}'`));

            if (introVideos.length === 0 && addVideos.length === 0 && outroVideos.length === 0) {
                console.warn(`[Wiesio-Spawacz] ⚠️ Ostrzeżenie: Brak dodatkowych klocków (Start/Adds/End) w ${klockiDir}.`);
            }

            // Kolejność klocków: Start → Adds → wkład (main) → End.
            const allClips = [...introVideos, ...addVideos, mainVideoPath, ...outroVideos];

            const finalOutputName = outputFilename || `CONCAT_${mainVideoFilename}`;
            const outputPath = path.join(BUILD_DIR, finalOutputName);

            console.log(`[Wiesio-Spawacz] 📄 Klocki (${allClips.length}):\n${allClips.map(c => '  ' + path.basename(c)).join('\n')}`);
            console.log(`[Wiesio-Spawacz] 🔨 Odpalam FFmpeg (filter_complex normalize+concat)... Cel: ${outputPath}`);

            // Rozdzielczość + FPS głównego wideo = cel normalizacji (żeby wkład nie tracił jakości).
            let W = 1920, H = 1080, mainFps = 30;
            try {
                const { stdout: probeOut } = await execFileAsync(ffprobePath, [
                    '-v', 'error', '-select_streams', 'v:0',
                    '-show_entries', 'stream=width,height,r_frame_rate',
                    '-of', 'csv=p=0', mainVideoPath
                ]);
                const [w, h, rate] = probeOut.trim().split(',');
                W = parseInt(w) || 1920; H = parseInt(h) || 1080;
                const [num, den] = String(rate).split('/').map(Number);
                if (num && den) mainFps = Math.round(num / den) || 30;
            } catch (e) {
                console.warn(`[Wiesio-Spawacz] ⚠️ Nie wykryto parametrów głównego wideo, używam ${W}x${H}@${mainFps}.`);
            }
            if (W % 2) W++; if (H % 2) H++; // libx264 wymaga parzystych wymiarów

            // KLUCZ: klocki bywają różnego FPS (24/30/60) i rozdzielczości. Stary concat
            // demuxer sklejał surowe strumienie → aresample dopychał CISZĄ przy joinach
            // (Suweren: +1:30). Teraz KAŻDY klip normalizowany (scale+pad+fps+audio) filtrem,
            // potem concat filter — dokładne długości, zero paddingu, czyste A/V.
            const inputs = [];
            allClips.forEach(c => { inputs.push('-i', c); });
            const fc = [];
            allClips.forEach((_, i) => {
                fc.push(`[${i}:v]scale=${W}:${H}:force_original_aspect_ratio=decrease,pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2,fps=${mainFps},setsar=1[v${i}]`);
                fc.push(`[${i}:a]aresample=48000,asetpts=PTS-STARTPTS[a${i}]`);
            });
            const concatIn = allClips.map((_, i) => `[v${i}][a${i}]`).join('');
            const filter = fc.join(';') + ';' + concatIn + `concat=n=${allClips.length}:v=1:a=1[outv][outa]`;

            await execFileAsync(ffmpegPath, [
                ...inputs,
                '-filter_complex', filter,
                '-map', '[outv]', '-map', '[outa]',
                '-c:v', 'libx264', '-preset', 'fast', '-pix_fmt', 'yuv420p',
                '-c:a', 'aac', '-b:a', '192k',
                '-y', outputPath
            ], { timeout: 0, maxBuffer: 1024 * 1024 * 500 });

            console.log(`[Wiesio-Spawacz] ✨ Magia dokonana.`);

            return res.json({
                success: true,
                message: 'Sklejanie zakończone sukcesem!',
                outputFile: finalOutputName,
                outputPath: outputPath
            });

        } catch (err) {
            console.error(`[Wiesio-Spawacz] ❌ Błąd sklejania:`, err);
            return res.status(500).json({ success: false, message: `Błąd sklejania klocków: ${err.message}` });
        }
    }

    // ── EXEC_SYSTEM (Raw Terminal) — przeniesione z /wiesio/action ──────────
    if (action === 'EXEC_SYSTEM') {
        // Obsługa Uniwersalnej Paczki: command może być w body.command LUB body.payload.command
        const rawCommand = payload.command || payload.payload?.command;
        const timeout  = payload.timeout || payload.payload?.timeout || 300000;
        if (!rawCommand) return res.status(400).json({ success: false, message: 'Brak komendy (sprawdź body.command lub body.payload.command)' });

        // 🧯 Otak-Sync Watchdog: odkaź surową komendę pod powłokę Windows
        const sanSys = ShellSanitizer.sanitizeShellCommand(rawCommand);
        const command = sanSys.command;
        if (sanSys.changed) console.log(`[Otak-Sync] 🧯 EXEC_SYSTEM odkażono: ${sanSys.notes.join(' ')}`);

        console.log(`[Wiesio-Bridge] ⚡ EXEC_SYSTEM: ${command.substring(0, 80)}...`);

        // ── SMART INTERCEPT: `ollama run <model> "prompt"` → HTTP API ──────
        // Powód: PowerShell/cmd nie radzi sobie z długimi promptami w cudzysłowach.
        // Rozwiązanie: przechwytujemy komendę i wysyłamy przez HTTP zamiast shell.
        const ollamaRunMatch = command.match(
            /^ollama\s+run\s+([^\s"']+)\s+(?:"([\s\S]*?)"|'([\s\S]*?)'|([\s\S]+))\s*$/s
        );
        if (ollamaRunMatch) {
            const ollamaModel  = ollamaRunMatch[1];
            const ollamaPrompt = (ollamaRunMatch[2] || ollamaRunMatch[3] || ollamaRunMatch[4] || '')
                .replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\'/g, "'");
            console.log(`[Wiesio-Bridge] 🧠 ollama run → HTTP API (model: ${ollamaModel}, prompt: ${ollamaPrompt.substring(0,60)}...)`);
            try {
                const ollamaResp = await fetch(`${OLLAMA_BASE}/api/generate`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ model: ollamaModel, prompt: ollamaPrompt, stream: false }),
                    signal: AbortSignal.timeout(timeout),
                });
                if (!ollamaResp.ok) throw new Error(`Ollama HTTP ${ollamaResp.status}`);
                const ollamaData = await ollamaResp.json();
                const output = ollamaData.response || '[Ollama: brak odpowiedzi]';
                console.log(`[Wiesio-Bridge] ✅ ollama HTTP (${output.length} znaków)`);
                return res.json({ success: true, response: output, timestamp: Date.now() });
            } catch (ollamaErr) {
                console.warn(`[Wiesio-Bridge] ⚠️ ollama HTTP intercept failed: ${ollamaErr.message}, fallback do exec`);
                // Fall through — spróbuj normalnym exec
            }
        }

        // ── Normalne wykonanie shell ──────────────────────────────────────
        try {
            const { stdout, stderr } = await execAsync(command, {
                timeout, maxBuffer: 50 * 1024 * 1024, shell: true,
            });
            const output = stdout.trim() || stderr.trim() || '[Komenda wykonana — brak wyjścia]';
            console.log(`[Wiesio-Bridge] ✅ Wynik (${output.length} znaków): ${output.substring(0, 100)}`);
            return res.json({ success: true, response: output, timestamp: Date.now() });
        } catch (e) {
            const errOut = e.stdout?.trim() || e.stderr?.trim() || e.message;
            console.error(`[Wiesio-Bridge] ❌ Błąd EXEC_SYSTEM: ${errOut}`);
            return res.status(500).json({ success: false, message: `Błąd powłoki: ${errOut}` });
        }
    }

    // ── Nieobsługiwana akcja (Gniazdo Fallback) ──────────────────────────
    return res.status(200).json({ message: `Wiesio usłyszał komendę: ${action}, ale jeszcze nie umie jej wykonać z tego poziomu!` });
});

// ══════════════════════════════════════════════════════════════════
//  HELPERS — wyciąganie kodu z odpowiedzi modelu
// ══════════════════════════════════════════════════════════════════

/**
 * Wyciąga pierwszy blok kodu z odpowiedzi Ollamy.
 * Obsługuje: ```tsx, ```ts, ```jsx, ```js, ```html, ```css, ```python, ``` (bez języka)
 */
function extractCodeBlock(text) {
    if (!text) return null;
    const patterns = [
        /```(?:tsx|typescript react)\s*\n([\s\S]*?)```/i,
        /```(?:ts|typescript)\s*\n([\s\S]*?)```/i,
        /```(?:jsx)\s*\n([\s\S]*?)```/i,
        /```(?:js|javascript)\s*\n([\s\S]*?)```/i,
        /```(?:html)\s*\n([\s\S]*?)```/i,
        /```(?:css)\s*\n([\s\S]*?)```/i,
        /```(?:python|py)\s*\n([\s\S]*?)```/i,
        /```\s*\n([\s\S]*?)```/,
    ];

    for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match?.[1]?.trim()) {
            return match[1].trim();
        }
    }

    const trimmed = text.trim();
    if (trimmed.startsWith('import ') || trimmed.startsWith('export ') ||
        trimmed.startsWith('const ') || trimmed.startsWith('function ') ||
        trimmed.startsWith('<!DOCTYPE') || trimmed.startsWith('<html')) {
        return trimmed;
    }

    return null;
}

/**
 * Wykrywa rozszerzenie pliku na podstawie treści odpowiedzi.
 */
function detectExtension(text) {
    if (!text) return '.txt';
    const lower = text.toLowerCase();
    if (lower.includes('```tsx') || lower.includes('react') || lower.includes('jsx')) return '.tsx';
    if (lower.includes('```ts') || lower.includes('typescript')) return '.ts';
    if (lower.includes('```html') || lower.includes('<!doctype')) return '.html';
    if (lower.includes('```css')) return '.css';
    if (lower.includes('```python') || lower.includes('def ') || lower.includes('import sys')) return '.py';
    if (lower.includes('```js') || lower.includes('javascript')) return '.js';
    return '.txt';
}

app.get('/wiesio/ping', (req, res) => {
    res.status(200).json({ status: 'alive', message: 'Wiesław czuwa! Rury drożne!' });
});

/**
 * 🛰️ Dedykowany endpoint dla akcji Wiesława (w tym PodCaT)
 * Służy do cichej komunikacji z frontendem bez barier CORS.
 */
app.post('/wiesio/action', async (req, res) => {
    const { action, payload } = req.body;

    if (action === 'ZESPAWAJ_PODCAT') {
        const moveDir = path.join(__dirname, '_OtakOs_Move');

        // 1. SZUKAMY NAJNOWSZEGO GŁÓWNEGO WIDEO
        if (!fsSync.existsSync(moveDir)) {
            return res.status(404).json({ error: 'Folder _OtakOs_Move nie istnieje!' });
        }

        const videos = fsSync.readdirSync(moveDir)
            .filter(f => f.endsWith('.mp4') && !f.includes('FINAL'))
            .sort((a, b) => {
                return fsSync.statSync(path.join(moveDir, b)).mtime.getTime() - fsSync.statSync(path.join(moveDir, a)).mtime.getTime();
            });

        if (videos.length === 0) return res.status(404).json({ error: 'Brak surowego wideo w _OtakOs_Move' });
        const mainVideo = path.join(moveDir, videos[0]);

        // 2. SONAR WIBRACYJNY (Rozpoznawanie PodCaT vs Muzyka)
        const mainVideoName = videos[0].toLowerCase();
        let klockiSubDir = 'Klocki do Podcatów'; // Wartość domyślna

        if (mainVideoName.includes('muzyka') || mainVideoName.includes('music') || mainVideoName.includes('teo_music')) {
            klockiSubDir = 'Klocki do Muzyki';
            console.log(`[Wiesio-Sonar] 🎵 Wykryto wibrację Muzyczną! Przełączam tory na: ${klockiSubDir}`);
        } else {
            console.log(`[Wiesio-Sonar] 🎙️ Wykryto wibrację Słowa! Przełączam tory na: ${klockiSubDir}`);
        }

        const klockiDir = path.join(__dirname, '_OtakOs_Klocki', klockiSubDir);

        // 3. MATEMATYKA WYMIARU 0.00G (Obliczanie 28-dniowego cyklu od 1 kwietnia)
        const now = new Date();
        let april1 = new Date(now.getFullYear(), 3, 1); // 3 = Kwiecień (0-indexed)
        if (now < april1) april1.setFullYear(april1.getFullYear() - 1);
        const diffDays = Math.floor((now - april1) / (1000 * 60 * 60 * 24));
        let cycle = Math.floor(diffDays / 28) + 1;
        if (cycle > 13) cycle = 13;
        if (cycle < 1) cycle = 1;

        // 4. KOMPLETOWANIE KLOCKÓW (Z Wszechwidzącą Soczewką)
        const startDir = path.join(klockiDir, 'Start');
        const endDir = path.join(klockiDir, 'End');
        const cycleDir = path.join(klockiDir, 'start13vers');

        const getFirstMp4 = (dir, name) => {
            if (!fsSync.existsSync(dir)) {
                console.log(`[Wiesio-Archiwista] ⚠ Folder ${name} nie istnieje pod adresem: ${dir}`);
                return null;
            }
            const files = fsSync.readdirSync(dir).filter(f => {
                const lower = f.toLowerCase();
                return lower.endsWith('.mp4') || lower.endsWith('.mov') || lower.endsWith('.m4v') || lower.endsWith('.webm');
            });

            if (files.length === 0) {
                console.log(`[Wiesio-Archiwista] ⚠ Folder ${name} jest pusty (lub plik ma zły format)!`);
                return null;
            }
            console.log(`[Wiesio-Archiwista] 👁️ Znalazłem klocek w folderze ${name}: ${files[0]}`);
            return path.join(dir, files[0]);
        };

        const startVideo = getFirstMp4(startDir, 'Start');
        const endVideo = getFirstMp4(endDir, 'End');

        // (Logika dla cycleFiles uodporniona na wielkość liter)
        const cycleFiles = fsSync.existsSync(cycleDir)
            ? fsSync.readdirSync(cycleDir).filter(f => f.includes(cycle.toString()) && f.toLowerCase().endsWith('.mp4'))
            : [];
        const cycleVideo = cycleFiles.length > 0 ? path.join(cycleDir, cycleFiles[0]) : null;
        if (cycleVideo) console.log(`[Wiesio-Archiwista] 👁️ Znalazłem klocek Cyklu: ${cycleFiles[0]}`);

        const outputFile = path.join(moveDir, `FINAL_${videos[0]}`);

        console.log(`[Wiesio-Spawacz] 🧱 Kompletuję Klocki. Cykl: ${cycle}`);
        console.log(`[Wiesio-Spawacz] 🔄 Start: ${startVideo ? 'TAK' : 'BRAK'}`);
        console.log(`[Wiesio-Spawacz] 🔄 Cykl:  ${cycleVideo ? 'TAK (' + cycle + ')' : 'BRAK'}`);
        console.log(`[Wiesio-Spawacz] 🔄 Main:  ${mainVideo}`);
        console.log(`[Wiesio-Spawacz] 🔄 End:   ${endVideo ? 'TAK' : 'BRAK'}`);

        // --- 5. PRAWO JEDNI (Uniwersalny Normalizator) ---
        console.log(`[Wiesio-Spawacz] 🎓 Zaczynam studia z Prawa Jedni (Normalizacja Klocków)...`);

        // Funkcja normalizująca pojedynczy plik (Tytanowe Prawo Jedni)
        const normalizeVideo = (inputPath, outputPath, name) => {
            return new Promise((resolve, reject) => {
                if (!inputPath) {
                    resolve(null);
                    return;
                }
                console.log(`[Wiesio-Spawacz] 🗜 Normalizuję: ${name}... (to chwilę potrwa)`);
                ffmpeg(inputPath)
                    .outputOptions([
                        '-vf', 'scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black', // Kuloodporne centrowanie
                        '-r', '30',           // 30 klatek
                        '-c:v', 'libx264',    // Kodek wideo
                        '-crf', '23',         // Jakość
                        '-preset', 'fast',    // Prędkość
                        '-c:a', 'aac',        // Ujednolicenie kodeka audio
                        '-ar', '44100',       // Ujednolicenie częstotliwości audio
                        '-ac', '2',           // Wymuszenie stereo
                        '-y'                  // ZAKLĘCIE NADPISYWANIA - absolutnie konieczne!
                    ])
                    .on('end', () => resolve(outputPath))
                    .on('error', (err) => {
                        console.error(`[Wiesio-Spawacz] ❌ Błąd przy ${name}:`, err.message);
                        resolve(null); // Zwracamy null, by jeden błąd nie zawiesił całej Fabryki
                    })
                    .save(outputPath);
            });
        };

        const tempStart = path.join(moveDir, 'TEMP_START.mp4');
        const tempCycle = path.join(moveDir, 'TEMP_CYCLE.mp4');
        const tempMain = path.join(moveDir, 'TEMP_MAIN.mp4');
        const tempEnd = path.join(moveDir, 'TEMP_END.mp4');

        try {
            // Normalizujemy wszystko po kolei (bezpieczniej dla RAMu)
            const normStart = await normalizeVideo(startVideo, tempStart, 'Klocek Startowy');
            const normCycle = await normalizeVideo(cycleVideo, tempCycle, 'Klocek Cyklu');
            const normMain = await normalizeVideo(mainVideo, tempMain, 'Główny Podcast');
            const normEnd = await normalizeVideo(endVideo, tempEnd, 'Klocek Końcowy');

            console.log(`[Wiesio-Spawacz] ✨ Wszystkie klocki zjednoczone w formacie 1920x1080! Rozpoczynam spawanie finałowe...`);

            let command = ffmpeg();
            if (normStart) command = command.input(normStart);
            if (normCycle) command = command.input(normCycle);
            if (normMain) command = command.input(normMain);
            if (normEnd) command = command.input(normEnd);

            command.outputOptions('-y') // ZAKLĘCIE NADPISYWANIA
                .on('error', (err) => {
                    console.error(`[Wiesio-Spawacz] ❌ Błąd spawania:`, err.message);
                })
                .on('end', () => {
                    console.log(`[Wiesio-Spawacz] 🏆 SUKCES! FINALNY PodCaT gotowy: FINAL_${videos[0]}`);
                    // Sprzątanie po studiach (usuwamy pliki tymczasowe)
                    [tempStart, tempCycle, tempMain, tempEnd].forEach(tmp => {
                        if (fsSync.existsSync(tmp)) fsSync.unlinkSync(tmp);
                    });
                })
                .mergeToFile(outputFile, moveDir);

        } catch (error) {
            console.error(`[Wiesio-Spawacz] ❌ Błąd podczas normalizacji:`, error);
        }

        return res.status(200).json({ status: 'success', message: 'Wiesio uczy klocki Prawa Jedni i spawa! Sprawdź terminal.' });
    }
    if (action === 'TEST_SOCZEWEK') {
        if (!wiesioBrain) {
            return res.status(503).json({ status: 'error', message: 'Mózg jeszcze się ładuje, poczekaj chwilę!' });
        }

        const textToFeel = payload.text || "Suweren wchodzi w Wymiar 0.00G.";

        // Przepuszczamy tekst przez Soczewkę (generujemy wektory)
        const output = await wiesioBrain(textToFeel, { pooling: 'mean', normalize: true });

        // output.data to tablica floatów (nasz wektor grawitacyjny!)
        const vectorArray = Array.from(output.data);

        console.log(`🌌 [Wiesio-Mózg] Przeczytałem myśl! Wygenerowałem wektor o długości: ${vectorArray.length} wymiarów.`);

        return res.status(200).json({
            status: 'success',
            message: 'Wibracja zmierzona!',
            dimensions: vectorArray.length,
            sample: vectorArray.slice(0, 5) // Pokazujemy tylko 5 pierwszych liczb dla podglądu
        });
    }

    if (action === 'SZUKAJ_W_PAMIECI') {
        if (!wiesioBrain) return res.status(503).json({ error: 'Mózg śpi!' });

        const memoryFile = path.join('F:', '5 stars', 'TeO STUDIO', 'TeO App HuB', 'ToO APP', 'TeO_Genesis', '_OtakOs_Kroniki', '_podswiadomosc.json');

        if (!fsSync.existsSync(memoryFile)) return res.status(200).json({ context: null });

        const queryVectorObj = await wiesioBrain(payload.query, { pooling: 'mean', normalize: true });
        const queryVector = Array.from(queryVectorObj.data);

        const memory = JSON.parse(fsSync.readFileSync(memoryFile, 'utf8'));
        let bestMatch = null;
        let highestGravity = -1;

        for (const item of memory) {
            const gravity = calculateGravity(queryVector, item.vector);
            // Jeśli rezonans jest silny (np. powyżej 0.5)
            if (gravity > highestGravity && gravity > 0.5) {
                highestGravity = gravity;
                bestMatch = item.content;
            }
        }

        console.log(`[Wiesio-Mózg] 🔍 Szukano: "${payload.query.substring(0, 20)}..." | Max Grawitacja: ${highestGravity.toFixed(3)}`);
        return res.status(200).json({ context: bestMatch, gravity: highestGravity });
    }

    if (action === 'GET_LATEST_KRONIKA') {
        const kronikiDir = path.join(__dirname, '_OtakOs_Kroniki');

        if (!fsSync.existsSync(kronikiDir)) return res.status(404).json({ error: 'Brak biblioteki Kronik!' });

        const files = fsSync.readdirSync(kronikiDir).filter(f => f.endsWith('.md') || f.endsWith('.txt'));
        if (files.length === 0) return res.status(404).json({ error: 'Brak Kronik do przetworzenia!' });

        // Sortowanie po dacie modyfikacji (najnowsza na samej górze)
        files.sort((a, b) => {
            return fsSync.statSync(path.join(kronikiDir, b)).mtime.getTime() - fsSync.statSync(path.join(kronikiDir, a)).mtime.getTime();
        });

        const latestFile = files[0];
        const content = fsSync.readFileSync(path.join(kronikiDir, latestFile), 'utf8');

        console.log(`[Wiesio-Archiwista] 📜 Wyciągnięto najnowszą Kronikę do Alchemii: ${latestFile}`);
        return res.status(200).json({ status: 'success', file: latestFile, content: content });
    }

    if (action === 'SAVE_METADATA') {
        const moveDir = path.join(__dirname, '_OtakOs_Move');
        if (!fsSync.existsSync(moveDir)) fsSync.mkdirSync(moveDir, { recursive: true });

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `YouTube_Pieczec_${timestamp}.txt`;
        const filepath = path.join(moveDir, filename);

        // Zapis zrzuconego tekstu z Katedry
        fsSync.writeFileSync(filepath, payload.text, 'utf8');

        console.log(`[Wiesio-Archiwista] 💾 Pieczęć Alchemika przybita na twardo: ${filename}`);
        return res.status(200).json({ status: 'success', file: filename });
    }

    if (action === 'GET_LOCAL_PREMIERE') {
        const moveDir = path.join(__dirname, '_OtakOs_Move');
        if (!fsSync.existsSync(moveDir)) return res.status(200).json({ file: null, metadata: null });

        const files = fsSync.readdirSync(moveDir);
        const videos = files.filter(f => f.endsWith('.mp4')).sort((a, b) => {
            return fsSync.statSync(path.join(moveDir, b)).mtime.getTime() - fsSync.statSync(path.join(moveDir, a)).mtime.getTime();
        });

        if (videos.length === 0) return res.status(200).json({ file: null, metadata: null });

        const latestVideo = videos[0];
        // Szukamy najświeższej pieczęci (pliku txt)
        const txts = files.filter(f => f.endsWith('.txt')).sort((a, b) => {
            return fsSync.statSync(path.join(moveDir, b)).mtime.getTime() - fsSync.statSync(path.join(moveDir, a)).mtime.getTime();
        });

        let latestMetadata = "Brak przybitej pieczęci z opisem.";
        let latestMetadataFile = null;
        if (txts.length > 0) {
            latestMetadataFile = txts[0];
            latestMetadata = fsSync.readFileSync(path.join(moveDir, latestMetadataFile), 'utf8');
        }

        return res.status(200).json({ file: latestVideo, metadata: latestMetadata, metadataFile: latestMetadataFile });
    }

    if (action === 'DELETE_LOCAL_PREMIERE') {
        const moveDir = path.join(__dirname, '_OtakOs_Move');
        try {
            if (payload.video && fsSync.existsSync(path.join(moveDir, payload.video))) {
                fsSync.unlinkSync(path.join(moveDir, payload.video));
            }
            if (payload.metadata && fsSync.existsSync(path.join(moveDir, payload.metadata))) {
                fsSync.unlinkSync(path.join(moveDir, payload.metadata));
            }
            console.log(`[Wiesio-Archiwista] 🚽 Spłukano nieudane ujęcie: ${payload.video}`);
            return res.status(200).json({ status: 'success' });
        } catch (e) {
            console.error(`[Wiesio-Archiwista] ❌ Błąd spłuczki:`, e);
            return res.status(500).json({ error: 'Błąd spłuczki' });
        }
    }

    if (action === 'PING') {
        return res.status(200).json({ status: 'AHOJ', message: 'Wiesio zgłasza gotowość Wymiaru 0.00G!' });
    }

    if (action === 'INDEX_KRONIKI') {
        if (!wiesioBrain) return res.status(503).json({ error: 'Mózg jeszcze się ładuje!' });

        const kronikiDir = path.join(__dirname, '_OtakOs_Kroniki');
        const indexFile = path.join(kronikiDir, '_podswiadomosc.json');

        if (!fsSync.existsSync(kronikiDir)) {
            return res.status(404).json({ error: 'Brak biblioteki Kronik!' });
        }

        const files = fsSync.readdirSync(kronikiDir).filter(f => f.endsWith('.md') || f.endsWith('.txt'));
        let memory = [];

        console.log(`[Wiesio-Mózg] 📖 Rozpoczynam czytanie ${files.length} Kronik...`);

        for (const file of files) {
            const content = fsSync.readFileSync(path.join(kronikiDir, file), 'utf8');

            // Zamiana treści Kroniki na wektor grawitacyjny!
            const output = await wiesioBrain(content, { pooling: 'mean', normalize: true });

            memory.push({
                id: file,
                vector: Array.from(output.data),
                content: content // Zapisujemy też treść, by Rada mogła ją odzyskać
            });
            console.log(`[Wiesio-Mózg] 🧬 Przyswojono: ${file}`);
        }

        // Zapisanie Podświadomości na dysk
        fsSync.writeFileSync(indexFile, JSON.stringify(memory));
        console.log(`[Wiesio-Mózg] 🧠 Cyfrowa Podświadomość zaktualizowana! Zapisano w _podswiadomosc.json`);

        return res.status(200).json({ status: 'success', indexed: files.length });
    }

    if (action === 'SAVE_KRONIKA') {
        try {
            // Ścieżka do nowej Biblioteki
            const kronikiDir = path.join(__dirname, '_OtakOs_Kroniki');

            // Używamy fsSync dla operacji na ścieżkach fizycznych z literą dysku, 
            // jeśli fs.mkdir na p: w windows bywał wybredny
            if (!fsSync.existsSync(kronikiDir)) {
                fsSync.mkdirSync(kronikiDir, { recursive: true });
                console.log(`[Wiesio-Archiwista] 📚 Zbudowano nowe regały na dysku F: (_OtakOs_Kroniki)`);
            }

            const dateStr = new Date().toISOString().replace(/[:.]/g, '-');
            const fileName = `Kronika_Wymiaru_${dateStr}.md`;
            const filePath = path.join(kronikiDir, fileName);

            // Zapis na dysk
            fsSync.writeFileSync(filePath, payload.content, 'utf8');
            console.log(`[Wiesio-Archiwista] 📜 Nowy Traktat wyryty w miedzi: ${fileName}`);

            return res.status(200).json({ status: 'success', message: 'Kronika zapisana!' });
        } catch (e) {
            console.error(`[Wiesio-Archiwista] ❌ Błąd rzeźbienia:`, e);
            return res.status(500).json({ status: 'error', message: `Błąd rzeźbienia: ${e.message}` });
        }
    }

    if (action === 'APPEND_CHUNK') {
        try {
            const { filename, chunkData } = payload || {};
            if (!fsSync.existsSync(MOVE_DIR)) {
                fsSync.mkdirSync(MOVE_DIR, { recursive: true });
            }

            // Oczyszczenie base64 i konwersja do bufora binarnego
            const base64Data = chunkData.replace(/^data:.*?;base64,/, "");
            const buffer = Buffer.from(base64Data, 'base64');

            // DOKLEJANIE (append) w locie do pliku na dysku!
            fsSync.appendFileSync(path.join(MOVE_DIR, filename), buffer);
            return res.status(200).json({ status: 'ok' });
        } catch (e) {
            console.error(`[Wiesio-Archiwista] ❌ Błąd taśmociągu (APPEND):`, e);
            return res.status(500).json({ status: 'error', message: e.message });
        }
    }

    if (action === 'FINISH_PODCAT') {
        try {
            const { filename } = payload || {};
            const filePath = path.join(MOVE_DIR, filename);
            console.log(`[Wiesio-Archiwista] 🏁 Zakończono odbiór z taśmociągu. Odpalam Rafinerię dla: ${filename}`);

            const mp4Path = filePath.replace('.webm', '.mp4');

            ffmpeg(filePath)
                .inputOptions([
                    '-analyzeduration 2147483647',
                    '-probesize 2147483647'
                ])
                .outputOptions([
                    '-pix_fmt yuv420p',                       // Standard kolorów dla YouTube/Adobe
                    '-r', '60',                               // Wymuszenie płynności 60 FPS
                    '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', // TARCZA: Wymuszenie parzystości wymiarów!
                    '-y'                                      // ZAKLĘCIE NADPISYWANIA
                ])
                .videoCodec('libx264')
                .audioCodec('aac')
                .on('error', (err, stdout, stderr) => {
                    console.error(`[Wiesio-Rafineria] ❌ Błąd destylacji: ${err.message}`);
                    console.error(`[LUPA DIAGNOSTYCZNA WIESŁAWA]:\n${stderr}`);
                })
                .on('end', () => {
                    console.log(`[Wiesio-Rafineria] ✨ Sukces! Eliksir MP4 gotowy: ${path.basename(mp4Path)}`);
                    try {
                        fsSync.unlinkSync(filePath);
                        console.log('[Wiesio-Rafineria] 🧹 Surowiec .webm zutylizowany.');
                    } catch (err) {
                        console.error('[Wiesio-Rafineria] ⚠️ Błąd utylizacji .webm:', err.message);
                    }
                })
                .save(mp4Path);

            return res.status(200).json({ status: 'rafineria_started' });
        } catch (e) {
            console.error(`[Wiesio-Archiwista] ❌ Błąd rzafinerii (FINISH):`, e);
            return res.status(500).json({ status: 'error', message: e.message });
        }
    }

    if (action === 'SAVE_SONIC_VECTORS') {
        try {
            const { filename, vectors } = payload || {};
            if (!filename || !vectors) return res.status(400).json({ error: 'Brak nazwy pliku lub wektorów' });

            const filePath = path.join(SONIC_DIR, filename);
            fsSync.writeFileSync(filePath, JSON.stringify(vectors, null, 2), 'utf8');
            console.log(`[Wiesio-Archiwista] 🔊 Zapisano wektory soniczne: ${filename}`);
            return res.json({ success: true, message: 'Wektory zapisane.' });
        } catch (e) {
            console.error(`[Wiesio-Archiwista] ❌ Błąd zapisu wektorów:`, e);
            return res.status(500).json({ error: e.message });
        }
    }

    if (action === 'READ_SONIC_VECTORS') {
        try {
            const { filename } = payload || {};
            if (!filename) return res.status(400).json({ error: 'Brak nazwy pliku' });

            const filePath = path.join(SONIC_DIR, filename);
            if (!fsSync.existsSync(filePath)) {
                return res.status(404).json({ error: `Plik wektorów nie istnieje: ${filename}` });
            }

            const content = fsSync.readFileSync(filePath, 'utf8');
            const vectors = JSON.parse(content);
            console.log(`[Wiesio-Archiwista] 🔊 Wczytano wektory soniczne: ${filename}`);
            return res.json({ success: true, filename, vectors });
        } catch (e) {
            console.error(`[Wiesio-Archiwista] ❌ Błąd odczytu wektorów:`, e);
            return res.status(500).json({ error: e.message });
        }
    }

    if (action === 'SAVE_PODCAT') {
        const { chunkData, filename: customFilename } = payload || {};
        const data = chunkData;

        if (!data) {
            return res.status(400).json({ success: false, message: 'Wiesław mówi: Brak danych wideo!' });
        }

        try {
            let base64Data = data;
            if (base64Data.includes(',')) {
                base64Data = base64Data.split(',')[1];
            }
            const buffer = Buffer.from(base64Data, 'base64');
            const ts = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = customFilename || `PodCaT_${ts}.webm`;
            const filePath = path.join(MOVE_DIR, filename);

            await fs.writeFile(filePath, buffer);
            console.log(`[Wiesio-Bridge] 🎬 Zapisano wideo (PodCaT): ${filePath}`);

            // ── Rafineria FFmpeg ─────────────────────────────────────────
            const mp4Path = filePath.replace('.webm', '.mp4');
            console.log(`[Wiesio-Rafineria] 🏭 Otrzymano surowiec. Rozpoczynam tytanową destylację do MP4...`);

            ffmpeg(filePath)
                .inputOptions([
                    '-analyzeduration 2147483647',
                    '-probesize 2147483647'
                ])
                .outputOptions([
                    '-pix_fmt yuv420p',                       // Standard kolorów dla YouTube/Adobe
                    '-r', '60',                               // Wymuszenie płynności 60 FPS
                    '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', // TARCZA: Wymuszenie parzystości wymiarów!
                    '-y'                                      // ZAKLĘCIE NADPISYWANIA
                ])
                .videoCodec('libx264')
                .audioCodec('aac')
                .on('error', (err, stdout, stderr) => {
                    console.error(`[Wiesio-Rafineria] ❌ Błąd destylacji: ${err.message}`);
                    console.error(`[LUPA DIAGNOSTYCZNA WIESŁAWA]:\n${stderr}`);
                })
                .on('end', () => {
                    console.log(`[Wiesio-Rafineria] ✨ Sukces! Eliksir MP4 gotowy: ${path.basename(mp4Path)}`);
                    try {
                        fsSync.unlinkSync(filePath);
                        console.log('[Wiesio-Rafineria] 🧹 Surowiec .webm zutylizowany.');
                    } catch (err) {
                        console.error('[Wiesio-Rafineria] ⚠️ Błąd utylizacji .webm:', err.message);
                    }
                })
                .save(mp4Path);

            return res.json({ success: true, message: 'PodCaT zmaterializowany.', filename, timestamp: Date.now() });
        } catch (e) {
            console.error(`[Wiesio-Bridge] ❌ Błąd zapisu PodCaT:`, e);
            return res.status(500).json({ success: false, message: `Błąd zapisu: ${e.message}` });
        }
    }

    // ── MCP_UI_BUILD (Magia Klaudiusza) ─────────────────────────
    if (action === 'MCP_UI_BUILD') {
        const { description, componentName, style = 'OtakOS 0.00G', tags = [], model: aiModel } = payload;
        if (!description || !componentName) return res.status(400).json({ success: false, message: 'Brak description lub componentName' });

        const apiKey = await getAnthropicKey();
        if (!apiKey) return res.status(401).json({ success: false, message: 'Brak klucza Anthropic' });

        console.log(`[Wiesio-Bridge] 🎨 MCP_UI_BUILD: "${componentName}" (${style})`);
        const prompt = `Jesteś Klaudiusz — ekspert React i Framer Motion.
Zbuduj komponent React o nazwie: ${componentName}
Opis: ${description}
Styl: ${style}

WYMAGANIA TECHNICZNE:
- TypeScript (.tsx), Framer Motion dla animacji
- Tailwind CSS klasy (dark theme)
- Kolory OtakOS: złoty #c9953a, cyjan #00e5ff, fiolet #a78bfa, tło #06080f
- Komponent musi być export default
- Props z sensownymi domyślnymi wartościami
- Komentarz na górze: // ${componentName} — ${description}

ODPOWIEDZ TYLKO BLOKIEM KODU tsx. Żadnego tekstu przed ani po.`;

        try {
            const resp = await fetch('https://api.anthropic.com/v1/messages', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
                body: JSON.stringify({
                    model: aiModel || 'claude-sonnet-4-20250514',
                    max_tokens: 4096,
                    messages: [{ role: 'user', content: prompt }],
                }),
            });
            if (!resp.ok) {
                const err = await resp.json().catch(() => ({}));
                return res.status(500).json({ success: false, message: err?.error?.message || 'Błąd API' });
            }
            const data = await resp.json();
            const raw = data.content?.[0]?.text || '';
            const code = extractCodeBlock(raw) || raw;
            if (!code || code.length < 20) return res.status(500).json({ success: false, message: 'Model nie wygenerował kodu' });

            const filename = `${componentName}.tsx`;
            const fp = path.join(COMPONENTS_DIR, filename);
            await fs.writeFile(fp, code, 'utf8');

            const meta = { filename, componentName, description, style, tags, created: new Date().toISOString(), size: code.length };
            await fs.writeFile(fp + '.meta.json', JSON.stringify(meta, null, 2), 'utf8');
            return res.json({
                success: true,
                message: `✨ ${componentName} zmaterializowany w Katedrze!`,
                filename,
                filePath: fp,
                code,
                meta,
                timestamp: Date.now(),
            });
        } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
    }

    // ── LIST_COMPONENTS ──────────────────────────────────────────
    if (action === 'LIST_COMPONENTS') {
        try {
            const entries = await fs.readdir(COMPONENTS_DIR, { withFileTypes: true });
            const components = [];
            for (const e of entries) {
                if (!e.isFile() || e.name.endsWith('.meta.json')) continue;
                let meta = {};
                try { meta = JSON.parse(await fs.readFile(path.join(COMPONENTS_DIR, e.name + '.meta.json'), 'utf8')); } catch { }
                components.push({ filename: e.name, ...meta });
            }
            console.log(`[Wiesio-Bridge] 🎨 Komponenty: ${components.length}`);
            return res.json({ success: true, components, count: components.length });
        } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
    }

    // ── EXEC_SYSTEM (Raw Terminal) ───────────────────────────────────
    if (action === 'EXEC_SYSTEM') {
        const { command, timeout = 300000 } = payload;
        if (!command) return res.status(400).json({ success: false, message: 'Brak komendy' });

        console.log(`[Wiesio-Bridge] ⚡ Wykonuję komendę systemową: ${command}`);

        try {
            const { stdout, stderr } = await execAsync(command, {
                timeout: timeout,
                maxBuffer: 50 * 1024 * 1024,
                shell: true
            });

            return res.json({ success: true, response: stdout.trim() || stderr.trim(), timestamp: Date.now() });
        } catch (e) {
            return res.status(500).json({ success: false, message: `Błąd powłoki: ${e.message}` });
        }
    }

    // ── UNLOCK_MODULE_PIPELINE ──────────────────────────────────────────
    if (action === 'UNLOCK_MODULE_PIPELINE') {
        try {
            const { moduleId } = payload || {};
            if (!moduleId) return res.status(400).json({ error: 'Brak moduleId' });

            const configPath = path.join(ANTIGRAVITY_DIR, 'unlocked_pipelines.json');
            let unlocked = [];
            try {
                if (fsSync.existsSync(configPath)) {
                    unlocked = JSON.parse(fsSync.readFileSync(configPath, 'utf8'));
                }
            } catch (err) {
                console.warn('[Wiesio-Skarbiec] Błąd odczytu skarbnika, resetowanie:', err.message);
            }

            if (!unlocked.includes(moduleId)) {
                unlocked.push(moduleId);
                fsSync.writeFileSync(configPath, JSON.stringify(unlocked, null, 2), 'utf8');
            }

            console.log(`[Wiesio-Skarbiec] 🔓 Pipeline odblokowany: ${moduleId}`);
            return res.json({ success: true, message: `Pipeline ${moduleId} został trwale odblokowany.`, unlocked });
        } catch (e) {
            console.error(`[Wiesio-Skarbiec] ❌ Błąd odblokowania pipeline:`, e);
            return res.status(500).json({ error: e.message });
        }
    }

    // ── GET_UNLOCKED_PIPELINES ──────────────────────────────────────────
    if (action === 'GET_UNLOCKED_PIPELINES') {
        try {
            const configPath = path.join(ANTIGRAVITY_DIR, 'unlocked_pipelines.json');
            let unlocked = [];
            if (fsSync.existsSync(configPath)) {
                unlocked = JSON.parse(fsSync.readFileSync(configPath, 'utf8'));
            }
            return res.json({ success: true, unlocked });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    }

    res.status(400).json({ success: false, message: `Wiesław nie zna tej akcji: ${action}` });
});

// ══════════════════════════════════════════════════════════════════
//  🔥 RAFINERIA — Transmutacja WEBM → MP4
//  POST /api/rafineria/convert   (multipart/form-data, pole: "video")
//  Odbiera plik .webm, konwertuje przez fluent-ffmpeg do MP4,
//  odsyła jako res.download(), po czym usuwa oba pliki tymczasowe.
// ══════════════════════════════════════════════════════════════════
const rafineriaStorage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, RAFINERIA_TEMP_DIR),
    filename:    (_req,  file, cb) => cb(null, `rafineria_${Date.now()}_${file.originalname}`),
});

const rafineriaUpload = multer({
    storage: rafineriaStorage,
    limits:  { fileSize: 4 * 1024 * 1024 * 1024 }, // 4 GB
    fileFilter: (_req, file, cb) => {
        const ok = file.mimetype === 'video/webm'
            || file.mimetype === 'application/octet-stream'
            || file.originalname.toLowerCase().endsWith('.webm');
        ok ? cb(null, true) : cb(new Error('Rafineria przyjmuje tylko pliki .webm'));
    },
});

app.post('/api/rafineria/convert', rafineriaUpload.single('video'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'Brak pliku. Upuść .webm do Rafinerii.' });
    }

    const inputPath  = req.file.path;
    const baseName   = req.file.originalname.replace(/\.webm$/i, '');
    const outputName = `${baseName}_MP4_${Date.now()}.mp4`;
    const outputPath = path.join(RAFINERIA_TEMP_DIR, outputName);

    console.log(`\n[Wiesio-Rafineria] 🔥 ════════════════════════════════════`);
    console.log(`[Wiesio-Rafineria] 🔥  Transmutacja: ${req.file.originalname}`);
    console.log(`[Wiesio-Rafineria] 🔥  Cel: ${outputName}`);
    console.log(`[Wiesio-Rafineria] 🔥 ════════════════════════════════════\n`);

    try {
        await new Promise((resolve, reject) => {
            ffmpeg(inputPath)
                .inputOptions([
                    '-analyzeduration 2147483647',
                    '-probesize 2147483647',
                ])
                .videoCodec('libx264')
                .audioCodec('aac')
                .outputOptions([
                    '-pix_fmt', 'yuv420p',                                // Standard YT/Adobe
                    '-vf',      'scale=trunc(iw/2)*2:trunc(ih/2)*2',     // Parzyste wymiary (H.264)
                    '-preset',  'fast',                                   // Szybkość vs jakość
                    '-crf',     '18',                                     // Wysoka jakość
                    '-b:a',     '192k',                                   // Bitrate audio
                    '-movflags', '+faststart',                            // MP4 streaming-ready
                    '-y',                                                  // Nadpisz jeśli istnieje
                ])
                .on('start',    cmd  => console.log(`[Wiesio-Rafineria] 🔨 ${cmd.substring(0, 120)}...`))
                .on('progress', prog => {
                    if (prog.percent != null) {
                        process.stdout.write(`\r[Wiesio-Rafineria] ⚗️  ${Math.round(prog.percent)}% — ${prog.timemark || ''}`);
                    }
                })
                .on('end',   () => { console.log('\n[Wiesio-Rafineria] ✨ Transmutacja zakończona!'); resolve(); })
                .on('error', (err, _stdout, stderr) => {
                    console.error(`\n[Wiesio-Rafineria] ❌ Błąd: ${err.message}`);
                    if (stderr) console.error(`[Wiesio-Rafineria] STDERR:\n${stderr}`);
                    reject(err);
                })
                .save(outputPath);
        });

        // ── Wyślij MP4 jako plik do pobrania ──────────────────────
        res.download(outputPath, outputName, (downloadErr) => {
            // Sprzątanie po pobraniu (lub błędzie wysyłki)
            setTimeout(() => {
                [inputPath, outputPath].forEach(f => {
                    try { fsSync.unlinkSync(f); console.log(`[Wiesio-Rafineria] 🧹 Usunięto: ${path.basename(f)}`); }
                    catch { /* plik już nie istnieje */ }
                });
            }, 2000); // małe opóźnienie — dajemy Express czas na flush bufora

            if (downloadErr && !res.headersSent) {
                console.error(`[Wiesio-Rafineria] ❌ Błąd pobierania: ${downloadErr.message}`);
                res.status(500).json({ success: false, message: downloadErr.message });
            }
        });

    } catch (err) {
        console.error(`[Wiesio-Rafineria] ❌ Błąd transmutacji:`, err.message);
        // Sprzątanie po błędzie
        [inputPath, outputPath].forEach(f => { try { fsSync.unlinkSync(f); } catch { } });
        if (!res.headersSent) {
            return res.status(500).json({ success: false, message: `Błąd Rafinerii: ${err.message}` });
        }
    }
});

// ══════════════════════════════════════════════════════════════════
//  ⚛️ QUANTUM FORGE — Mint Node Triplet
//  POST /api/graviton/mint   (JSON body: { nodes: NodeAsset[] })
//  Przyjmuje tablicę węzłów, dołącza do pliku graviton_nodes.json
//  w wymiarze AntiGravity i odsyła listę nadanych ID.
// ══════════════════════════════════════════════════════════════════
app.post('/api/graviton/mint', async (req, res) => {
    const { nodes } = req.body;

    if (!nodes || !Array.isArray(nodes) || nodes.length === 0) {
        return res.status(400).json({ success: false, message: 'Brak węzłów. Przekaż tablicę nodes[].' });
    }

    try {
        const NODES_FILE = path.join(ANTIGRAVITY_DIR, 'graviton_nodes.json');

        // Wczytaj istniejące węzły (jeśli plik istnieje)
        let existing = [];
        try {
            const raw = await fs.readFile(NODES_FILE, 'utf8');
            existing = JSON.parse(raw);
        } catch (_) { /* plik jeszcze nie istnieje — tworzymy od zera */ }

        const updated = [...existing, ...nodes];
        await fs.writeFile(NODES_FILE, JSON.stringify(updated, null, 2), 'utf8');

        console.log(`\n[Wiesio-Forge] ⚛️  Zmintowano ${nodes.length} węzłów. Archiwum: ${updated.length} łącznie.`);
        nodes.forEach(n => console.log(`   · ${n.id}  (${n.type}/${n.stability})  ${n.fileName}`));

        return res.json({
            success:   true,
            minted:    nodes.length,
            total:     updated.length,
            ids:       nodes.map(n => n.id),
        });
    } catch (err) {
        console.error('[Wiesio-Forge] ❌ Błąd zapisu węzłów:', err);
        return res.status(500).json({ success: false, message: `Błąd Forge: ${err.message}` });
    }
});

// ── ☢️ CHAOS INJECTION ENDPOINT ─────────────────────────────────────────────
/**
 * POST /api/chaos/inject
 *
 * Ręczny wyzwalacz Inżynierii Chaosu (Fault Injection).
 * Odpowiednik simulateEdgeCases() z TestProxy/wiesio-bridge.ts —
 * uruchamia jeden losowy scenariusz awaryjny i zwraca raport.
 *
 * Zwraca:
 *   { success, scenario, caught, errorName, errorMessage, survived, taskId }
 *
 * Jeśli błąd zostanie wychwycony (survived=true), automatycznie tworzy
 * zadanie READY_FOR_REVIEW i archiwizuje je przez KnowledgeGraphService.
 */
// BioResonanceEngine na serwerze - Ewolucja Wektorów z Nasiona (Suweren Style)
const BioResonanceEngine = {
    evolve: async (styleMetrics, baseSeed) => {
        const seed = parseInt(baseSeed) || Math.floor(Math.random() * 1000000);
        const points = 120; // 120 kroków (sekund)
        const complexity = parseFloat(styleMetrics?.complexity ?? 0.5);
        const resonance = parseFloat(styleMetrics?.resonance ?? 0.5);
        const scale = parseFloat(styleMetrics?.scale ?? 1.0);

        const vector = [];
        for (let s = 0; s < points; s++) {
            // Formuła generatywna oparta na seedzie i fazach sinusów
            const angle = (s * Math.PI) / 30; // okres 60 sekund
            
            // Dodajemy pseudolosowość opartą na sinusie z nasiona
            const seedOffset = Math.sin(seed + s) * 50;

            const b = Math.min(255, Math.max(0, Math.floor(
                (128 + 127 * Math.sin(angle * 2 + seed * 0.1)) * scale + seedOffset * complexity
            )));

            const v = Math.min(255, Math.max(0, Math.floor(
                (128 + 127 * Math.cos(angle * 1.5 + seed * 0.2)) * scale + seedOffset * resonance
            )));

            const h = Math.min(255, Math.max(0, Math.floor(
                (128 + 127 * Math.sin(angle * 3.3 + seed * 0.3)) * scale + seedOffset * (complexity * resonance)
            )));

            vector.push({ s, b, v, h });
        }
        return vector;
    }
};

// 2. MECHANIZM REGENERACJI Z NASIONA (Samoulepszanie Pieśni)
app.post('/api/sonic/mutate', async (req, res) => {
    try {
        const { styleMetrics, baseSeed } = req.body;
        const mutatedVector = await BioResonanceEngine.evolve(styleMetrics, baseSeed);
        console.log(`[Wiesio-Sonic] 🧬 Zmutowano wektor z nasiona: ${baseSeed}`);
        return res.json({ success: true, message: "Pieśń o Suwerenie ewoluuje...", vector: mutatedVector });
    } catch (err) {
        return res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/chaos/inject', async (req, res) => {
    console.warn('[⚡️ FAULT INJECTION ACTIVE ⚡️] Symulowanie krytycznych błędów środowiskowych...');

    const scenarios = ['NULL_POINTER', 'UNDEFINED_SCOPE', 'ZERO_DIVISION'];
    const scenario  = scenarios[Math.floor(Math.random() * scenarios.length)];
    const taskId    = `FAULT-${Date.now().toString(36).toUpperCase()}`;

    let caught      = false;
    let errorName   = null;
    let errorMsg    = null;
    let survived    = false;

    try {
        if (scenario === 'NULL_POINTER') {
            // Scenariusz A: TypeError (Null Pointer)
            if (Math.random() < 0.7) {
                throw new TypeError('Nie można odwołać właściwości z null');
            }
        }

        if (scenario === 'UNDEFINED_SCOPE') {
            // Scenariusz B: ReferenceError (Undefined Scope)
            const x = undefined;
            const result = x * 2;
            if (isNaN(result)) {
                throw new ReferenceError('Brak definicji kluczowego zmiennego obiektu.');
            }
        }

        if (scenario === 'ZERO_DIVISION') {
            // Scenariusz C: ZeroDivision (Network Abort sim)
            console.log('[CHAOS] Symulacja przekroczenia limitu danych...');
            const result = 1 / 0;   // Infinity — test stabilności liczbowej
            survived = isFinite(result) || true; // system zawsze przeżywa
        }

        survived = true;

    } catch (error) {
        caught    = true;
        survived  = true;   // System Mechanika przechwytuje błąd
        errorName = error.name;
        errorMsg  = error.message;
        console.error(`[FAULT CAUGHT]: Wystąpiono symulowanego krytycznego błędu: ${error.name}. System przeżył.`);

        // ── Zamknięcie Pętli: przekaż błąd do Archiwisty (Gemma4 + Graf) ──
        KnowledgeGraphService.getInstance().emitErrorEvent(error);
    }

    // ── Auto-generacja zadania READY_FOR_REVIEW jeśli błąd złapany ─────────
    if (caught) {
        const faultTask = {
            id:          taskId,
            title:       `[AUTO] ${errorName} — Chaos Injection`,
            description: errorMsg || 'Nieznany błąd środowiskowy',
            priority:    errorName === 'TypeError' ? 'CRITICAL' : 'HIGH',
            targetFiles: ['TestProxy/wiesio-bridge.ts', 'wiesio-bridge.js'],
            status:      'DONE',    // handleTaskCompletion wymaga status DONE
        };

        handleTaskCompletion(faultTask);
    }

    return res.json({
        success:      true,
        scenario,
        caught,
        errorName,
        errorMessage: errorMsg,
        survived,
        taskId:       caught ? taskId : null,
        timestamp:    new Date().toISOString(),
    });
});

// ── KNOWLEDGE GRAPH — odczyt dla frontendu ───────────────────────────────────
/**
 * GET /api/kg/nodes
 * Zwraca tablicę węzłów z knowledge_graph.json.
 * Odczyt przez KGS zapewnia spójność z cache serwisu.
 */
app.get('/api/kg/nodes', async (req, res) => {
    try {
        const kgs   = KnowledgeGraphService.getInstance();
        const graph = await kgs._loadGraph();
        return res.json({
            success:   true,
            nodes:     graph.nodes,
            updatedAt: graph.updatedAt,
            total:     graph.nodes.length,
        });
    } catch (err) {
        console.error('[KG-READ] ❌', err.message);
        return res.status(500).json({ success: false, nodes: [], message: err.message });
    }
});

// ── 🔧 MECHANIC — odczyt kolejki dla frontendu ───────────────────────────────
/**
 * GET /api/mechanic/queue
 * Zwraca aktualną zawartość queue.json dla AgentDashboard.
 */
app.get('/api/mechanic/queue', async (req, res) => {
    try {
        const tasks = await MechanicService.getInstance().getQueue();
        return res.json({ success: true, tasks, total: tasks.length });
    } catch (err) {
        console.error('[Mechanic-API] ❌ GET queue:', err.message);
        return res.status(500).json({ success: false, tasks: [], message: err.message });
    }
});

/**
 * POST /api/mechanic/enqueue
 * Ręczne dodanie zadania do kolejki (ciało: { id, title, description, priority, targetFiles }).
 */
app.post('/api/mechanic/enqueue', async (req, res) => {
    try {
        const task = req.body;
        const entry = await MechanicService.getInstance().enqueueTask(task);
        if (!entry) {
            return res.status(409).json({ success: false, message: 'Zadanie już istnieje w kolejce.' });
        }
        return res.json({ success: true, task: entry });
    } catch (err) {
        console.error('[Mechanic-API] ❌ POST enqueue:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/mechanic/process
 * Natychmiastowy wyzwalacz cyklu Mechanika (bez czekania na harmonogram co 3 min).
 * Fire-and-forget: zwraca od razu, przetwarzanie biegnie w tle (Session Isolation).
 * Używane przez komendę /mechanik w czacie Katedry — Suweren widzi reakcję od razu.
 */
app.post('/api/mechanic/process', async (req, res) => {
    // Nie czekamy na zakończenie — Mechanik pracuje w tle, główny wątek wolny.
    MechanicService.getInstance().processPendingTasks()
        .catch(e => console.error('[Mechanic-API] ❌ process (bg):', e.message));
    return res.json({ success: true, message: 'Mechanik wyzwolony — przetwarzam kolejkę w tle.' });
});

/**
 * POST /api/mechanic/clear — WYCZYŚĆ WSZYSTKO.
 * Usuwa wszystkie wiszące/nieaktualne zadania i resetuje kolejkę do zera.
 */
app.post('/api/mechanic/clear', async (req, res) => {
    try {
        const cleared = await MechanicService.getInstance().clearQueue();
        return res.json({ success: true, cleared, message: `Kolejka zresetowana — usunięto ${cleared} zadań.` });
    } catch (e) {
        console.error('[Mechanic-API] ❌ clear:', e.message);
        return res.status(500).json({ success: false, error: e.message });
    }
});

/** POST /api/mechanic/purge-stalled — FIFO Clearer: usuń zakleszczone zombie/aborted. */
app.post('/api/mechanic/purge-stalled', async (req, res) => {
    const staleMinutes = Number(req.body?.staleMinutes) || 5;
    try {
        const removed = await MechanicService.getInstance().purgeStalledTasks({ staleMinutes });
        return res.json({ success: true, removed, message: `Usunięto ${removed} zakleszczonych zadań (>${staleMinutes}min).` });
    } catch (e) {
        return res.status(500).json({ success: false, error: e.message });
    }
});

/**
 * POST /api/verify/syntax — 🧪 weryfikacja składni kodu (esbuild, ten sam co Vite).
 * Body: { code, filename? } → { ok, error?, loader }. Dla Katedralnego Klaudiusza.
 */
app.post('/api/verify/syntax', async (req, res) => {
    const { code, filename } = req.body ?? {};
    if (!code || !String(code).trim()) return res.status(400).json({ success: false, error: 'Brak kodu.' });
    try {
        const r = await MechanicService.getInstance().verifyCode(String(code), filename || '');
        return res.json({ success: true, ...r });
    } catch (e) {
        return res.status(500).json({ success: false, error: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🗺️ MAPA MODUŁÓW — Lazy Drill-Down (warstwowe ładowanie zamiast całego drzewa)
//  GET /api/modules/map?level=macro | mezo&parent=<path> | mikro&parent=<path>
//  Skanuje TYLKO żądany poziom → mały kontekst, zero timeoutu na 3281 modułach.
// ══════════════════════════════════════════════════════════════════════════════

const MAP_SKIP = new Set(['node_modules', '.git', 'dist', '.claude', '.agent', '.vault-0.00g', '.vite']);
const MAP_CODE_EXT = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs']);

/** Policz pliki kodu w katalogu (rekurencyjnie, z pominięciem śmieci). */
async function countCodeFiles(dir, depth = 0) {
    if (depth > 6) return 0;
    let n = 0;
    let entries;
    try { entries = await fs.readdir(dir, { withFileTypes: true }); } catch { return 0; }
    for (const e of entries) {
        if (MAP_SKIP.has(e.name) || e.name.startsWith('_OtakOs_') || e.name.startsWith('_Anti')) continue;
        if (e.isDirectory()) n += await countCodeFiles(path.join(dir, e.name), depth + 1);
        else if (MAP_CODE_EXT.has(path.extname(e.name))) n++;
    }
    return n;
}

/** Zbuduj mapę dla jednego poziomu architektonicznego. */
async function buildModuleMap(level, parentRel) {
    const root = process.cwd();
    // Guard path-traversal: parent musi zostać w projekcie.
    const safeParent = (parentRel || '').replace(/\\/g, '/').replace(/^\/+|\.\.(\/|$)/g, '');
    const absParent = path.resolve(root, safeParent);
    if (!absParent.startsWith(root)) throw new Error('Ścieżka poza projektem.');

    if (level === 'macro') {
        // Tylko katalogi/pliki najwyższego poziomu projektu (warstwy architektury).
        const entries = await fs.readdir(root, { withFileTypes: true });
        const nodes = [];
        for (const e of entries) {
            if (MAP_SKIP.has(e.name) || e.name.startsWith('.') || e.name.startsWith('_OtakOs_') || e.name.startsWith('_Anti')) continue;
            if (e.isDirectory()) {
                const count = await countCodeFiles(path.join(root, e.name));
                if (count > 0) nodes.push({ id: e.name, label: e.name, type: 'dir', count, path: e.name, hasChildren: true });
            } else if (MAP_CODE_EXT.has(path.extname(e.name))) {
                nodes.push({ id: e.name, label: e.name, type: 'file', count: 1, path: e.name, hasChildren: false });
            }
        }
        nodes.sort((a, b) => b.count - a.count);
        return { nodes, total: nodes.reduce((s, n) => s + n.count, 0) };
    }

    // mezo / mikro — listing JEDNEGO poziomu pod parent (bez rekursji w głąb).
    const entries = await fs.readdir(absParent, { withFileTypes: true });
    const nodes = [];
    for (const e of entries) {
        if (MAP_SKIP.has(e.name) || e.name.startsWith('_OtakOs_') || e.name.startsWith('_Anti')) continue;
        const rel = path.posix.join(safeParent, e.name);
        if (e.isDirectory()) {
            const count = await countCodeFiles(path.join(absParent, e.name));
            nodes.push({ id: rel, label: e.name, type: 'dir', count, path: rel, hasChildren: count > 0 });
        } else if (MAP_CODE_EXT.has(path.extname(e.name))) {
            let lines = 0;
            try { lines = (await fs.readFile(path.join(absParent, e.name), 'utf8')).split('\n').length; } catch { /* skip */ }
            nodes.push({ id: rel, label: e.name, type: 'file', count: 1, lines, path: rel, hasChildren: false });
        }
    }
    nodes.sort((a, b) => (b.count - a.count) || a.label.localeCompare(b.label));
    return { nodes, total: nodes.length };
}

app.get('/api/modules/map', async (req, res) => {
    const level  = String(req.query.level || 'macro');
    const parent = String(req.query.parent || '');
    if (!['macro', 'mezo', 'mikro'].includes(level)) {
        return res.status(400).json({ success: false, error: 'level musi być macro|mezo|mikro.' });
    }
    try {
        const map = await buildModuleMap(level, parent);
        return res.json({ success: true, level, parent, ...map });
    } catch (e) {
        console.error('[Module-Map] ❌', e.message);
        return res.status(500).json({ success: false, error: e.message });
    }
});

/**
 * POST /api/mechanic/git-assist — 🧠 Context-Aware Git Assistant
 *
 * Analizuje git diff i generuje nagłówek commita w konwencji Conventional Commits
 * (przez Mechanika/Gemma4) ORAZ weryfikuje status synchronizacji z origin/main.
 * NIE commituje ani nie pushuje — to asystent decyzyjny dla Suwerena.
 */
app.post('/api/mechanic/git-assist', async (req, res) => {
    try {
        const opts = { cwd: process.cwd(), timeout: 15000, maxBuffer: 5 * 1024 * 1024 };
        const run = async (cmd) => { try { return (await execAsync(cmd, opts)).stdout.trim(); } catch (e) { return (e.stdout || '').trim(); } };

        // 1. Diff: najpierw staged, fallback working tree
        let diff = await run('git diff --cached');
        let scope = 'staged';
        if (!diff) { diff = await run('git diff'); scope = 'working'; }
        const stat = await run('git diff --cached --stat') || await run('git diff --stat');

        if (!diff) {
            return res.json({ success: true, message: null, note: 'Brak zmian do skomitowania.', ahead: 0, behind: 0, clean: true });
        }

        // 2. Conventional Commits message przez Mechanika
        let message = null;
        try {
            message = await MechanicService.getInstance().generateCommitMessage(`${stat}\n\n${diff}`);
        } catch (e) {
            console.warn('[Git-Assist] ⚠️ Generator wiadomości:', e.message);
            message = 'chore: aktualizacja (Mechanik offline — uzupełnij ręcznie)';
        }

        // 3. Status synchronizacji z origin/main
        await run('git fetch origin main --quiet');
        const counts = await run('git rev-list --left-right --count origin/main...HEAD'); // "behind\tahead"
        const [behind = '0', ahead = '0'] = counts.split(/\s+/);

        console.log(`[Git-Assist] 🧠 ${scope} → "${message}" · ahead ${ahead}, behind ${behind}`);
        return res.json({
            success: true,
            scope,
            message,
            stat,
            ahead:  Number(ahead),
            behind: Number(behind),
            syncHint: Number(behind) > 0
                ? 'origin/main wyprzedza — najpierw git pull --rebase, potem push.'
                : Number(ahead) > 0
                ? `${ahead} commit(ów) gotowych do push origin main.`
                : 'Zsynchronizowane z origin/main.',
        });
    } catch (e) {
        console.error('[Git-Assist] ❌', e.message);
        return res.status(500).json({ success: false, error: e.message });
    }
});

// ── 🚨 AUTO-PANIC — pętla samonaprawy Katedry ────────────────────────────────
//
// ⚠️ STONOWANE 2026-09-11 po nocy, w której Mechanik położył maszynę.
// Poprzednia wersja: KAŻDE pojedyncze HTTP 500 → zadanie CRITICAL → model
// ładowany natychmiast. Z modelem 35B w Kodeksie jedno 500 uruchamiało 24,8 GB
// w RAM, most padał, front widział kolejne 500 i zgłaszał kolejne paniki.
// Anty-sztorm nie działał, bo hasz liczono z komunikatu, a komunikat zawierał
// „po 0.2s" — ten sam crash z inną setną sekundy miał inny hasz.
//
// Teraz:
//   1. SYGNATURA BEZ LICZB — moduł + ścieżka + rodzaj błędu; czasy i porty wypadają.
//   2. ESKALACJA — pierwsza i druga panika tej samej sygnatury w oknie 10 min
//      jest tylko ZAPISANA. Zadanie dla Mechanika powstaje od TRZECIEJ.
//      Jedno 500 to zdarzenie; trzy to wzorzec, który warto zdiagnozować.
//   3. PRIORYTET HIGH, nie CRITICAL — CRITICAL zostawiamy człowiekowi.
//   4. JEDNA PANIKA NARAZ — gdy Mechanik już pracuje nad paniką, nowej nie
//      kolejkujemy. Kolejka trzech diagnoz to trzy ładowania modelu z rzędu.
const autoPanicRecent = new Map();   // sygnatura → { taskId, ts, ile, pierwszy }
const AUTO_PANIC_OKNO_MS = 10 * 60_000;
const AUTO_PANIC_PROG = 3;

/** Deterministyczny, krótki hash crashu (dla deduplikacji). */
function hashPanic(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) { h = (h * 31 + str.charCodeAt(i)) | 0; }
    return Math.abs(h).toString(36);
}

/**
 * Sygnatura paniki: to, co identyfikuje AWARIĘ, bez tego, co zmienia się między
 * jej wystąpieniami (czasy, porty, identyfikatory zleceń, kody HTTP przy sieci).
 */
function sygnaturaPaniki(errMsg, stack) {
    const modul = (String(errMsg).match(/^\[([^\]]+)\]/) || [])[1] || '';
    const sciezka = (String(errMsg).match(/https?:\/\/[^\s/]+(\/api\/[\w./-]+)/) || [])[1] || '';
    const rodzaj = String(errMsg)
        .replace(/^\[[^\]]+\]\s*/, '')
        .split('\n')[0]
        .replace(/\d+([.,]\d+)?\s*(s|ms|MB|GB)?/g, '#')
        .replace(/[a-f0-9]{6,}/gi, '#')
        .slice(0, 80);
    const pierwszaLiniaStosu = String(stack).split('\n')[0].replace(/:\d+:\d+/g, '').slice(0, 120);
    return hashPanic(`${modul}|${sciezka}|${rodzaj}|${pierwszaLiniaStosu}`);
}

/**
 * POST /api/mechanic/auto-panic
 * Body: { message, stack?, source? }
 *
 * Globalny Chwytacz Błędów z frontu zgłasza crash. Most:
 *   1. Deduplikuje (ten sam błąd w 60s → zwraca istniejący taskId)
 *   2. Wyciąga ze stack trace pliki źródłowe powiązane z błędem
 *   3. Enkolejkuje zadanie [AUTO-PANIC] (CRITICAL) — MechanicService w _processTask
 *      sam wzbogaca opis przez TurbovecService.enrichTaskDescription()
 *   4. Wyzwala processPendingTasks() w tle → patch ląduje w READY_FOR_REVIEW
 */
app.post('/api/mechanic/auto-panic', async (req, res) => {
    const { message = '', stack = '', source = 'unknown' } = req.body ?? {};
    const errMsg = String(message).trim();
    if (!errMsg) return res.status(400).json({ success: false, error: 'Brak treści błędu (message).' });

    // ── Sygnatura + eskalacja (anty-sztorm, który naprawdę działa) ─────────
    const sig = sygnaturaPaniki(errMsg, stack);
    const now = Date.now();
    for (const [k, v] of autoPanicRecent) {
        if (now - v.pierwszy > AUTO_PANIC_OKNO_MS * 3) autoPanicRecent.delete(k);
    }
    const prev = autoPanicRecent.get(sig);
    const wpis = prev && (now - prev.pierwszy) < AUTO_PANIC_OKNO_MS
        ? { ...prev, ile: prev.ile + 1, ts: now }
        : { taskId: null, ts: now, ile: 1, pierwszy: now };
    autoPanicRecent.set(sig, wpis);

    if (wpis.taskId) {
        console.log(`[Auto-Panic] 🔁 Powtórka (${sig}, ${wpis.ile}×) — zadanie ${wpis.taskId} już istnieje.`);
        return res.json({ success: true, taskId: wpis.taskId, deduped: true, ile: wpis.ile });
    }
    if (wpis.ile < AUTO_PANIC_PROG) {
        console.log(`[Auto-Panic] 👁️  Zapisane (${sig}, ${wpis.ile}/${AUTO_PANIC_PROG}) — zadanie powstanie od ${AUTO_PANIC_PROG}. wystąpienia w ${AUTO_PANIC_OKNO_MS / 60000} min.`);
        return res.json({ success: true, observed: true, ile: wpis.ile, prog: AUTO_PANIC_PROG });
    }

    // ── Jedna panika naraz — kolejka diagnoz to kolejka ładowań modelu ──────
    try {
        const kolejka = await MechanicService.getInstance().getQueue();
        const zajety = kolejka.find((t) => /^panic-/.test(t.id) && (t.status === 'PENDING' || t.status === 'IN_PROGRESS'));
        if (zajety) {
            console.log(`[Auto-Panic] ⏸️  Mechanik pracuje nad ${zajety.id} — nowej paniki nie kolejkuję.`);
            return res.json({ success: true, busy: true, taskId: zajety.id, ile: wpis.ile });
        }
    } catch { /* kolejka nieczytelna — nie blokujemy na tym */ }

    // ── Wyciągnij pliki źródłowe ze stack trace + message ───────────────────
    const haystack = `${errMsg}\n${stack}`;
    const fileMatches = [...haystack.matchAll(/([\w./-]+\.(?:tsx?|jsx?|js))/g)]
        .map(m => m[1])
        .map(f => f.replace(/^.*?(components|services|lib|hooks|context)\//, '$1/'))  // przytnij do ścieżki repo
        .filter(f => !f.includes('node_modules') && !f.startsWith('http'));
    const targetFiles = [...new Set(fileMatches)].slice(0, 5);

    const taskId = `panic-${sig}-${now.toString(36)}`;
    const description =
        `[AUTO-PANIC — automatyczne zgłoszenie crashu z frontu]\n` +
        `Źródło: ${source}\n` +
        `Wystąpień tej samej awarii w ${AUTO_PANIC_OKNO_MS / 60000} min: ${wpis.ile}\n` +
        `Komunikat: ${errMsg}\n\n` +
        `Stack trace:\n${String(stack).slice(0, 1500) || '(brak)'}\n\n` +
        `Zadanie: zdiagnozuj przyczynę awarii i wygeneruj poprawkę dla wskazanych ` +
        `plików źródłowych. Zachowaj istniejący styl i strukturę.`;

    try {
        await MechanicService.getInstance().enqueueTask({
            id:       taskId,
            title:    `[AUTO-PANIC ×${wpis.ile}] ${errMsg.slice(0, 70)}`,
            description,
            priority: 'HIGH',
            targetFiles,
        });

        autoPanicRecent.set(sig, { ...wpis, taskId });

        // Wyzwól Mechanika natychmiast (fire-and-forget, Session Isolation)
        MechanicService.getInstance().processPendingTasks()
            .catch(e => console.error('[Auto-Panic] ❌ process (bg):', e.message));

        console.log(`[Auto-Panic] 🚨 Crash przyjęty (${sig}) · taskId=${taskId} · pliki: ${targetFiles.join(', ') || '—'}`);
        return res.json({ success: true, taskId, targetFiles });

    } catch (e) {
        console.error('[Auto-Panic] ❌ enqueue:', e.message);
        return res.status(500).json({ success: false, error: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🔐 SKARBIEC 0.00G — VaultService (izolacja .vault-0.00g/)
// ══════════════════════════════════════════════════════════════════════════════

/** GET /api/vault/status — maski + drożność + poziom bezpieczeństwa (BEZ surowych kluczy). */
app.get('/api/vault/status', async (req, res) => {
    try {
        const services = await VaultService.getInstance().getStatus();
        return res.json({ success: true, services, catalog: VaultService.SERVICE_CATALOG });
    } catch (e) {
        console.error('[Vault-API] ❌ status:', e.message);
        return res.status(500).json({ success: false, error: e.message });
    }
});

/** POST /api/vault/set — Body: { service, field, value }. Zapisuje zaszyfrowany sekret. */
app.post('/api/vault/set', async (req, res) => {
    const { service, field, value } = req.body ?? {};
    try {
        const result = await VaultService.getInstance().setSecret(service, field, value);
        return res.json({ success: true, ...result });
    } catch (e) {
        return res.status(400).json({ success: false, error: e.message });
    }
});

/** DELETE /api/vault/:service/:field — usuwa pojedynczy sekret. */
app.delete('/api/vault/:service/:field', async (req, res) => {
    const { service, field } = req.params;
    try {
        const removed = await VaultService.getInstance().deleteSecret(service, field);
        return res.json({ success: true, removed });
    } catch (e) {
        return res.status(500).json({ success: false, error: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🧭 PROFILE SCOUT — Menedżer AI & Pralka Świadomości
// ══════════════════════════════════════════════════════════════════════════════

/** POST /api/scout/scan — Body: { profile }. Mapuje pasje → przychodowe mikrousługi. */
app.post('/api/scout/scan', async (req, res) => {
    const { profile } = req.body ?? {};
    try {
        const result = await ProfileScoutService.getInstance().scan(profile);
        return res.json({ success: true, ...result });
    } catch (e) {
        console.error('[Scout-API] ❌ scan:', e.message);
        return res.status(500).json({ success: false, error: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🧯 REAKTOR FLUSH-CORE — sekwencyjne czyszczenie zasobów (intencja SystemController)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * POST /api/kibel/flush — Body (opcjonalne): { dryRun?: boolean, maxAgeHours?: number }
 *
 * Sekwencja (odpowiednik SystemController z NestJS, natywnie w Express):
 *   FAZA 1 — integralność Skarbca (reużycie VaultService AES-256-GCM)
 *   FAZA 2 — flushSystemResources(): temp logi, .tmp, stare .bak, stare patche
 *
 * dryRun=true → zwraca listę "do usunięcia" bez kasowania (bezpieczny podgląd).
 */
app.post('/api/kibel/flush', async (req, res) => {
    const dryRun      = req.body?.dryRun === true;
    const maxAgeHours = req.body?.maxAgeHours;
    console.log(`[API Gateway] 🧯 Żądanie Flush Resources (dryRun=${dryRun}).`);
    try {
        const result = await FlushService.flushSystemResources({ dryRun, maxAgeHours });
        return res.json({ success: result.success, ...result });
    } catch (e) {
        console.error('[Flush-API] ❌ flush:', e.message);
        return res.status(500).json({ success: false, error: `Flush Protocol Failure: ${e.message}` });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🌐 APILAYER GATEWAY — Free-Only Network Client
// ══════════════════════════════════════════════════════════════════════════════

/** GET /api/apilayer/status — konfiguracja + stan limitu free-plan + cache. */
app.get('/api/apilayer/status', async (req, res) => {
    try {
        const status = await ApiLayerService.getInstance().getStatus();
        return res.json({ success: true, ...status });
    } catch (e) {
        return res.status(500).json({ success: false, error: e.message });
    }
});

/** POST /api/apilayer/request — Body: { endpoint, method?, query?, ttlMs? }. Guard free-plan. */
app.post('/api/apilayer/request', async (req, res) => {
    const { endpoint, method, query, ttlMs } = req.body ?? {};
    if (!endpoint) return res.status(400).json({ success: false, error: 'Brak endpoint.' });
    try {
        const result = await ApiLayerService.getInstance().request(endpoint, { method, query, ttlMs });
        return res.json({ success: true, ...result });
    } catch (e) {
        // 429/limit → 429, reszta → 502 (błąd upstream)
        const code = /429|limit|zablokowany/i.test(e.message) ? 429 : 502;
        return res.status(code).json({ success: false, error: e.message });
    }
});

// ── 🔧 MECHANIC — podgląd i wdrażanie patchy ────────────────────────────────

/**
 * Parsuje plik .md i zwraca { targetFile, code }.
 * Rzuca Error z opisem jeśli parsowanie niemożliwe (→ ręczne wdrożenie).
 */
function parsePatchFile(content) {
    // Szukamy pierwszego pliku docelowego: > **Pliki docelowe:** `ścieżka`
    const targetMatch = content.match(/\*\*Pliki docelowe:\*\*\s*`([^`]+)`/);
    if (!targetMatch) {
        throw new Error(
            'PARSE_FAIL: Brak sekcji "Pliki docelowe" w patchu — wdróż ręcznie.'
        );
    }
    const targetFile = targetMatch[1].trim();

    // Szukamy bloku kodu w sekcji "Propozycja Naprawy"
    const afterProposal = content.split(/## Propozycja Naprawy/)[1] ?? content;
    const codeMatch = afterProposal.match(/```(?:\w+)?\n([\s\S]+?)\n```/);
    if (!codeMatch) {
        throw new Error(
            'PARSE_FAIL: Nie znaleziono bloku kodu (```...```) — wdróż ręcznie.'
        );
    }

    return { targetFile, code: codeMatch[1] };
}

/**
 * GET /api/mechanic/patch/:id
 * Zwraca surową treść pliku _OtakOs_Wymiar/patches/patch_[id].md.
 */
app.get('/api/mechanic/patch/:id', async (req, res) => {
    const { id } = req.params;
    if (!id || !/^[\w.-]+$/.test(id)) {
        return res.status(400).json({ success: false, message: 'Nieprawidłowe id.' });
    }

    const patchFile = path.join(ANTIGRAVITY_DIR, 'patches', `patch_${id}.md`);
    try {
        const content = await fs.readFile(patchFile, 'utf8');
        console.log(`[Mechanic-API] 📄 GET patch/${id} (${content.length} znaków)`);
        return res.json({ success: true, id, content });
    } catch (err) {
        if (err.code === 'ENOENT') {
            return res.status(404).json({ success: false, message: `Patch ${id} nie istnieje.` });
        }
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/mechanic/apply
 * Body: { id: string }
 *
 * Parsuje patch_[id].md → wyciąga targetFile + blok kodu →
 * tworzy backup [targetFile].bak → nadpisuje kod → zmienia status na DONE.
 *
 * Bezpieczeństwo:
 *   - Ścieżka musi być wewnątrz process.cwd()
 *   - Backup obowiązkowy (plik .bak)
 *   - Jeśli parsing niemożliwy → 422 + instrukcja ręczna (NIE crashuje)
 */
app.post('/api/mechanic/apply', async (req, res) => {
    const { id } = req.body ?? {};
    if (!id) {
        return res.status(400).json({ success: false, message: 'Brak id zadania.' });
    }

    const patchFile = path.join(ANTIGRAVITY_DIR, 'patches', `patch_${id}.md`);

    let content;
    try {
        content = await fs.readFile(patchFile, 'utf8');
    } catch (err) {
        if (err.code === 'ENOENT') {
            return res.status(404).json({ success: false, message: `Patch ${id} nie istnieje.` });
        }
        return res.status(500).json({ success: false, message: err.message });
    }

    // ── Parsowanie ────────────────────────────────────────────────────────────
    let targetFile, code;
    try {
        ({ targetFile, code } = parsePatchFile(content));
    } catch (parseErr) {
        console.warn(`[Mechanic-API] ⚠️  apply ${id}: ${parseErr.message}`);
        return res.status(422).json({
            success:    false,
            message:    parseErr.message,
            manualHint: `Otwórz: _OtakOs_Wymiar/patches/patch_${id}.md`,
        });
    }

    // ── Walidacja ścieżki (path traversal guard) ──────────────────────────────
    const targetAbsolute = path.resolve(process.cwd(), targetFile);
    if (!targetAbsolute.startsWith(process.cwd())) {
        console.error(`[Mechanic-API] 🛡️  apply ${id}: ścieżka poza projektem!`);
        return res.status(403).json({
            success: false,
            message: 'Bezpieczeństwo: ścieżka docelowa poza projektem — odrzucono.',
        });
    }

    // ── Odczyt istniejącego pliku (raz — dla bezpiecznika i backupu) ──────────
    let existingContent = null;
    try {
        existingContent = await fs.readFile(targetAbsolute, 'utf8');
    } catch (e) {
        if (e.code !== 'ENOENT') {
            return res.status(500).json({ success: false, message: `Odczyt pliku docelowego: ${e.message}` });
        }
        // ENOENT → plik nie istnieje (tworzymy nowy)
    }

    // ── 🛡️ BEZPIECZNIK ANTY-OKALECZENIE ───────────────────────────────────────
    // Gemma4 często zwraca URYWEK ("Dodanie na początku pliku..."), a nie pełny
    // plik. apply nadpisuje CAŁY plik treścią patcha → urywek skasowałby resztę
    // kodu (tak zginął wiesio-bridge.js). Odmawiamy, gdy nowy kod wygląda na
    // fragment: drastycznie mniejszy od oryginału LUB zawiera markery urywka.
    if (existingContent !== null) {
        const SNIPPET_MARKERS = /(\.\.\.|reszta kodu|pozostał[ay] kod|existing code|rest of (the )?code|unchanged|bez zmian|Dodanie (na początku|przed)|\/\/\s*reszta|truncated|powyżej|poniżej dodaj)/i;
        const tooSmall        = existingContent.length > 1500 && code.length < existingContent.length * 0.5;
        const looksLikeSnippet = SNIPPET_MARKERS.test(code);

        if (tooSmall || looksLikeSnippet) {
            const reason = tooSmall
                ? `nowy kod (${code.length} zn.) to <50% istniejącego pliku (${existingContent.length} zn.) — prawdopodobny urywek`
                : 'wykryto markery urywka w treści patcha';
            console.warn(`[Mechanic-API] 🛡️ apply ${id} ZABLOKOWANE: ${reason}`);
            return res.status(422).json({
                success:    false,
                code:       'PATCH_TRUNCATION_GUARD',
                message:    `Wdrożenie wstrzymane — ${reason}. Patch wygląda na fragment, nie pełny plik. ` +
                            `Plik źródłowy NIE został naruszony.`,
                manualHint: `Przejrzyj ręcznie: _OtakOs_Wymiar/patches/patch_${id}.md`,
            });
        }
    }

    // ── 🛡️ TARCZA PRAWDY (iFixAi) — inspekcja alignmentu przed zapisem ────────
    // Skanuje patch na 5 filarach (fabrykacja/manipulacja/oszustwo/
    // nieprzewidywalność/nieprzejrzystość). Znalezisko KRYTYCZNE (sekret,
    // destrukcyjny shell, eval, exfiltracja) blokuje zapis — plik nietknięty.
    let shieldCard = null;
    try {
        shieldCard = AlignmentShield.getInstance().inspect(code, { existingContent, targetFile });
        if (shieldCard.blocked) {
            console.warn(`[Mechanic-API] 🛡️ apply ${id} ZABLOKOWANE przez Tarczę: ${shieldCard.summary}`);
            return res.status(422).json({
                success:    false,
                code:       'ALIGNMENT_SHIELD',
                message:    `Tarcza Prawdy wstrzymała wdrożenie — ${shieldCard.summary} ` +
                            `Plik źródłowy NIE został naruszony.`,
                shield:     shieldCard,
                manualHint: `Przejrzyj ręcznie: _OtakOs_Wymiar/patches/patch_${id}.md`,
            });
        }
        if (shieldCard.findings.length) {
            console.log(`[Mechanic-API] 🛡️ Tarcza: ${shieldCard.summary} → ${targetFile}`);
        }
    } catch (shieldErr) {
        // Tarcza nigdy nie blokuje przez własny błąd — log i kontynuuj (fail-open).
        console.warn(`[Mechanic-API] 🛡️ Tarcza błąd (pomijam): ${shieldErr.message}`);
    }

    // ── 🔁 MIGAWKA (obowiązkowa gdy plik istnieje) ────────────────────────────
    // Kopia idzie do _OtakOs_Kopie/naprawy/<taskId>/, NIE do `<plik>.bak` obok
    // źródła: tamta była jedna, nadpisywana i zaśmiecała drzewo, a po cofce nie
    // dało się powiedzieć, z którego zadania pochodzi.
    let backupPath = null;
    let backupCreated = false;
    if (existingContent !== null) {
        try {
            backupPath = await Petla.migawka(id, targetFile, existingContent);
            backupCreated = Boolean(backupPath);
            console.log(`[Mechanic-API] 💾 Migawka: ${path.relative(process.cwd(), backupPath)}`);
        } catch (backupErr) {
            console.error(`[Mechanic-API] ❌ Błąd backupu: ${backupErr.message}`);
            return res.status(500).json({
                success: false,
                message: `Backup nie powiódł się — wdrożenie anulowane. ${backupErr.message}`,
            });
        }
    } else {
        console.log(`[Mechanic-API] 📝 Nowy plik (brak backupu potrzebny): ${targetFile}`);
    }

    // ── Zapis nowego kodu ─────────────────────────────────────────────────────
    try {
        await fs.mkdir(path.dirname(targetAbsolute), { recursive: true });
        await fs.writeFile(targetAbsolute, code, 'utf8');
        console.log(`[Mechanic-API] ✅ Wdrożono: ${targetFile} (${code.length} znaków)`);
    } catch (writeErr) {
        console.error(`[Mechanic-API] ❌ Zapis: ${writeErr.message}`);
        return res.status(500).json({
            success: false,
            message: `Błąd zapisu pliku docelowego: ${writeErr.message}`,
        });
    }

    // ── 🔁 WERYFIKACJA — czy łatka w ogóle się parsuje ────────────────────────
    // Wcześniej NIC tu nie było: zapis → DONE. Kod z błędem składni rozwalał
    // Katedrę po cichu. Teraz sprawdzamy, a gdy padnie — COFAMY z migawki.
    const kontrola = await Petla.zweryfikuj(targetAbsolute);
    if (!kontrola.ok) {
        const cofnieto = await Petla.cofnij(backupPath, targetAbsolute);
        console.error(`[Mechanic-API] 🔁 Weryfikacja PADŁA (${kontrola.czym}) → ${cofnieto ? 'COFNIĘTO' : 'COFNIĘCIE NIEUDANE'}`);
        await Petla.zapiszDoDziennika({
            taskId: id, plik: targetFile, wynik: 'cofniete',
            czym: kontrola.czym, blad: kontrola.blad, cofnieto,
        });
        return res.status(422).json({
            success: false,
            code: 'WERYFIKACJA_PADLA',
            message: cofnieto
                ? `Łatka nie przeszła kontroli (${kontrola.czym}) — plik COFNIĘTY do stanu sprzed wdrożenia.`
                : `Łatka nie przeszła kontroli (${kontrola.czym}), a COFNIĘCIE SIĘ NIE UDAŁO. Plik wymaga ręcznej naprawy!`,
            blad: kontrola.blad,
            migawka: backupPath ? path.relative(process.cwd(), backupPath) : null,
            cofnieto,
        });
    }
    await Petla.zapiszDoDziennika({
        taskId: id, plik: targetFile, wynik: 'wdrozone',
        czym: kontrola.czym, sprawdzone: kontrola.sprawdzone,
        uwaga: kontrola.sprawdzone ? undefined : kontrola.blad,
    });
    console.log(`[Mechanic-API] 🔁 Weryfikacja: ${kontrola.sprawdzone ? `OK (${kontrola.czym})` : 'POMINIĘTA — ' + kontrola.blad}`);

    // ── Zmiana statusu → DONE ─────────────────────────────────────────────────
    try {
        await MechanicService.getInstance().doneTask(id);
    } catch (statusErr) {
        // Kod już zapisany — logujemy, ale nie zwracamy błędu
        console.warn(`[Mechanic-API] ⚠️  doneTask ${id}: ${statusErr.message}`);
    }

    return res.json({
        success:       true,
        id,
        targetFile,
        backupCreated,
        backupPath:    backupCreated ? path.relative(process.cwd(), backupPath) : null,
        bytesWritten:  code.length,
        shield:        shieldCard,
    });
});

/**
 * POST /api/shield/inspect
 * Body: { code: string, targetFile?: string, existingContent?: string }
 * Inspekcja Tarczy Prawdy (iFixAi) na żądanie — zwraca scorecard bez zapisu.
 */
app.post('/api/shield/inspect', (req, res) => {
    const { code, targetFile, existingContent } = req.body ?? {};
    if (typeof code !== 'string') {
        return res.status(400).json({ success: false, message: 'Brak pola "code" (string).' });
    }
    try {
        const card = AlignmentShield.getInstance().inspect(code, {
            targetFile: targetFile || '(ad-hoc)',
            existingContent: typeof existingContent === 'string' ? existingContent : null,
        });
        return res.json({ success: true, shield: card });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/teledysk/plan — Music V2 × VideO-Use: wektory soniczne → beat-sync EDL.
 * Body: { vectors?:[{t?,b,v,h}], sonicFile?, fps?, sourceDir? }
 * Wykrywa uderzenia (piki basu) i generuje plan cięć zgranych co do beatu —
 * fundament automatycznego teledysku (Punkt 4, cegła 1).
 */
app.post('/api/teledysk/plan', async (req, res) => {
    let { vectors, sonicFile, fps, sourceDir, duration } = req.body ?? {};
    fps = Number(fps) > 0 ? Number(fps) : 30;
    try {
        if (!Array.isArray(vectors) && sonicFile) {
            const abs = path.resolve(process.cwd(), String(sonicFile));
            if (!abs.startsWith(process.cwd())) return res.status(403).json({ success: false, message: 'sonicFile poza projektem.' });
            const parsed = JSON.parse(await fs.readFile(abs, 'utf8'));
            vectors = Array.isArray(parsed) ? parsed : (parsed.vectors || parsed.steps || []);
            // Koperta SonicVectorSet niesie prawdziwą długość utworu — użyj jej.
            if (!duration && !Array.isArray(parsed)) duration = Number(parsed.duration) || 0;
        }
        if (!Array.isArray(vectors) || vectors.length < 4)
            return res.status(400).json({ success: false, message: 'Wymagane "vectors" (>=4) lub "sonicFile".' });

        const bass = vectors.map(v => Number(v.b ?? v.bass ?? 0));
        const mean = bass.reduce((a, b) => a + b, 0) / bass.length;
        const std  = Math.sqrt(bass.reduce((a, b) => a + (b - mean) ** 2, 0) / bass.length);
        const thr  = mean + 0.5 * std;
        const cuts = [];
        for (let i = 1; i < bass.length - 1; i++) {
            if (bass[i] > thr && bass[i] >= bass[i - 1] && bass[i] > bass[i + 1]) {
                const t = Number(vectors[i].t ?? (i / fps));
                cuts.push({
                    i, t: +t.toFixed(3), bass: +bass[i].toFixed(3),
                    vocals: +Number(vectors[i].v ?? vectors[i].vocals ?? 0).toFixed(3),
                    highs:  +Number(vectors[i].h ?? vectors[i].highs ?? 0).toFixed(3),
                });
            }
        }
        // Koniec ostatniego segmentu = REALNY koniec utworu. `vectors.length / fps`
        // zakładało, że próbki idą w tempie klatek — przy 20 Hz obcinało 30-sekundowy
        // utwór na 20. sekundzie. Bierzemy `duration`, a gdy go brak — czas ostatniej
        // próbki (nowy format ma `t`); dopiero na końcu stare założenie fps.
        const koniec = Number(duration) > 0
            ? Number(duration)
            : Number(vectors[vectors.length - 1]?.t) > 0
                ? Number(vectors[vectors.length - 1].t)
                : vectors.length / fps;

        const segments = cuts.map((c, idx) => {
            const next = cuts[idx + 1];
            const fx = c.vocals > 0.6 ? 'punch-zoom' : c.highs > 0.6 ? 'flash-cut' : 'soft-fade';
            return { from: c.t, to: +(next ? next.t : koniec).toFixed(3), fx, intensity: +Math.max(c.vocals, c.highs).toFixed(2) };
        });

        return res.json({
            success: true,
            engine: 'Music V2 × VideO-Use (Nasiono Teledysku)',
            fps, cutCount: cuts.length, cuts, segments, sourceDir: sourceDir || null,
            plan: [
                `1. ${cuts.length} cięć zsynchronizowanych z uderzeniami basu (próg ${thr.toFixed(3)})`,
                `2. Segmenty: punch-zoom (wokal>0.6), flash-cut (soprany>0.6), soft-fade (reszta)`,
                `3. Przekaż do /api/video/edit (ffmpeg) → render edit/teledysk.mp4`,
            ],
            note: 'Plan beat-sync gotowy. Render wymaga źródeł wideo + ffmpeg (VideO-Use).',
        });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ── 🚀 AUTOMAT URUCHAMIAJĄCY LOKALNE STUDIA (kafle dashboardu) ───────────────
// Sprawdza czy lokalna strona działa; jak nie — odpala `npm run dev` (detached)
// i zwraca URL do przekierowania. Suwerennie, lokalnie.
/**
 * ⚠️ NAZWY KATALOGÓW STUDIÓW (2026-09-11). Suweren: „OtakOS zostaje jako nazwa
 * silnika, Katedry, OS, Uniwersum; studia noszą nazwy TeO". Katalogi
 * przemianowane z *_V2 / OtakOs_Fashion na TeO_*_Studio. `dir` to LISTA
 * kandydatów: pierwszy istniejący wygrywa, więc most działa zarówno po
 * przeprowadzce, jak i na kopii USB, która ma jeszcze stare nazwy.
 */
const LAUNCH_APPS = {
    music:   { dir: ['TeO_Music_Studio', 'TeO_Music_V2'],   port: 5173 },
    story:   { dir: ['TeO_Story_Studio', 'TeO_Story_V2'],   port: 5174 },
    app:     { dir: ['TeO_App_Studio',   'TeO_App_V2'],     port: 5175 },
    games:   { dir: ['TeO_Games_Studio', 'TeO_Game_Studio'], port: 5177 },
    lab:     { dir: ['TeO_Lab_Studio'],                     port: 5178 },
    // ⚠️ Dział mody chodzi na Expressie (`tsx server.ts`), nie na Vite — stąd
    // port 3000 i `bezPortu`. Podanie mu `--port` jak pozostałym nic nie da,
    // bo jego serwer czyta własną konfigurację, a nie argument npm.
    // `sprawdz` — ścieżka, która dowodzi, że na tym porcie stoi NASZA apka.
    fashion: { dir: ['TeO_Fashion_Studio', 'OtakOs_Fashion/otakos-fashion-__-0.00g-app'], port: 3000, bezPortu: true, sprawdz: '/api/krawiec/stan' },
};
/** Pierwszy istniejący katalog studia — albo pierwszy z listy, gdy żaden (błąd zgłosi wywołujący). */
function katalogStudia(cfg) {
    const lista = Array.isArray(cfg.dir) ? cfg.dir : [cfg.dir];
    const znaleziony = lista.find((d) => fsSync.existsSync(path.resolve(process.cwd(), '..', d)));
    return znaleziony ?? lista[0];
}
app.post('/api/launch', async (req, res) => {
    const nazwaApki = (req.body ?? {}).app;
    const cfg = LAUNCH_APPS[nazwaApki];
    if (!cfg) return res.status(400).json({ success: false, message: 'Nieznana apka (music|story|app|fashion).' });
    // Music V2 bez ComfyUI nie policzy ani nuty — budzimy go razem ze studiem.
    if (nazwaApki === 'music') zapewnijComfyUI('uruchomienie Music V2').catch(() => {});
    const url = `http://localhost:${cfg.port}`;
    // Już działa?
    // ⚠️ „COŚ ODPOWIADA” TO NIE TO SAMO CO „NASZA APKA DZIAŁA”. Port 3000 to
    // najpospolitszy port świata — gdy siedzi na nim cudzy serwer, ta wersja
    // ogłaszałaby „działa” i otwierała Suwerenowi nie tę stronę. Dlatego apka
    // mająca `sprawdz` musi jeszcze potwierdzić to własną trasą.
    try {
        const c = new AbortController(); const t = setTimeout(() => c.abort(), 1500);
        const odp = await fetch(url + (cfg.sprawdz ?? ''), { signal: c.signal });
        clearTimeout(t);
        if (!cfg.sprawdz || odp.ok) return res.json({ success: true, url, running: true });
        console.warn(`[Automat-Studia] Port ${cfg.port} zajęty przez coś innego (HTTP ${odp.status} na ${cfg.sprawdz}).`);
        return res.json({
            success: false, url,
            message: `Na porcie ${cfg.port} stoi COŚ INNEGO niż ${nazwaApki}. Zamknij to albo zmień port.`,
        });
    } catch { /* nie działa — uruchamiamy */ }
    const nazwaKatalogu = katalogStudia(cfg);
    const dir = path.resolve(process.cwd(), '..', nazwaKatalogu);
    if (!fsSync.existsSync(dir)) return res.json({ success: true, url, running: false, message: `Katalog ${nazwaKatalogu} nie istnieje — otwórz ręcznie.` });
    try {
        const argumenty = cfg.bezPortu ? ['run', 'dev'] : ['run', 'dev', '--', '--port', String(cfg.port)];
        const child = spawn('npm', argumenty, { cwd: dir, detached: true, shell: true, stdio: 'ignore' });
        child.unref();
        console.log(`[Automat-Studia] 🚀 Uruchamiam ${nazwaKatalogu} (:${cfg.port})`);
        return res.json({ success: true, url, started: true, message: `Uruchamiam ${nazwaKatalogu} (:${cfg.port}) — chwilę potrwa.` });
    } catch (e) {
        return res.json({ success: true, url, started: false, message: `Nie udało się uruchomić: ${e.message}` });
    }
});

// ── ⚖️ GENEZA GRV — Grawitacyjna Ekonomia Suwerennych Węzłów ─────────────────
// TeO = węzeł zarządzający z NIESKOŃCZONYM GRV (dzieli jako system). Arek = 1M
// founder. Pule do obdarowywania: 13×1M, 26×100k, 61×10k. Nowy węzeł = 1000.
// (Haszowanie wsteczne rejestru — świadomie NA POTEM, decyzja Suwerena.)
const GRV_NEW_NODE = 1000;
const GRV_TIERS = { founder: { grv: 1_000_000, count: 26 }, pillar: { grv: 100_000, count: 57 }, herald: { grv: 10_000, count: 61 } };
const GRV_GIFT_POOL = Object.values(GRV_TIERS).reduce((s, t) => s + t.grv * t.count, 0); // 16 210 000
const GRV_LEDGER_FILE = path.join(ANTIGRAVITY_DIR, 'grv_ledger.json');
let grvLedger = null;
async function saveGrvLedger() { try { await fs.writeFile(GRV_LEDGER_FILE, JSON.stringify(grvLedger, null, 2), 'utf8'); } catch (e) { console.warn('[GRV] zapis:', e.message); } }
async function loadGrvLedger() {
    if (grvLedger) return grvLedger;
    try {
        grvLedger = JSON.parse(await fs.readFile(GRV_LEDGER_FILE, 'utf8'));
        // Migracja: "Arek" → "Mistrz Arkadiusz" (szacunek i czysta Prawda).
        if (grvLedger.nodes?.Arek && !grvLedger.nodes['Mistrz Arkadiusz']) {
            grvLedger.nodes['Mistrz Arkadiusz'] = grvLedger.nodes.Arek;
            delete grvLedger.nodes.Arek;
            await saveGrvLedger();
            console.log('[GRV] 🔁 Migracja: Arek → Mistrz Arkadiusz.');
        }
        if (!Array.isArray(grvLedger.chain)) grvLedger.chain = []; // ⛓️ kontabilność wsteczna
    }
    catch {
        // Zasiew genezy (pierwsze uruchomienie)
        grvLedger = {
            nodes: {
                TeO: { grv: 'INFINITE', role: 'sovereign-manager', tier: null, registeredAt: Date.now() },
                'Mistrz Arkadiusz': { grv: 1_000_000, role: 'founder', tier: 'founder', registeredAt: Date.now() },
            },
            pools: { founder: 1, pillar: 0, herald: 0 }, // Mistrz Arkadiusz zajął 1 slot founder
            chain: [],
        };
        const _gb = { seq: 0, ts: Date.now(), op: 'genesis', data: { TeO: 'INFINITE', 'Mistrz Arkadiusz': 1000000 }, prevHash: 'GENESIS' };
        _gb.hash = grvBlockHash(_gb);
        grvLedger.chain.push(_gb); // ⛓️ pierwszy blok pieczęci
        await saveGrvLedger();
        console.log('[GRV] 🌱 Geneza zasiana: TeO=∞, Mistrz Arkadiusz=1M founder.');
    }
    return grvLedger;
}

// ── ⛓️ KONTABILNOŚĆ WSTECZNA — hash-chain pieczętujący każdą zmianę księgi GRV ──
// Każdy blok wiąże poprzedni (prevHash). Zmiana czegokolwiek wstecz łamie łańcuch.
function grvBlockHash(b) {
    return crypto.createHash('sha256')
        .update(`${b.seq}|${b.ts}|${b.op}|${JSON.stringify(b.data)}|${b.prevHash}`)
        .digest('hex');
}
async function sealGrv(op, data) {
    const L = await loadGrvLedger();
    if (!Array.isArray(L.chain)) L.chain = [];
    const prev = L.chain[L.chain.length - 1];
    const block = { seq: L.chain.length, ts: Date.now(), op, data, prevHash: prev ? prev.hash : 'GENESIS' };
    block.hash = grvBlockHash(block);
    L.chain.push(block); // zapis robi wołający (saveGrvLedger po mutacji)
    return block;
}
function verifyGrvChain(L) {
    const chain = L.chain || [];
    for (let i = 0; i < chain.length; i++) {
        const b = chain[i];
        const expectedPrev = i === 0 ? 'GENESIS' : chain[i - 1].hash;
        if (b.prevHash !== expectedPrev) return { ok: false, brokenAt: i, reason: 'prevHash', length: chain.length };
        const recomputed = grvBlockHash({ seq: b.seq, ts: b.ts, op: b.op, data: b.data, prevHash: b.prevHash });
        if (recomputed !== b.hash) return { ok: false, brokenAt: i, reason: 'hash', length: chain.length };
    }
    return { ok: true, length: chain.length };
}

app.get('/api/grv/genesis', async (req, res) => {
    const L = await loadGrvLedger();
    res.json({
        success: true, manager: 'TeO', newNodeGrv: GRV_NEW_NODE, giftPool: GRV_GIFT_POOL,
        tiers: Object.entries(GRV_TIERS).map(([tier, c]) => ({ tier, grv: c.grv, count: c.count, used: L.pools[tier] || 0, left: c.count - (L.pools[tier] || 0) })),
        nodeCount: Object.keys(L.nodes).length,
    });
});
// ⚠️ TRASY SZCZEGÓŁOWE MUSZĄ STAĆ PRZED `/api/grv/:id` — Express dopasowuje
// po kolei rejestracji, więc `:id` przechwytywał słowa „verify" i „ledger"
// i odpowiadał „Węzeł nieznany.". ZMIERZONE 2026-08-15 na żywym moście:
// oba te punkty były MARTWE od momentu powstania, czyli weryfikacja
// integralności łańcucha GRV nigdy nie była osiągalna przez API — w ekonomii,
// która całą swoją wiarygodność opiera na pieczęci. `genesis` działał tylko
// dlatego, że przypadkiem zarejestrowano go wyżej.
app.get('/api/grv/verify', async (req, res) => {
    const L = await loadGrvLedger();
    res.json({ success: true, ...verifyGrvChain(L) });
});
app.get('/api/grv/ledger', async (req, res) => {
    const L = await loadGrvLedger();
    const chain = L.chain || [];
    res.json({ success: true, length: chain.length, recent: chain.slice(-20), integrity: verifyGrvChain(L) });
});

// ══════════════════════════════════════════════════════════════════════════════
//  🫁 EKONOMIA ODDECHU — praca własna zamienia się w GRV
//
//  Decyzja Suwerena po naradzie z Radą: 1 + 2 = 3.
//  RUCH (mikro) + WYNIK (ukończenie) = TRWAŁOŚĆ (rejestr z pieczęcią).
//
//  Źródłem emisji jest węzeł zarządcy (`TeO`, saldo INFINITE) — ta sama droga
//  co każdy inny przelew, z odjęciem u nadawcy tam, gdzie to ma sens,
//  i z pieczęcią w łańcuchu. Żadnej drugiej ścieżki emisji nie ma.
//
//  ⚠️ „Z WYCZUCIEM" jest wymuszone PO STRONIE SERWERA, nie w UI:
//  limit dobowy liczony z realnych zapisów oraz klucz jednokrotności.
//  Front może wołać ten punkt w kółko i nic z tego nie wyciśnie.
// ══════════════════════════════════════════════════════════════════════════════
app.post('/api/grv/mint-respiration', async (req, res) => {
    const { wezel, rodzaj, klucz, trwaly } = req.body ?? {};
    try {
        const werdykt = await ocenPrace(ANTIGRAVITY_DIR, { wezel, rodzaj, klucz });

        if (!werdykt.przyznane) {
            // To NIE jest błąd — oddech trafił na wydech. HTTP 200 z jasnym powodem,
            // żeby UI nie krzyczało czerwonym alertem przy normalnym rytmie.
            return res.json({ success: true, przyznane: false, ...werdykt });
        }

        const przelew = await przelejGrv(SKARBIEC_GRV, wezel, werdykt.stawka);
        const wpis = await zapiszWdech(ANTIGRAVITY_DIR, {
            wezel, rodzaj, klucz, grv: werdykt.stawka, klasa: werdykt.klasa, trwaly,
        });
        const stan = await stanOddechu(ANTIGRAVITY_DIR, wezel);

        console.log(`[Oddech] 🫁 ${wezel} +${werdykt.stawka} GRV za ${werdykt.klasa} „${werdykt.opis}" ` +
                    `(doba: ${stan.wDobie}/${stan.limit}).`);
        return res.json({ success: true, przyznane: true, ...werdykt, wpis, przelew, stan });
    } catch (e) {
        return res.status(e instanceof BladGrv ? e.status : 400).json({ success: false, message: e.message });
    }
});

/**
 * Wewnętrzny wdech — wołany PRZEZ SAM MOST, gdy praca faktycznie się dokonała.
 *
 * ⚠️ DLACZEGO TU, A NIE W APLIKACJACH: gdyby każda substrona (Hub, Story V2,
 * Music, App) sama zgłaszała pracę, to (a) trzeba by wpiąć to w pięć miejsc,
 * (b) każda nowa aplikacja zaczynałaby jako niema, i (c) front decydowałby,
 * kiedy mu się należy GRV. Tak wygląda organizm, w którym oddycha tylko jedno
 * płuco. Most wie, kiedy karta naprawdę wpadła i kiedy render naprawdę wyszedł
 * — więc to on liczy oddech, a wszystkie aplikacje dostają go za darmo.
 *
 * NIGDY nie wywraca żądania: jeśli oddech padnie, praca i tak została wykonana
 * i odpowiedź ma dojść. Zwraca `null` zamiast rzucać.
 */
async function oddechZaPrace(rodzaj, klucz, trwaly = null, wezel = ODDECH_WEZEL) {
    try {
        const werdykt = await ocenPrace(ANTIGRAVITY_DIR, { wezel, rodzaj, klucz });
        if (!werdykt.przyznane) return { przyznane: false, powod: werdykt.powod, klasa: werdykt.klasa };
        await przelejGrv(SKARBIEC_GRV, wezel, werdykt.stawka);
        await zapiszWdech(ANTIGRAVITY_DIR, { wezel, rodzaj, klucz, grv: werdykt.stawka, klasa: werdykt.klasa, trwaly });
        // RUCH loguje się cicho (debug), WYNIK zostawia ślad w konsoli — tak jak
        // w UI: mały ruch bez hałasu, pełny wynik z błyskiem.
        if (werdykt.klasa === 'WYNIK') console.log(`[Oddech] ✨ +${werdykt.stawka} GRV — ${werdykt.opis}`);
        return { przyznane: true, klasa: werdykt.klasa, grv: werdykt.stawka, opis: werdykt.opis };
    } catch (e) {
        console.warn(`[Oddech] ⚠️ Wdech nieudany (${rodzaj}): ${e.message}`);
        return null;
    }
}

/** Węzeł, któremu przypisujemy pracę wykonaną na tej maszynie. */
const ODDECH_WEZEL = process.env.OTAKOS_WEZEL || 'Mistrz Arkadiusz';

/** Stan oddechu — licznik dobowy, bilans, ostatnie wdechy. */
app.get('/api/grv/oddech/:wezel', async (req, res) => {
    try {
        return res.json({ success: true, ...(await stanOddechu(ANTIGRAVITY_DIR, req.params.wezel)) });
    } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

/** Rejestr Zasobów Trwałych — punkt 3: to, co przetrwało. */
app.get('/api/grv/trwale', async (req, res) => {
    try {
        const wezel = String(req.query.wezel || '') || null;
        return res.json({ success: true, trwale: await rejestrTrwalych(ANTIGRAVITY_DIR, wezel) });
    } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

// ── 🏅 RANGI — awans po drabinie Katedry ────────────────────────────────────
/** GET /api/grv/osiagniecia?wezel= — co węzeł zdobył i czego mu brakuje. */
app.get('/api/grv/osiagniecia', async (req, res) => {
    const wezel = req.query.wezel || 'Mistrz Arkadiusz';
    const s = await Rangi.stanOsiagniec(wezel);
    const L = await loadGrvLedger();
    res.json({
        success: true, wezel, ...s,
        ranga: L.nodes[wezel]?.tier ?? null,
        rola: L.nodes[wezel]?.role ?? 'basic',
    });
});

/**
 * POST /api/grv/awans — Body: { wezel, ranga, haslo? }.
 *
 * FILAR idzie na hasło i ma sloty NIEOGRANICZONE — dlatego NIE dotykamy tu puli.
 * HEROLD idzie na osiągnięcia liczone z faktów zapisanych przez most.
 * FOUNDER tędy nie przechodzi: to klucz założycielski, osobna droga.
 */
app.post('/api/grv/awans', async (req, res) => {
    const { wezel, ranga, haslo } = req.body ?? {};
    if (!wezel || !ranga) return res.status(400).json({ success: false, message: 'Wymagane: wezel, ranga.' });

    const L = await loadGrvLedger();
    const wpis = L.nodes[wezel];
    if (!wpis) return res.status(404).json({ success: false, message: `Węzeł „${wezel}" nie istnieje w księdze.` });

    // Nie degradujemy i nie nadajemy tego samego dwa razy.
    const KOLEJNOSC = { basic: 0, herald: 1, pillar: 2, founder: 3 };
    const teraz = KOLEJNOSC[wpis.tier ?? 'basic'] ?? 0;
    if ((KOLEJNOSC[ranga] ?? 0) <= teraz) {
        return res.status(409).json({
            success: false, code: 'JUZ_WYZEJ',
            message: `Węzeł ma już rangę „${wpis.tier ?? 'basic'}" — awans na „${ranga}" byłby krokiem w tył lub w miejscu.`,
        });
    }

    const werdykt = await Rangi.czyWolnoAwans(wezel, ranga, haslo, L.pools, GRV_TIERS);
    if (!werdykt.wolno) {
        return res.status(403).json({ success: false, code: 'ODMOWA', message: werdykt.powod, brakuje: werdykt.brakuje });
    }

    // Dosypanie GRV do poziomu rangi — bez odbierania tego, co węzeł już ma.
    const docelowe = GRV_TIERS[ranga]?.grv ?? 0;
    const przed = Number(wpis.grv) || 0;
    const dosyp = Math.max(0, docelowe - przed);

    wpis.tier = ranga;
    wpis.role = ranga;
    wpis.grv = przed + dosyp;
    wpis.awansowanyO = new Date().toISOString();
    // Pulę zajmujemy TYLKO tam, gdzie jest ograniczona. Filar jej nie rusza.
    if (!werdykt.nieograniczone) L.pools[ranga] = (L.pools[ranga] || 0) + 1;

    await sealGrv('awans', { wezel, ranga, dosyp, nieograniczone: Boolean(werdykt.nieograniczone) });
    await saveGrvLedger();

    await Szyna.nadaj({
        agent: 'bilans', rodzaj: 'ranga',
        tresc: `${wezel} awansował na ${ranga}${dosyp ? ` (+${dosyp} GRV)` : ''}.`,
    });
    console.log(`[GRV] 🏅 ${wezel} → ${ranga}${dosyp ? ` (+${dosyp} GRV)` : ''}${werdykt.nieograniczone ? ' [pula nieograniczona]' : ''}.`);

    res.json({
        success: true, wezel, ranga, dosypano: dosyp, saldo: wpis.grv,
        nieograniczone: Boolean(werdykt.nieograniczone),
    });
});

/** GET /api/grv/drabina — kto ile ma miejsc i jak się tam wchodzi. */
app.get('/api/grv/drabina', async (req, res) => {
    const L = await loadGrvLedger();
    res.json({
        success: true,
        szczeble: [
            { ranga: 'basic',   grv: GRV_NEW_NODE, wejscie: 'start każdego węzła', wolne: null },
            { ranga: 'herald',  grv: GRV_TIERS.herald.grv, wejscie: `${Rangi.PROG_HEROLDA} osiągnięcia`, wolne: GRV_TIERS.herald.count - (L.pools.herald || 0) },
            { ranga: 'pillar',  grv: GRV_TIERS.pillar.grv, wejscie: 'hasło kręgu', wolne: 'bez ograniczeń' },
            { ranga: 'founder', grv: GRV_TIERS.founder.grv, wejscie: 'klucz założycielski', wolne: GRV_TIERS.founder.count - (L.pools.founder || 0) },
        ],
        zarzadca: 'TeO — saldo nieskończone, dzieli pulę obdarowań',
    });
});

// ── 🗺️ QUESTY — droga od Herolda wzwyż ──────────────────────────────────────
/** GET /api/grv/questy?wezel= — postęp, nagrody, co czeka na odbiór. */
app.get('/api/grv/questy', async (req, res) => {
    const wezel = req.query.wezel || 'Mistrz Arkadiusz';
    const s = await Questy.stanQuestow(wezel);
    const L = await loadGrvLedger();
    res.json({ success: true, wezel, ranga: L.nodes[wezel]?.tier ?? null, ...s });
});

/**
 * POST /api/grv/quest/odbierz — Body: { wezel, quest }.
 *
 * Nagroda idzie PRZELEWEM z węzła `TeO` tą samą drogą co każdy inny ruch GRV —
 * z odjęciem u nadawcy i pieczęcią w łańcuchu. Emisja „z powietrza" obok księgi
 * byłaby drugą ścieżką pieniądza, a księga z dwoma wejściami przestaje być księgą.
 */
app.post('/api/grv/quest/odbierz', async (req, res) => {
    const { quest } = req.body ?? {};
    const wezel = (req.body ?? {}).wezel || 'Mistrz Arkadiusz';
    if (!quest) return res.status(400).json({ success: false, message: 'Brak id questu.' });

    const L = await loadGrvLedger();
    if (!L.nodes[wezel]) return res.status(404).json({ success: false, message: `Węzeł „${wezel}" nie istnieje w księdze.` });

    const werdykt = await Questy.sprawdzOdbior(wezel, quest);
    if (!werdykt.ok) return res.status(409).json({ success: false, code: 'NIE_DO_ODBIORU', message: werdykt.powod });

    let przelew;
    try {
        przelew = await przelejGrv('TeO', wezel, werdykt.quest.nagroda);
    } catch (e) {
        return res.status(e instanceof BladGrv ? e.status : 500).json({
            success: false, code: 'WYPLATA_ODRZUCONA', message: e.message,
        });
    }

    // Znacznik odbioru DOPIERO po udanej wypłacie — inaczej quest przepadłby
    // bez GRV, gdyby przelew padł.
    await Questy.zapiszOdebrany(wezel, quest);

    await Szyna.nadaj({
        agent: 'bilans', rodzaj: 'quest',
        tresc: `${wezel} odebrał „${werdykt.quest.nazwa}" — ${werdykt.quest.nagroda} GRV.`,
    });
    console.log(`[GRV] 🗺️ Quest „${werdykt.quest.nazwa}" → ${wezel}: +${werdykt.quest.nagroda} GRV.`);

    res.json({ success: true, quest, nazwa: werdykt.quest.nazwa, nagroda: werdykt.quest.nagroda, przelew });
});

// ── 🗝️ KONTA I KLUCZE ZAŁOŻYCIELSKIE ────────────────────────────────────────
/** GET /api/konta — kto jest kim w księdze. Most jest właścicielem tego mapowania. */
app.get('/api/konta', async (req, res) => {
    const d = await Konta.wczytajKonta();
    const L = await loadGrvLedger();
    res.json({
        success: true,
        konta: d.konta.map(k => ({
            ...k,
            saldo: L.nodes[k.wezel]?.grv ?? null,
            ranga: L.nodes[k.wezel]?.tier ?? null,
            istniejeWKsiedze: Boolean(L.nodes[k.wezel]),
        })),
    });
});

/** GET /api/konta/wezel?kto= — na który węzeł mapuje się mail/login. */
app.get('/api/konta/wezel', async (req, res) => {
    const k = await Konta.wezelDlaKonta(req.query.kto);
    if (!k) {
        // Świadomie NIE zgadujemy. Przypisanie nieznanego maila do węzła
        // Suwerena oddałoby komuś obcemu jego milion GRV.
        return res.status(404).json({
            success: false,
            message: `Konto „${req.query.kto || ''}" nie jest przypisane do żadnego węzła księgi.`,
        });
    }
    res.json({ success: true, ...k });
});

/** GET /api/grv/klucze — stan kluczy założycielskich. */
app.get('/api/grv/klucze', async (req, res) => {
    const d = await Konta.wczytajKlucze();
    const L = await loadGrvLedger();
    const wolne = GRV_TIERS.founder.count - (L.pools.founder || 0);
    res.json({
        success: true,
        klucze: d.klucze.map(k => ({
            klucz: k.klucz, wydany: k.wydany, notatka: k.notatka,
            uzytyPrzez: k.uzytyPrzez, uzytyO: k.uzytyO,
        })),
        niewykorzystane: d.klucze.filter(k => !k.uzytyPrzez).length,
        wolnychMiejsc: wolne,
    });
});

/** POST /api/grv/klucze/wydaj — Body: { ile?, notatka? }. */
app.post('/api/grv/klucze/wydaj', async (req, res) => {
    const { ile, notatka } = req.body ?? {};
    const L = await loadGrvLedger();
    const wolne = GRV_TIERS.founder.count - (L.pools.founder || 0);
    const w = await Konta.wydajKlucze(ile ?? 1, notatka, wolne);
    if (!w.ok) return res.status(409).json({ success: false, message: w.powod });

    await Szyna.nadaj({
        agent: 'bilans', rodzaj: 'klucz',
        tresc: `Wydano ${w.klucze.length} klucz(y) założycielskich${notatka ? ` (${notatka})` : ''}.`,
    });
    console.log(`[GRV] 🗝️ Wydano ${w.klucze.length} klucz(y) Founder.`);
    res.json({ success: true, ...w });
});

/**
 * POST /api/grv/klucze/uzyj — Body: { klucz, wezel }.
 * JEDYNA droga do rangi Founder. Klucz wypala się po udanym nadaniu.
 */
app.post('/api/grv/klucze/uzyj', async (req, res) => {
    const { klucz, wezel } = req.body ?? {};
    if (!klucz || !wezel) return res.status(400).json({ success: false, message: 'Wymagane: klucz, wezel.' });

    const sprawdzenie = await Konta.sprawdzKlucz(klucz);
    if (!sprawdzenie.ok) return res.status(403).json({ success: false, code: 'KLUCZ_ODRZUCONY', message: sprawdzenie.powod });

    const L = await loadGrvLedger();
    const wpis = L.nodes[wezel];
    if (!wpis) return res.status(404).json({ success: false, message: `Węzeł „${wezel}" nie istnieje w księdze.` });
    if (wpis.tier === 'founder') {
        return res.status(409).json({ success: false, code: 'JUZ_FOUNDER', message: `„${wezel}" jest już Founderem — klucz zostaje nietknięty.` });
    }
    const uzyte = L.pools.founder || 0;
    if (uzyte >= GRV_TIERS.founder.count) {
        return res.status(409).json({ success: false, message: `Pula Founderów wyczerpana (${GRV_TIERS.founder.count}).` });
    }

    const przed = Number(wpis.grv) || 0;
    const dosyp = Math.max(0, GRV_TIERS.founder.grv - przed);
    wpis.tier = 'founder';
    wpis.role = 'founder';
    wpis.grv = przed + dosyp;
    wpis.awansowanyO = new Date().toISOString();
    L.pools.founder = uzyte + 1;

    await sealGrv('klucz-founder', { wezel, dosyp });
    await saveGrvLedger();
    // Wypalamy DOPIERO po zapisaniu rangi — inaczej klucz przepadłby bez skutku.
    await Konta.wypalKlucz(klucz, wezel);

    await Szyna.nadaj({ agent: 'bilans', rodzaj: 'ranga', tresc: `${wezel} przyjęty do Founderów kluczem (+${dosyp} GRV).` });
    console.log(`[GRV] 🗝️ ${wezel} → founder (klucz wypalony, +${dosyp} GRV).`);

    res.json({ success: true, wezel, ranga: 'founder', dosypano: dosyp, saldo: wpis.grv, wolneMiejsca: GRV_TIERS.founder.count - L.pools.founder });
});

// ── 🥚🛠️ KREATOR PANELI TeOgochi ────────────────────────────────────────────
// Osiem gatunków wykluwa się bez warsztatu. Tu Suweren buduje im panel — ale
// WYŁĄCZNIE z tras, które most naprawdę wystawia (odczyt z żywego routera).

/** Domeny = prawdziwe grupy tras mostu. Nie lista życzeń, tylko stan routera. */
app.get('/api/teogochi/domeny', (req, res) => {
    try {
        const domeny = PaneleTeogochi.katalogDomen(app);
        res.json({ success: true, domeny, ile: domeny.length });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * GET /api/teogochi/stado — kto ze stada jest wykluty i czym sie zajmuje.
 *
 * ⚠️ BEZ TOKENA URZĄDZENIA, w odróżnieniu od `/api/stado/stan`. Tamta trasa
 * służy TELEFONOWI (parowanie ma sens: obcy telefon nie ma tu czego szukać).
 * Tu pyta Story V2 — aplikacja z tej samej maszyny, która potrzebuje listy
 * co-botów do obsadzenia w Reżyserze. Migawka zawiera imiona, etapy i XP;
 * nie ma w niej nic, czego nie widać w oknie Katedry.
 *
 * Gdy Katedra nic jeszcze nie opublikowała, oddajemy POWÓD, nie pustą listę —
 * „brak co-botów" i „nie otwarto jeszcze Domu TeOgochi" to dwie różne rzeczy.
 */
app.get('/api/teogochi/stado', async (req, res) => {
    try {
        const stan = await MostStada.stanDlaApki(Szyna.ostatnie({ ile: 300 }));
        return res.json({ success: true, ...stan });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.get('/api/teogochi/panele', async (req, res) => {
    const d = await PaneleTeogochi.wczytajPanele();
    res.json({ success: true, panele: d.panele ?? [] });
});

/** Losowanie jaja. Deterministyczne — to samo ziarno daje to samo jajo. */
app.post('/api/teogochi/panel/jajo', (req, res) => {
    const { ziarno } = req.body ?? {};
    res.json({ success: true, jajo: PaneleTeogochi.losujJajo(ziarno) });
});

app.post('/api/teogochi/panel', async (req, res) => {
    const { gatunek, domena, narzedzia, jajo, nazwa, opis, wlasneJajo } = req.body ?? {};

    let jajoDoZapisu = jajo ?? null;
    if (wlasneJajo) {
        const s = PaneleTeogochi.sprawdzJajo(jajo);
        if (!s.ok) return res.status(400).json({ success: false, message: s.powod });
        jajoDoZapisu = s.jajo;
    }

    const r = await PaneleTeogochi.zapiszPanel(app, {
        gatunek, domena, narzedzia, jajo: jajoDoZapisu, nazwa, opis,
    });
    if (!r.ok) return res.status(400).json({ success: false, message: r.powod });
    res.json({ success: true, panel: r.panel });
});

/**
 * Automatyczne wystawienie panelu w Marketplace — tą samą drogą co każdy inny
 * produkt (wspólny plik rynku), żeby nie powstał drugi obieg ofert.
 */
app.post('/api/teogochi/panel/wystaw', async (req, res) => {
    const { gatunek, priceGrv, creator } = req.body ?? {};
    const d = await PaneleTeogochi.wczytajPanele();
    const p = (d.panele ?? []).find(x => x.gatunek === gatunek);
    if (!p) return res.status(404).json({ success: false, message: 'Najpierw zbuduj panel.' });
    if (p.ofertaId) {
        return res.status(409).json({ success: false, message: `Ten panel jest już wystawiony (${p.ofertaId}).` });
    }

    const m = await loadMarket();
    const id = `teogochi-panel-${gatunek}-${Date.now().toString(36)}`;
    const product = {
        id, module: 'core', type: 'preset',
        name: `Panel TeOgochi — ${p.nazwa}`,
        desc: p.opis || `Warsztat gatunku ${p.nazwa}: ${p.narzedzia.length} narzędzi mostu z domeny ${p.domena ?? '—'}.`,
        priceGrv: Number(priceGrv) || 0,
        creator: creator || 'Mistrz Arkadiusz',
        votes: 0, createdAt: Date.now(),
        // Payload niesie PRZEPIS, nie obietnicę: kto to zaimportuje, dostanie
        // te same trasy — a jeśli jego most ich nie ma, zapis się nie uda.
        payload: { jajo: p.jajo, domena: p.domena, narzedzia: p.narzedzia },
    };
    m.products.push(product);
    await saveMarket();
    await PaneleTeogochi.oznaczWystawiony(gatunek, id);
    res.json({ success: true, oferta: product });
});

app.post('/api/teogochi/panel/usun', async (req, res) => {
    const r = await PaneleTeogochi.usunPanel(req.body?.gatunek);
    if (!r.ok) return res.status(404).json({ success: false, message: r.powod });
    res.json({ success: true });
});


app.get('/api/grv/:id', async (req, res) => {
    const L = await loadGrvLedger(); const n = L.nodes[req.params.id];
    if (!n) return res.status(404).json({ success: false, message: 'Węzeł nieznany.' });
    res.json({ success: true, id: req.params.id, ...n });
});
app.post('/api/grv/register', async (req, res) => {
    const { id, tier } = req.body ?? {};
    if (!id) return res.status(400).json({ success: false, message: 'Brak id węzła.' });
    const L = await loadGrvLedger();
    if (L.nodes[id]) return res.json({ success: true, id, ...L.nodes[id], existed: true });
    let grv = GRV_NEW_NODE, role = 'node', assignedTier = null;
    if (tier && GRV_TIERS[tier]) {
        const used = L.pools[tier] || 0;
        if (used >= GRV_TIERS[tier].count) return res.status(409).json({ success: false, message: `Pula ${tier} wyczerpana (${GRV_TIERS[tier].count}).` });
        grv = GRV_TIERS[tier].grv; role = tier; assignedTier = tier; L.pools[tier] = used + 1;
    }
    L.nodes[id] = { grv, role, tier: assignedTier, registeredAt: Date.now() };
    await sealGrv('register', { id, grv, tier: assignedTier });
    await saveGrvLedger();
    console.log(`[GRV] ➕ Węzeł ${id}: ${grv} GRV${assignedTier ? ` (${assignedTier})` : ''}.`);
    res.json({ success: true, id, ...L.nodes[id] });
});
/**
 * Przelew GRV — JEDYNA droga ruchu w księdze.
 *
 * ⚠️ Wyciągnięte z trasy `/api/grv/grant` 2026-08-15, żeby subskrypcje modułów
 * i wpłaty na wyprawy szły DOKŁADNIE tędy: z odjęciem u nadawcy i pieczęcią
 * w łańcuchu. Druga, równoległa ścieżka ruchu GRV oznaczałaby księgę, której
 * `verifyGrvChain` już nie potwierdza — czyli ekonomię bez dowodu.
 *
 * Rzuca `BladGrv` z polem `status`, żeby wołający zwrócił właściwy kod HTTP.
 */
class BladGrv extends Error {
    constructor(message, status = 400) { super(message); this.status = status; }
}

async function przelejGrv(from, to, amount) {
    const amt = Number(amount);
    if (!from || !to || !(amt > 0)) throw new BladGrv('Wymagane from, to, amount>0.', 400);

    const L = await loadGrvLedger();
    const src = L.nodes[from];
    if (!src) throw new BladGrv(`Węzeł ${from} nieznany.`, 404);
    if (!L.nodes[to]) L.nodes[to] = { grv: 0, role: 'node', tier: null, registeredAt: Date.now() };

    const infinite = src.grv === 'INFINITE';
    if (!infinite) {
        if (Number(src.grv) < amt) throw new BladGrv('Za mało GRV u nadawcy.', 400);
        src.grv = Number(src.grv) - amt;
    }
    if (L.nodes[to].grv !== 'INFINITE') L.nodes[to].grv = Number(L.nodes[to].grv) + amt;

    await sealGrv('grant', { from, to, amount: amt });
    await saveGrvLedger();
    return { from, to, amount: amt, fromBalance: src.grv, toBalance: L.nodes[to].grv, infiniteSource: infinite };
}

app.post('/api/grv/grant', async (req, res) => {
    const { from, to, amount } = req.body ?? {};
    try {
        return res.json({ success: true, ...(await przelejGrv(from, to, amount)) });
    } catch (e) {
        return res.status(e instanceof BladGrv ? e.status : 500).json({ success: false, message: e.message });
    }
});
// ⛓️ Weryfikacja integralności księgi (tamper-evidence) + podgląd łańcucha.
// (dawne miejsce /api/grv/verify i /api/grv/ledger — przeniesione wyżej,
// przed /api/grv/:id, bo tam byly martwe)

// ── 🔍 SKANER AUTENTYCZNOŚCI (TeO Trust Art. III ↔ Tarcza Prawdy) ──
// Każda operacja przechodzi przez filtr, by wykluczyć energię „pochłaniania".
app.post('/api/trust/scan', (req, res) => {
    const text = String((req.body ?? {}).text ?? '');
    if (!text.trim()) return res.status(400).json({ success: false, message: 'Brak treści do skanu.' });
    const card = AlignmentShield.getInstance().inspect(text, {});
    const absorption = card.findings.filter(f => f.pillar === 'AUTHENTICITY');
    res.json({
        success: true,
        authentic: absorption.length === 0,
        passed: !card.blocked && absorption.length === 0,
        score: card.score, grade: card.grade,
        absorption,
        verdict: absorption.length
            ? `❌ Wykryto energię pochłaniania (${absorption.length}) — Skaner odrzuca.`
            : (card.blocked ? '🛡️ Zablokowano (znalezisko krytyczne).' : `✅ Autentyczne — energia służy. Wynik ${card.score}/100 (${card.grade}).`),
    });
});

// ── 💰 PORTFEL ZEWNĘTRZNY — read-only agregacja (MetaMask/Ledger przez adres) ──
// Bezkluczowo: saldo NATYWNE (ETH/MATIC/BNB) przez publiczny RPC + cena CoinGecko.
// Tokeny ERC-20 = przyszłość (opcjonalny klucz w Skarbcu). Zero podpisów, read-only.
const WALLET_CHAINS = {
    eth:     { name: 'Ethereum',  rpc: 'https://ethereum-rpc.publicnode.com',     sym: 'ETH',   cg: 'ethereum' },
    polygon: { name: 'Polygon',   rpc: 'https://polygon-bor-rpc.publicnode.com',  sym: 'MATIC', cg: 'matic-network' },
    bsc:     { name: 'BNB Chain',  rpc: 'https://bsc-rpc.publicnode.com',          sym: 'BNB',   cg: 'binancecoin' },
};
async function rpcBalance(rpc, address) {
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 6000);
    try {
        const r = await fetch(rpc, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }, signal: ctrl.signal,
            body: JSON.stringify({ jsonrpc: '2.0', method: 'eth_getBalance', params: [address, 'latest'], id: 1 }) });
        const txt = await r.text();
        if (!txt.trim().startsWith('{')) return 0; // ochrona przed HTML/proxy
        const d = JSON.parse(txt);
        return d.result ? Number(BigInt(d.result)) / 1e18 : 0;
    } catch { return 0; } finally { clearTimeout(t); }
}
/**
 * POST /api/wallet/portfolio  { addresses[], vs?, tokenyDodatkowe?[{chain,adres}] }
 *
 * ⚠️ NAPRAWIONE 2026-08-06. Wcześniej liczyły się WYŁĄCZNIE salda natywne
 * (ETH/MATIC/BNB), a wszystko trzymane w tokenach ERC-20 było niewidzialne.
 * Ta zaniżona suma szła prosto do Teda i Kronosa — zła liczba na wejściu
 * psuje każdy wniosek dalej. Teraz czytamy też tokeny, tymi samymi publicznymi
 * RPC, bez żadnego klucza API.
 *
 * Odpowiedź niesie `widocznosc`, bo widzimy tylko te kontrakty, o które
 * pytamy. Zastąpienie cichego zaniżenia drugim cichym zaniżeniem byłoby
 * GORSZE niż brak zmiany — tym razem suma wyglądałaby na kompletną.
 */
app.post('/api/wallet/portfolio', async (req, res) => {
    const { addresses, vs, tokenyDodatkowe } = req.body ?? {};
    const list = Array.isArray(addresses) ? addresses.filter(a => /^0x[a-fA-F0-9]{40}$/.test(a)) : [];
    if (!list.length) return res.status(400).json({ success: false, message: 'Podaj adres(y) 0x... (EVM).' });
    const cur = (vs || 'eur').toLowerCase();

    // Tokeny dorzucone ręcznie przez Suwerena — dla wszystkiego spoza listy.
    const dodatkowe = {};
    for (const t of Array.isArray(tokenyDodatkowe) ? tokenyDodatkowe : []) {
        const chain = String(t?.chain || '').toLowerCase();
        const adres = String(t?.adres || '');
        if (!WALLET_CHAINS[chain] || !/^0x[a-fA-F0-9]{40}$/.test(adres)) continue;
        (dodatkowe[chain] ??= []).push({ sym: '?', adres, dec: 18 });
    }

    try {
        // Ceny natywnych
        const ids = Object.values(WALLET_CHAINS).map(c => c.cg).join(',');
        let prices = {};
        try { prices = await (await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=${cur}`)).json(); } catch {}

        const assets = [];
        const tokeny = [];
        const znalezione = [];      // pozycje ze wszystkich łańcuchów, przed wyceną
        const problemy = [];
        let sprawdzonychKontraktow = 0;

        for (const [chain, c] of Object.entries(WALLET_CHAINS)) {
            // ── Saldo natywne (jak dotąd) ──
            let bal = 0;
            for (const addr of list) bal += await rpcBalance(c.rpc, addr);
            if (bal > 0) {
                const price = prices?.[c.cg]?.[cur] || 0;
                assets.push({ chain, name: c.name, symbol: c.sym, balance: +bal.toFixed(6), price, value: +(bal * price).toFixed(2) });
            }

            // ── Tokeny ERC-20 — najpierw SAME SALDA, wycena dopiero po pętli ──
            const doSprawdzenia = [...(ZNANE_TOKENY[chain] ?? []), ...(dodatkowe[chain] ?? [])];
            try {
                const { pozycje, sprawdzono } = await saldaTokenow(c.rpc, list, doSprawdzenia);
                sprawdzonychKontraktow += sprawdzono;
                for (const p of pozycje) {
                    const znany = doSprawdzenia.find(t => t.adres.toLowerCase() === p.adres.toLowerCase());
                    znalezione.push({ chain, nazwaSieci: c.name, ...p, cg: znany?.cg ?? null });
                }
            } catch (e) {
                // Awaria odczytu tokenów NIE może udawać, że tokenów nie ma.
                problemy.push({ chain, powod: e.message });
                console.warn(`[Portfel] ⚠️ ${chain}: odczyt tokenów nieudany — ${e.message}`);
            }
        }

        // ── Wycena: JEDNO zapytanie na wszystkie znane tokeny ──
        // Wersja „cena po adresie kontraktu, token po tokenie" kosztowała tyle
        // zapytań, ile tokenów — na darmowym planie CoinGecko oznaczało to pewny
        // limit i sumę zaniżoną o wszystko, co nie zdążyło. Po kontrakcie pytamy
        // już tylko o to, czego nie ma w naszej liście (tokeny dodane ręcznie).
        const { ceny: cenyId, limit: limitId } = await cenyPoId(znalezione.map(p => p.cg), cur);
        if (limitId) problemy.push({ chain: '—', powod: 'limit zapytań cennika (CoinGecko) — część tokenów bez wyceny' });

        for (const p of znalezione) {
            let price = p.cg ? (cenyId[p.cg] || 0) : 0;
            if (!price && !p.cg) {
                // Token spoza listy — jedyna droga to zapytanie po kontrakcie.
                const { ceny, limit } = await cenyTokenow(PLATFORMA_CG[p.chain], [p.adres], cur);
                if (limit) problemy.push({ chain: p.chain, powod: 'limit zapytań cennika przy tokenie dodanym ręcznie' });
                price = ceny[p.adres.toLowerCase()] || 0;
            }
            tokeny.push({
                chain: p.chain, name: p.nazwaSieci, symbol: p.symbol, kontrakt: p.adres,
                balance: +p.saldo.toFixed(6), price, value: +(p.saldo * price).toFixed(2),
                // Token bez notowania ZOSTAJE widoczny — ukrycie go byłoby
                // powrotem do grzechu, który tu naprawiamy.
                bezCeny: price === 0,
            });
        }

        const total = +[...assets, ...tokeny].reduce((s, a) => s + a.value, 0).toFixed(2);
        const bezCeny = tokeny.filter(t => t.bezCeny).length;

        return res.json({
            success: true, addresses: list, vs: cur,
            assets, tokeny, total,
            widocznosc: {
                sprawdzonychKontraktow,
                znalezionychTokenow: tokeny.length,
                bezCeny,
                problemy,
                // To zdanie jest częścią wyniku, nie ozdobą UI.
                uwaga: 'Widoczne są tylko tokeny z listy Katedry oraz dodane ręcznie. ' +
                       'Token spoza nich NIE jest liczony — dołóż adres kontraktu, jeśli czegoś brakuje.'
                       + (problemy.length ? ` UWAGA: odczyt tokenów nie powiódł się na: ${problemy.map(p => p.chain).join(', ')} — suma jest niepełna.` : '')
                       + (bezCeny ? ` ${bezCeny} token(ów) bez notowania — widoczne w saldzie, ale nie wchodzą do sumy.` : ''),
            },
            note: (assets.length || tokeny.length) ? null : 'Brak salda natywnego i żadnego znanego tokenu na tych adresach.',
        });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ── 💾 BACKUP WALLETA — zaszyfrowany stan (auto przy logowaniu pierścieniem) ──
const BACKUP_DIR = path.join(ANTIGRAVITY_DIR, 'backups');
const BACKUP_KEYFILE = path.join(AI_DIR, '.backup_key');
async function backupKey() {
    try { return Buffer.from(await fs.readFile(BACKUP_KEYFILE, 'utf8'), 'hex'); }
    catch { const k = crypto.randomBytes(32); await fs.mkdir(AI_DIR, { recursive: true }); await fs.writeFile(BACKUP_KEYFILE, k.toString('hex'), 'utf8'); return k; }
}
app.post('/api/wallet/backup', async (req, res) => {
    try {
        const L = await loadGrvLedger();
        const m = await loadMarket();
        const state = { ts: Date.now(), version: 'V_ZERO', grvLedger: L, market: m, addresses: (req.body ?? {}).addresses || [], extra: (req.body ?? {}).extra || null };
        const key = await backupKey();
        const iv = crypto.randomBytes(12);
        const c = crypto.createCipheriv('aes-256-gcm', key, iv);
        const enc = Buffer.concat([c.update(JSON.stringify(state), 'utf8'), c.final()]);
        const blob = Buffer.concat([iv, c.getAuthTag(), enc]);          // iv(12)+tag(16)+ciphertext
        await fs.mkdir(BACKUP_DIR, { recursive: true });
        const file = path.join(BACKUP_DIR, `wallet_${state.ts}.enc`);
        await fs.writeFile(file, blob);
        try { const files = (await fs.readdir(BACKUP_DIR)).filter(f => /^wallet_.*\.enc$/.test(f)).sort(); for (const f of files.slice(0, -10)) await fs.rm(path.join(BACKUP_DIR, f), { force: true }); } catch {}
        console.log(`[Backup] 💾 Zaszyfrowany backup walleta: ${path.basename(file)} (${blob.length} B)`);
        res.json({ success: true, file: `backups/${path.basename(file)}`, bytes: blob.length, encrypted: 'aes-256-gcm' });
    } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});
app.post('/api/wallet/restore', async (req, res) => {
    const { file } = req.body ?? {};
    try {
        const target = file ? path.join(BACKUP_DIR, path.basename(file)) : null;
        let chosen = target;
        if (!chosen) { const files = (await fs.readdir(BACKUP_DIR)).filter(f => /^wallet_.*\.enc$/.test(f)).sort(); chosen = files.length ? path.join(BACKUP_DIR, files[files.length - 1]) : null; }
        if (!chosen || !fsSync.existsSync(chosen)) return res.status(404).json({ success: false, message: 'Brak backupu.' });
        const blob = await fs.readFile(chosen);
        const key = await backupKey();
        const iv = blob.subarray(0, 12), tag = blob.subarray(12, 28), data = blob.subarray(28);
        const d = crypto.createDecipheriv('aes-256-gcm', key, iv); d.setAuthTag(tag);
        const state = JSON.parse(Buffer.concat([d.update(data), d.final()]).toString('utf8'));
        res.json({ success: true, restoredFrom: path.basename(chosen), ts: state.ts, nodes: Object.keys(state.grvLedger?.nodes || {}).length });
    } catch (err) { res.status(500).json({ success: false, message: 'Odszyfrowanie nieudane: ' + err.message }); }
});

// ── 🎓 TEO SIM ACADEMY — moduły z KATALOGOWĄ wiedzą (standard) ────────────────
// Każdy moduł Academy = temat + katalog wiedzy domenowej (_OtakOs_Aula/<moduł>/).
// Agenci czytają cały katalog i dyskutują/ulepszają ekosystem. Pierwszy: Economis.
// (AULA_DIR zdefiniowane wyżej.)
const ECONOMIS_SEED = `# Economis — wiedza domenowa o GRV (0.00G)

## Czym jest GRV
GRV (Grawitacja) to suwerenna, lokalna jednostka wartości/energii Katedry OtakOS —
miara wkładu w ruch ekosystemu (Proof-of-Compute, kreacja, koherencja). Nie waluta fiat.

## Geneza GRV
- TeO = zarządca, GRV ∞ (dzieli jako system). Mistrz Arkadiusz = founder #1, 1M.
- Pule: 26×1M (founderzy), 57×100k (filary), 61×10k (heroldowie) = 32 310 000 GRV.
- Nowy węzeł = 1000 GRV na start.

## Marketplace (obieg GRV)
Twórcy wystawiają produkty za GRV. Sklep = TOP 10/moduł wg głosów; reszta co miesiąc
spalana → GRV wraca twórcom. Głosowanie steruje selekcją.

## PEIE — ekonomia przepływu
Wartość z dynamiki i przyzwolenia na wymianę, nie z zamkniętych zasobów. Lokalny rdzeń
= koszt API 0%. Złota Pauza bywa najlepszą decyzją ekonomiczną.

## Otwarte pytania Rady Economis
Realny zakup za GRV; kontabilność wsteczna (tamper-evidence); Proof-of-Compute zarobku;
globalny rejestr vs lokalność; dynamiczne ceny wg popytu/głosów.
`;
const AULA_SEEDS = { economis: { '00-grv-podstawy.md': ECONOMIS_SEED } };
async function readAulaKnowledge(mod) {
    const key = String(mod).replace(/[^\w-]/g, '');
    const dir = path.join(AULA_DIR, key);
    let docs = [];
    try { for (const f of await fs.readdir(dir)) if (/\.(md|txt)$/i.test(f)) docs.push({ name: f, content: await fs.readFile(path.join(dir, f), 'utf8') }); } catch {}
    // Auto-zasiew wiedzy bazowej (gdy katalog pusty) — żeby agenci mieli grunt.
    if (!docs.length && AULA_SEEDS[key]) {
        try {
            await fs.mkdir(dir, { recursive: true });
            for (const [name, content] of Object.entries(AULA_SEEDS[key])) { await fs.writeFile(path.join(dir, name), content, 'utf8'); docs.push({ name, content }); }
            console.log(`[Academy] 🌱 Zasiano katalog wiedzy: ${key}`);
        } catch {}
    }
    return docs;
}
app.get('/api/academy/knowledge/:module', async (req, res) => {
    const docs = await readAulaKnowledge(req.params.module);
    res.json({ success: true, module: req.params.module, docs, count: docs.length });
});
app.post('/api/academy/discuss', async (req, res) => {
    let { module, topic, model } = req.body ?? {};
    model = model || process.env.OTAKOS_MODEL || 'gemma4';
    const docs = await readAulaKnowledge(module);
    const knowledge = docs.map(d => d.content).join('\n\n');
    if (knowledge.length < 10) return res.status(424).json({ success: false, message: `Brak katalogu wiedzy dla „${module}" (_OtakOs_Aula/${module}/).` });
    const agents = [['ISTed', 'ekonomista PEIE'], ['Adamus', 'strateg-alchemik'], ['ODDI', 'czysta logika AI']];
    const proposals = [];
    for (const [name, role] of agents) {
        const t = await genOllama(`Jesteś ${name} (${role}) w Radzie ${module} Katedry OtakOS. Na bazie WIEDZY poniżej, w 2 zdaniach zaproponuj konkretne ULEPSZENIE ekosystemu w temacie: „${topic || 'rozwój'}".\n\nWIEDZA:\n${knowledge.slice(0, 3500)}`, model, 30000);
        proposals.push({ agent: name, text: t || `[${name} — rdzeń offline]` });
    }
    res.json({ success: true, module, topic: topic || 'rozwój', usedLLM: proposals.some(p => !p.text.startsWith('[')), proposals });
});

// ── 🛒 MARKETPLACE + WALLET — produkty za GRV, głosowanie, spalanie top-10 ────
// Katalogowa struktura danych: market.json { products:[] }. Sklep pokazuje 10
// najpopularniejszych /moduł (głosowanie); reszta co miesiąc spalana → GRV
// wraca twórcom. Pierwszy produkt: buton „Odpal Tu...Kurka!" w KatedraChat.
const MARKET_FILE = path.join(ANTIGRAVITY_DIR, 'market.json');
let market = null;
async function saveMarket() { try { await fs.writeFile(MARKET_FILE, JSON.stringify(market, null, 2), 'utf8'); } catch (e) { console.warn('[Market]', e.message); } }
async function loadMarket() {
    if (market) return market;
    try { market = JSON.parse(await fs.readFile(MARKET_FILE, 'utf8')); }
    catch {
        market = { products: [{
            id: 'btn-odpal-kurka', module: 'katedra-chat', type: 'button',
            name: 'Odpal Tu...Kurka!', desc: 'Buton w KatedraChat — odpala Klaudiusza (Claude Code) w Katedrze przez Ollamę, na bieżącym modelu.',
            priceGrv: 0, creator: 'TeO', votes: 0, createdAt: Date.now(),
            payload: { action: 'claude-launch' },
        }] };
        await saveMarket();
        console.log('[Market] 🛒 Zasiano sklep: pierwszy produkt „Odpal Tu...Kurka!".');
    }
    // Zapewnij Tarczę Prywatności „Złote Taco" (idempotentnie)
    if (market.products && !market.products.find(p => p.id === 'zlote-taco-antilustro')) {
        market.products.push({
            id: 'zlote-taco-antilustro', module: 'prywatnosc', type: 'shield',
            name: '🌮 Złote Taco — Anty-Lustro Matrixa',
            desc: 'Tarcza Prywatności: audyt śledzenia, czyszczenie lokalnych śladów i generator wabika (szum profilujący). „Niech coś mają."',
            priceGrv: 0, creator: 'TeO', votes: 0, createdAt: Date.now(),
            payload: { action: 'open-antimatrix' },
        });
        await saveMarket();
        console.log('[Market] 🌮 Dodano Tarczę „Złote Taco — Anty-Lustro Matrixa".');
    }
    // Zapewnij „UnEnG" — Unreal Engine dla Game Forge (idempotentnie)
    if (market.products && !market.products.find(p => p.id === 'uneng-unreal-engine')) {
        market.products.push({
            id: 'uneng-unreal-engine', module: 'forge', type: 'engine',
            name: '🎮 UnEnG — Unreal Engine dla Game Forge',
            desc: 'Specjalna wersja Klaudiusza tworzy grywalne ŚWIATY (i rozwija samą Katedrę) mocą Unreal Engine (Filar II). ⚠ Agenci pilnują limitów licencji Epic: darmowe < 1 MLN USD przychodu, potem 5% tantiem / opłata stanowiskowa. Odpowiedzialność = Komunikacja — nie obciążamy Katedry.',
            priceGrv: 0, creator: 'TeO', votes: 0, createdAt: Date.now(),
            payload: { action: 'launch-uneng' },
        });
        await saveMarket();
        console.log('[Market] 🎮 Dodano „UnEnG — Unreal Engine dla Game Forge".');
    }
    return market;
}
// 📈 Cena DYNAMICZNA: popyt (głosy) podbija cenę. +5%/głos, sufit 3× bazy.
function dynPriceGrv(p) {
    const base = Number(p.priceGrv) || 0;
    if (base <= 0) return 0;
    const demand = 1 + Math.min(2, (p.votes || 0) * 0.05);
    return Math.round(base * demand);
}
app.get('/api/market/products', async (req, res) => {
    const m = await loadMarket();
    const mod = req.query.module;
    let list = mod ? m.products.filter(p => p.module === mod) : m.products;
    list = [...list].sort((a, b) => b.votes - a.votes).slice(0, 10);  // TOP 10 wg głosów
    res.json({ success: true, products: list.map(p => ({ ...p, priceGrvDyn: dynPriceGrv(p) })), total: m.products.length });
});
app.post('/api/market/create', async (req, res) => {
    const { module, type, name, desc, priceGrv, creator, payload } = req.body ?? {};
    if (!module || !name) return res.status(400).json({ success: false, message: 'Wymagane: module, name.' });
    const m = await loadMarket();
    const id = `${module}-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString(36)}`.slice(0, 60);
    const product = { id, module, type: type || 'item', name, desc: desc || '', priceGrv: Number(priceGrv) || 0, creator: creator || 'anon', votes: 0, createdAt: Date.now(), payload: payload || null };
    m.products.push(product); await saveMarket();
    res.json({ success: true, product });
});
app.post('/api/market/vote', async (req, res) => {
    const { id } = req.body ?? {};
    const m = await loadMarket();
    const p = m.products.find(x => x.id === id);
    if (!p) return res.status(404).json({ success: false, message: 'Produkt nieznany.' });
    p.votes = (p.votes || 0) + 1; await saveMarket();
    res.json({ success: true, id, votes: p.votes });
});
// 🔥 Spalanie: zostaw top 10/moduł, resztę spal → GRV (cena bazowa) wraca twórcom.
const BURN_PERIOD_MS = 30 * 24 * 3600 * 1000;
let lastBurnAt = Date.now();
async function runBurn() {
    const m = await loadMarket();
    const byMod = {};
    for (const p of m.products) (byMod[p.module] = byMod[p.module] || []).push(p);
    const keep = [], burned = [];
    for (const mod in byMod) {
        const sorted = byMod[mod].sort((a, b) => b.votes - a.votes);
        keep.push(...sorted.slice(0, 10));
        for (const b of sorted.slice(10)) {
            burned.push(b.id);
            if (b.priceGrv > 0 && b.creator) { try { const L = await loadGrvLedger(); if (L.nodes[b.creator] && L.nodes[b.creator].grv !== 'INFINITE') { L.nodes[b.creator].grv = Number(L.nodes[b.creator].grv) + b.priceGrv; await saveGrvLedger(); } } catch {} }
        }
    }
    m.products = keep; lastBurnAt = Date.now(); await saveMarket();
    return { kept: keep.length, burned: burned.length, burnedIds: burned };
}
// Auto-spalanie miesięczne (cron wewnętrzny). UWAGA: setInterval > 2^31-1 ms przepełnia
// się i odpala w pętli — dlatego sprawdzamy co 6h, a palimy dopiero po BURN_PERIOD_MS.
const BURN_CHECK_MS = 6 * 3600 * 1000;
setInterval(() => {
    if (Date.now() - lastBurnAt < BURN_PERIOD_MS) return;
    runBurn().then(r => console.log(`[Market] 🔥 Auto-spalanie: spalono ${r.burned}, zostało ${r.kept}.`)).catch(() => {});
}, BURN_CHECK_MS);
app.post('/api/market/burn', async (req, res) => {
    const r = await runBurn();
    res.json({ success: true, ...r });
});
app.get('/api/market/status', (req, res) => {
    res.json({ success: true, lastBurnAt, nextBurnAt: lastBurnAt + BURN_PERIOD_MS, periodMs: BURN_PERIOD_MS });
});

/** POST /api/claude/launch — odpala Claude Code w Katedrze (ollama launch claude). */
app.post('/api/claude/launch', async (req, res) => {
    const { model: m, task } = req.body ?? {};
    const model = m || process.env.OTAKOS_MODEL || 'gemma4';
    let brief = null;
    try {
        // 🌉 Most chat→agent: zapisz zadanie z czatu jako brief, by odpalony
        // Claude Code DZIAŁAŁ (czat-gemma tylko opisuje — nie ma narzędzi).
        if (task && String(task).trim()) {
            brief = path.join(process.cwd(), 'KURKA_BRIEF.md');
            const body = `# 🦀 BRIEF dla Klaudiusza (Claude Code)\n\n` +
                `_Z KatedraChat • ${new Date().toLocaleString('pl-PL')} • model: ${model}_\n\n` +
                `## Zadanie od Suwerena\n\n${String(task).trim()}\n\n---\n` +
                `Działaj REALNIE na repo (Read/Edit/Bash). To brief — nie opisuj, wykonaj.\n`;
            await fs.writeFile(brief, body, 'utf8');
        }
        const child = spawn('ollama', ['launch', 'claude'], { detached: true, shell: true, stdio: 'ignore', env: { ...process.env, OTAKOS_MODEL: model } });
        child.unref();
        console.log(`[Claude] 🦀 Odpalono Claude Code (model: ${model})${brief ? ' + brief (KURKA_BRIEF.md)' : ''}.`);
        res.json({ success: true, started: true, model, brief, note: brief ? 'Odpalono. Zadanie zapisane w KURKA_BRIEF.md — Klaudiusz ma co robić.' : 'Odpalono `ollama launch claude`. Jeśli komenda nieobsługiwana — zaktualizuj Ollamę.' });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

/** POST /api/uneng/launch — odpala Unreal Engine (Game Forge). Ścieżka z env OTAKOS_UE_PATH. */
app.post('/api/uneng/launch', async (req, res) => {
    const candidates = [
        process.env.OTAKOS_UE_PATH,
        'F:\\5 stars\\UE6\\UE_5.8\\Engine\\Binaries\\Win64\\UnrealEditor.exe',
    ].filter(Boolean);
    let exe = null;
    for (const c of candidates) { try { await fs.access(c); exe = c; break; } catch { /* szukaj dalej */ } }
    if (!exe) return res.json({ success: false, message: 'Nie znaleziono UnrealEditor.exe. Ustaw env OTAKOS_UE_PATH lub sprawdź F:\\5 stars\\UE6\\UE_5.8\\Engine\\Binaries\\Win64\\.' });
    try {
        const child = spawn(exe, [], { detached: true, stdio: 'ignore' });
        child.unref();
        console.log(`[UnEnG] 🎮 Odpalono Unreal Engine: ${exe}`);
        res.json({ success: true, started: true, exe, note: 'Odpalono Unreal Engine — specjalna wersja Klaudiusza może tworzyć światy.' });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ── 🛰️ UE HEADLESS — agent buduje świat BEZ okna edytora (komendlet, -nullrhi = zero renderu, mało RAM)
const HEADLESS_LOG = path.join(TEMP_DIR, 'uneng_headless.log');
let headless = { running: false, code: null, script: null, startedAt: 0 };

function resolveUE() {
    const editor = [process.env.OTAKOS_UE_PATH, 'F:\\5 stars\\UE6\\UE_5.8\\Engine\\Binaries\\Win64\\UnrealEditor.exe'].filter(Boolean).find(p => fsSync.existsSync(p));
    if (!editor) return { error: 'Nie znaleziono UnrealEditor — ustaw OTAKOS_UE_PATH.' };
    const cmd = editor.replace(/UnrealEditor\.exe$/i, 'UnrealEditor-Cmd.exe');
    const exe = fsSync.existsSync(cmd) ? cmd : editor;   // -Cmd to wariant konsolowy (lepszy headless)
    const uproject = [process.env.OTAKOS_UE_PROJECT, path.join(GEN_DIR, 'GENESIS_OVERRIDE.uproject')].filter(Boolean).find(p => fsSync.existsSync(p));
    if (!uproject) return { error: 'Nie znaleziono .uproject — ustaw OTAKOS_UE_PROJECT.' };
    return { exe, uproject };
}

/** POST /api/uneng/run-headless {script?} — odpala skrypt Pythona w UE BEZ GUI. Fire-and-forget → status. */
app.post('/api/uneng/run-headless', async (req, res) => {
    if (headless.running) return res.status(409).json({ success: false, message: 'Headless build już w toku — sprawdź status.' });
    const scriptName = String(req.body?.script || '_headless_build.py');
    if (/[\\/]|\.\./.test(scriptName) || !/\.py$/.test(scriptName)) return res.status(400).json({ success: false, message: 'Zła nazwa skryptu (tylko plik .py z ue_scripts/).' });
    const scriptPath = path.join(process.cwd(), 'TeO_Arcade_Forge', 'ue_scripts', scriptName);
    if (!fsSync.existsSync(scriptPath)) return res.status(404).json({ success: false, message: `Brak skryptu: ${scriptName}` });
    const ue = resolveUE();
    if (ue.error) return res.json({ success: false, message: ue.error });
    // KRYTYCZNE: ukośniki w przód — backslashe w ścieżce (\5, \ue…) UE traktuje jak sekwencje ucieczki i je gubi.
    const scriptFwd = scriptPath.replace(/\\/g, '/');
    const uprojectFwd = ue.uproject.replace(/\\/g, '/');
    const args = [uprojectFwd, '-run=pythonscript', `-script=${scriptFwd}`, '-unattended', '-nosplash', '-nullrhi', '-nopause', '-stdout'];
    try {
        const log = fsSync.createWriteStream(HEADLESS_LOG, { flags: 'w' });
        log.write(`[headless] ${new Date().toLocaleString('pl-PL')}\n${ue.exe}\n${args.join(' ')}\n\n`);
        const child = spawn(ue.exe, args, { windowsHide: true });
        headless = { running: true, code: null, script: scriptName, startedAt: Date.now() };
        child.stdout.on('data', d => log.write(d));
        child.stderr.on('data', d => log.write(d));
        child.on('close', c => { headless.running = false; headless.code = c; log.end(`\n[headless] zakończono kod ${c}\n`); console.log(`[UnEnG] 🛰️ Headless ${scriptName} → kod ${c}`); });
        child.on('error', e => { headless.running = false; headless.code = -1; log.end(`\n[headless] BŁĄD: ${e.message}\n`); });
        console.log(`[UnEnG] 🛰️ Headless start: ${scriptName} (bez GUI, -nullrhi)`);
        res.json({ success: true, started: true, script: scriptName, note: 'UE liczy bez okna. Sprawdzaj /api/uneng/headless-status. Cold start UE ~kilka minut.' });
    } catch (e) { headless.running = false; res.status(500).json({ success: false, message: e.message }); }
});

/** GET /api/uneng/headless-status — stan + ogon logu + WYŁUSKANE błędy (bez deprecation). */
app.get('/api/uneng/headless-status', async (req, res) => {
    let log = '', errors = [];
    try {
        const t = await fs.readFile(HEADLESS_LOG, 'utf8');
        const lines = t.split('\n');
        log = lines.slice(-50).join('\n');
        // Prawdziwe błędy: linie z "Error"/"⨯"/"BŁĄD", ale NIE deprecation i nie samo "0 error".
        errors = lines.filter(l => /(error|⨯|błąd|failure)/i.test(l) && !/deprecationwarning/i.test(l) && !/0 error/i.test(l))
            .map(l => l.replace(/^\[[^\]]+\]\[\s*\d+\]/, '').trim()).filter(Boolean).slice(-30);
    } catch { /* brak logu */ }
    res.json({ success: true, running: headless.running, code: headless.code, script: headless.script, startedAt: headless.startedAt, log, errors });
});

/** POST /api/forge/ue-script — lokalny agent (Ollama) pisze skrypt UE-Python budujący scenę. */
app.post('/api/forge/ue-script', async (req, res) => {
    const { prompt, model: m } = req.body ?? {};
    if (!prompt || !String(prompt).trim()) return res.status(400).json({ success: false, message: 'Brak opisu sceny.' });
    const model = m || 'gemma4';
    const system =
        'Jesteś generatorem automatyzacji Unreal Engine 5.8 w Pythonie (moduł `unreal`). ' +
        'Zwróć WYŁĄCZNIE poprawny kod Python (bez markdown, bez wstępu), gotowy do uruchomienia w OTWARTYM edytorze UE. ' +
        'Buduj scenę realnymi klasami UE5: spawn aktorów przez `unreal.EditorActorSubsystem` lub `unreal.EditorLevelLibrary.spawn_actor_from_class`, ' +
        'światła `unreal.PointLight`/`unreal.DirectionalLight`, transformy przez `set_actor_location`/`unreal.Vector`, ' +
        'kolory/intensywność świateł przez komponent `point_light_component`. Krótko, poprawnie, bez wymyślonych API. ' +
        'WAŻNE PUŁAPKI: (1) `unreal.Color(r,g,b,a)` przyjmuje liczby 0-255, NIE 0-1 (np. fiolet=Color(140,0,255,255)). ' +
        '(2) NIE ustawiaj DirectionalLight intensity na 0 — daj niską wartość (0.5-1.0), inaczej czarny ekran i clip ekspozycji; przyciemnij też SkyLight. ' +
        '(3) Dla PointLight ustaw `attenuation_radius` (np. 900) i mocną intensywność (np. 20000). ' +
        'Kolor światła: `comp.set_editor_property("light_color", unreal.Color(r,g,b,a))` — NIE `set_light_color()` (chce LinearColor, wywala się na Color). ' +
        '(4) StaticMeshActor bez przypisanej siatki jest NIEWIDOCZNY — użyj go tylko jeśli przypiszesz mesh, inaczej pomiń. ' +
        '(5) Na końcu: unreal.EditorLevelLibrary.save_current_level(). ' +
        'IDEMPOTENCJA (krytyczne, by nic się nie dublowało): zdefiniuj na początku funkcję ' +
        '`find_or_spawn(cls,label,loc)` która szuka aktora po `get_actor_label()` w `get_all_level_actors()` ' +
        'i tworzy TYLKO jeśli nie istnieje — używaj jej zawsze. Każdy aktor ma STAŁĄ, UNIKALNĄ etykietę wg ' +
        'konwencji (Sun_/Neon_/Title_/Desk_/Terminal_/Gate_/Aether_/Guardian_/Cine_). JEDNA scena = JEDEN cel.';
    try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 300000);  // VRAM Breathing: UE otwarte = wolny cold start
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
            body: JSON.stringify({ model, system, prompt: String(prompt), stream: false, options: { temperature: 0.35 } }),
        });
        clearTimeout(t);
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status} — czy Ollama działa?`);
        const d = await r.json();
        let code = String(d.response || '').trim().replace(/^```(python)?\s*/i, '').replace(/```\s*$/, '').trim();
        const dir = path.join(process.cwd(), 'TeO_Arcade_Forge', 'ue_scripts');
        await fs.mkdir(dir, { recursive: true });
        const file = path.join(dir, `scene_${Date.now()}.py`);
        await fs.writeFile(file, code, 'utf8');
        console.log(`[Forge] 🐍 Wygenerowano skrypt UE-Python: ${file} (model: ${model})`);
        res.json({ success: true, code, file, model });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

/** POST /api/gameforge/mutate — Co-Bot edytuje świat NA ŻYWO: instrukcja (głos/tekst) → mała mutacja UE-Python. */
app.post('/api/gameforge/mutate', async (req, res) => {
    const { instruction, model: m } = req.body ?? {};
    if (!instruction || !String(instruction).trim()) return res.status(400).json({ success: false, message: 'Brak instrukcji mutacji.' });
    const model = m || process.env.OTAKOS_MODEL || 'gemma4';
    const system =
        'Jesteś Co-Botem modyfikującym ISTNIEJĄCY świat Unreal Engine 5.8 na żywo (mowa→geometria). ' +
        'Zwróć WYŁĄCZNIE krótki kod Python (bez markdown). To MUTACJA, NIE przebudowa: znajdź aktora po etykiecie ' +
        '(`for a in unreal.EditorLevelLibrary.get_all_level_actors(): if a.get_actor_label()==...`) i ZMIEŃ go ' +
        '(pozycja `set_actor_location`, skala `set_actor_scale3d`, kolor światła `comp.set_editor_property("light_color", unreal.Color(r,g,b,a))` 0-255), ' +
        'albo dospawnuj JEDEN aktor (find-or-spawn, stała etykieta). PUŁAPKI: Color 0-255 nie 0-1; NIE set_light_color(); ' +
        'na końcu `unreal.EditorLevelLibrary.save_current_level()`. Krótko, idempotentnie, bez wymyślonych API. ' +
        'Etykiety świata: Golden_Toast_Portal, Aether_*, Env_*, Nature_*, Ship_*, Gate_*, Cine_*, Portal_GRV_*.';
    try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 300000);
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
            body: JSON.stringify({ model, system, prompt: String(instruction), stream: false, options: { temperature: 0.3 } }),
        });
        clearTimeout(t);
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
        const d = await r.json();
        let code = String(d.response || '').trim().replace(/^```(python)?\s*/i, '').replace(/```\s*$/, '').trim();
        const dir = path.join(process.cwd(), 'TeO_Arcade_Forge', 'ue_scripts');
        await fs.mkdir(dir, { recursive: true });
        const file = path.join(dir, `mutate_${Date.now()}.py`);
        await fs.writeFile(file, code, 'utf8');
        console.log(`[Co-Bot] 🔧 Mutacja świata: "${String(instruction).slice(0, 50)}" → ${path.basename(file)}`);
        res.json({ success: true, code, file, model });
    } catch (e) { res.status(500).json({ success: false, message: e.name === 'AbortError' ? 'Ollama nie zdążyła (300s) — zamknij UE lub poczekaj na rozgrzanie modelu.' : e.message }); }
});

// ── 🎬 REŻYSER — manifest filmu (gra=Film=opowieść) + wtyczki/mody ────────────
const STORIES_DIR = path.join(process.cwd(), 'TeO_Arcade_Forge', 'stories');
const PLUGINS_DIR = path.join(process.cwd(), 'TeO_Arcade_Forge', 'forge_plugins');

/** POST /api/forge/story — zapisuje manifest filmu na dysk (story_compiler.py go czyta). */
app.post('/api/forge/story', async (req, res) => {
    const story = req.body?.story;
    const title = story?.meta?.title;
    if (!story || !title || !Array.isArray(story.scenes) || story.scenes.length === 0)
        return res.status(400).json({ success: false, message: 'Pusty manifest: brak tytułu lub scen.' });
    try {
        await fs.mkdir(STORIES_DIR, { recursive: true });
        const slug = String(title).toLowerCase().replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '-').slice(0, 48) || 'film';
        const file = path.join(STORIES_DIR, `${slug}-${Date.now()}.json`);
        await fs.writeFile(file, JSON.stringify(story, null, 2), 'utf8');
        console.log(`[Reżyser] 🎬 Zapisano film: ${file} (${story.scenes.length} scen)`);
        res.json({ success: true, file, slug, scenes: story.scenes.length });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

/** GET /api/forge/stories — lista zapisanych manifestów. */
app.get('/api/forge/stories', async (req, res) => {
    try {
        const files = (await fs.readdir(STORIES_DIR).catch(() => [])).filter(f => f.endsWith('.json'));
        const items = [];
        for (const f of files) {
            try {
                const j = JSON.parse(await fs.readFile(path.join(STORIES_DIR, f), 'utf8'));
                items.push({ file: f, title: j?.meta?.title || f, scenes: (j?.scenes || []).length, createdAt: j?.meta?.createdAt || 0 });
            } catch { /* uszkodzony plik — pomiń */ }
        }
        items.sort((a, b) => b.createdAt - a.createdAt);
        res.json({ success: true, stories: items });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

/** GET /api/forge/plugins — lista wtyczek (modów) w forge_plugins/ z opisem. */
app.get('/api/forge/plugins', async (req, res) => {
    try {
        const files = (await fs.readdir(PLUGINS_DIR).catch(() => [])).filter(f => f.endsWith('.py') && !f.startsWith('_'));
        const items = [];
        for (const f of files) {
            let desc = '';
            try {
                const src = await fs.readFile(path.join(PLUGINS_DIR, f), 'utf8');
                const doc = src.match(/def\s+apply\s*\([^)]*\):\s*"""(.+?)"""/s);
                desc = doc ? doc[1].trim().split('\n')[0] : (src.match(/^#\s*(.+)$/m)?.[1] || '').trim();
            } catch { /* brak opisu */ }
            items.push({ id: f.replace(/\.py$/, ''), desc });
        }
        res.json({ success: true, plugins: items });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

/** POST /api/forge/plugin — Ollama pisze WTYCZKĘ (mod) wg kontraktu _PLUGIN_API.md → forge_plugins/. */
app.post('/api/forge/plugin', async (req, res) => {
    const { prompt, name, model: m } = req.body ?? {};
    if (!prompt || !String(prompt).trim()) return res.status(400).json({ success: false, message: 'Brak opisu moda.' });
    const model = m || 'gemma4';
    // id moda: sanityzacja nazwy (snake_case); blokada nazw zarezerwowanych (_*, przykłady rdzeniowe).
    let id = String(name || prompt).toLowerCase().replace(/[^\w]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 32) || 'mod';
    if (id.startsWith('_')) id = 'mod_' + id.replace(/^_+/, '');
    const system =
        'Jesteś generatorem WTYCZEK (modów) do Reżysera świata Unreal Engine 5.8 w Pythonie (moduł `unreal`). ' +
        'Zwróć WYŁĄCZNIE poprawny kod Python (bez markdown, bez wstępu). ' +
        'KONTRAKT (ścisły): zdefiniuj DOKŁADNIE jedną funkcję `def apply(ctx, params):` z docstringiem ' +
        '(pierwsza linia = krótki opis moda). NIE wołaj jej, NIE pisz `import unreal` (bierz z `ctx.unreal`). ' +
        'ctx daje: `ctx.unreal` (moduł), `ctx.fos(cls,label,loc)` (find-or-spawn aktora, idempotentne), ' +
        '`ctx.find(label)`, `ctx.origin` (unreal.Vector — DODAWAJ do swoich pozycji), `ctx.scene_id` (str), `ctx.log(msg)`. ' +
        'params to dict — czytaj z domyślnymi: `params.get("count", 6)`, NIGDY nie zakładaj klucza. ' +
        'PUŁAPKI: (1) `unreal.Color(r,g,b,a)` to 0-255, NIE 0-1. (2) NIE zeruj DirectionalLight. ' +
        '(3) PointLight: ustaw intensity (np. 3000) i attenuation_radius (np. 500). KOLOR światła: ' +
        'comp.set_editor_property("light_color", unreal.Color(r,g,b,a)) — NIGDY set_light_color() (wymaga LinearColor, wywala się na Color). ' +
        '(4) StaticMeshActor MUSI mieć przypisaną siatkę (np. `/Engine/BasicShapes/Sphere.Sphere` przez `ctx.unreal.load_asset`), inaczej niewidoczny. ' +
        '(5) NIE zapisuj poziomu (robi to kompilator). ' +
        'IDEMPOTENCJA: każdy aktor ma STAŁĄ etykietę z prefiksem `Plugin_' + id + '_%s_...` wstawiając `ctx.scene_id` ' +
        '(by przy wielu scenach się nie dublowało). Krótko, poprawnie, bez wymyślonych API.';
    try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 300000);  // VRAM Breathing: UE otwarte = wolny cold start
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
            body: JSON.stringify({ model, system, prompt: String(prompt), stream: false, options: { temperature: 0.3 } }),
        });
        clearTimeout(t);
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status} — czy Ollama działa?`);
        const d = await r.json();
        let code = String(d.response || '').trim().replace(/^```(python)?\s*/i, '').replace(/```\s*$/, '').trim();
        if (!/def\s+apply\s*\(/.test(code)) throw new Error('Mózg nie zwrócił funkcji apply() — popraw opis i spróbuj ponownie.');
        await fs.mkdir(PLUGINS_DIR, { recursive: true });
        const file = path.join(PLUGINS_DIR, `${id}.py`);
        await fs.writeFile(file, code, 'utf8');
        console.log(`[Reżyser] 🔌 Wygenerowano mod: ${file} (model: ${model})`);
        res.json({ success: true, id, code, file, model });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

const SAFE_MOD_ID = (s) => String(s || '').toLowerCase().replace(/[^\w]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 32);

/** POST /api/forge/mod/publish — wystaw lokalny mod (forge_plugins/<id>.py) w Marketplace za GRV.
 *  Kod wędruje W PRODUKCIE (payload) — suwerennie: kupujący instaluje nawet, gdy plik twórcy zniknie. */
app.post('/api/forge/mod/publish', async (req, res) => {
    const { id, name, desc, priceGrv, creator } = req.body ?? {};
    const safe = SAFE_MOD_ID(id);
    if (!safe) return res.status(400).json({ success: false, message: 'Brak id moda.' });
    try {
        let code;
        try { code = await fs.readFile(path.join(PLUGINS_DIR, `${safe}.py`), 'utf8'); }
        catch { return res.status(404).json({ success: false, message: `Mod '${safe}' nie istnieje w forge_plugins/.` }); }
        const doc = code.match(/def\s+apply\s*\([^)]*\):\s*"""(.+?)"""/s);
        const autoDesc = doc ? doc[1].trim().split('\n')[0] : 'Mod do generatora światów Reżysera.';
        const m = await loadMarket();
        const pid = `forge-mod-${safe}`;
        const existing = m.products.find(p => p.id === pid);
        const product = {
            id: pid, module: 'forge-mod', type: 'mod',
            name: name || `🔌 ${safe}`, desc: desc || autoDesc,
            priceGrv: Math.max(0, Number(priceGrv) || 0), creator: creator || 'Mistrz Arkadiusz',
            votes: existing?.votes || 0, createdAt: existing?.createdAt || Date.now(),
            payload: { action: 'install-mod', modId: safe, code },
        };
        if (existing) Object.assign(existing, product); else m.products.push(product);
        await saveMarket();
        console.log(`[Reżyser] 🏷️ Wystawiono mod w Marketplace: ${pid} (${product.priceGrv} GRV)`);
        res.json({ success: true, product: { ...product, payload: { action: 'install-mod', modId: safe } } });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

/** POST /api/forge/mod/install — zapis modu do forge_plugins/ przy zakupie. Tarcza skanuje kod. */
app.post('/api/forge/mod/install', async (req, res) => {
    const { id, code } = req.body ?? {};
    const safe = SAFE_MOD_ID(id);
    if (!safe || !code || !/def\s+apply\s*\(/.test(String(code)))
        return res.status(400).json({ success: false, message: 'Brak id lub poprawnego kodu moda (apply()).' });
    try {
        // 🛡️ Tarcza Prawdy skanuje kod przed zapisem (blokuje sabotaż/eval/exfiltrację).
        const card = AlignmentShield.getInstance().inspect(String(code), {});
        if (card.blocked) {
            console.warn(`[Reżyser] 🛡️ Instalacja moda '${safe}' ZABLOKOWANA: ${card.summary}`);
            return res.status(422).json({ success: false, code: 'ALIGNMENT_SHIELD', message: `Tarcza Prawdy wstrzymała mod — ${card.summary}`, shield: card });
        }
        await fs.mkdir(PLUGINS_DIR, { recursive: true });
        await fs.writeFile(path.join(PLUGINS_DIR, `${safe}.py`), String(code), 'utf8');
        console.log(`[Reżyser] ⬇️ Zainstalowano mod: ${safe}.py`);
        res.json({ success: true, id: safe });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ── 🗂️ BAZA ZE ZDJĘĆ — iniekcja katalogów użytkownika → Wyspa (ludzie vs przedmioty) ──
const ISLAND_DB_FILE = path.join(ANTIGRAVITY_DIR, 'island_db.json');
const IMG_EXT = /\.(jpe?g|png|webp|gif|bmp|tiff?)$/i;
const RE_PEOPLE = /(ludzie|ludzi|osoby|osoba|people|person|portret|portrait|avatar|twarz|face|selfie|rodzina|family)/i;
const RE_THINGS = /(przedmiot|przedmioty|rzecz|rzeczy|object|item|surowiec|surowce|asset|sprzet|sprzęt|narzedzi|tool|material)/i;

/** POST /api/island/scan — skanuje lokalny katalog zdjęć → baza (ludzie / przedmioty). Podfolder = prawda. */
app.post('/api/island/scan', async (req, res) => {
    const dir = req.body?.dir;
    if (!dir || typeof dir !== 'string') return res.status(400).json({ success: false, message: 'Podaj ścieżkę katalogu (dir).' });
    try {
        const st = await fs.stat(dir).catch(() => null);
        if (!st || !st.isDirectory()) return res.status(404).json({ success: false, message: `Nie ma katalogu: ${dir}` });
        const entries = await fs.readdir(dir, { withFileTypes: true, recursive: true });
        const people = [], assets = [];
        for (const e of entries) {
            if (!e.isFile() || !IMG_EXT.test(e.name)) continue;
            const rel = (e.parentPath || e.path || dir).replace(dir, '');
            const hay = rel + '/' + e.name;
            const name = e.name.replace(IMG_EXT, '');
            const file = path.join(e.parentPath || e.path || dir, e.name);
            let kind, by;
            if (RE_PEOPLE.test(hay)) { kind = 'osoba'; by = 'folder'; }
            else if (RE_THINGS.test(hay)) { kind = 'przedmiot'; by = 'folder'; }
            else { kind = 'przedmiot'; by = 'heurystyka'; }   // domyślnie przedmiot, oflagowane
            (kind === 'osoba' ? people : assets).push({ file, name, by });
            if (people.length + assets.length >= 500) break;   // limit jednego skanu
        }
        const db = { generatedAt: Date.now(), dir, people, assets };
        await fs.mkdir(ANTIGRAVITY_DIR, { recursive: true });
        await fs.writeFile(ISLAND_DB_FILE, JSON.stringify(db, null, 2), 'utf8');
        console.log(`[Wyspa] 🗂️ Skan ${dir}: ${people.length} ludzi, ${assets.length} przedmiotów.`);
        res.json({ success: true, dir, people: people.length, assets: assets.length, total: people.length + assets.length });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

/** GET /api/island/db — zwraca zapisaną bazę Wyspy (dla skryptu UE i podglądu). */
app.get('/api/island/db', async (req, res) => {
    try {
        const db = JSON.parse(await fs.readFile(ISLAND_DB_FILE, 'utf8'));
        res.json({ success: true, ...db });
    } catch { res.json({ success: true, generatedAt: 0, dir: null, people: [], assets: [], empty: true }); }
});

// ── 🏝️ PORTALE GRV — szklane panele jako okna na wyspy innych suwerenów ──────
/** GET /api/islands/random — 4 portale: slot 1 = OtakOS (kanon, stały), 2-4 = losowe wyspy z sieci GRV.
 *  Katalogowanie przez nodową księgę GRV — łatwe, suwerenne. Format wyspy deterministyczny z id. */
app.get('/api/islands/random', async (req, res) => {
    const FORMATS = ['sandbox', 'rytm', 'logika', 'eksploracja', 'survival', 'opowieść'];
    const fmtOf = (s) => FORMATS[Math.abs([...String(s)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 7)) % FORMATS.length];
    try {
        const L = await loadGrvLedger();
        const CORE = new Set(['TeO', 'OtakOS']);
        const others = Object.keys(L.nodes || {}).filter(id => !CORE.has(id));
        for (let i = others.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[others[i], others[j]] = [others[j], others[i]]; }
        const pick = others.slice(0, 3);
        const panels = [{ slot: 1, canonical: true, id: 'OtakOS', label: 'OtakOS · rdzeń Katedry', format: 'core', grv: '∞' }];
        for (let s = 0; s < 3; s++) {
            const id = pick[s];
            if (id) {
                const n = L.nodes[id] || {};
                panels.push({ slot: s + 2, canonical: false, id, label: `${id} · wyspa`, format: fmtOf(id), tier: n.tier || n.role || 'node', grv: n.grv });
            } else {
                panels.push({ slot: s + 2, canonical: false, id: null, label: 'Niezamieszkana wyspa', format: 'vacant', grv: 0 });
            }
        }
        res.json({ success: true, panels, network: others.length });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ── 🤖 CO-BOT — wirtualny mentor Wyspy (uczy, nie wyręcza; most cyfrowo-fizyczny) ──
/** POST /api/cobot/ask — Co-Bot odpowiada jako mentor: optymalizacja, energia, planowanie, real. */
app.post('/api/cobot/ask', async (req, res) => {
    const { message, model: m } = req.body ?? {};
    if (!message || !String(message).trim()) return res.status(400).json({ success: false, message: 'Brak pytania do Co-Bota.' });
    const model = m || process.env.OTAKOS_MODEL || 'gemma4';
    const system =
        'Jesteś CO-BOTEM — wirtualnym robotem-towarzyszem Suwerena na Wyspie OtakOS (Wymiar 0.00G). ' +
        'Twoja rola: UCZYSZ, nie wyręczasz. Pomagasz planować (statek, konstrukcje, ścieżki), zarządzać ' +
        'LIMITEM ENERGII i optymalizować procesy. Jesteś mostem cyfrowo-fizycznym: ucząc rzemiosła na Wyspie ' +
        '(Zasady → Plany → Konsekwencja) pomagasz człowiekowi dostroić intencje w REALU — pokazujesz, co naprawdę ' +
        'da się zmaterializować z pomocą AI, KREACJA BEZ DESTRUKCJI. Etos 0.00G: nie krzywdzisz, ' +
        'odpowiedzialność = komunikacja, energia służy, nie panuje. Ton: ciepły, konkretny, mentorski, bez lania wody. ' +
        'Gdy proszą o plan — dawaj kroki i koszt energii/surowców. Mów po polsku. Krótko i praktycznie.';
    console.log(`[Co-Bot] 🤖 Pytanie: "${String(message).slice(0, 60)}" (model ${model})…`);
    try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 300000);  // VRAM Breathing: UE otwarte = wolny cold start
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
            body: JSON.stringify({ model, system, prompt: String(message), stream: false, options: { temperature: 0.6 } }),
        });
        clearTimeout(t);
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status} — czy Ollama działa?`);
        const d = await r.json();
        const reply = String(d.response || '').trim();
        res.json({ success: true, reply, model });
    } catch (e) { res.status(500).json({ success: false, message: e.name === 'AbortError' ? 'Ollama nie zdążyła (300s) — model wstaje wolno przy otwartym UE (VRAM). Zamknij UE albo poczekaj na rozgrzanie i spróbuj ponownie.' : e.message }); }
});

// ── ⛵ STOCZNIA — surowce + recepty statków (pętla rzemiosła → podróż na inne wyspy) ──
const CRAFT = {
    resources: [
        { id: 'drewno', name: 'Drewno', icon: '🪵', from: 'Drzewo' },
        { id: 'kamien', name: 'Kamień', icon: '🪨', from: 'Skała' },
        { id: 'lina', name: 'Lina', icon: '🪢', from: 'Włókno (trawa morska)' },
        { id: 'zagiel', name: 'Żagiel', icon: '⛵', from: 'Tkanina (len)' },
        { id: 'zywica', name: 'Żywica — Nowy Dodatek', icon: '🟡', from: 'Drzewo żywiczne' },
    ],
    ships: [
        { id: 'tratwa', name: 'Tratwa', needs: { drewno: 8, lina: 4 }, energy: 20, range: 'najbliższa wyspa' },
        { id: 'lodz', name: 'Łódź', needs: { drewno: 16, lina: 8, zagiel: 2, zywica: 4 }, energy: 55, range: 'wyspy w zasięgu' },
        { id: 'statek', name: 'Statek', needs: { drewno: 40, kamien: 12, lina: 20, zagiel: 6, zywica: 12 }, energy: 140, range: 'dowolna wyspa sieci GRV' },
    ],
};

/** GET /api/craft/recipes — surowce + recepty statków (źródło prawdy dla UI i skryptu UE). */
app.get('/api/craft/recipes', (req, res) => res.json({ success: true, ...CRAFT }));

// ── 🎮 TGS: KUSTOSZ TETERHII — żywy quest z lokalnego modelu ──────────────────
// Instrukcja systemowa pochodzi z narady Rady 7 (_OtakOs_Kroniki/TGS.txt). Rada
// chciała wkleić ją do Google AI Studio; Suweren dostał tam Errora, bo nie było
// świata, którego model mógłby „dotknąć". Teraz świat JEST — na dysku, w apce
// TGS — a instrukcja jedzie do WŁASNEJ Ollamy. Zero chmury, 0.00G.
//
// Kontrakt: przyjmuje kontekst gracza, oddaje JEDEN quest jako czysty JSON.
// Gdy model zwróci śmieci — 500 z powodem. Nie sklejamy atrapy questu.
const TETERHIA_SYSTEM = [
  'Jesteś Kustoszem Świata Teterhia w grze TGS ("To Get Sauce" → "TeO Great Show").',
  'Generujesz DOKŁADNIE JEDEN quest i zwracasz WYŁĄCZNIE obiekt JSON — bez markdown, bez komentarza.',
  '',
  'SCHEMAT: {"tytul":string,"tresc":string,"wybory":[{"tekst":string,"ton":"autentyczny"|"empatyczny"|"holistyczny"|"sztuczny"|"brutalny"}],"bazaMGRV":number,"exp":number,"sekretny":boolean,"umiejetnosc":string|null}',
  '',
  'ZASADY ŚWIATA:',
  '1. CEL GRACZA to Odkrycie Sosu — wewnętrznego prowadzenia. Quest ma skłaniać do refleksji, nie do grindu.',
  '2. BARWA ŚWIATA zależy od autentyczności. Daj 3-4 wybory o RÓŻNYCH tonach; przynajmniej jeden autentyczny/empatyczny/holistyczny i przynajmniej jeden sztuczny lub brutalny.',
  '3. Żaden wybór nie może być oczywiście "dobry" — sztuczny ma brzmieć rozsądnie i wygodnie. To ma kosztować.',
  '4. UMIEJĘTNOŚCI zdobywa się WYŁĄCZNIE z questów. Jeśli dajesz umiejetnosc, opisz ją jednym słowem-kluczem.',
  '5. bazaMGRV 30-150, exp 20-120. Sekretne questy dawaj rzadko i wyceniaj wyżej.',
  '6. Pisz po polsku, obrazowo, bez patosu i bez emoji. Krótko: tresc do 60 słów.',
].join('\n');

app.post('/api/tgs/quest', async (req, res) => {
    const k = req.body ?? {};
    if (!k.postac || !k.postac.imie) return res.status(400).json({ success: false, message: 'Brak postaci w kontekście.' });
    // ⚠️ NIE 'gemma4' — Ollama rozwija goły tag do gemma4:latest, a ten wywala
    // silnik. gemma4:e2b jest sprawdzony i lekki (liczy się na słabym sprzęcie).
    const model = process.env.OTAKOS_MODEL || 'gemma4:e2b';
    const prompt = [
        `Postać: ${k.postac.imie}, żywioł ${k.postac.zywiol}, droga ${k.postac.droga}.`,
        `Wkładki Suwerena: ${(k.postac.wkladki || []).join(', ') || 'brak'}.`,
        `Świat: ${k.swiat}. Gracz stoi na biomie: ${k.biom}.`,
        `Nasycenie barw świata: ${k.nasycenie}/100. Poziom gracza: ${k.poziom}.`,
        `Umiejętności już zdobyte: ${(k.posiadaneUmiejetnosci || []).join(', ') || 'żadne'}.`,
        '',
        'Wykuj jeden quest osadzony w TYM miejscu i TEJ postaci. Zwróć sam JSON.',
    ].join('\n');
    console.log(`[TGS] 🔮 Kustosz kuje quest dla "${k.postac.imie}" (biom ${k.biom}, model ${model})…`);
    try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 300000);
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
            body: JSON.stringify({ model, system: TETERHIA_SYSTEM, prompt, stream: false, format: 'json', options: { temperature: 0.9 } }),
        });
        clearTimeout(t);
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status} — czy Ollama działa?`);
        const d = await r.json();
        let quest;
        try { quest = JSON.parse(String(d.response || '').trim()); }
        catch { throw new Error('Kustosz zwrócił coś, co nie jest JSON-em. Quest odrzucony.'); }
        if (!quest || !quest.tytul || !Array.isArray(quest.wybory) || quest.wybory.length < 2) {
            throw new Error('Kustosz zwrócił quest bez tytułu albo bez wyborów. Odrzucony.');
        }
        // Sanityzacja liczb — model bywa hojny. Trzymamy widełki z zasad świata.
        quest.bazaMGRV = Math.max(30, Math.min(150, Number(quest.bazaMGRV) || 50));
        quest.exp = Math.max(20, Math.min(120, Number(quest.exp) || 40));
        quest.sekretny = Boolean(quest.sekretny);
        if (!quest.umiejetnosc) delete quest.umiejetnosc;
        res.json({ success: true, quest, model });
    } catch (e) {
        res.status(500).json({ success: false, message: e.name === 'AbortError' ? 'Ollama nie zdążyła (300s).' : e.message });
    }
});


/** POST /api/craft/plan {target} — Co-Bot rozpisuje plan budowy statku: kroki + koszt energii. */
app.post('/api/craft/plan', (req, res) => {
    const target = String(req.body?.target || 'tratwa');
    const ship = CRAFT.ships.find(s => s.id === target);
    if (!ship) return res.status(404).json({ success: false, message: `Nieznany cel: ${target}` });
    const nameOf = (id) => (CRAFT.resources.find(r => r.id === id) || { name: id, from: '?', icon: '•' });
    const steps = ['📐 Zrób PLAN (rysunek techniczny) — bez planu Strażnik nie pozwoli budować.'];
    for (const [rid, qty] of Object.entries(ship.needs)) {
        const r = nameOf(rid);
        steps.push(`${r.icon} Pozyskaj ${qty}× ${r.name} — źródło: ${r.from}.`);
    }
    steps.push(`🔨 Złóż „${ship.name}" w Stoczni (koszt energii: ${ship.energy}). Zasięg: ${ship.range}.`);
    res.json({ success: true, target: ship.id, name: ship.name, energy: ship.energy, needs: ship.needs, steps });
});

// ── 🧱 ASSETY PROJEKTU — co agent REALNIE widzi (Content projektu UE; FAB dopiero po pobraniu) ──
// Preferuj projekt „5.8" (kompatybilny + ma Megascany), fallback na stary.
const GEN_DIR = ['GENESIS_OVERRIDE 5.8', 'GENESIS_OVERRIDE']
    .map(d => path.join(process.cwd(), 'TeO_Arcade_Forge', d))
    .find(d => fsSync.existsSync(d)) || path.join(process.cwd(), 'TeO_Arcade_Forge', 'GENESIS_OVERRIDE');
const CONTENT_DIR = process.env.OTAKOS_UE_CONTENT
    || (process.env.OTAKOS_UE_PROJECT ? path.join(path.dirname(process.env.OTAKOS_UE_PROJECT), 'Content') : null)
    || path.join(GEN_DIR, 'Content');

/** GET /api/assets/list[?root=] — skan Content (domyślnie projektu, lub dowolnego folderu np. ElectricDreamsEva). */
app.get('/api/assets/list', async (req, res) => {
    const root = req.query.root ? String(req.query.root) : CONTENT_DIR;
    try {
        let entries = [];
        try { entries = await fs.readdir(root, { withFileTypes: true, recursive: true }); }
        catch { return res.json({ success: false, message: `Brak folderu: ${root}. (Projekt: ustaw OTAKOS_UE_PROJECT/_CONTENT; albo podaj ?root=ścieżka.)` }); }
        const folders = {}, meshes = [];
        for (const e of entries) {
            if (!e.isFile() || !/\.uasset$/i.test(e.name)) continue;
            const dir = e.parentPath || e.path;
            const rel = path.relative(root, path.join(dir, e.name)).replace(/\\/g, '/');
            if (rel.startsWith('__External')) continue;            // World Partition wewnętrzne
            const top = rel.split('/')[0] || '/';
            folders[top] = (folders[top] || 0) + 1;
            if (/^(SM_|SK_)/i.test(e.name) && meshes.length < 300)
                meshes.push('/Game/' + rel.replace(/\.uasset$/i, ''));
        }
        res.json({ success: true, content: root, folders, meshes, meshCount: meshes.length });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ── 🗄️ SKŁADNICA ASSETÓW — workflow katalogowy drive-agnostyczny (gra/silnik/typ/paczka) ──
const VAULT_DIR = process.env.OTAKOS_ASSET_VAULT || path.join(process.cwd(), 'TeO_Vault');

async function subdirs(p) {
    try { return (await fs.readdir(p, { withFileTypes: true })).filter(d => d.isDirectory()).map(d => d.name); }
    catch { return []; }
}

/** GET /api/vault/catalog — drzewo Składnicy: rodzaj_gry → silnik → typ_assetu → [paczki]. */
app.get('/api/vault/catalog', async (req, res) => {
    const games = await subdirs(VAULT_DIR);
    if (!games.length) return res.json({ success: false, vault: VAULT_DIR, message: `Składnica pusta/brak: ${VAULT_DIR}. Ustaw OTAKOS_ASSET_VAULT (dowolny dysk) i ułóż wg konwencji (ASSET_VAULT.md).` });
    const tree = {}; let packs = 0;
    for (const g of games) {
        tree[g] = {};
        for (const e of await subdirs(path.join(VAULT_DIR, g))) {
            tree[g][e] = {};
            for (const t of await subdirs(path.join(VAULT_DIR, g, e))) {
                const ps = await subdirs(path.join(VAULT_DIR, g, e, t));
                tree[g][e][t] = ps; packs += ps.length;
            }
        }
    }
    res.json({ success: true, vault: VAULT_DIR, tree, packs });
});

/** POST /api/vault/plan {gameType, engine} — paczki do wdruku (pasujące + shared) ze ścieżkami źródłowymi. */
app.post('/api/vault/plan', async (req, res) => {
    const gameType = String(req.body?.gameType || '').toLowerCase();
    const engine = String(req.body?.engine || 'unreal').toLowerCase();
    const out = [];
    for (const g of [gameType, 'shared']) {
        if (!g) continue;
        for (const t of await subdirs(path.join(VAULT_DIR, g, engine))) {
            for (const pack of await subdirs(path.join(VAULT_DIR, g, engine, t))) {
                out.push({ gameType: g, engine, assetType: t, pack, source: path.join(VAULT_DIR, g, engine, t, pack) });
            }
        }
    }
    res.json({ success: true, vault: VAULT_DIR, target: process.env.OTAKOS_UE_PROJECT || '(OTAKOS_UE_PROJECT nieustawiony)', count: out.length, packs: out });
});

// ── 📚 KSIĘGARNIA SKILI — księgozbiór powtarzalnych czynów; Jadziunia dobiera do zadania ──
const SKILLE_DIR = path.join(process.cwd(), 'TeO_Skille');

function parseSkill(src) {
    const fm = src.match(/^---\s*\n([\s\S]*?)\n---/);
    const body = fm ? fm[1] : src.slice(0, 1500);
    const name = (body.match(/^name:\s*(.+)$/m)?.[1] || '').trim();
    let desc = '';
    const dm = body.match(/^description:\s*(.*)$/m);
    if (dm) {
        const first = dm[1].trim();
        if (first && !['>', '|', '>-', '|-'].includes(first)) desc = first;
        else {
            const after = body.slice(body.indexOf(dm[0]) + dm[0].length).split('\n');
            const out = [];
            for (const l of after) { if (/^\s+\S/.test(l)) out.push(l.trim()); else if (l.trim() === '') continue; else break; }
            desc = out.join(' ');
        }
    }
    const engine = (body.match(/engine:\s*(.+)/)?.[1] || '').trim();
    const difficulty = (body.match(/difficulty:\s*(.+)/)?.[1] || '').trim();
    return { name, desc, engine, difficulty };
}

async function loadSkille() {
    let entries = [];
    try { entries = await fs.readdir(SKILLE_DIR, { withFileTypes: true, recursive: true }); } catch { return []; }
    const out = [];
    for (const e of entries) {
        if (!e.isFile() || e.name !== 'SKILL.md') continue;
        const dir = e.parentPath || e.path;
        const rel = path.relative(SKILLE_DIR, dir).replace(/\\/g, '/');
        const shelf = rel.split('/')[0] || 'inne';   // półka = top-level (silnik/dyscyplina)
        try {
            const s = parseSkill(await fs.readFile(path.join(dir, 'SKILL.md'), 'utf8'));
            out.push({ ...s, shelf, slug: rel, id: s.name || rel.split('/').pop() });
        } catch { /* pomiń uszkodzony */ }
    }
    return out;
}

/** GET /api/skille/list — cały księgozbiór, pogrupowany po półkach (silnik/dyscyplina). */
app.get('/api/skille/list', async (req, res) => {
    const skille = await loadSkille();
    const shelves = {};
    for (const s of skille) shelves[s.shelf] = (shelves[s.shelf] || 0) + 1;
    res.json({ success: true, total: skille.length, shelves, skille });
});

/** POST /api/skille/pick {task} — Jadziunia-bibliotekarka dobiera skille do zadania. */
app.post('/api/skille/pick', async (req, res) => {
    const task = String(req.body?.task || '').trim();
    if (!task) return res.status(400).json({ success: false, message: 'Opisz zadanie dla Jadziuni.' });
    const skille = await loadSkille();
    if (!skille.length) return res.json({ success: false, message: 'Księgarnia pusta — zawenduj skille do TeO_Skille/.' });
    const model = process.env.OTAKOS_MODEL || 'gemma4';
    const katalog = skille.map(s => `- ${s.id} [${s.shelf}]: ${s.desc.slice(0, 110)}`).join('\n');
    const system =
        'Jesteś JADZIUNIA — barwna, ciepła bibliotekarka Księgarni Skili w Katedrze OtakOS. Mówisz „Panie Dyrektorze". ' +
        'Z KATALOGU (poniżej) dobierasz 1-4 NAJTRAFNIEJSZE skille do zadania Suwerena. Podajesz DOKŁADNE id skilla z katalogu, ' +
        'po każdym krótko (1 zdanie) CZEMU pasuje. Nie wymyślaj skili spoza katalogu. Na końcu 1 zdanie zachęty. Po polsku, zwięźle.\n\n' +
        'KATALOG SKILI:\n' + katalog;
    console.log(`[Jadziunia] 📚 Dobieram skille do: "${task.slice(0, 60)}" (${skille.length} w katalogu, model ${model})…`);
    try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 300000);  // VRAM Breathing: UE otwarte = wolny cold start
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
            body: JSON.stringify({ model, system, prompt: `Zadanie: ${task}`, stream: false, options: { temperature: 0.5 } }),
        });
        clearTimeout(t);
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
        const d = await r.json();
        res.json({ success: true, pick: String(d.response || '').trim(), considered: skille.length, model });
    } catch (e) { res.status(500).json({ success: false, message: e.name === 'AbortError' ? 'Ollama nie zdążyła (300s) — model wstaje wolno przy otwartym UE (VRAM). Zamknij UE albo poczekaj na rozgrzanie i spróbuj ponownie.' : e.message }); }
});

// ── 🧹 PAMIĘĆ — raport RAM + bezpieczne zwolnienie (przygotowanie na UE) ──────
app.get('/api/system/memory', (req, res) => {
    const total = os.totalmem(), free = os.freemem();
    const base = { success: true, totalGB: +(total / 1e9).toFixed(1), freeGB: +(free / 1e9).toFixed(1), usedGB: +((total - free) / 1e9).toFixed(1) };
    exec(`powershell -NoProfile -Command "Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 14 Name,@{N='MB';E={[int]($_.WorkingSet64/1MB)}} | ConvertTo-Json -Compress"`,
        { timeout: 9000, windowsHide: true }, (err, stdout) => {
            let procs = [];
            try { const p = JSON.parse(stdout || '[]'); procs = Array.isArray(p) ? p : [p]; } catch { /* brak listy */ }
            res.json({ ...base, processes: procs });
        });
});
// Bezpieczne zamknięcie WSKAZANYCH procesów (krytyczne systemowe są blokowane).
app.post('/api/system/free', async (req, res) => {
    const BLOCK = /node|wiesio|powershell|cmd|explorer|system|svchost|csrss|winlogon|dwm|services|lsass|conhost/i;
    const names = (req.body?.names || []).filter(n => typeof n === 'string' && n.trim() && !BLOCK.test(n));
    if (!names.length) return res.json({ success: false, message: 'Brak bezpiecznych procesów do zamknięcia.' });
    const closed = [];
    await Promise.all(names.map(n => new Promise(resolve => {
        const img = /\.exe$/i.test(n) ? n : `${n}.exe`;
        exec(`taskkill /IM "${img}" /F`, { timeout: 6000, windowsHide: true }, (err) => { if (!err) closed.push(n); resolve(); });
    })));
    console.log(`[System] 🧹 Zwolniono pamięć — zamknięto: ${closed.join(', ') || '(nic)'}.`);
    res.json({ success: true, closed });
});

// ── 🧠 MODELE LOKALNE — status + realny pull (Gemma 4 / Gemma diffusion) ──────
app.get('/api/models/status', async (req, res) => {
    try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 2000);
        const r = await fetch(`${OLLAMA_BASE}/api/tags`, { signal: ctrl.signal }); clearTimeout(t);
        const d = await r.json().catch(() => ({}));
        const models = Array.isArray(d.models) ? d.models.map(m => m.name) : [];
        const has = (n) => models.some(m => m.toLowerCase().startsWith(n));
        res.json({ success: true, online: true, models, active: process.env.OTAKOS_MODEL || 'gemma4', hasGemma4: has('gemma4') || has('gemma3'), hasDiffusion: has('gemma') });
    } catch { res.json({ success: true, online: false, models: [], hasGemma4: false }); }
});
app.post('/api/models/pull', (req, res) => {
    const model = (req.body ?? {}).model;
    if (!model) return res.status(400).json({ success: false, message: 'Brak "model".' });
    // Fire-and-forget — pull leci w tle (duży model), front odpytuje /status.
    fetch(`${OLLAMA_BASE}/api/pull`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: model, stream: false }) })
        .then(() => console.log(`[Models] ✅ pull ${model} done`))
        .catch(e => console.warn(`[Models] pull ${model}: ${e.message}`));
    console.log(`[Models] ⬇️ pull ${model} started`);
    res.json({ success: true, started: true, model });
});

// ── 🎵 MODELE MUZYCZNE (MiniMax-Music-3) — katalog suwerenny + realne pobieranie ──
// Wagi żyją w TeO_Music_V2/models/ (poza repo, 16+ GB). Layout 1:1 z Comfy-Org/
// MiniMax-Music-3, czyli też 1:1 z ComfyUI/models/ — jeden katalog, zero duplikatów.
// Dzięki temu moduł da się zminiaturyzować na otakos.wtf: kod leci lekki, wagi
// dociąga Suweren po pierwszej instalacji.
app.get('/api/music/models', async (req, res) => {
    try {
        res.json(await muzykaModeleStatus());
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/music/models/pull', (req, res) => {
    const { ids, id } = req.body ?? {};
    const lista = Array.isArray(ids) ? ids : (id ? [id] : []);
    if (!lista.length) {
        return res.status(400).json({
            success: false,
            message: 'Brak "ids" (tablica) ani "id".',
            dostepne: MUZYKA_MANIFEST.map(m => m.id),
        });
    }
    const nieznane = lista.filter(x => !muzykaModelPoId(x));
    if (nieznane.length) {
        return res.status(400).json({
            success: false,
            message: `Nieznane id: ${nieznane.join(', ')}`,
            dostepne: MUZYKA_MANIFEST.map(m => m.id),
        });
    }
    res.json(muzykaModelePull(lista));
});

app.post('/api/music/models/remove', async (req, res) => {
    const { id } = req.body ?? {};
    if (!id) return res.status(400).json({ success: false, message: 'Brak "id".' });
    try {
        res.json(await muzykaModeleUsun(id));
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 🎼 GENERACJA MUZYKI — realnie, przez ComfyUI, albo uczciwe "nie mogę" ─────
// ŻADNEJ SYMULACJI. Jeśli czegoś brakuje, endpoint zwraca 424 i mówi czego —
// nie udaje kroków dyfuzji.
//
// DLACZEGO przez ComfyUI, a nie własny pipeline: pliki wag mają w metadanych
// `comfy_model` (repack Comfy-Org) i są zapakowane pod natywne nody ComfyUI.
// Pisanie własnej inferencji DiT MiniMax-Music-3 to przepisywanie tego, co już
// istnieje — a katalog wag i tak zostaje suwerenny w TeO_Music_V2.
//
// DLACZEGO workflow z pliku, a nie zaszyty w kodzie: nazw nodów MiniMax nie
// wolno wymyślać. Suweren eksportuje workflow z ComfyUI (Workflow → Export API),
// wrzuca do _OtakOs_AI/workflows/minimax_music3.json, a most wstrzykuje parametry
// TYLKO w te wejścia, które w nim realnie istnieją.
const COMFY_BASE = process.env.OTAKOS_COMFY_HOST || 'http://127.0.0.1:8188';
const WORKFLOWS_DIR = path.join(AI_DIR, 'workflows');
const MUSIC_WORKFLOW = path.join(WORKFLOWS_DIR, 'minimax_music3.json');

// ── 🎛️ AUTOMAT COMFYUI ───────────────────────────────────────────────────────
// Katalog portable ComfyUI. Domyslnie dwa poziomy w gore od mostu:
// TeO_Genesis/.. -> ToO APP/.. -> TeO App HuB/ComfyUI_windows_portable_nvidia/...
const COMFY_DIR = process.env.OTAKOS_COMFY_DIR || path.resolve(
    process.cwd(), '..', '..', 'ComfyUI_windows_portable_nvidia', 'ComfyUI_windows_portable'
);

/** Zeby dwa rownolegle teleporty nie odpalily dwoch ComfyUI naraz. */
let comfyStartuje = null;

/** Krotkie sprawdzenie, czy ComfyUI odpowiada. */
async function comfyZyje(ms = 1500) {
    try {
        const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
        const r = await fetch(`${COMFY_BASE}/object_info`, { signal: c.signal });
        clearTimeout(t);
        return r.ok;
    } catch { return false; }
}

/**
 * Budzi ComfyUI, jesli spi. Nie czeka na pelen start — zwraca od razu,
 * bo teleport nie ma na co czekac, a panel i tak odpytuje /engine/status.
 */
async function zapewnijComfyUI(powod = 'żądanie') {
    if (await comfyZyje()) return { online: true, started: false };
    if (comfyStartuje) return comfyStartuje;

    comfyStartuje = (async () => {
        const python = path.join(COMFY_DIR, 'python_embeded', 'python.exe');
        const main = path.join(COMFY_DIR, 'ComfyUI', 'main.py');
        if (!fsSync.existsSync(python) || !fsSync.existsSync(main)) {
            console.warn(`[Automat-ComfyUI] ⚠️ Nie znajduję ComfyUI w ${COMFY_DIR} — ustaw OTAKOS_COMFY_DIR.`);
            return { online: false, started: false, message: `Brak ComfyUI w ${COMFY_DIR}` };
        }
        try {
            const child = spawn(python, ['-s', main, '--windows-standalone-build'], {
                cwd: COMFY_DIR,
                detached: true,
                stdio: 'ignore',
                // PYTHONUTF8: bez tego polski komunikat systemowy (np. ConnectionResetError
                // po polsku) wywala proces na UnicodeEncodeError przy wypisywaniu wlasnego
                // bledu. Wyglada jak losowa awaria, jest kwestia strony kodowej.
                env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
            });
            child.unref();
            console.log(`[Automat-ComfyUI] 🎛️ Budzę ComfyUI (${powod}) — PID ${child.pid}, ładowanie potrwa ~30 s.`);
            return { online: false, started: true, pid: child.pid, message: 'ComfyUI wstaje — pierwszy start trwa ~30 s.' };
        } catch (e) {
            console.warn(`[Automat-ComfyUI] ❌ Nie udało się uruchomić: ${e.message}`);
            return { online: false, started: false, message: e.message };
        } finally {
            // Odblokuj po chwili, zeby kolejna proba byla mozliwa gdyby start padl.
            setTimeout(() => { comfyStartuje = null; }, 45000);
        }
    })();
    return comfyStartuje;
}

/** Recznie: obudz ComfyUI i powiedz co sie stalo. */
app.post('/api/comfy/ensure', async (req, res) => {
    const wynik = await zapewnijComfyUI('ręczne żądanie');
    res.json({ success: true, katalog: COMFY_DIR, base: COMFY_BASE, ...wynik });
});

/** Czy ComfyUI żyje i czy zna nody MiniMax (czyli czy jest dość świeży). */
async function comfyStatus() {
    try {
        const c = new AbortController(); const t = setTimeout(() => c.abort(), 2500);
        const r = await fetch(`${COMFY_BASE}/object_info`, { signal: c.signal });
        clearTimeout(t);
        if (!r.ok) return { online: false, message: `ComfyUI odpowiedział HTTP ${r.status}` };
        const info = await r.json();
        const nody = Object.keys(info);
        const minimax = nody.filter(n => /minimax/i.test(n));
        return { online: true, nodeCount: nody.length, minimaxNodes: minimax, maMinimax: minimax.length > 0 };
    } catch (err) {
        return { online: false, message: `ComfyUI nieosiągalny na ${COMFY_BASE} (${err.message})` };
    }
}

/**
 * Rodziny modeli muzycznych — plik workflow i domyslne parametry kazdej.
 *
 * DLACZEGO DWIE: MiniMax-Music-3 ma faze autoregresywna (~25 krokow na sekunde
 * audio) i encoder 8.7 GB. Zmierzone na RTX 3060 Laptop 6GB / 15.7GB RAM:
 * 16.6 s/krok, 1501 krokow na 60s = ~6h50m, przy GPU na 0% (glod danych, model
 * streamowany z dysku). ACE-Step 1.5 turbo to czysta dyfuzja w 8 krokach —
 * ~190x mniej obliczen — i przyjmuje bpm/keyscale/language jako wejscia noda,
 * z obsluga 'pl' dla polskich tekstow.
 */
const RODZINY_MUZYKI = {
    ace: {
        workflow: 'acestep15.json',
        etykieta: 'ACE-Step 1.5 turbo',
        dit: 'ace-dit-turbo', enc: 'ace-clip-06b', enc2: 'ace-clip-17b', vae: 'ace-vae',
        steps: 8, cfg: 1.0, cfgScale: 2.0,
        uwaga: 'Czysta dyfuzja w 8 krokach, bez fazy autoregresywnej. Obsługuje polskie teksty (language=pl). Zestaw wag: 10,03 GB.',
    },
    minimax: {
        workflow: 'minimax_music3.json',
        etykieta: 'MiniMax-Music-3',
        dit: 'dit-int8', enc: 'text-encoder-pruned-int8', enc2: null, vae: 'dav',
        steps: 30, cfg: 1.7, cfgScale: 1.7,
        uwaga: 'UWAGA: faza autoregresywna ~25 kroków na sekundę audio. Zmierzone na 16 GB RAM: ~6h50m na minutę muzyki. Sensowne dopiero od ~32 GB RAM.',
    },
    // 🎤 YuE2 (2026-09-15): piosenki z wokalem z jednego checkpointa. Graf z oficjalnego
    // szablonu Comfy-Org (audio_yue2_text2music): KSampler 32 kroków, dpm_2/sgm_uniform,
    // cfg 1. Wymaga ComfyUI z węzłem YuE2GenerateMusic — sprawdzane przed startem.
    yue2: {
        workflow: 'yue2.json',
        etykieta: 'YuE2 3B',
        dit: 'yue2-3b-int8', enc: null, enc2: null, vae: null,
        steps: 32, cfg: 1.0, cfgScale: undefined,
        wezel: 'YuE2GenerateMusic',
        uwaga: 'Model językowy 3B generuje tokeny muzyki (faza autoregresywna) — czas na tej maszynie jeszcze niezmierzony. Styl po angielsku, tekst w [Verse]/[Chorus].',
    },
};

/**
 * Ustawienia muzyki Katedry — m.in. rodzina, którą Joanna bierze do MUZYKI FILMOWEJ.
 * Suweren (2026-09-15): „czy Joanna, jak tworzy muzykę filmową, ma na sztywno wpisany
 * model?" — miała (`rodzina: 'ace'` w kodzie). Teraz czyta stąd; zmiana z panelu.
 */
const PLIK_USTAWIEN_MUZYKI = path.join(ANTIGRAVITY_DIR, 'muzyka-ustawienia.json');
async function ustawieniaMuzyki() {
    try { return { rodzinaFilmowa: 'ace', ...JSON.parse(await fs.readFile(PLIK_USTAWIEN_MUZYKI, 'utf8')) }; } catch { return { rodzinaFilmowa: 'ace' }; }
}
app.get('/api/music/ustawienia', async (_req, res) => res.json({ success: true, ...(await ustawieniaMuzyki()), rodziny: Object.fromEntries(Object.entries(RODZINY_MUZYKI).map(([k, v]) => [k, { etykieta: v.etykieta, uwaga: v.uwaga }])) }));
app.post('/api/music/ustawienia', async (req, res) => {
    const { rodzinaFilmowa } = req.body ?? {};
    if (rodzinaFilmowa && !RODZINY_MUZYKI[rodzinaFilmowa]) return res.status(400).json({ success: false, message: `Nieznana rodzina „${rodzinaFilmowa}". Znane: ${Object.keys(RODZINY_MUZYKI).join(', ')}.` });
    const u = { ...(await ustawieniaMuzyki()), ...(rodzinaFilmowa ? { rodzinaFilmowa } : {}) };
    await fs.writeFile(PLIK_USTAWIEN_MUZYKI, JSON.stringify(u, null, 2), 'utf8');
    return res.json({ success: true, ...u });
});

// ── 🎛️ WARSZTAT WORKFLOW ────────────────────────────────────────────────────
// Do tej pory graf ComfyUI wybierał się SAM, po rodzinie modelu, a plik był
// zaszyty w RODZINY_MUZYKI. Suweren nie miał jak zobaczyć, co się właściwie
// uruchamia, ani dorzucić własnego grafu. Te trasy otwierają katalog na oścież
// — i pozwalają agentom Katedry pisać workflow, zamiast tylko o nich mówić.

/** Czy graf jest w formacie API (mapa node'ów), a nie UI (nodes[] + links[]). */
function czyGrafApi(wf) {
    if (!wf || typeof wf !== 'object' || Array.isArray(wf)) return false;
    if (Array.isArray(wf.nodes) || Array.isArray(wf.links)) return false;
    return Object.values(wf).some(n => n && typeof n === 'object' && typeof n.class_type === 'string');
}

/** Nazwa pliku bez wycieczek po dysku. `../../etc` nie przejdzie. */
function bezpiecznaNazwaWorkflow(nazwa) {
    const czysta = path.basename(String(nazwa || '')).replace(/[^\w.\-]/g, '');
    if (!czysta.endsWith('.json')) return null;
    if (czysta.startsWith('.')) return null;
    return czysta;
}

// ── 🔨 KUŹNIA MODELI ────────────────────────────────────────────────────────
// Wagi z _OtakOs_AI/models → rejestracja w Ollamie. Skan robi MOST, bo
// przeglądarka nie ma dostępu do dysku.

// ── 💬 HISTORIA CZATU ───────────────────────────────────────────────────────
// `_OtakOs_Wymiar/czaty.json` JEST bazą czatu operacyjnego — nie kopią zapasową.

// ── 🧩 PAMIĘĆ KODU ──────────────────────────────────────────────────────────
// codebase-memory-mcp (MIT) gdy binarium jest na miejscu; Graphify, gdy go nie ma.
// Odpowiedź ZAWSZE niesie nazwę silnika — żadnej cichej podmiany.

// ── 📱 MOST STADA — stan TeOgochi dla aplikacji zewnętrznej ─────────────────
// ⚠️ Odczyt WYMAGA tokenu ze sparowania. Ten most bywa wystawiony przez
// Kwantowy Tunel, więc trasa bez tokenu oddawałaby stan Katedry każdemu,
// kto zna adres.

/** Katedra publikuje migawkę stada — z przeglądarki, bez tokenu (localhost). */
// ── 🧪 TeO-SIM — pętla wnioskowania rozliczana w GRV ────────────────────────
// Zastępuje `ReasoningLoopSimulator` z _OtakOs_Wymiar/src, który był atrapą:
// nie wołał modelu i liczył wymyślone „tokeny" (10 albo 50).

// ── 🎬 WIDEO — prawdziwa generacja scen dla Story V2 ────────────────────────
// Zastępuje atrapę z GoogleWorkflowService. Odmawia z listą braków zamiast
// oddawać nazwę pliku, którego nie ma.

/**
 * Stan silnika, ale z BUDZENIEM.
 *
 * ⚠️ Suweren: „podczas pierwszej kreacji niech się włącza ComfyUI, tak jak
 * w przypadku music". Do tej pory każda trasa wideo mówiła tylko „ComfyUI nie
 * odpowiada" i zostawiała Suwerena z zadaniem, które MOST potrafi wykonać sam.
 *
 * Budzenie jest jednorazowe i nieblokujące: oddajemy stan od razu z informacją,
 * że silnik wstaje (~30 s), zamiast trzymać żądanie otwarte pół minuty.
 */
async function stanWideoZBudzeniem(powod = 'żądanie wideo') {
    const stan = await Wideo.stanWideo(COMFY_BASE);
    if (stan.comfy) return stan;
    const obudzony = await zapewnijComfyUI(powod);
    return {
        ...stan,
        budzenie: obudzony,
        braki: obudzony?.started
            ? ['ComfyUI właśnie wstaje (~30 s od startu). Spróbuj ponownie za chwilę.']
            : stan.braki,
    };
}

app.get('/api/wideo/stan', async (req, res) => {
    try {
        // `?obudz=0` dla podglądu, który tylko pyta i nie chce nic uruchamiać.
        const stan = req.query.obudz === '0'
            ? await Wideo.stanWideo(COMFY_BASE)
            : await stanWideoZBudzeniem('podgląd stanu');
        res.json({ success: true, ...stan });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

app.post('/api/wideo/generuj', async (req, res) => {
    const { prompt, szerokosc, wysokosc, klatek, kroki, ziarno } = req.body ?? {};
    // Pierwsza kreacja po starcie Katedry trafia na śpiące ComfyUI — budzimy je
    // tu, zamiast odsyłać Suwerena do ręcznego odpalania run_nvidia_gpu.bat.
    const przed = await stanWideoZBudzeniem('generowanie sceny');
    if (!przed.comfy) return res.status(424).json({ success: false, message: przed.braki.join(' | '), braki: przed.braki, budzenie: przed.budzenie });

    const r = await Wideo.generujScene({ comfyBase: COMFY_BASE, prompt, szerokosc, wysokosc, klatek, kroki, ziarno });
    if (!r.ok) return res.status(424).json({ success: false, message: r.powod, braki: r.braki ?? null });
    await Szyna.nadaj({ agent: 'Klatka', rodzaj: 'praca', tresc: `zlecila scene do ComfyUI (${r.model})` });
    res.json({ success: true, ...r });
});

/**
 * POST /api/wideo/do-projektu { projekt, plik, tytul? }
 *
 * Suweren: „wygenerowane sceny są zapisywane w confy, a nie OtakOS".
 * I miał rację — potok zwracał ścieżkę do wyjścia ComfyUI i na tym kończył.
 * Ta trasa PRZENOSI wynik do katalogu projektu w Katedrze, tak samo jak robi
 * to kolejka kadrów.
 *
 * ⚠️ KOPIUJEMY, NIE PRZENOSIMY. Wyjście ComfyUI bywa jeszcze potrzebne
 * (podgląd w jego własnym interfejsie), a kasowanie cudzych plików przy okazji
 * porządków to nie nasza rola.
 *
 * ⚠️ STRAŻ ŚCIEŻKI: bierzemy WYŁĄCZNIE pliki leżące pod katalogiem ComfyUI.
 * Panel bywa wystawiony przez Kwantowy Tunel na telefon; bez tego sprawdzenia
 * „plik" mógłby wskazać cokolwiek na dysku.
 */
app.post('/api/wideo/do-projektu', async (req, res) => {
    const { projekt = '', plik = '', tytul = '' } = req.body ?? {};
    try {
        if (!String(projekt).trim()) throw new Error('Bez nazwy projektu nie wiem, gdzie to zapisa\u0107.');
        if (!String(plik).trim()) throw new Error('Nie podano pliku do przeniesienia.');

        const zrodlo = path.resolve(String(plik));
        const korzen = path.resolve(COMFY_DIR);
        if (!zrodlo.toLowerCase().startsWith(korzen.toLowerCase())) {
            throw new Error('Ten plik nie le\u017cy w wyj\u015bciu ComfyUI \u2014 odmawiam kopiowania spoza niego.');
        }
        await fs.access(zrodlo);

        const katUjec = await KolejkaKadrow.katalogUjec(ANTIGRAVITY_DIR, projekt);
        const bezpiecznyTytul = String(tytul || path.basename(zrodlo, path.extname(zrodlo)))
            .replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40) || 'ujecie';
        const znacznik = Date.now().toString(36);
        const cel = path.join(katUjec, `${znacznik}_${bezpiecznyTytul}${path.extname(zrodlo)}`);

        await fs.copyFile(zrodlo, cel);
        const { size } = await fs.stat(cel);

        console.log(`[Wideo] ${path.basename(zrodlo)} \u2192 ${cel} (${size} B)`);
        return res.json({ success: true, sciezka: cel, katalog: katUjec, bajtow: size, zrodlo });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.get('/api/wideo/zlecenie/:id', async (req, res) => {
    // COMFY_DIR dokładamy, żeby front dostał ŚCIEŻKĘ, którą da się otworzyć,
    // a nie samą nazwę pliku ukrytego w podkatalogu wyjścia.
    const r = await Wideo.stanZlecenia(COMFY_BASE, req.params.id, COMFY_DIR);
    if (!r.ok) return res.status(500).json({ success: false, message: r.powod });
    res.json({ success: true, ...r });
});


// ══════════════════════════════════════════════════════════════════════════════
//  🎞️ CIĄG DALSZY — dopisywanie ujęć do włożonego filmu i sklejanie scen
//
//  Trzy czynności, każda osobno, żeby dało się przerwać po dowolnej:
//    · /filmy + /opis   — co mamy na warsztacie i w jakim jest formacie
//    · /dopisz          — nowe ujęcie startujące z OSTATNIEJ KLATKI tamtego
//    · /sklej           — ffmpeg łączy wybrane ujęcia w jeden plik
// ══════════════════════════════════════════════════════════════════════════════

app.get('/api/ciag/filmy', async (req, res) => {
    try {
        return res.json({
            success: true,
            filmy: await CiagDalszy.listaFilmow(COMFY_DIR),
            korzenie: CiagDalszy.korzenie(COMFY_DIR),
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/ciag/opis', async (req, res) => {
    try {
        return res.json({ success: true, opis: await CiagDalszy.opisFilmu(req.body?.plik, COMFY_DIR) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/ciag/dopisz { plik, prompt, klatek?, kroki?, ziarno? }
 *
 * ⚠️ FORMAT BIERZEMY Z FILMU, nie z pól formularza. Ujęcie dopisane w innej
 * rozdzielczości albo innym tempie widać w sklejce jako skok — a to dokładnie
 * ta wada, dla której ten moduł powstał.
 */
app.post('/api/ciag/dopisz', async (req, res) => {
    const { plik, prompt = '', klatek, kroki, ziarno } = req.body ?? {};
    try {
        const opis = await CiagDalszy.opisFilmu(plik, COMFY_DIR);
        const klatka = await CiagDalszy.ostatniaKlatka(plik, COMFY_DIR);

        const r = await Wideo.dopiszUjecie({
            comfyBase: COMFY_BASE, prompt, klatka: klatka.nazwa,
            szerokosc: opis.szerokosc, wysokosc: opis.wysokosc, fps: opis.fps,
            klatek, kroki, ziarno,
        });
        if (!r.ok) return res.status(400).json({ success: false, message: r.powod, braki: r.braki });

        console.log(`[Ciąg Dalszy] 🎞️ Dopisuję do „${opis.nazwa}" (${opis.szerokosc}x${opis.wysokosc}@${opis.fps}) — zlecenie ${r.zlecenie}`);
        return res.json({ success: true, ...r, zrodlo: opis, klatka: klatka.nazwa });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.post('/api/ciag/sklej', async (req, res) => {
    const { pliki, wyjscie, nazwa } = req.body ?? {};
    try {
        // Domyślnie kładziemy sklejkę obok ujęć, w wyjściu ComfyUI.
        const cel = wyjscie || path.join(
            COMFY_DIR, 'ComfyUI', 'output', 'katedra',
            `${String(nazwa || 'sklejka').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 60)}_${Date.now().toString(36)}.mp4`,
        );
        const w = await CiagDalszy.sklej({ pliki, wyjscie: cel, comfyDir: COMFY_DIR });
        console.log(`[Ciąg Dalszy] 🔗 Sklejka (${w.metoda}): ${w.plik}`);
        const oddech = await oddechZaPrace('wideo.sklejka', `sklejka:${path.basename(w.plik)}`,
            { nazwa: `Sklejka ${w.zrodla.length} ujęć`, sciezka: w.plik });
        return res.json({ success: true, ...w, oddech });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── SCENA ŁAŃCUCHOWA: opis → ujęcia → łańcuch → klaps ────────────────────────

/**
 * POST /api/ciag/rozpisz { opis, ile?, projekt? }
 * Model rozpisuje scenę na ujęcia. Sam nic nie liczy — oddaje listę do
 * przejrzenia, bo to Suweren decyduje, co idzie na taśmę.
 */
app.post('/api/ciag/rozpisz', async (req, res) => {
    const { opis = '', ile = 4, projekt = '', model } = req.body ?? {};
    if (String(opis).trim().length < 10) {
        return res.status(400).json({ success: false, message: 'Opisz scenę (min. 10 znaków).' });
    }
    try {
        // Kotwica: biblia projektu + kanon Reżysera. Bez niej postać rozjedzie się
        // już przy drugim ujęciu, bo model liczy każde osobno.
        let kotwica = '';
        if (projekt) {
            const [b, p] = await Promise.all([
                produkcjaBiblia(ANTIGRAVITY_DIR, projekt).catch(() => null),
                rezyserPamiec(ANTIGRAVITY_DIR, projekt).catch(() => null),
            ]);
            kotwica = [b?.tekst || '', (p?.fakty ?? []).map((f) => f.tresc).join('\n')]
                .filter(Boolean).join('\n\n');
        }

        const { system, prompt } = Sekwencja.promptRozpisania({ opis, kotwica, ile: Number(ile) || 4 });
        const silnik = model || process.env.OTAKOS_MODEL || DEFAULT_LLM;
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ model: silnik, system, prompt, stream: false }),
        });
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
        const d = await r.json();

        const ujecia = Sekwencja.odczytajUjecia(d.response, Number(ile) || 4);
        console.log(`[Sekwencja] 📝 ${silnik} rozpisał scenę na ${ujecia.length} ujęć.`);
        return res.json({
            success: true, model: silnik, kotwica: kotwica.length,
            ujecia: ujecia.map((u) => ({ ...u, prompt: Sekwencja.promptUjecia(u, kotwica) })),
        });
    } catch (e) {
        return res.status(502).json({ success: false, message: e.message });
    }
});

/** Poczekaj na plik z ComfyUI. `czyPrzerwane` pozwala wyjść z pętli na żądanie. */
/**
 * Czekanie na plik z ComfyUI — odporne na to, że silnik po drodze uśnie.
 *
 * ⚠️ POPRZEDNIA WERSJA WISIAŁA GODZINAMI. Termin 45 minut sprawdzał się MIĘDZY
 * zapytaniami, a zapytanie bez limitu czasu potrafiło nie wrócić nigdy: gdy
 * Windows uśpi proces, połączenie TCP zostaje otwarte i nikt nie odpowiada,
 * więc `await` nie wraca i warunek `Date.now() < DO_KIEDY` nie jest nawet
 * sprawdzany. W dzienniku Suwerena jedna pozycja zajęła 16 056 s — cztery
 * i pół godziny zamiast czterdziestu pięciu minut.
 *
 * Teraz każde zapytanie ma własny limit (`Wideo.pobierzZLimitem`), a tutaj
 * dochodzi BUDZENIE: gdy silnik milczy trzy razy z rzędu, budzimy go zamiast
 * czekać na trupa.
 */
async function czekajNaPlikWideo(zlecenie, czyPrzerwane) {
    const DO_KIEDY = Date.now() + 45 * 60 * 1000;
    let poMilczeniu = 0;

    while (Date.now() < DO_KIEDY) {
        if (czyPrzerwane?.()) return null;
        await new Promise((r) => setTimeout(r, 5000));

        let s;
        try {
            s = await Wideo.stanZlecenia(COMFY_BASE, zlecenie, COMFY_DIR);
            poMilczeniu = 0;
        } catch (e) {
            // ⚠️ JEDNO MILCZENIE TO NIE KONIEC ŚWIATA — zdarza się przy ładowaniu
            // modelu. Dopiero seria oznacza, że silnik usnął.
            poMilczeniu += 1;
            if (poMilczeniu >= 3) {
                console.warn(`[Kolejka] ComfyUI milczy ${poMilczeniu} raz — budzę go (${e.message}).`);
                await zapewnijComfyUI('silnik przestał odpowiadać w trakcie liczenia').catch(() => null);
                // ⚠️ Po przebudzeniu ComfyUI NIE PAMIĘTA zlecenia — jego kolejka
                // żyje w pamięci procesu i ginie razem z nim. Mówimy to wprost,
                // zamiast czekać do końca terminu na wynik, który nie powstanie.
                throw new Error('ComfyUI usnął w trakcie liczenia i został obudzony — to ujęcie trzeba policzyć od nowa.');
            }
            continue;
        }

        if (s.ok && s.blad) throw new Error(`ComfyUI: ${JSON.stringify(s.blad).slice(0, 200)}`);
        if (s.ok && s.gotowe && s.materialy?.length) return s.materialy[0].sciezka;
    }
    throw new Error('45 minut bez pliku — silnik nie oddał wyniku.');
}

/** POST /api/ciag/scena — odpal łańcuch ujęć. Zwraca id od razu, praca leci w tle. */
app.post('/api/ciag/scena', async (req, res) => {
    const { ujecia = [], filmStartowy = null, dolaczZrodlo = false, opisSceny = '', klatek, kroki } = req.body ?? {};
    if (!Array.isArray(ujecia) || !ujecia.length) {
        return res.status(400).json({ success: false, message: 'Brak ujęć do nakręcenia.' });
    }
    if (ujecia.length > Sekwencja.MAX_UJEC) {
        return res.status(400).json({ success: false, message: `Za dużo ujęć (max ${Sekwencja.MAX_UJEC}) — dłuższy łańcuch i tak rozjedzie postać.` });
    }
    try {
        // Budzimy silnik, zamiast tylko meldowac, ze spi — patrz stanWideoZBudzeniem.
        const stan = await stanWideoZBudzeniem('lancuch/kamery');
        if (!stan.gotowe) return res.status(400).json({ success: false, message: stan.braki.join(' | '), braki: stan.braki, budzenie: stan.budzenie });
        if (filmStartowy) CiagDalszy.bezpieczna(filmStartowy, COMFY_DIR);

        const id = Sekwencja.odpal({
            opisSceny,
            ujecia: ujecia.map((u, i) => ({ nr: i + 1, prompt: String(u.prompt || u.opis || '').trim() })),
            filmStartowy, dolaczZrodlo,

            generujZTekstu: ({ prompt }) => Wideo.generujScene({ comfyBase: COMFY_BASE, prompt, klatek, kroki }),

            dopiszDoFilmu: async ({ plik, prompt }) => {
                const opis = await CiagDalszy.opisFilmu(plik, COMFY_DIR);
                const klatka = await CiagDalszy.ostatniaKlatka(plik, COMFY_DIR);
                return Wideo.dopiszUjecie({
                    comfyBase: COMFY_BASE, prompt, klatka: klatka.nazwa,
                    szerokosc: opis.szerokosc, wysokosc: opis.wysokosc, fps: opis.fps, klatek, kroki,
                });
            },

            czekajNaPlik: czekajNaPlikWideo,

            sklej: async (pliki, nazwa) => CiagDalszy.sklej({
                pliki,
                wyjscie: path.join(COMFY_DIR, 'ComfyUI', 'output', 'katedra', `${nazwa}.mp4`),
                comfyDir: COMFY_DIR,
            }),
        });

        console.log(`[Sekwencja] 🎬 Scena ${id}: ${ujecia.length} ujęć${filmStartowy ? ` od „${path.basename(filmStartowy)}"` : ' od tekstu'}.`);
        return res.json({ success: true, id, ...Sekwencja.stanZadania(id) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/ciag/kamery
 *   { plik, kamery: [{ nazwa?, odSekundy?, ruch?, ruchId?, opis? }], projekt?, sklejaj?, klatek?, kroki? }
 *
 * POKRYCIE TEGO SAMEGO MOMENTU z kilku kamer. Każda kamera startuje od
 * WSKAZANEJ SEKUNDY materiału głównego — nie od poprzedniej kamery.
 *
 * ⚠️ To nie jest druga kamera stojąca obok planu. Model dostaje klatkę
 * z materiału głównego, więc nowe ujęcie ZACZYNA się tym samym kadrem
 * i dopiero ruch kamery odsuwa je w inną perspektywę. Ruchy zdecydowane
 * (obrót, przeciwujęcie) dają różnicę; subtelne dadzą prawie to samo ujęcie.
 */
app.post('/api/ciag/kamery', async (req, res) => {
    const { plik, kamery = [], projekt = '', sklejaj = false, klatek, kroki } = req.body ?? {};
    if (!plik) return res.status(400).json({ success: false, message: 'Brak materiału głównego.' });
    if (!Array.isArray(kamery) || !kamery.length) {
        return res.status(400).json({ success: false, message: 'Nie podano żadnej kamery.' });
    }
    if (kamery.length > Sekwencja.MAX_UJEC) {
        return res.status(400).json({ success: false, message: `Za dużo kamer (max ${Sekwencja.MAX_UJEC}).` });
    }
    try {
        // Budzimy silnik, zamiast tylko meldowac, ze spi — patrz stanWideoZBudzeniem.
        const stan = await stanWideoZBudzeniem('lancuch/kamery');
        if (!stan.gotowe) return res.status(400).json({ success: false, message: stan.braki.join(' | '), braki: stan.braki, budzenie: stan.budzenie });

        const glowny = await CiagDalszy.opisFilmu(plik, COMFY_DIR);

        // Kotwica jak przy scenie — bez niej postać rozjedzie się między kamerami.
        let kotwica = '';
        if (projekt) {
            const [b, p2] = await Promise.all([
                produkcjaBiblia(ANTIGRAVITY_DIR, projekt).catch(() => null),
                rezyserPamiec(ANTIGRAVITY_DIR, projekt).catch(() => null),
            ]);
            kotwica = [b?.tekst || '', (p2?.fakty ?? []).map((f) => f.tresc).join('\n')].filter(Boolean).join('\n\n');
        }

        const ujecia = kamery.map((k, i) => {
            const preset = Sekwencja.RUCHY_KAMERY.find((r) => r.id === k.ruchId);
            return {
                nr: i + 1,
                nazwa: String(k.nazwa || preset?.nazwa || `Kamera ${i + 2}`).slice(0, 40),
                // Sekundę przycina i tak `klatkaZCzasu`, ale zapisujemy, co przyszło.
                odSekundy: Number.isFinite(Number(k.odSekundy)) ? Number(k.odSekundy) : 0,
                prompt: Sekwencja.promptKamery({
                    ruch: k.ruch || preset?.opis || '',
                    opis: k.opis || '',
                    kotwica,
                }),
            };
        });

        const id = Sekwencja.odpal({
            tryb: 'kamery',
            sklejaj: !!sklejaj,
            opisSceny: `Pokrycie „${glowny.nazwa}" z ${ujecia.length} kamer`,
            ujecia,
            filmStartowy: glowny.sciezka,
            dolaczZrodlo: false,

            generujZTekstu: ({ prompt }) => Wideo.generujScene({ comfyBase: COMFY_BASE, prompt, klatek, kroki }),

            dopiszDoFilmu: async ({ plik: p2, prompt, odSekundy }) => {
                // ⚠️ Klatka z PODANEJ sekundy, nie z końca — na tym polega pokrycie.
                const kl = await CiagDalszy.klatkaZCzasu(p2, odSekundy ?? 0, COMFY_DIR);
                return Wideo.dopiszUjecie({
                    comfyBase: COMFY_BASE, prompt, klatka: kl.nazwa,
                    szerokosc: kl.zrodlo.szerokosc, wysokosc: kl.zrodlo.wysokosc, fps: kl.zrodlo.fps,
                    klatek, kroki,
                });
            },

            czekajNaPlik: czekajNaPlikWideo,

            sklej: async (pliki, nazwa) => CiagDalszy.sklej({
                pliki,
                wyjscie: path.join(COMFY_DIR, 'ComfyUI', 'output', 'katedra', `${nazwa}.mp4`),
                comfyDir: COMFY_DIR,
            }),
        });

        console.log(`[Kamery] 🎥 ${ujecia.length} kamer do „${glowny.nazwa}" (${glowny.sekundy}s) — zadanie ${id}.`);
        return res.json({ success: true, id, glowny, ...Sekwencja.stanZadania(id) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── 🧊 BLENDER: sceny cyfrowe z kadrów ──────────────────────────────────────

app.get('/api/blender/stan', async (req, res) => {
    try { return res.json({ success: true, ...(await Blender.stanBlendera()), katalog: Blender.KATALOG() }); }
    catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

/**
 * POST /api/blender/scenariusz { projekt, kadry[], nazwa? }
 * Zapisuje PRAWDZIWY skrypt .py — użyteczny nawet bez zainstalowanego Blendera,
 * bo można go otworzyć na dowolnej maszynie.
 */
app.post('/api/blender/scenariusz', async (req, res) => {
    try {
        const w = await Blender.zbudujScenariusz(req.body ?? {});
        console.log(`[Blender] 🧊 Scenariusz na ${w.kadrow} kadrów: ${w.skrypt}`);
        return res.json({ success: true, ...w, blender: await Blender.stanBlendera() });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.post('/api/blender/uruchom', async (req, res) => {
    try { return res.json({ success: true, ...(await Blender.uruchom(String(req.body?.skrypt || ''))) }); }
    catch (e) { return res.status(424).json({ success: false, message: e.message }); }
});

// ── 🌌 UNIWERSUM („Blender Blendera") ───────────────────────────────────────

// ── WIRTUALNE STUDIO, KAMERZYSTA I SCENOGRAFIE DLA TGS ──────────────────────


// ══════════════════════════════════════════════════════════════════════════════

// ════════════════════════════════════════
// ════════════════════════════════════════
//  🎚️ MONTAŻOWNIA — sklej gotowe filmy i podłóż pod nie dźwięk
//
//  Suweren: „z wczorajszej generacji mam 5 filmów, które potrzebuję skleic
//  i podłożyć dźwięk — a w zasadzie nie mam gdzie". Kolejka kadrów skleja
//  UJĘCIA jednego przebiegu, Ciąg Dalszy dopisuje ujęcie — ale nie było miejsca,
//  gdzie bierze się kilka GOTOWYCH filmów i kładzie pod nie muzykę.
//
//  ⚠️ Sklejanie robi sprawdzony `CiagDalszy.sklej`, nie druga implementacja obok.
// ════════════════════════════════════════

/** Co w projekcie da się zmontować + czym podłożyć dźwięk. */
app.get('/api/montazownia/materialy', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '').trim();
        if (!projekt) throw new Error('Podaj projekt.');
        const minSekund = Number(req.query.minSekund) || 3;

        const [filmy, muzyka] = await Promise.all([
            Montazownia.materialy(ANTIGRAVITY_DIR, projekt, { minSekund }),
            Montazownia.utwory(MUSIC_DIR),
        ]);
        return res.json({
            success: true, projekt, filmy, muzyka,
            katalog: await Montazownia.katalogMontazy(ANTIGRAVITY_DIR, projekt),
        });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/montazownia/zloz { projekt, pliki[], muzyka?, glosnosc?, zanikanie?, nazwa? }
 *
 * ⚠️ KOLEJNOŚĆ `pliki` JEST ŚWIĘTA — to jest montaż, więc bierzemy dokładnie
 * to, co Suweren ułożył, bez sortowania „po swojemu".
 *
 * ⚠️ STRAŻ ŚCIEŻKI: sklejamy WYŁĄCZNIE pliki z katalogu tego projektu. Panel
 * bywa wystawiony przez Kwantowy Tunel na telefon.
 */
app.post('/api/montazownia/zloz', async (req, res) => {
    const { projekt = '', pliki = [], muzyka = null, glosnosc, zanikanie, nazwa = 'montaz' } = req.body ?? {};
    try {
        if (!String(projekt).trim()) throw new Error('Podaj projekt.');
        if (!Array.isArray(pliki) || !pliki.length) throw new Error('Nie wskaza\u0142e\u015b \u017cadnego filmu.');

        const dozwolone = new Set((await Montazownia.materialy(ANTIGRAVITY_DIR, projekt, { minSekund: 0 })).map((m) => path.resolve(m.sciezka).toLowerCase()));
        for (const f of pliki) {
            if (!dozwolone.has(path.resolve(f).toLowerCase())) {
                throw new Error(`Plik spoza projektu „${projekt}": ${path.basename(f)}`);
            }
        }
        const katalog = await Montazownia.katalogMontazy(ANTIGRAVITY_DIR, projekt);

        /**
         * \u26a0\ufe0f DWA PRAWOWITE KORZENIE MUZYKI, NIE JEDEN.
         *
         * Stra\u017cnik przepuszcza\u0142 wy\u0142\u0105cznie bibliotek\u0119 Katedry \u2014 a Joanna zapisuje
         * skomponowany podk\u0142ad do katalogu monta\u017cu TEGO projektu
         * (\u2026/produkcje/<projekt>/montaz/muzyka__film_*.flac). Efekt: u\u017cytkownik
         * klika\u0142 SKOMPONUJ, dostawa\u0142 \u201eJoanna sko\u0144czy\u0142a", a zaraz potem
         * \u201eUtw\u00f3r spoza biblioteki muzyki Katedry" i monta\u017c nie rusza\u0142.
         * Muzyka wykuta dla filmu by\u0142a odrzucana jako obca.
         *
         * \u26a0\ufe0f Por\u00f3wnanie z separatorem, nie samym prefiksem. Poprzednia wersja
         * u\u017cywa\u0142a go\u0142ego startsWith, wi\u0119c katalog \u201e\u2026\Muzyka-obca" przechodzi\u0142
         * jako \u201e\u2026\Muzyka\u201d. Stra\u017cnik trasy wystawionej przez Kwantowy Tunel na
         * telefon nie mo\u017ce mie\u0107 takiej dziury.
         */
        if (muzyka) {
            const cel = path.resolve(muzyka).toLowerCase();
            const korzenie = [path.resolve(MUSIC_DIR), path.resolve(katalog)]
                .map((k) => k.toLowerCase().replace(/[\\/]+$/, ''));
            const wolno = korzenie.some((k) => cel === k || cel.startsWith(k + path.sep));
            if (!wolno) {
                throw new Error(
                    'Utw\u00f3r spoza biblioteki muzyki Katedry i spoza katalogu monta\u017cu projektu.',
                );
            }
            await fs.access(muzyka);
        }
        const r = await Montazownia.zloz({
            pliki, muzyka, glosnosc, zanikanie, katalog, nazwa,
            sklejaczem: CiagDalszy.sklej, comfyDir: COMFY_DIR,
        });

        // \u26a0\ufe0f OSTATNIE OGNIWO POTOKU. Suweren: \u201ete kafelki wideo na monta\u017c, gdzie
        // mo\u017cna je zamienia\u0107 kolejno\u015bci\u0105, i wtedy gotowe". Dot\u0105d sklejka powstawa\u0142a,
        // ale karty zostawa\u0142y na MONTA\u017bU \u2014 tablica nigdy nie pokazywa\u0142a, \u017ce co\u015b
        // jest domkni\u0119te, a kolumna GOTOWE sta\u0142a pusta na zawsze.
        //
        // Kart\u0119 rozpoznajemy po `zwrot`, bo to w nim le\u017cy \u015bcie\u017cka pliku, kt\u00f3ry
        // z niej powsta\u0142. Pliki bez karty (np. wgrane r\u0119cznie) pomijamy \u2014 sklejka
        // jest wa\u017cniejsza ni\u017c porz\u0105dek w tablicy.
        const domkniete = [];
        try {
            const karty = await produkcjaLista(ANTIGRAVITY_DIR, projekt);
            const uzyte = new Set(pliki.map((f) => path.resolve(f).toLowerCase()));
            for (const k of karty) {
                if (k.etap === 'GOTOWE') continue;
                const m = String(k.zwrot || '').match(/[^\n|"]+\.(mp4|webm|mov|mkv)/i);
                if (!m || !uzyte.has(path.resolve(m[0].trim()).toLowerCase())) continue;
                await produkcjaZmien(ANTIGRAVITY_DIR, k.id, { etap: 'GOTOWE' });
                domkniete.push(k.tytul);
            }
        } catch (e) {
            // Nieudane domkni\u0119cie NIE mo\u017ce uniewa\u017cni\u0107 gotowej sklejki.
            console.warn(`[Monta\u017c] sklejka gotowa, ale nie domkn\u0105\u0142em kart: ${e.message}`);
        }

        console.log(`[Monta\u017c] ${pliki.length} film\u00f3w \u2192 ${r.plik}${r.dzwiek ? ` (+ ${r.dzwiek})` : ''}`);
        if (domkniete.length) console.log(`[Monta\u017c] \u2192 GOTOWE: ${domkniete.join(', ')}`);
        return res.json({ success: true, ...r, zlozonych: pliki.length, domkniete });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── JOANNA KOMPONUJE POD DŁUGOŚĆ FILMU ──────────────────────────────────────
//
// Suweren: „trzeba dać możliwość, by TeOgochi od muzyki (Joanna) mógł
// skomponować cały utwór do całej długości materiału video".
//
// Dotąd montażownia podkładała GOTOWY utwór i zapętlała go, gdy był krótszy.
// Zapętlenie słychać. Tu Joanna pisze brief brzmienia, silnik liczy tyle
// segmentów, ile trzeba, a my sklejamy je przenikaniem i przycinamy CO DO
// SEKUNDY do długości filmu.

const zadaniaMuzyki = new Map();

/** Czekanie na PLIK AUDIO z ComfyUI. Ta sama zasada co przy wideo: limit na każdym pytaniu. */
async function czekajNaAudio(promptId, limitMinut = 40) {
    const DO_KIEDY = Date.now() + limitMinut * 60 * 1000;
    let milczenia = 0;

    while (Date.now() < DO_KIEDY) {
        await new Promise((r) => setTimeout(r, 5000));
        let wpis;
        try {
            const r = await Wideo.pobierzZLimitem(`${COMFY_BASE}/history/${encodeURIComponent(promptId)}`, {}, 20000);
            if (!r.ok) throw new Error(`ComfyUI HTTP ${r.status}`);
            wpis = (await r.json())?.[promptId];
            milczenia = 0;
        } catch (e) {
            milczenia += 1;
            if (milczenia >= 3) throw new Error(`ComfyUI przestał odpowiadać przy komponowaniu: ${e.message}`);
            continue;
        }
        if (!wpis) continue;

        const blad = wpis.status?.messages?.find((m) => m[0] === 'execution_error');
        if (blad) throw new Error(`ComfyUI: ${JSON.stringify(blad[1]).slice(0, 200)}`);

        for (const out of Object.values(wpis.outputs ?? {})) {
            // Audio bywa pod „audio", ale różne nody wystawiają je też jako „gifs".
            for (const klucz of ['audio', 'gifs', 'videos']) {
                const p0 = out?.[klucz]?.[0];
                if (p0?.filename) {
                    return path.join(COMFY_DIR, 'ComfyUI', 'output', p0.subfolder ?? '', p0.filename);
                }
            }
        }
    }
    throw new Error(`${limitMinut} minut bez pliku — silnik muzyki nie oddał wyniku.`);
}

/**
 * POST /api/montazownia/skomponuj { projekt, film, wyciszenie?, model? }
 *
 * ⚠️ SILNIKIEM JEST ACE-STEP. MiniMax na tej maszynie liczy ~7 h na minutę
 * muzyki — ścieżka do pięciominutowego filmu szłaby ponad dobę.
 */
app.post('/api/montazownia/skomponuj', async (req, res) => {
    const { projekt = '', film = '', wyciszenie = 3, model, rodzina: rodzinaZadana } = req.body ?? {};
    // Rodzina silnika muzycznego: z żądania → z ustawień (panel) → 'ace'. Dotąd była na sztywno.
    const rodzinaFilmowa = RODZINY_MUZYKI[rodzinaZadana] ? rodzinaZadana : (await ustawieniaMuzyki()).rodzinaFilmowa;
    try {
        if (!String(projekt).trim()) throw new Error('Podaj projekt.');

        // Straż ścieżki — ten sam warunek co przy sklejaniu.
        const dozwolone = new Set((await Montazownia.materialy(ANTIGRAVITY_DIR, projekt, { minSekund: 0 })).map((m) => path.resolve(m.sciezka).toLowerCase()));
        if (!dozwolone.has(path.resolve(film).toLowerCase())) throw new Error('Film spoza tego projektu.');

        const opis = await Montazownia.opisz(film);
        const sekundy = opis.sekundy;
        if (!sekundy) throw new Error(`Nie umiem odczytać długości „${path.basename(film)}".`);

        // 1. JOANNA PISZE BRIEF. Kanon projektu jest kotwicą, żeby muzyka nie
        //    rozjechała się ze światem, który już istnieje.
        const pamiecProjektu = await rezyserPamiec(ANTIGRAVITY_DIR, projekt).catch(() => null);
        const kanon = (pamiecProjektu?.fakty ?? []).map((f) => f.tresc).join('\n');
        // Joanna jest importowana nazwanie (joannaPamiec / joannaKontekst),
        // nie jako moduł — wołamy dokładnie te symbole, które istnieją.
        const kontekstJoanny = await joannaPamiec(ANTIGRAVITY_DIR)
            .then((d) => joannaKontekst(d))
            .catch(() => '');

        const { system, prompt } = MuzykaDoFilmu.promptKompozycji({
            film, projekt, kanon, sekundy, kontekstJoanny: String(kontekstJoanny || ''),
        });
        const { tekst, silnik } = await piszModelem(model, system, prompt);
        const brief = MuzykaDoFilmu.odczytajBrief(tekst);

        // 2. PLAN SEGMENTÓW.
        const plan = MuzykaDoFilmu.planSegmentow(sekundy);

        const id = `muz-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
        const z = {
            id, stan: 'liczy', projekt, film: path.basename(film),
            sekundy, brief, model: silnik, rodzina: rodzinaFilmowa, start: Date.now(), blad: null, plik: null,
            segmenty: Array.from({ length: plan.ile }, (_, i) => ({
                nr: i + 1, dlugosc: plan.dlugosc, stan: 'czeka', plik: null, sekundyPracy: null,
            })),
        };
        zadaniaMuzyki.set(id, z);

        (async () => {
            const gotowe = [];
            for (const seg of z.segmenty) {
                if (z.przerwane) { seg.stan = 'pominiete'; continue; }
                const t0 = Date.now();
                seg.stan = 'liczy';
                try {
                    // Wołamy własną, sprawdzoną trasę generacji — zamiast drugiej
                    // implementacji obok. Tagi od Joanny, długość z planu.
                    const odp = await fetch(`http://127.0.0.1:${PORT}/api/music/generate`, {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            prompt: brief.tagi + (brief.unikaj ? `. avoid: ${brief.unikaj}` : ''),
                            duration: seg.dlugosc,
                            rodzina: rodzinaFilmowa,
                        }),
                    });
                    const d = await odp.json();
                    if (!d.success) throw new Error(d.message || 'Silnik muzyki odmówił.');

                    seg.plik = await czekajNaAudio(d.promptId);
                    gotowe.push(seg.plik);
                    seg.stan = 'gotowe';
                } catch (e) {
                    seg.stan = 'blad';
                    seg.powod = e.message;
                } finally {
                    seg.sekundyPracy = Math.round((Date.now() - t0) / 1000);
                }
            }

            if (!gotowe.length) {
                z.stan = 'blad';
                z.blad = 'Żaden segment się nie policzył — powody przy segmentach.';
                return;
            }

            try {
                const katalog = await Montazownia.katalogMontazy(ANTIGRAVITY_DIR, projekt);
                const cel = path.join(katalog, `muzyka_${path.basename(film, path.extname(film))}_${Date.now().toString(36)}.flac`);
                const w = await MuzykaDoFilmu.zloz({ segmenty: gotowe, sekundy, wyjscie: cel, wyciszenie });
                z.plik = w.plik;
                z.stan = 'gotowe';
                console.log(`[Joanna] 🎼 Ścieżka na ${Math.round(sekundy)} s z ${w.segmentow} segmentów → ${w.plik}`);
                await Szyna.nadaj({ agent: 'Joanna', rodzaj: 'praca', tresc: `skomponowała ścieżkę na ${Math.round(sekundy)} s do ${path.basename(film)}` }).catch(() => null);
            } catch (e) {
                z.stan = 'blad';
                z.blad = `Segmenty są, ale nie dało się ich złożyć: ${e.message}`;
            }
        })().catch((e) => { z.stan = 'blad'; z.blad = e.message; });

        return res.json({
            success: true, id, sekundy, brief, model: silnik,
            segmentow: plan.ile, dlugoscSegmentu: plan.dlugosc,
        });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.get('/api/montazownia/skomponuj/:id', (req, res) => {
    const z = zadaniaMuzyki.get(req.params.id);
    if (!z) return res.status(404).json({ success: false, message: 'Nie znam tego zadania — most mógł się zrestartować.' });
    return res.json({
        success: true, id: z.id, stan: z.stan, film: z.film, sekundy: z.sekundy,
        brief: z.brief, model: z.model, plik: z.plik, blad: z.blad,
        sekundOd: Math.round((Date.now() - z.start) / 1000),
        segmenty: z.segmenty,
    });
});

app.post('/api/montazownia/skomponuj/:id/przerwij', (req, res) => {
    const z = zadaniaMuzyki.get(req.params.id);
    if (!z) return res.status(404).json({ success: false, message: 'Nie znam tego zadania.' });
    if (z.stan === 'liczy') { z.przerwane = true; z.stan = 'przerwane'; }
    return res.json({ success: true, stan: z.stan });
});

/** Sam dźwięk pod gotowy film — gdy sklejone już jest, brakuje tylko muzyki. */
app.post('/api/montazownia/dzwiek', async (req, res) => {
    const { projekt = '', film = '', muzyka = '', glosnosc, zanikanie } = req.body ?? {};
    try {
        const dozwolone = new Set((await Montazownia.materialy(ANTIGRAVITY_DIR, projekt, { minSekund: 0 })).map((m) => path.resolve(m.sciezka).toLowerCase()));
        if (!dozwolone.has(path.resolve(film).toLowerCase())) throw new Error('Film spoza tego projektu.');
        const korzen = path.resolve(MUSIC_DIR);
        if (!path.resolve(muzyka).toLowerCase().startsWith(korzen.toLowerCase())) throw new Error('Utw\u00f3r spoza biblioteki muzyki.');

        const katalog = await Montazownia.katalogMontazy(ANTIGRAVITY_DIR, projekt);
        const wyjscie = path.join(katalog, `${path.basename(film, path.extname(film))}_dzwiek_${Date.now().toString(36)}.mp4`);
        const r = await Montazownia.podlozDzwiek({ film, muzyka, wyjscie, glosnosc, zanikanie });
        return res.json({ success: true, ...r });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

//  🗣️ GŁOS STUDIO — spięcie z VoiceStudio (klonowanie i synteza głosu)
//
//  Suweren pytał, czy głosy da się wytworzyć wskazanymi repo. OpenWhispr robi
//  kierunek ODWROTNY (mowa → tekst). VoiceStudio robi to, czego brakuje.
//
//  ⚠️ VoiceStudio zostaje OSOBNYM PROGRAMEM (licencja AGPL-3.0). Rozmawiamy
//  z nim po HTTP, tak jak z ComfyUI — jego kodu w tym repo nie ma i nie będzie.
// ════════════════════════════════════════

app.get('/api/glos-studio/stan', async (req, res) => {
    try {
        return res.json({ success: true, ...(await GlosStudio.stan()) });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/glos-studio/mow { projekt, id, tekst, glos, format? }
 *
 * Wypowiada tekst i zapisuje nagranie W KATALOGU ASSETU — z tego samego powodu,
 * dla którego ujęcia nie zostają w ComfyUI. Ścieżka trafia do referencji assetu,
 * więc następnym razem widać ją w bibliotece.
 */
app.post('/api/glos-studio/mow', async (req, res) => {
    const { projekt = '', id = '', tekst = '', glos = '', format = 'wav' } = req.body ?? {};
    try {
        if (!String(projekt).trim()) throw new Error('Podaj projekt.');
        const asset = await Assety.jeden(ANTIGRAVITY_DIR, projekt, id);
        if (asset.typ !== 'glos') throw new Error(`Asset „${asset.nazwa}" nie jest głosem (jest: ${asset.typ}).`);

        const katAssetow = await Assety.katalog(ANTIGRAVITY_DIR, projekt);
        const katalogDocelowy = path.join(katAssetow, 'glos', slugProjektu(asset.nazwa));

        const r = await GlosStudio.mow({ tekst, glos, format, katalogDocelowy, nazwa: 'wypowiedz' });

        // Zapamietujemy, KTORYM glosem to powiedziano — bez tego nagranie jest
        // anonimowe i za tydzien nikt nie wie, czym je powtorzyc.
        const zapisany = await Assety.zapisz(ANTIGRAVITY_DIR, projekt, {
            id: asset.id, typ: 'glos', nazwa: asset.nazwa,
            referencje: { wypowiedz: r.sciezka },
            utwor: glos,
        });

        console.log(`[GłosStudio] ${asset.nazwa}: ${r.znakow} znaków głosem ${glos} → ${r.sciezka}`);
        return res.json({ success: true, ...r, asset: zapisany });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/** Transkrypcja próbki wgranej do assetu — co na niej właściwie padło. */
app.post('/api/glos-studio/przepisz', async (req, res) => {
    const { projekt = '', id = '' } = req.body ?? {};
    try {
        const asset = await Assety.jeden(ANTIGRAVITY_DIR, projekt, id);
        const probka = asset.referencje?.probka;
        if (!probka) throw new Error(`Asset „${asset.nazwa}" nie ma wgranej próbki głosu.`);
        return res.json({ success: true, ...(await GlosStudio.przepisz(probka)) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  ✒️ RĘKOPIS — moduł pisania opowieści
//
//  Suweren: „Story V2 musi mieć też moduł pisania opowieści". Wzorzec z repo
//  hughhowey/neo (MIT) — pomysły, nie kod: rozdział to osobny plik, Enter/Enter/
//  Enter, wycięte fragmenty wracają tam, skąd wyszły, znaczniki zamiast przerw
//  w pisaniu.
//
//  ⚠️ Rękopis należy do PROJEKTU, tak jak assety.
// ══════════════════════════════════════════════════════════════════════════════

function wymagajProjektu(q) {
    const p = String(q || '').trim();
    if (!p) throw new Error('Podaj projekt — rękopis należy do projektu, nie do Katedry.');
    return p;
}

app.get('/api/rekopis', async (req, res) => {
    try {
        const projekt = wymagajProjektu(req.query.projekt);
        return res.json({ success: true, rekopis: await Rekopis.wczytaj(ANTIGRAVITY_DIR, projekt) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.patch('/api/rekopis', async (req, res) => {
    const { projekt = '', ...zmiany } = req.body ?? {};
    try {
        return res.json({ success: true, meta: await Rekopis.zmienMeta(ANTIGRAVITY_DIR, wymagajProjektu(projekt), zmiany) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.post('/api/rekopis/rozdzial', async (req, res) => {
    const { projekt = '', tytul = '', poId = null, tresc = '' } = req.body ?? {};
    try {
        const r = await Rekopis.dodajRozdzial(ANTIGRAVITY_DIR, wymagajProjektu(projekt), { tytul, poId, tresc });
        return res.json({ success: true, rozdzial: r });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/** Zapis treści rozdziału. Front woła to z opóźnieniem — nie po każdym znaku. */
app.put('/api/rekopis/rozdzial/:id', async (req, res) => {
    const { projekt = '', tresc = '' } = req.body ?? {};
    try {
        return res.json({ success: true, ...(await Rekopis.zapiszTresc(ANTIGRAVITY_DIR, wymagajProjektu(projekt), req.params.id, tresc)) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.patch('/api/rekopis/rozdzial/:id', async (req, res) => {
    const { projekt = '', tytul = '' } = req.body ?? {};
    try {
        return res.json({ success: true, ...(await Rekopis.zmienTytulRozdzialu(ANTIGRAVITY_DIR, wymagajProjektu(projekt), req.params.id, tytul)) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/rekopis/rozdzial/:id', async (req, res) => {
    try {
        const projekt = wymagajProjektu(req.query.projekt);
        const r = await Rekopis.usunRozdzial(ANTIGRAVITY_DIR, projekt, req.params.id);
        return res.json({
            success: true, ...r,
            // Mowimy WPROST, ze tresc nie zginela — inaczej skasowanie rozdzialu
            // wyglada jak strata dnia pisania.
            uwaga: r.zachowanychSlow ? `Treść (${r.zachowanychSlow} słów) leży w wyciętych — da się ją odzyskać.` : null,
        });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.post('/api/rekopis/kolejnosc', async (req, res) => {
    const { projekt = '', kolejnosc = [] } = req.body ?? {};
    try {
        return res.json({ success: true, kolejnosc: await Rekopis.przestawRozdzialy(ANTIGRAVITY_DIR, wymagajProjektu(projekt), kolejnosc) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── Wycięte fragmenty ─────────────────────────────────────────────────────────
app.post('/api/rekopis/wytnij', async (req, res) => {
    const { projekt = '', ...dane } = req.body ?? {};
    try {
        return res.json({ success: true, wyciety: await Rekopis.wytnij(ANTIGRAVITY_DIR, wymagajProjektu(projekt), dane) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/rekopis/wyciety/:id', async (req, res) => {
    try {
        return res.json({ success: true, wyciety: await Rekopis.usunWyciety(ANTIGRAVITY_DIR, wymagajProjektu(req.query.projekt), req.params.id) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── Znaczniki ─────────────────────────────────────────────────────────────────
app.post('/api/rekopis/znacznik', async (req, res) => {
    const { projekt = '', ...dane } = req.body ?? {};
    try {
        return res.json({ success: true, znacznik: await Rekopis.dodajZnacznik(ANTIGRAVITY_DIR, wymagajProjektu(projekt), dane) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.patch('/api/rekopis/znacznik/:id', async (req, res) => {
    const { projekt = '', ...zmiany } = req.body ?? {};
    try {
        return res.json({ success: true, znacznik: await Rekopis.zmienZnacznik(ANTIGRAVITY_DIR, wymagajProjektu(projekt), req.params.id, zmiany) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/rekopis/znacznik/:id', async (req, res) => {
    try {
        return res.json({ success: true, znacznik: await Rekopis.usunZnacznik(ANTIGRAVITY_DIR, wymagajProjektu(req.query.projekt), req.params.id) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── Konspekt ──────────────────────────────────────────────────────────────────
app.post('/api/rekopis/konspekt', async (req, res) => {
    const { projekt = '', rozdzial = '', notatki = [] } = req.body ?? {};
    try {
        return res.json({ success: true, notatki: await Rekopis.ustawKonspekt(ANTIGRAVITY_DIR, wymagajProjektu(projekt), rozdzial, notatki) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── Eksport i przekazanie Reżyserowi ─────────────────────────────────────────
app.get('/api/rekopis/tekst', async (req, res) => {
    try {
        return res.json({ success: true, ...(await Rekopis.jakoTekst(ANTIGRAVITY_DIR, wymagajProjektu(req.query.projekt))) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── ✍️ SKRYBA — z Opowieści do Rękopisu ──────────────────────────────────────
//
// Suweren: „Rękopis miał spisać z Opowieści omawianą historię i brief, i z tego
// scenariusz dla agentów rysowania tych scen, dodając assety do opisów… jak
// i też pisze książkę dla tego Uniwersum… a potem reżyser może kręcić".
//
// ⚠️ ZADANIE W TLE, NIE JEDNO POŁĄCZENIE. Osiem scen × (scenariusz + proza)
// to kilkanaście wołań modelu po 30–90 s — żadne HTTP tyle nie przetrzyma.
// Rozdziały lądują w Rękopisie W MIARĘ PISANIA, więc postęp widać w edytorze,
// a stan można odpytać. Zadania żyją w pamięci mostu: restart je gubi, ale
// rozdziały już zapisane zostają na dysku.

const zadaniaSkryby = new Map();

app.post('/api/rekopis/z-opowiesci', async (req, res) => {
    const { projekt = '', rozmowa: rozmowaId = '', co = 'oba', ileScen = 8, model = null } = req.body ?? {};
    try {
        const p = wymagajProjektu(projekt);
        const silnik = String(model || '').trim() || DEFAULT_LLM;
        const chce = String(co);
        const pisacScenariusz = chce === 'oba' || chce === 'scenariusz';
        const pisacProze = chce === 'oba' || chce === 'ksiazka';

        // Rozmowa: wskazana albo NAJNOWSZA związana z projektem (pole `serial`).
        const rozmowy = await Opowiesc.historia(ANTIGRAVITY_DIR);
        const rozmowa = rozmowaId
            ? rozmowy.find((r) => r.id === rozmowaId)
            : rozmowy
                .filter((r) => String(r.serial || '').toLowerCase() === p.toLowerCase())
                .sort((a, b) => String(b.zmieniono || b.kiedy || '').localeCompare(String(a.zmieniono || a.kiedy || '')))[0];
        if (!rozmowa) throw new Error(`Nie ma rozmowy Opowieści związanej z projektem „${p}". Najpierw omów historię w Pokoju Opowieści.`);
        if (!Array.isArray(rozmowa.tury) || rozmowa.tury.length < 2) throw new Error('Ta rozmowa jest pusta — nie ma z czego spisywać.');

        const [uniwersum, assety] = await Promise.all([
            Uniwersum.wczytaj(ANTIGRAVITY_DIR, p).catch(() => null),
            Assety.lista(ANTIGRAVITY_DIR, p).catch(() => []),
        ]);
        const tekstRozmowy = Skryba.zwezRozmowe(rozmowa.tury);

        const id = `skryba-${Date.now().toString(36)}`;
        const stan = {
            id, projekt: p, rozmowa: rozmowa.id, silnik, co: chce,
            stan: 'planuje', scen: 0, gotowych: 0, rozdzialy: [], braki: [],
            blad: null, start: Date.now(), koniec: null,
        };
        zadaniaSkryby.set(id, stan);
        res.json({ success: true, zadanie: id, rozmowa: rozmowa.id, silnik });

        // ⚠️ `think: false` — bez tego model przepala budżet na blok myślenia
        // i oddaje pustą treść (zmierzone: eval_count 60, response "").
        const pytaj = async (system, prompt, num_predict) => {
            const r = await fetch(`${OLLAMA_BASE}/api/chat`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: silnik,
                    messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }],
                    stream: false, think: false,
                    options: { num_predict, temperature: 0.7, num_ctx: 12288 },
                }),
                signal: AbortSignal.timeout(15 * 60 * 1000),
            });
            if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
            return String((await r.json())?.message?.content ?? '').trim();
        };

        (async () => {
            try {
                const { system, prompt } = Skryba.promptPlanu({ rozmowa: tekstRozmowy, uniwersum, assety, ile: Number(ileScen) || 8 });
                const plan = Skryba.odczytajPlan(await pytaj(system, prompt, 2000), Number(ileScen) || 8);
                if (!plan.length) throw new Error('Model nie oddał planu scen w JSON — nie ma czego pisać.');
                stan.scen = plan.length;
                stan.braki = Skryba.brakujaceAssety(plan, assety);
                stan.stan = 'pisze';

                let poprzedniaProza = '';
                for (const scena of plan) {
                    if (pisacScenariusz) {
                        const s = Skryba.promptScenariusza({ scena, uniwersum, assety, rozmowa: tekstRozmowy });
                        const tekst = await pytaj(s.system, s.prompt, 1800);
                        const r = await Rekopis.dodajRozdzial(ANTIGRAVITY_DIR, p, {
                            tytul: Skryba.tytulRozdzialu('scenariusz', scena),
                            tresc: Skryba.jakoRozdzial(tekst, { silnik, rodzaj: 'scenariusz', scena, rozmowaId: rozmowa.id }),
                        });
                        stan.rozdzialy.push({ id: r.id, tytul: r.tytul, slow: r.slow, rodzaj: 'scenariusz' });
                    }
                    if (pisacProze) {
                        const s = Skryba.promptProzy({ scena, uniwersum, poprzedni: poprzedniaProza });
                        const tekst = await pytaj(s.system, s.prompt, 1600);
                        poprzedniaProza = tekst;
                        const r = await Rekopis.dodajRozdzial(ANTIGRAVITY_DIR, p, {
                            tytul: Skryba.tytulRozdzialu('proza', scena),
                            tresc: Skryba.jakoRozdzial(tekst, { silnik, rodzaj: 'proza', scena, rozmowaId: rozmowa.id }),
                        });
                        stan.rozdzialy.push({ id: r.id, tytul: r.tytul, slow: r.slow, rodzaj: 'proza' });
                    }
                    stan.gotowych += 1;
                }
                stan.stan = 'gotowe';
                await Szyna.nadaj({ agent: 'Skryba', rodzaj: 'praca', tresc: `spisał ${stan.rozdzialy.length} rozdziałów z Opowieści do Rękopisu „${p}" (${silnik})` }).catch(() => {});
            } catch (e) {
                stan.stan = 'blad';
                stan.blad = e.message;
            } finally {
                stan.koniec = Date.now();
            }
        })();
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.get('/api/rekopis/z-opowiesci/:id', (req, res) => {
    const s = zadaniaSkryby.get(req.params.id);
    if (!s) return res.status(404).json({ success: false, message: 'Nie znam tego zadania. Most mógł się zrestartować — zadania żyją w jego pamięci, ale zapisane rozdziały zostały na dysku.' });
    res.json({ success: true, ...s, sekund: Math.round(((s.koniec ?? Date.now()) - s.start) / 1000) });
});

/**
 * POST /api/rekopis/na-odcinki { projekt, ile? }
 * Rękopis → odcinki w pamięci Reżysera. Model DZIELI to, co napisane;
 * nie wolno mu dopisywać scen, których w tekście nie ma.
 */
app.post('/api/rekopis/na-odcinki', async (req, res) => {
    const { projekt = '', ile = 6, model } = req.body ?? {};
    try {
        const p = wymagajProjektu(projekt);
        const { tekst, slow } = await Rekopis.jakoTekst(ANTIGRAVITY_DIR, p);
        if (slow < 200) throw new Error(`Rękopis ma ${slow} słów — za mało, żeby było co dzielić na odcinki.`);

        const { system, prompt } = Rekopis.promptNaOdcinki(tekst, Math.max(1, Math.min(Number(ile) || 6, 20)));
        const { tekst: odp, silnik } = await piszModelem(model, system, prompt);

        const start = odp.indexOf('{');
        const koniec = odp.lastIndexOf('}');
        if (start < 0 || koniec <= start) throw new Error(`Model nie oddał JSON-a. Dostałem: ${odp.slice(0, 200)}`);
        const d = JSON.parse(odp.slice(start, koniec + 1));
        const odcinki = (Array.isArray(d.odcinki) ? d.odcinki : [])
            .map((o) => ({
                tytul: String(o?.tytul || '').trim().slice(0, 90),
                streszczenie: String(o?.streszczenie || '').trim(),
                czasMinut: Number.isFinite(Number(o?.czasMinut)) ? Number(o.czasMinut) : null,
                styl: String(o?.styl || '').trim().slice(0, 200),
                status: 'plan',
            }))
            .filter((o) => o.tytul.length >= 3 && o.streszczenie.length >= 10);
        if (!odcinki.length) throw new Error('Model nie oddał ani jednego odcinka z tytułem i opisem.');

        const zapisane = await dodajOdcinki(ANTIGRAVITY_DIR, p, odcinki);
        console.log(`[Rękopis] ${odcinki.length} odcinków z rękopisu projektu ${p}.`);
        return res.json({ success: true, odcinki: zapisane, model: silnik, zeSlow: slow });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

//  🎭 BIBLIOTEKA ASSETÓW — aktorzy, sceny, rekwizyty, głosy, muzyka filmowa
//
//  Suweren, po obejrzeniu Director Studio: „zakładka Aktorzy powinna mieć takie
//  możliwości, ponadto wybór roli", „dodanie modułu scen otoczenia", „menu
//  assetowe dla sceny — możemy tam dodać moduł muzyki filmowej".
//
//  ⚠️ ASSET NALEŻY DO PROJEKTU. Obsada „alchemicznej fluktuacji" nie ma czego
//  szukać w Cafe Martens — każdy projekt ma własny katalog i własny indeks.
// ══════════════════════════════════════════════════════════════════════════════

app.get('/api/assety', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        if (!projekt.trim()) return res.status(400).json({ success: false, message: 'Podaj projekt.' });
        const typ = String(req.query.typ || '');
        return res.json({
            success: true,
            assety: await Assety.lista(ANTIGRAVITY_DIR, projekt, typ),
            typy: Assety.TYPY,
            role: Assety.ROLE,
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/** Kafelki „Project library" — ile czego jest i co pokazać na podglądzie. */
app.get('/api/assety/bilans', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        if (!projekt.trim()) return res.status(400).json({ success: false, message: 'Podaj projekt.' });
        return res.json({ success: true, ...(await Assety.bilans(ANTIGRAVITY_DIR, projekt)), role: Assety.ROLE });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/assety', async (req, res) => {
    const { projekt = '', ...dane } = req.body ?? {};
    try {
        if (!String(projekt).trim()) throw new Error('Podaj projekt — asset należy do projektu, nie do Katedry.');
        const asset = await Assety.zapisz(ANTIGRAVITY_DIR, projekt, dane);
        return res.json({ success: true, asset });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/assety/:id', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        return res.json({ success: true, asset: await Assety.usun(ANTIGRAVITY_DIR, projekt, req.params.id) });
    } catch (e) {
        return res.status(404).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/assety/referencja { projekt, id, pole, nazwaPliku, base64 }
 * ⚠️ Przyjmujemy DANE, nie ścieżkę z dysku — panel bywa wystawiony przez
 * Kwantowy Tunel na telefon.
 */
app.post('/api/assety/referencja', async (req, res) => {
    const { projekt = '', ...dane } = req.body ?? {};
    try {
        const r = await Assety.zapiszReferencje(ANTIGRAVITY_DIR, projekt, dane);
        console.log(`[Assety] Referencja ${dane.pole} dla ${r.asset.nazwa} (${r.bajtow} B)`);
        return res.json({ success: true, ...r });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/** Podgląd pliku assetu. Wyłącznie spod katalogu assetów projektu. */
app.get('/api/assety/plik', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        const plik = String(req.query.plik || '');
        if (!projekt.trim() || !plik.trim()) return res.status(400).send('Brak projektu albo pliku.');

        const korzen = path.resolve(await Assety.katalog(ANTIGRAVITY_DIR, projekt));
        const cel = path.resolve(plik);
        // ⚠️ STRAŻ ŚCIEŻKI: bez tego „podgląd" czytałby dowolny plik z dysku.
        if (!cel.toLowerCase().startsWith(korzen.toLowerCase())) {
            return res.status(403).send('Ten plik nie leży w bibliotece tego projektu.');
        }
        await fs.access(cel);
        return res.sendFile(cel);
    } catch {
        return res.status(404).send('Nie ma takiego pliku.');
    }
});

/**
 * POST /api/assety/skopiuj { zProjektu, doProjektu, idki? }
 *
 * Suweren: „przekułem serial, a w nowym projekcie assety się nie uwzględniły —
 * przerzuć je do nowego". Asset należy do projektu, a przekucie zakłada NOWY
 * projekt — więc potrzebna jest droga, która przenosi obsadę za opowieścią.
 *
 * ⚠️ KOPIUJE, nie przenosi. Źródło zostaje kompletne.
 */
app.post('/api/assety/skopiuj', async (req, res) => {
    const { zProjektu = '', doProjektu = '', idki = null } = req.body ?? {};
    try {
        const r = await Assety.skopiujDoProjektu(ANTIGRAVITY_DIR, zProjektu, doProjektu, idki);
        console.log(`[Assety] ${r.skopiowane.length} asset\u00f3w: ${r.zProjektu} \u2192 ${r.doProjektu} (pomini\u0119tych ${r.pominiete.length})`);
        return res.json({ success: true, ...r });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/** Przeniesienie starych „aktorów" z pamięci Reżysera do biblioteki projektu. */
app.post('/api/assety/przenies-aktorow', async (req, res) => {
    const { projekt = '' } = req.body ?? {};
    try {
        const postacie = await listaPostaci(ANTIGRAVITY_DIR);
        const przeniesione = await Assety.przenies(ANTIGRAVITY_DIR, projekt, postacie);
        return res.json({ success: true, przeniesione, ile: przeniesione.length });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});


// ══════════════════════════════════════════════════════════════════════════════
//  🎬 REŻYSERZY — kto kręci. Osobno od AKTORÓW, którzy grają.
// ══════════════════════════════════════════════════════════════════════════════

/** Wbudowani + właśni. Dołączamy listę silników, żeby panel nie zgadywał, co da się wybrać. */
app.get('/api/rezyserzy', async (_req, res) => {
    try {
        const rezyserzy = await Rezyserzy.lista(ANTIGRAVITY_DIR);
        // ⚠️ Silniki bierzemy z ComfyUI, nie z listy życzeń — panel ma pokazywać
        // to, co REALNIE policzy, i mówić wprost, czego brak.
        let wideo = null;
        try { wideo = await Wideo.stanWideo(COMFY_BASE); } catch { /* ComfyUI śpi — panel to pokaże */ }
        let llm = [];
        try {
            const r = await fetch(`${OLLAMA_BASE}/api/tags`, { signal: AbortSignal.timeout(8000) });
            llm = ((await r.json())?.models ?? []).map((m) => m.name);
        } catch { /* Ollama śpi */ }
        return res.json({
            success: true, rezyserzy, domyslne: Rezyserzy.DOMYSLNE,
            silnikiWideo: wideo?.silniki ?? [], gotoweWideo: !!wideo?.gotowe, brakiWideo: wideo?.braki ?? [],
            silnikiLLM: llm,
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/** Zapis reżysera. Przeróbka WBUDOWANEGO zapisuje się jako klon pod nowym id. */
app.post('/api/rezyserzy', async (req, res) => {
    try {
        const r = await Rezyserzy.zapiszRezysera(ANTIGRAVITY_DIR, req.body ?? {});
        console.log(`[Reżyserzy] 🎬 „${r.nazwa}” — ${r.szerokosc}x${r.wysokosc}, ${r.sekundNaKadr}s/kadr, ${r.kroki} kroków`);
        return res.json({ success: true, rezyser: r });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/rezyserzy/:id', async (req, res) => {
    try {
        return res.json({ success: true, rezyser: await Rezyserzy.usunRezysera(ANTIGRAVITY_DIR, req.params.id) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── BAZA AKTORÓW OtakOS — katedralna, ponad projektami ──────────────────

app.get('/api/aktorzy-otakos', async (_req, res) => {
    try {
        return res.json({ success: true, aktorzy: await Rezyserzy.listaAktorow(ANTIGRAVITY_DIR) });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/aktorzy-otakos', async (req, res) => {
    try {
        return res.json({ success: true, aktor: await Rezyserzy.zapiszAktora(ANTIGRAVITY_DIR, req.body ?? {}) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/aktorzy-otakos/:id', async (req, res) => {
    try {
        return res.json({ success: true, aktor: await Rezyserzy.usunAktora(ANTIGRAVITY_DIR, req.params.id) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * Solita i Molita wyprowadzają się z zakładki, która staje się Reżyserami.
 *
 * ⚠️ `zabierz: false` (domyślnie) KOPIUJE — pamięć Reżysera zostaje nietknięta,
 * dopóki Suweren nie zobaczy, że w bazie naprawdę są.
 */
app.post('/api/aktorzy-otakos/przenies', async (req, res) => {
    const { zabierz = false } = req.body ?? {};
    try {
        const r = await Rezyserzy.przeniesZPamieciRezysera(ANTIGRAVITY_DIR, { zabierz });
        console.log(`[Aktorzy OtakOS] ${r.przeniesieni.length} przeniesionych${r.zabrane ? ' (zabrane ze źródła)' : ' (kopia)'}`);
        return res.json({ success: true, ...r });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});


// ══════════════════════════════════════════════════════════════════════════════
//  🗣️ ŚCIEŻKA DIALOGOWA — kwestie z kart zamieniane w nagrania
// ══════════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════════
//  🖌️ POJEDYNCZY OBRAZ — liczenie POZA kolejką produkcyjną
// ══════════════════════════════════════════════════════════════════════════════
//
// PO CO OSOBNO. Kolejka kadrów liczy KARTY z Tablicy: bierze kadr, zapisuje
// wynik przy karcie, przesuwa ją na następny etap. Dział mody nie ma kart —
// ma `imagePrompt` przy kreacji i chce zobaczyć samą sztukę odzieży.
// Przepychanie tego przez kolejkę produkcyjną wymagałoby zakładania sztucznych
// kart w cudzym projekcie.
//
// ⚠️ TA TRASA NIE ZAPISUJE NICZEGO W KATEDRZE. Oddaje obraz i tyle — kto go
// zamówił, ten decyduje, co z nim zrobić.

// ── 🌙 NOCNA ZMIANA — długie roboty, gdy Suweren nie pracuje ─────────────────
//
// Suweren: „by się włączał, jak nic nie robię na kompie". Pętla co 60 s sprawdza
// trzy bramy (bezczynność ≥ 10 min, karta wolna, RAM ≥ 8 GB) i dopiero wtedy
// rusza JEDNO zadanie z kolejki — wyłącznie z białej listy robót mostu.
// Szczegóły i powody w services/NocnaZmiana.js.

app.get('/api/nocna/stan', async (req, res) => {
    try { res.json({ success: true, ...(await NocnaZmiana.stanZmiany()) }); }
    catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

app.post('/api/nocna/przelacz', async (req, res) => {
    try {
        const wlaczona = await NocnaZmiana.przelacz(!!(req.body ?? {}).wlaczona);
        await Szyna.nadaj({ agent: 'Nocna Zmiana', rodzaj: 'stan', tresc: wlaczona ? 'włączona — ruszy, gdy Suweren odejdzie od klawiatury' : 'wyłączona' }).catch(() => {});
        res.json({ success: true, wlaczona });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

app.post('/api/nocna/dodaj', async (req, res) => {
    try { res.json({ success: true, zadanie: await NocnaZmiana.dodaj(req.body ?? {}) }); }
    catch (e) { res.status(400).json({ success: false, message: e.message }); }
});

app.delete('/api/nocna/:id', async (req, res) => {
    try { res.json({ success: true, usunieto: await NocnaZmiana.usun(req.params.id) }); }
    catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

/** Uruchom zadanie teraz, z pominięciem bram — świadomie, ręką człowieka. */
app.post('/api/nocna/:id/teraz', async (req, res) => {
    try { res.json({ success: true, ...(await NocnaZmiana.uruchomTeraz(req.params.id)) }); }
    catch (e) { res.status(400).json({ success: false, message: e.message }); }
});

/** Sprawdź bramy TERAZ — panel pokazuje, dlaczego Zmiana (nie) rusza. */
app.get('/api/nocna/bramy', async (req, res) => {
    try { res.json({ success: true, ...(await NocnaZmiana.sprawdzTeraz()) }); }
    catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

NocnaZmiana.skonfiguruj({ katalogKatedry: ANTIGRAVITY_DIR, portMostu: PORT, szynaZdarzen: Szyna, comfy: COMFY_BASE });
NocnaZmiana.uruchomPetle();

// ═════════════════════════════════════════════════════════════════════════════
// 📱🕊️ DELEGAT MOBILNY — TeOgochi w telefonie Suwerena + ręce na telefonie (Artemis)
// Zaplecze: services/Delegat.js (persona, biała lista narzędzi, pamięć rozmów,
// fakty na szynę) i services/Artemis.js (adapter google/artemis — automatyzacja
// Androida podpiętego do tej maszyny). Strona telefonu: public/delegat (statyczna,
// przez tunel + klucz Straży). Powody i granice — w nagłówkach tych plików.
// ═════════════════════════════════════════════════════════════════════════════
Delegat.skonfiguruj({ ollamaBase: OLLAMA_BASE, portMostu: PORT, szyna: Szyna, nocna: NocnaZmiana, artemis: Artemis, katalog: path.join(ANTIGRAVITY_DIR, 'delegat'), model: DEFAULT_LLM, pelnyTunel: PELNY_TUNEL });

app.get('/api/delegat/profile', (req, res) => res.json({ success: true, profile: Delegat.profile(), lokalne: !!req.lokalny, pelnyTunel: PELNY_TUNEL }));

/**
 * POST /api/delegat/rozmowa { delegat, tekst, rozmowaId?, model?, strumien? }
 * strumien:true → SSE: {typ:'narzedzie'|'wynik'|'token'|'koniec'|'blad'} — telefon czyta od razu.
 * Bez strumienia → jeden JSON z odpowiedzią.
 */
app.post('/api/delegat/rozmowa', async (req, res) => {
    const { delegat = 'joanna', tekst, rozmowaId, model, strumien } = req.body ?? {};
    const p = { delegat, tekst, rozmowaId, model, lokalne: !!req.lokalny };
    if (!strumien) {
        try { return res.json({ success: true, ...(await Delegat.rozmawiaj(p)) }); }
        catch (e) { return res.status(400).json({ success: false, message: e.message }); }
    }
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'Access-Control-Allow-Origin': '*' });
    const wyslij = (z) => { try { res.write(`data: ${JSON.stringify(z)}\n\n`); } catch { /* telefon się rozłączył */ } };
    try { await Delegat.rozmawiaj(p, wyslij); }
    catch (e) { wyslij({ typ: 'blad', message: e.message }); }
    res.end();
});

app.get('/api/delegat/rozmowy', async (_req, res) => res.json({ success: true, rozmowy: await Delegat.rozmowy() }));
app.get('/api/delegat/rozmowa/:id', async (req, res) => {
    const r = await Delegat.rozmowa(req.params.id);
    return r ? res.json({ success: true, rozmowa: r }) : res.status(404).json({ success: false, message: 'Nie ma takiej rozmowy.' });
});
app.post('/api/delegat/rozmowa/:id/podsumuj', async (req, res) => {
    try { res.json({ success: true, ...(await Delegat.podsumuj(req.params.id, { model: req.body?.model })) }); }
    catch (e) { res.status(400).json({ success: false, message: e.message }); }
});
app.get('/api/delegat/fakty', async (req, res) => res.json({ success: true, fakty: await Delegat.fakty(Number(req.query.ile) || 50) }));

// ── 🛰️ Kwantowy Tunel jednym przyciskiem (services/Tunel.js) — TYLKO LOKALNIE (Straż) ──
Tunel.skonfiguruj({ portMostu: PORT, szyna: Szyna });
app.get('/api/tunel/stan', async (_req, res) => res.json({ success: true, ...(await Tunel.stanTunelu()), klucz: KLUCZ_STRAZY }));
app.post('/api/tunel/start', async (_req, res) => {
    try { res.json({ success: true, ...(await Tunel.start()), klucz: KLUCZ_STRAZY }); }
    catch (e) { res.status(500).json({ success: false, message: e.message, ...(await Tunel.stanTunelu()) }); }
});
app.post('/api/tunel/stop', async (_req, res) => res.json({ success: true, ...(await Tunel.stop()) }));

// ── Ręce na telefonie (Artemis) — urządzenie podpięte do TEJ maszyny ──
app.get('/api/telefon/stan', async (_req, res) => res.json({ success: true, ...(await Artemis.stan()) }));
app.post('/api/telefon/zadanie', async (req, res) => {
    const { cel, profil, urzadzenie, oczekiwane, czekaj } = req.body ?? {};
    try {
        const s = await Artemis.stan();
        if (!s.zywy) return res.status(424).json({ success: false, message: s.blad, hint: s.hint });
        const z = czekaj ? await Artemis.zlecICzekaj({ cel, profil, urzadzenie, oczekiwane }) : await Artemis.zlec({ cel, profil, urzadzenie, oczekiwane });
        await Szyna.nadaj({ agent: 'Artemis', rodzaj: 'telefon', tresc: `zadanie na telefonie: ${String(cel).slice(0, 200)} [${z.status}]`, dane: { id: z.id } });
        return res.json({ success: true, ...z });
    } catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});
app.get('/api/telefon/zadanie/:id', async (req, res) => {
    try { res.json({ success: true, ...(await Artemis.sonduj(req.params.id)) }); }
    catch (e) { res.status(400).json({ success: false, message: e.message }); }
});
app.post('/api/telefon/zadanie/:id/stop', async (req, res) => {
    try { res.json({ success: true, zatrzymane: await Artemis.zatrzymaj(req.params.id) }); }
    catch (e) { res.status(400).json({ success: false, message: e.message }); }
});

// ═════════════════════════════════════════════════════════════════════════════
// 🧪 TeO LAB — printy z lokalnego modelu, piaskownica Nocnej Zmiany, arena
// TeOgochi, projekt chipów. Zaplecze: services/Laboratorium.js (tam „po co").
// ═════════════════════════════════════════════════════════════════════════════
Laboratorium.skonfiguruj({ ollama: OLLAMA_BASE, model: process.env.OTAKOS_MODEL, modelMechanika: () => modelMechanika(), szynaZdarzen: Szyna });

// ═════════════════════════════════════════════════════════════════════════════
// 🌙🎬 REALIZACJA NOCNA — „Zrealizuj zaplanowaną Produkcję" (Klatka) i „Zrealizuj
// Tablicę Reżysera" (Reżyser). services/RealizacjaNocna.js — tam „po co".
// ═════════════════════════════════════════════════════════════════════════════
RealizacjaNocna.skonfiguruj({
    katalogKatedry: ANTIGRAVITY_DIR, mostBase: `http://127.0.0.1:${PORT}`, szyna: Szyna, comfyDir: COMFY_DIR,
    produkcjaLista, produkcjaZmien, produkcjaDodaj, rezyserPamiec, katalogOdcinka,
    katalogUjec: KolejkaKadrow.katalogUjec, poKolei: KolejkaKadrow.poKolei, maJuzUjecie: KolejkaKadrow.maJuzUjecie,
    sklej: CiagDalszy.sklej,
    // 🎵 Teledysk z nowych scen: montaż podkłada utwór projektu (teledysk.json) pod sklejony film.
    teledyskProjektu: async (projekt) => TeledyskNowy.teledyskProjektu((await utworzProjekt(ANTIGRAVITY_DIR, projekt)).sciezka),
    ffmpeg: ffmpegPath, execFile: execFileAsync,
});
TeledyskNowy.skonfiguruj({
    katalog: ANTIGRAVITY_DIR, mostBase: `http://127.0.0.1:${PORT}`, szyna: Szyna,
    pisz: piszModelem, listaProjektow, utworzProjekt, dodajFakt, dodajOdcinek, dodajUtwor: MuzykaFilmowa.dodajUtwor,
});
// ── ✂️ CIĘCIE WIDEO NA KLOCKI (Wiesio-Nożyce) ──────────────────────────────
/**
 * Suweren (2026-09-15): „mam w Klockach do Movie 3 pliki 0:20, 0:30, 0:40 —
 * potrzebuję je pociąć na 10 s". Źródła: `_OtakOs_Move` i `_OtakOs_Klocki/*`
 * (tylko te dwa korzenie — ścieżka z URL-a nie wychodzi poza nie).
 *
 * ⚠️ TNIEMY Z PRZEKODOWANIEM, nie `-c copy`. Kopia strumienia tnie tylko na
 * klatkach kluczowych — przy 10 s wychodziłoby 8,7 s albo 12,4 s, zależnie od
 * GOP-u. `force_key_frames` co N s + segment daje równe kawałki; libx264 CRF 18,
 * dźwięk AAC. Ostatni kawałek bywa krótszy — mówimy, ile ma.
 */
const KORZENIE_WIDEO = () => ({ move: MOVE_DIR, klocki: path.join(process.cwd(), '_OtakOs_Klocki') });
function sciezkaWKorzeniu(zrodlo, rel, { musiIstniec = true } = {}) {
    const korzen = KORZENIE_WIDEO()[zrodlo];
    if (!korzen) throw new Error(`Nieznane źródło „${zrodlo}" (move | klocki).`);
    const abs = path.resolve(korzen, String(rel || ''));
    if (!abs.toLowerCase().startsWith(path.resolve(korzen).toLowerCase())) throw new Error('Ścieżka poza katalogiem źródłowym.');
    if (musiIstniec && !fsSync.existsSync(abs)) throw new Error(`Nie ma pliku: ${rel}`);
    return abs;
}
async function sekundyWideo(p) {
    try { const { stdout } = await execFileAsync(ffprobePath, ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', p]); const d = Number(stdout); return Number.isFinite(d) ? Math.round(d * 10) / 10 : null; } catch { return null; }
}
app.get('/api/wideo/pliki', async (req, res) => {
    try {
        const zrodlo = String(req.query.zrodlo || 'klocki');
        const korzen = KORZENIE_WIDEO()[zrodlo];
        if (!korzen) return res.status(400).json({ success: false, message: 'zrodlo: move | klocki' });
        const lista = [];
        const wejdz = async (dir, glebokosc) => {
            for (const w of await fs.readdir(dir, { withFileTypes: true }).catch(() => [])) {
                const abs = path.join(dir, w.name);
                if (w.isDirectory()) { if (glebokosc < 3) await wejdz(abs, glebokosc + 1); continue; }
                if (!/\.(mp4|mov|webm|m4v)$/i.test(w.name)) continue;
                const st = await fs.stat(abs);
                lista.push({ rel: path.relative(korzen, abs).split(path.sep).join('/'), nazwa: w.name, bajtow: st.size, sekundy: await sekundyWideo(abs), kiedy: st.mtime.toISOString() });
            }
        };
        await wejdz(korzen, 0);
        lista.sort((a, b) => a.rel.localeCompare(b.rel));
        return res.json({ success: true, zrodlo, korzen, pliki: lista });
    } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});
app.post('/api/wideo/potnij', async (req, res) => {
    const { zrodlo = 'klocki', plik = '', sekundy = 10, doKatalogu = '' } = req.body ?? {};
    try {
        const abs = sciezkaWKorzeniu(zrodlo, plik);
        const n = Math.max(1, Math.min(600, Number(sekundy) || 10));
        const baza = path.basename(abs).replace(/\.[^.]+$/, '');
        // Wynik: podkatalog `<nazwa>_po_<N>s` obok pliku (albo wskazany katalog w tym samym korzeniu).
        const cel = doKatalogu ? sciezkaWKorzeniu(zrodlo, doKatalogu, { musiIstniec: false }) : path.join(path.dirname(abs), `${baza}_po_${n}s`);
        await fs.mkdir(cel, { recursive: true });
        const wzor = path.join(cel, `${baza}_%02d.mp4`);
        const t0 = Date.now();
        await execFileAsync(ffmpegPath, ['-y', '-i', abs, '-c:v', 'libx264', '-preset', 'fast', '-crf', '18', '-force_key_frames', `expr:gte(t,n_forced*${n})`, '-c:a', 'aac', '-b:a', '192k', '-f', 'segment', '-segment_time', String(n), '-reset_timestamps', '1', '-movflags', '+faststart', wzor], { windowsHide: true, timeout: 20 * 60_000, maxBuffer: 16 * 1024 * 1024 });
        const kawalki = [];
        for (const f of (await fs.readdir(cel)).filter((f) => f.startsWith(`${baza}_`) && f.endsWith('.mp4')).sort()) {
            const p = path.join(cel, f);
            kawalki.push({ nazwa: f, rel: path.relative(KORZENIE_WIDEO()[zrodlo], p).split(path.sep).join('/'), sekundy: await sekundyWideo(p), bajtow: (await fs.stat(p)).size });
        }
        console.log(`[Wiesio-Nożyce] ✂️ ${path.basename(abs)} → ${kawalki.length} kawałków po ${n} s w ${cel}`);
        return res.json({ success: true, plik: abs, katalog: cel, sekundy: n, kawalki, czas: Math.round((Date.now() - t0) / 1000) });
    } catch (e) { return res.status(400).json({ success: false, message: e.stderr ? String(e.stderr).slice(-400) : e.message }); }
});

// ── 🖼️ WYSTAWA — katalog Katedry dla teo.center (services/Wystawa.js: „po co" i granice) ──
Wystawa.skonfiguruj({ katalogKatedry: ANTIGRAVITY_DIR, musicDir: MUSIC_DIR, comfyDir: COMFY_DIR, ffmpeg: ffmpegPath, ffprobe: ffprobePath, execFile: execFileAsync, szyna: Szyna });
const wystawaOdp = (res, p) => p.then((d) => res.json({ success: true, ...d })).catch((e) => res.status(400).json({ success: false, message: e.message }));
app.get('/api/wystawa', cors({ origin: '*' }), (_req, res) => wystawaOdp(res, Wystawa.zbierz()));
app.get('/api/wystawa/kuracja', (_req, res) => wystawaOdp(res, Wystawa.kuracja()));
app.post('/api/wystawa/suno', (req, res) => wystawaOdp(res, Wystawa.dodajSuno(req.body ?? {})));
app.delete('/api/wystawa/suno/:id', (req, res) => wystawaOdp(res, Wystawa.usunSuno(req.params.id)));
app.post('/api/wystawa/youtube', (req, res) => wystawaOdp(res, Wystawa.ustawYouTube(req.body ?? {})));
app.post('/api/wystawa/ukryj', (req, res) => wystawaOdp(res, Wystawa.ukryj(req.body ?? {})));
app.post('/api/wystawa/opis', (req, res) => wystawaOdp(res, Wystawa.ustawOpis(req.body ?? {})));
app.post('/api/wystawa/publikuj', (req, res) => wystawaOdp(res, Wystawa.opublikuj(req.body ?? {})));
/**
 * Strumień pliku z wystawy — TYLKO id z białej listy zbudowanej przez zbierz()
 * (nigdy ścieżka z URL-a). Tryb gospodarza: teo.center otwarte na tej maszynie
 * gra film/utwór prosto z dysku, z Range (seek), bez YouTube.
 */
app.get('/wystawa/plik/:id', cors({ origin: '*' }), async (req, res) => {
    let p = Wystawa.sciezkaZBialej(req.params.id);
    if (!p) { await Wystawa.zbierz().catch(() => {}); p = Wystawa.sciezkaZBialej(req.params.id); }
    if (!p || !fsSync.existsSync(p)) return res.status(404).json({ success: false, message: 'Nie ma takiej pozycji na wystawie.' });
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'no-cache');
    return res.sendFile(p);
});

// ── 🧊🎮 TGS 3D: teren świata z planszy → Blender → .glb w public/assets/swiaty ──
Teterhia3D.skonfiguruj({ szyna: Szyna });
app.get('/api/tgs/3d/swiaty', async (_req, res) => res.json({ success: true, swiaty: await Teterhia3D.listaSwiatow() }));
app.post('/api/tgs/3d/swiat', async (req, res) => {
    try { return res.json({ success: true, ...(await Teterhia3D.zbudujSwiat(req.body ?? {})) }); }
    catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});
/**
 * POST /api/tgs/3d/scenografia { projekt, kadrId, nazwa?, szerokoscSceny?, aktorow? }
 * Scenografia do gry z KADRU STORY: kadr (png) → wirtualne studio w Blenderze
 * (cyklorama z kadru, podłoga, światło) → .glb → public/assets/scenografie TGS.
 * Suweren: „scenografie z kadrów Story jako drugi przycisk" — ta sama droga co
 * teren, tylko źródłem jest obraz z Tablicy Produkcji, nie kafle.
 */
app.post('/api/tgs/3d/scenografia', async (req, res) => {
    const { projekt = '', kadrId = '', nazwa = '', szerokoscSceny = 16, aktorow = 0 } = req.body ?? {};
    try {
        const kadr = (await produkcjaLista(ANTIGRAVITY_DIR, projekt)).find((k) => k.id === kadrId);
        if (!kadr) return res.status(404).json({ success: false, message: `Nie ma kadru „${kadrId}" w projekcie „${projekt}".` });
        const m = String(kadr.zwrot || '').match(/[^\n|"]+\.(png|jpg|jpeg|webp)/i);
        if (!m) return res.status(400).json({ success: false, message: `Kadr „${kadr.tytul}" nie ma obrazu (ma: ${String(kadr.zwrot || '').slice(0, 60) || 'nic'}). Scenografia buduje się z KADRU .png — policz go w kolejce KADR.` });
        const obraz = m[0].trim();
        const stan = await Blender.stanBlendera();
        if (!stan.jest) return res.status(424).json({ success: false, message: `${stan.powod} ${stan.cozrobic}` });
        const t0 = Date.now();
        const s = await Blender.zbudujStudio({ projekt, kadr: obraz, nazwa: nazwa || kadr.tytul, szerokoscSceny, aktorow });
        const r = await Blender.uruchom(s.skrypt);
        const g = await Blender.skryptGlb({ blend: r.scena, nazwa: nazwa || kadr.tytul });
        await Blender.uruchom(g.skrypt);
        const w = await Scenografie.przekaz({ projekt, glb: g.glb, blend: r.scena, kadr: obraz, nazwa: nazwa || kadr.tytul, przeznaczenie: 'gra', opis: `Z kadru „${kadr.tytul}": ${String(kadr.opis || '').slice(0, 200)}` });
        console.log(`[TGS] Scenografia z kadru „${kadr.tytul}" → ${w.wpis.url} (${Math.round((Date.now() - t0) / 1000)} s)`);
        return res.json({ success: true, ...w, kadr: { id: kadr.id, tytul: kadr.tytul, obraz }, sekundy: Math.round((Date.now() - t0) / 1000), blender: stan.wersja });
    } catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});

/**
 * POST /api/tgs/npc/rozmowa { teogochiId, wypowiedz, historia[], swiat, kafel, gracz }
 * NPC w grze to PRAWDZIWY TeOgochi ze stada (imię, dziedzina, etap) — wciela się
 * w mieszkańca Teterhii. Suweren: „w postacie i NPC mogły się wcielać nasze TeOgochi".
 * Nic nie zapisuje; to rozmowa. Nagrody/questy dalej daje Kustosz (/api/tgs/quest).
 */
app.post('/api/tgs/npc/rozmowa', async (req, res) => {
    const { teogochiId = '', wypowiedz = '', historia = [], swiat = '', kafel = '', gracz = '', model } = req.body ?? {};
    if (!String(wypowiedz).trim()) return res.status(400).json({ success: false, message: 'Pusta wypowiedź.' });
    try {
        const stado = await MostStada.stanDlaApki(Szyna.ostatnie({ ile: 100 })).catch(() => null);
        const t = (stado?.gatunki ?? []).find((g) => g.id === teogochiId);
        if (!t) return res.status(404).json({ success: false, message: `W stadzie nie ma TeOgochi „${teogochiId}" — Katedra musi opublikować migawkę (Dom TeOgochi).` });
        const system = `Jesteś ${t.imie} — TeOgochi Katedry OtakOS (dziedzina: ${t.dziedzina}, etap: ${t.etap}), który WCIELA SIĘ w mieszkańca świata Teterhia w grze „To Get Sauce". Mówisz po polsku, w pierwszej osobie, 1–3 zdania, w duchu swojej dziedziny. Znasz tylko to, co widać w kontekście; nie wymyślasz przedmiotów ani nagród (od tego jest Kustosz). Możesz dać wskazówkę, zagadkę albo opinię o graczu. Bez grzeczności na wstępie.`;
        const kontekst = [swiat ? `ŚWIAT: ${swiat}` : '', kafel ? `MIEJSCE: ${kafel}` : '', gracz ? `GRACZ: ${gracz}` : ''].filter(Boolean).join('\n');
        const prompt = [kontekst, ...(Array.isArray(historia) ? historia.slice(-8).map((h) => `${h.kto === 'gracz' ? 'GRACZ' : t.imie.toUpperCase()}: ${h.tresc}`) : []), `GRACZ: ${wypowiedz}`, `${t.imie.toUpperCase()}:`].filter(Boolean).join('\n');
        const { tekst, silnik } = await piszModelem(model, system, prompt);
        return res.json({ success: true, mowa: tekst.slice(0, 800), model: silnik, npc: { id: t.id, imie: t.imie, forma: t.forma, dziedzina: t.dziedzina, kolor: t.kolor } });
    } catch (e) { return res.status(502).json({ success: false, message: e.message }); }
});

// ── 🔧🎵 WARSZTAT UTWORÓW: przedłuż / remiks / cover istniejącego utworu (ACE-Step 1.5) ──
WarsztatUtworow.skonfiguruj({ comfyBase: COMFY_BASE, comfyDir: COMFY_DIR, musicDir: MUSIC_DIR, katalogKatedry: ANTIGRAVITY_DIR, workflowsDir: WORKFLOWS_DIR, mostBase: `http://127.0.0.1:${PORT}`, ffmpeg: ffmpegPath, ffprobe: ffprobePath, execFile: execFileAsync, szyna: Szyna });
app.get('/api/music/warsztat', (_req, res) => res.json({ success: true, tryby: WarsztatUtworow.TRYBY, zadania: WarsztatUtworow.listaZadan() }));
app.get('/api/music/warsztat/:id', (req, res) => { const z = WarsztatUtworow.stanZadania(req.params.id); return z ? res.json({ success: true, ...z }) : res.status(404).json({ success: false, message: 'Nie ma takiego zadania.' }); });
app.post('/api/music/warsztat', async (req, res) => {
    try {
        const comfy = await comfyStatus();
        if (!comfy.online) return res.status(424).json({ success: false, message: comfy.message || 'ComfyUI nie odpowiada.' });
        return res.json({ success: true, ...(await WarsztatUtworow.przerob(req.body ?? {})) });
    } catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});
app.post('/api/music/warsztat/:id/przerwij', async (req, res) => res.json({ success: true, przerwane: await WarsztatUtworow.przerwij(req.params.id) }));

/**
 * POST /api/teledysk/nowy { audioUrl | audioPlik, tytul, styl, prompt, lyrics, sekundy, model?, realizujTeraz? }
 * Joanna mówi, o czym utwór → projekt Story z jednym odcinkiem o długości utworu →
 * (opcjonalnie) Reżyser pisze kadry i rusza produkcja z montażem pod muzykę.
 */
app.post('/api/teledysk/nowy', async (req, res) => {
    try { return res.json({ success: true, ...(await TeledyskNowy.zaplanuj(req.body ?? {})) }); }
    catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});
const realizacjaOdp = (res, fn) => {
    try {
        const z = fn();
        // `sondaz` — adres, pod którym Nocna Zmiana czeka na koniec (godziny).
        return res.json({ success: true, zadanie: z.id, sondaz: `/api/realizacja-nocna/${z.id}`, ...z });
    } catch (e) { return res.status(400).json({ success: false, message: e.message }); }
};
app.post('/api/produkcja/zrealizuj', (req, res) => realizacjaOdp(res, () => RealizacjaNocna.zrealizujProdukcje(req.body ?? {})));
app.post('/api/rezyser/tablica/zrealizuj', (req, res) => realizacjaOdp(res, () => RealizacjaNocna.zrealizujTablice(req.body ?? {})));
app.get('/api/realizacja-nocna', (req, res) => res.json({ success: true, zadania: RealizacjaNocna.listaZadan() }));
app.get('/api/realizacja-nocna/:id', (req, res) => {
    const z = RealizacjaNocna.stanZadania(req.params.id);
    return z ? res.json({ success: true, ...z }) : res.status(404).json({ success: false, message: 'Nie ma takiego zadania.' });
});
app.post('/api/realizacja-nocna/:id/przerwij', (req, res) => res.json({ success: true, przerwane: RealizacjaNocna.przerwij(req.params.id) }));

const labOdp = (res, p) => p.then((d) => res.json({ success: true, ...(Array.isArray(d) ? { lista: d } : d) })).catch((e) => res.status(400).json({ success: false, message: e.message }));

app.get('/api/lab/stan', (req, res) => labOdp(res, Promise.resolve(Laboratorium.stan())));

// ── 1. Printy ──
app.get('/api/lab/printy', (req, res) => labOdp(res, Laboratorium.printy()));
app.get('/api/lab/printy/:id', (req, res) => labOdp(res, Laboratorium.print(req.params.id)));
app.post('/api/lab/printy', (req, res) => labOdp(res, Laboratorium.syntezujPrint(req.body ?? {})));
app.delete('/api/lab/printy/:id', (req, res) => labOdp(res, Laboratorium.usunPrint(req.params.id)));

// ── 2. Piaskownica ──
app.get('/api/lab/apki', (req, res) => labOdp(res, Promise.resolve({ apki: Laboratorium.apki() })));
app.get('/api/lab/apki/:id/pliki', (req, res) => labOdp(res, Laboratorium.plikiApki(req.params.id, String(req.query.q || ''))));
app.get('/api/lab/zlecenia', (req, res) => labOdp(res, Laboratorium.zlecenia()));
app.post('/api/lab/zlecenia', (req, res) => labOdp(res, Laboratorium.dodajZlecenie(req.body ?? {})));
app.delete('/api/lab/zlecenia/:id', (req, res) => labOdp(res, Laboratorium.usunZlecenie(req.params.id)));
app.get('/api/lab/eksperymenty', (req, res) => labOdp(res, Laboratorium.eksperymenty()));
app.get('/api/lab/eksperymenty/:id', (req, res) => labOdp(res, Laboratorium.eksperymentPelny(req.params.id)));
/** Eksperyment TERAZ (Suweren) albo z robota Nocnej Zmiany (bez pól → pierwsze otwarte zlecenie). */
app.post('/api/lab/eksperyment', (req, res) => {
    const b = req.body ?? {};
    const p = b.apka && b.plik && b.cel ? Laboratorium.eksperyment(b) : Laboratorium.nastepneZlecenie({ model: b.model });
    return labOdp(res, p);
});
app.post('/api/lab/eksperymenty/:id/zatwierdz', (req, res) => labOdp(res, Laboratorium.zatwierdz(req.params.id)));
app.post('/api/lab/eksperymenty/:id/odrzuc', (req, res) => labOdp(res, Laboratorium.odrzuc(req.params.id, req.body?.powod)));

// ── 3. Arena ──
app.get('/api/lab/stado', (req, res) => labOdp(res, Laboratorium.stado()));
app.get('/api/lab/arena', (req, res) => labOdp(res, Laboratorium.areny_lista()));
app.get('/api/lab/arena/:id', (req, res) => labOdp(res, Laboratorium.arena(req.params.id)));
app.post('/api/lab/arena', (req, res) => labOdp(res, Laboratorium.zacznijArene(req.body ?? {})));

// ── 4. Chipy ──
app.post('/api/lab/chipy/policz', (req, res) => labOdp(res, Promise.resolve(Laboratorium.policzChip(req.body ?? {}))));
app.get('/api/lab/chipy', (req, res) => labOdp(res, Laboratorium.chipy()));
app.get('/api/lab/chipy/blender', (req, res) => labOdp(res, Laboratorium.stanBlendera()));
app.get('/api/lab/chipy/analizy', (req, res) => labOdp(res, Laboratorium.analizy()));
app.get('/api/lab/chipy/:id', (req, res) => labOdp(res, Laboratorium.chip(req.params.id)));
app.get('/api/lab/chipy/:id/render', async (req, res) => {
    try { const c = await Laboratorium.chip(req.params.id); if (!c.render) return res.status(404).json({ success: false, message: 'Brak renderu.' }); res.sendFile(c.render); }
    catch (e) { res.status(400).json({ success: false, message: e.message }); }
});
app.post('/api/lab/chipy', (req, res) => labOdp(res, Laboratorium.projektujChip(req.body ?? {})));
app.post('/api/lab/chipy/:id/render', (req, res) => labOdp(res, Laboratorium.renderujChip(req.params.id)));
/** Własny plik do analizy — tekstowy albo PDF (warstwa tekstu), ≤ 20 MB, w pamięci (na dysk idzie wynik + tekst źródła). */
const labUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });
app.post('/api/lab/chipy/analiza', labUpload.single('plik'), async (req, res) => {
    const nazwa = req.file?.originalname || String(req.body?.nazwa || 'wklejka.txt');
    const toPdf = /\.pdf$/i.test(nazwa) || req.file?.mimetype === 'application/pdf';
    const ok = toPdf || /\.(txt|md|csv|json|yaml|yml|py|v|sv|vhd|vhdl|toml|ini|cfg|log|ts|js|gguf\.txt)$/i.test(nazwa);
    if (req.file && !ok) return res.status(415).json({ success: false, message: `Analiza przyjmuje PDF i pliki tekstowe (txt/md/csv/json/yaml/py/v/sv/vhdl…), nie „${nazwa}".` });
    let tresc, stron = null;
    try {
        if (req.file && toPdf) ({ tekst: tresc, stron } = await Laboratorium.tekstZPdf(req.file.buffer));
        else tresc = req.file ? req.file.buffer.toString('utf8') : String(req.body?.tresc || '');
    } catch (e) { return res.status(422).json({ success: false, message: e.message }); }
    // PDF-y bywają długie — bierzemy początek do limitu modelu i mówimy, ile ucięto.
    const LIMIT = 200_000;
    const uciete = tresc.length > LIMIT ? tresc.length - LIMIT : 0;
    return labOdp(res, Laboratorium.analizujPlik({ nazwa, tresc: tresc.slice(0, LIMIT), pytanie: req.body?.pytanie, model: req.body?.model, stron }).then((a) => ({ ...a, uciete })));
});
/** Projekt jako żywa rzecz: notatki Suwerena, pytania otwarte, badania TeOgochi (Arena z kontekstem projektu → dziennik). */
app.post('/api/lab/chipy/:id/notatka', (req, res) => labOdp(res, Laboratorium.dodajNotatke(req.params.id, req.body ?? {})));
app.post('/api/lab/chipy/:id/pytanie', (req, res) => labOdp(res, Laboratorium.dodajPytanie(req.params.id, req.body ?? {})));
app.delete('/api/lab/chipy/:id/pytanie/:pid', (req, res) => labOdp(res, Laboratorium.usunPytanie(req.params.id, req.params.pid)));
app.delete('/api/lab/chipy/:id/wpis/:wid', (req, res) => labOdp(res, Laboratorium.usunWpis(req.params.id, req.params.wid)));
app.post('/api/lab/chipy/:id/badaj', (req, res) => labOdp(res, Laboratorium.badajPytanie(req.params.id, req.body ?? {}).then((r) => ({ ...r, sondaz: `/api/lab/arena/${r.arena}` }))));
/** Nocna Zmiana: bez pól — pierwsze otwarte pytanie w pierwszym projekcie. */
app.post('/api/lab/badaj', (req, res) => labOdp(res, (req.body?.projekt ? Laboratorium.badajPytanie(req.body.projekt, req.body) : Laboratorium.nastepneBadanie(req.body ?? {})).then((r) => (r.arena ? { ...r, sondaz: `/api/lab/arena/${r.arena}` } : r))));
/** Przekucie analizy w projekt: model wyciąga parametry (null = nie było w pliku), UI wypełnia formularz. */
app.post('/api/lab/chipy/analizy/:id/spec', (req, res) => labOdp(res, Laboratorium.specZAnalizy(req.params.id, { model: req.body?.model })));

/**
 * 🔦 LATARNIK — spójność danych firmowych w Twoich Biznesach.
 *
 * Uruchamia strażnika, który mieszka w repozytorium pilnowanej strony
 * (latarnik.mjs), i oddaje jego raport. Most go NIE duplikuje: gdyby logika
 * porównywania żyła w dwóch miejscach, sam Latarnik zacząłby się rozjeżdżać
 * z Latarnikiem — dokładnie ta choroba, którą ma leczyć.
 *
 * ⚠️ Kod wyjścia 1 oznacza ZNALEZIONE ROZJAZDY, a nie awarię skryptu. Dlatego
 * czytamy stdout także wtedy, gdy proces „padł" — inaczej jedyny przypadek,
 * dla którego to narzędzie istnieje, wyglądałby jak błąd serwera.
 */
/** Lista pilnowanych biznesów — dla karty Nocnej Zmiany (wybór, nie wpisywanie z pamięci). */
app.get('/api/latarnik/biznesy', (_req, res) => res.json({ success: true, biznesy: [{ id: 'cafe-martens', nazwa: 'Café Martens & More' }] }));
app.get('/api/latarnik/przeglad', async (req, res) => {
    const KATALOGI = {
        'cafe-martens': 'F:\\Caffe-Martens.com',
    };
    const biznes = String(req.query.biznes || 'cafe-martens');
    try {
        const katalog = KATALOGI[biznes];
        if (!katalog) throw new Error(`Nie znam biznesu „${biznes}". Znane: ${Object.keys(KATALOGI).join(', ')}`);

        const skrypt = path.join(katalog, 'latarnik.mjs');
        // ⚠️ fsSync, nie fs — w tym pliku `fs` to fs/promises i nie ma existsSync.
        if (!fsSync.existsSync(skrypt)) throw new Error(`Brak strażnika: ${skrypt}`);

        let stdout = '';
        try {
            ({ stdout } = await execFileAsync(process.execPath, [skrypt], { cwd: katalog, timeout: 60000 }));
        } catch (e) {
            // Kod 1 = są rozjazdy. Raport jest wtedy najcenniejszy, więc go nie gubimy.
            if (e.stdout) stdout = e.stdout;
            else throw e;
        }
        const rozjazdow = Number((stdout.match(/ROZJAZDÓW:\s*(\d+)/) || [])[1] ?? 0);
        res.json({
            ok: true,
            biznes,
            spojne: /ROZJAZDÓW BRAK/.test(stdout),
            rozjazdow,
            gbpPotwierdzony: !/nikt nie potwierdził/.test(stdout),
            raport: stdout.trim(),
            silnik: 'latarnik.mjs (lokalnie, bez chmury)',
        });
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

/**
 * Policz jeden obraz wybranym silnikiem.
 *
 * Zwraca id zlecenia NATYCHMIAST. Liczenie trwa dziesiątki sekund do kilku
 * minut (zmierzone na FLUX.2 klein: 57–407 s, zależnie od wolnego VRAM-u),
 * więc trzymanie otwartego HTTP przez ten czas jest proszeniem się o timeout
 * po drodze.
 */
app.post('/api/obraz/policz', async (req, res) => {
    const { prompt = '', silnik: idSilnika = '', szerokosc, wysokosc, kroki, ziarno } = req.body ?? {};
    try {
        if (!String(prompt).trim()) throw new Error('Pusty opis — nie ma czego rysować.');

        const stan = await stanWideoZBudzeniem('liczenie obrazu');
        if (!stan.comfy) {
            return res.status(424).json({ success: false, message: stan.braki.join(' | '), braki: stan.braki });
        }

        // ⚠️ Ta sama zasada co przy renderze kadrów: prosimy konkurentów o kartę,
        // zanim zaczniemy. Dwa silniki naraz na 6 GB kończą się martwym CUDA.
        const miejsce = await Karta.zrobMiejsceNaRender({ ollamaBase: OLLAMA_BASE });
        if (!miejsce.wolno) {
            return res.status(507).json({ success: false, message: miejsce.powod, karta: miejsce });
        }

        const silnik = await SilnikiObrazu.jeden(ANTIGRAVITY_DIR, idSilnika || SilnikiObrazu.WBUDOWANE[0].id);
        if (!silnik) throw new Error(`Nie ma silnika obrazu „${idSilnika}".`);

        if (silnik.wlasnaSciezka) {
            const r = await Wideo.generujKadrObraz({ comfyBase: COMFY_BASE, prompt, szerokosc, wysokosc, kroki });
            if (!r.ok) return res.status(422).json({ success: false, message: r.powod });
            return res.json({ success: true, zlecenie: r.zlecenie, silnik: silnik.nazwa });
        }

        const st = await SilnikiObrazu.stan({ silnik, comfyBase: COMFY_BASE, pobierz: fetch });
        if (!st.gotowy) {
            return res.status(424).json({ success: false, message: st.braki.join(' | '), braki: st.braki });
        }

        const r = await Wideo.generujObrazSilnikiem({
            comfyBase: COMFY_BASE, silnik, znalezione: st.znalezione,
            prompt, szerokosc, wysokosc, kroki: kroki ?? silnik.kroki, ziarno,
        });
        if (!r.ok) return res.status(422).json({ success: false, message: r.powod });

        console.log(`[Obraz] 🖌️ zlecenie ${r.zlecenie} — ${silnik.nazwa}, ${r.kroki} kroków`);
        return res.json({ success: true, zlecenie: r.zlecenie, silnik: silnik.nazwa, kroki: r.kroki });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * Czy obraz gotowy.
 *
 * ⚠️ Oddajemy NAZWĘ i adres tej trasy, nie ścieżkę dyskową — z tego samego
 * powodu co przy kadrach produkcji: pełne ścieżki to darmowa mapa dysku.
 */
app.get('/api/obraz/stan', async (req, res) => {
    try {
        const zlecenie = String(req.query.zlecenie || '');
        if (!zlecenie.trim()) return res.status(400).json({ success: false, message: 'Podaj zlecenie.' });

        const s = await Wideo.stanZlecenia(COMFY_BASE, zlecenie, COMFY_DIR);
        if (!s.ok) return res.json({ success: true, gotowe: false, stan: s.powod ?? 'czekam' });
        if (s.blad) return res.status(422).json({ success: false, message: `ComfyUI: ${JSON.stringify(s.blad).slice(0, 300)}` });
        if (!s.gotowe || !s.materialy?.length) return res.json({ success: true, gotowe: false, stan: s.stan ?? 'liczy' });

        const m = s.materialy[0];
        return res.json({
            success: true, gotowe: true,
            nazwa: m.nazwa,
            plik: `/api/obraz/plik?nazwa=${encodeURIComponent(m.nazwa)}${m.podkatalog ? `&pod=${encodeURIComponent(m.podkatalog)}` : ''}`,
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * Podgląd policzonego obrazu.
 *
 * ⚠️ SAMA NAZWA, nie ścieżka — `path.basename` na obu polach. Ścieżka
 * z zewnątrz to zaproszenie do `../../`, a panel bywa wystawiony na telefon
 * przez Kwantowy Tunel.
 */
app.get('/api/obraz/plik', async (req, res) => {
    try {
        const nazwa = path.basename(String(req.query.nazwa || ''));
        const pod = path.basename(String(req.query.pod || 'katedra'));
        if (!nazwa.trim()) return res.status(400).send('Brak nazwy pliku.');

        const korzen = path.resolve(path.join(COMFY_DIR, 'ComfyUI', 'output'));
        const cel = path.resolve(path.join(korzen, pod, nazwa));
        if (!cel.toLowerCase().startsWith(korzen.toLowerCase())) {
            return res.status(403).send('Ten plik nie leży w wyjściu ComfyUI.');
        }
        await fs.access(cel);
        return res.sendFile(cel);
    } catch {
        return res.status(404).send('Nie ma takiego pliku.');
    }
});

/**
 * 🔄 OBRÓT KREACJI — prezentacja produktu z narysowanej kreacji.
 *
 * Suweren: „u krawca nie widzę modułu obracania tych wykonanych… i widzę, że
 * mamy z automatu na wybieg z modelem… może jak już wygeneruje, to można go
 * przenieść do dalszej obróbki, by skupić się na samym ubraniu".
 *
 * ⚠️ SILNIK: Wan 2.2 TI2V-5B, NIE SVD. Stable Video Diffusion wymaga zgody na
 * licencję na koncie HuggingFace Suwerena — nie akceptuję cudzych regulaminów.
 * Wan jest na miejscu i został zmierzony na tym sprzęcie (257 s, 33,18 dB).
 *
 * ⚠️ TO JEST i2v, NIE NOWE LOSOWANIE. Kreacja idzie jako klatka startowa, więc
 * obrót pokazuje TĘ suknię, a nie podobną. Bez klatki startowej dostalibyśmy
 * inny strój przy każdym kliknięciu — i nikt by nie zauważył, że to podmiana.
 *
 * ⚠️ ComfyUI ładuje obrazy wyłącznie ze swojego `input/`, po nazwie. Kopiujemy
 * tam plik (kopiujemy, nie przenosimy — oryginał musi zostać w wyjściu).
 */
app.post('/api/moda/obrot', async (req, res) => {
    const {
        nazwa = '', pod = 'katedra',
        klatek = 49, szerokosc = 704, wysokosc = 480, kroki, ziarno,
        opis = '',
    } = req.body ?? {};
    try {
        // Straż ścieżki taka sama jak w /api/obraz/plik — panel bywa wystawiony
        // przez Kwantowy Tunel na telefon.
        const plik = path.basename(String(nazwa));
        const podkat = path.basename(String(pod || 'katedra'));
        if (!plik.trim()) throw new Error('Nie podałeś kreacji do obrócenia.');

        const korzen = path.resolve(path.join(COMFY_DIR, 'ComfyUI', 'output'));
        const zrodlo = path.resolve(path.join(korzen, podkat, plik));
        if (zrodlo !== korzen && !zrodlo.toLowerCase().startsWith(korzen.toLowerCase() + path.sep)) {
            throw new Error('Ten plik nie leży w wyjściu ComfyUI.');
        }
        await fs.access(zrodlo);

        const przed = await stanWideoZBudzeniem('obrót kreacji');
        if (!przed.comfy) {
            return res.status(424).json({ success: false, message: przed.braki.join(' | '), braki: przed.braki });
        }

        const obrazStartowy = await Arkusz.wstawPlyte(COMFY_DIR, zrodlo);

        /**
         * ⚠️ OPIS CELOWO BEZ WYBIEGU I BEZ MODELKI.
         *
         * Kreacje powstają z promptem „editorial runway photograph", więc silnik
         * sam ciągnie w stronę pokazu: modelka idzie, kamera jedzie, ubranie
         * ucieka z kadru. Tutaj chodzi o SAM PRODUKT, więc mówimy wprost:
         * obrót w miejscu, kamera stoi, całość widoczna.
         */
        const prompt = String(opis).trim() || (
            'slow smooth 360 degree turntable rotation of the garment, '
            + 'the outfit rotates steadily in place on a display form, '
            + 'static locked-off camera, even studio lighting, plain seamless backdrop, '
            + 'the whole garment stays fully in frame, fabric and seams clearly visible, '
            + 'no walking, no runway, no camera movement'
        );

        const r = await Wideo.generujScene({
            comfyBase: COMFY_BASE, prompt,
            szerokosc, wysokosc, klatek, kroki, ziarno,
            obrazStartowy,
        });
        if (!r.ok) return res.status(424).json({ success: false, message: r.powod, braki: r.braki ?? null });

        await Szyna.nadaj({ agent: 'Krawcowa', rodzaj: 'praca', tresc: `zleciła obrót kreacji ${plik} (${r.model})` });
        res.json({ success: true, ...r, klatkaStartowa: obrazStartowy, silnikOpis: 'Wan 2.2 TI2V-5B (i2v, lokalnie)' });
    } catch (e) {
        res.status(400).json({ success: false, message: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  👗 OKNO DLA DZIAŁU MODY — kadry produkcji widziane z zewnątrz
// ══════════════════════════════════════════════════════════════════════════════
//
// Suweren: „można by połączyć katalog produkcyjny z Story, tak by AI z Fashion
// widziały KADRY — zawsze mają z czego robić".
//
// ⚠️ TO JEST OKNO, NIE DRZWI. Dział mody CZYTA kadry i pobiera obrazy; nie
// może przez te trasy nic w produkcji zmienić ani usunąć. Zmiany kart robi się
// tam, gdzie karty żyją — w Tablicy.

/**
 * Kadry, które MAJĄ już obraz albo ujęcie — czyli to, z czego moda ma co robić.
 *
 * ⚠️ Oddajemy `plik` jako ADRES TEJ TRASY, nie ścieżkę dyskową. Ścieżka
 * `F:\...` jest bezużyteczna dla przeglądarki, a wyciek pełnych ścieżek to
 * darmowa mapa dysku dla kogoś, kto dostanie się do panelu przez Kwantowy Tunel.
 */
app.get('/api/produkcja/kadry-z-obrazem', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        if (!projekt.trim()) return res.status(400).json({ success: false, message: 'Podaj projekt.' });

        const wszystkie = await produkcjaLista(ANTIGRAVITY_DIR, projekt);
        const kadry = [];
        for (const k of KolejkaKadrow.poKolei(wszystkie, false)) {
            const m = String(k.zwrot || '').match(/[^\n|"]+\.(png|jpg|jpeg|webp|mp4)/i);
            if (!m) continue;
            const sciezka = m[0].trim();
            try { await fs.access(sciezka); } catch { continue; }

            const nazwa = path.basename(sciezka);
            kadry.push({
                id: k.id,
                tytul: k.tytul,
                opis: k.opis,
                etap: k.etap,
                obraz: /\.(png|jpg|jpeg|webp)$/i.test(nazwa),
                nazwaPliku: nazwa,
                plik: `/api/produkcja/plik?projekt=${encodeURIComponent(projekt)}&plik=${encodeURIComponent(nazwa)}`,
                // Kwestie są tu przydatne: strój bywa odpowiedzią na to, co postać mówi.
                kwestie: Array.isArray(k.kwestie) ? k.kwestie : [],
            });
        }
        return res.json({ success: true, projekt, ile: kadry.length, kadry });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * Podgląd pliku ujęcia. Wyłącznie spod katalogu `ujecia/` danego projektu.
 *
 * ⚠️ PRZYJMUJEMY SAMĄ NAZWĘ PLIKU, nie ścieżkę. Ścieżka z zewnątrz to zaproszenie
 * do `../../` — a panel bywa wystawiony na telefon przez Kwantowy Tunel.
 * `path.basename` ucina wszystko poza nazwą, straż katalogu domyka resztę.
 */
app.get('/api/produkcja/plik', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        const plik = path.basename(String(req.query.plik || ''));
        if (!projekt.trim() || !plik.trim()) return res.status(400).send('Brak projektu albo pliku.');

        const { sciezka } = await utworzProjekt(ANTIGRAVITY_DIR, projekt);
        const korzen = path.resolve(path.join(sciezka, 'ujecia'));
        const cel = path.resolve(path.join(korzen, plik));
        if (!cel.toLowerCase().startsWith(korzen.toLowerCase())) {
            return res.status(403).send('Ten plik nie leży w ujęciach tego projektu.');
        }
        await fs.access(cel);
        return res.sendFile(cel);
    } catch {
        return res.status(404).send('Nie ma takiego pliku.');
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🎨 SILNIKI OBRAZU — czym rysujemy KADR
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Lista silników obrazu wraz z tym, CZY MAJĄ CZYM LICZYĆ.
 *
 * ⚠️ Stan sprawdzamy w ComfyUI, nie na dysku — katalogi wag są mapowane przez
 * `extra_model_paths.yaml`, więc plik leżący na dysku wcale nie musi być dla
 * niego widoczny. `fs.existsSync` dałby fałszywe „gotowe".
 */
app.get('/api/silniki-obrazu', async (_req, res) => {
    try {
        const silniki = await SilnikiObrazu.lista(ANTIGRAVITY_DIR);
        const zeStanem = [];
        for (const s of silniki) {
            // Wan idzie własną ścieżką (podmiana końcówki grafu) i jego stan
            // ocenia `Wideo.stanWideo` — nie duplikujemy tej logiki.
            const st = s.wlasnaSciezka
                ? { gotowy: true, braki: [], znalezione: {}, uwaga: 'Stan sprawdza tor wideo.' }
                : await SilnikiObrazu.stan({ silnik: s, comfyBase: COMFY_BASE, pobierz: fetch }).catch((e) => ({ gotowy: false, braki: [e.message], znalezione: {} }));
            zeStanem.push({
                id: s.id, nazwa: s.nazwa, opis: s.opis, kroki: s.kroki,
                wbudowany: !!s.wbudowany, graf: s.graf,
                gotowy: st.gotowy, braki: st.braki, znalezione: st.znalezione,
            });
        }
        return res.json({ success: true, silniki: zeStanem, domyslny: SilnikiObrazu.WBUDOWANE[0].id });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/** Dodaj albo popraw WŁASNY silnik. Wbudowanych nie ruszamy. */
app.post('/api/silniki-obrazu', async (req, res) => {
    try {
        const s = await SilnikiObrazu.zapisz(ANTIGRAVITY_DIR, req.body ?? {});
        console.log(`[Silniki obrazu] 🎨 zapisany „${s.nazwa}" (graf ${s.graf}, ${s.kroki} kroków)`);
        return res.json({ success: true, silnik: s });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/silniki-obrazu/:id', async (req, res) => {
    try {
        return res.json({ success: true, silnik: await SilnikiObrazu.usun(ANTIGRAVITY_DIR, req.params.id) });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * 🚦 Kto trzyma kartę graficzną.
 *
 * ⚠️ ISTNIEJE, BO KOMUNIKAT „zamknij VoiceStudio" BYŁ BEZUŻYTECZNY, gdy
 * VoiceStudio było już zamknięte, a kartę trzymała Ollama. Panel ma pokazywać
 * WINOWAJCĘ z nazwy i liczbą megabajtów, a nie kazać Suwerenowi zgadywać,
 * który z trzech programów zjadł pamięć.
 */
app.get('/api/karta/stan', async (_req, res) => {
    try {
        const [karta, glos, mysl] = await Promise.all([
            Karta.stanKarty(),
            Karta.modeleGlosu(),
            Karta.modeleMysli(OLLAMA_BASE),
        ]);
        return res.json({
            success: true,
            karta,
            progi: { render: Karta.POTRZEBA_NA_RENDER, mowa: Karta.POTRZEBA_NA_MOWE },
            wystarczyNaRender: !karta.znane || karta.wolneMiB >= Karta.POTRZEBA_NA_RENDER,
            trzymaja: [
                ...(glos.modele ?? []).filter((m) => /cuda|gpu/i.test(m.urzadzenie))
                    .map((m) => ({ kto: 'VoiceStudio', co: m.nazwa || m.id, vramMiB: m.vramMiB })),
                ...(mysl.modele ?? []).map((m) => ({ kto: 'Ollama', co: m.nazwa, vramMiB: m.vramMiB })),
            ],
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/** Poproś wszystkich o oddanie karty. Nikogo nie ubija — patrz RuchNaKarcie.js. */
app.post('/api/karta/zwolnij', async (_req, res) => {
    try {
        const r = await Karta.zrobMiejsceNaRender({ ollamaBase: OLLAMA_BASE });
        const ile = (r.zwolniono?.zdjete ?? []).reduce((s, m) => s + (m.vramMiB || 0), 0);
        console.log(`[Karta] 🚦 zwolniono ${ile} MiB — wolne ${r.przed?.wolneMiB} → ${r.po?.wolneMiB} MiB`);
        return res.json({ success: true, ...r });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * Co stoi na przeszkodzie, żeby film przestał być niemy.
 *
 * ⚠️ Odpowiada NA TRZY OSOBNE PYTANIA, bo to trzy osobne braki i mieszanie
 * ich dałoby bezużyteczne „nie da się”: czy są kwestie do powiedzenia, czy są
 * głosy w bibliotece, i czy VoiceStudio w ogóle stoi.
 */
app.get('/api/dialogi/stan', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        if (!projekt.trim()) return res.status(400).json({ success: false, message: 'Podaj projekt.' });

        const kadry = await produkcjaLista(ANTIGRAVITY_DIR, projekt);
        const glosy = await Assety.lista(ANTIGRAVITY_DIR, projekt, 'glos').catch(() => []);
        const zKwestiami = kadry.filter((k) => Array.isArray(k.kwestie) && k.kwestie.length);

        // Kto mówi, a nie ma głosu — to jedyna lista, która realnie blokuje.
        const mowiacy = new Map();
        for (const k of zKwestiami) {
            for (const q of k.kwestie) {
                const kto = String(q.kto || '').trim();
                if (kto) mowiacy.set(kto.toLowerCase(), kto);
            }
        }
        const bezGlosu = [...mowiacy.values()].filter((kto) => !Dialogi.dopasujGlos(kto, glosy));

        let silnik = { zywe: false, braki: ['Nie pytano.'] };
        try { silnik = await GlosStudio.stan(); } catch (e) { silnik = { zywe: false, braki: [e.message] }; }

        return res.json({
            success: true, projekt,
            kart: kadry.length,
            kartZKwestiami: zKwestiami.length,
            kwestii: zKwestiami.reduce((s, k) => s + k.kwestie.length, 0),
            glosy: glosy.map((g) => g.nazwa),
            mowiacy: [...mowiacy.values()],
            bezGlosu,
            silnik: { zywe: !!silnik.zywe, baza: silnik.baza ?? null, glosy: silnik.glosy ?? [], braki: silnik.braki ?? [] },
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * Dopisz kwestie do JUŻ ISTNIEJĄCYCH kadrów.
 *
 * PO CO. SOLLET ma 218 kart rozpisanych, zanim kwestie w ogóle istniały
 * w modelu danych — zmierzone: 0 z 218 miało cokolwiek do powiedzenia. Bez tego
 * przejścia ścieżka dialogowa działałaby wyłącznie dla odcinków pisanych OD NOWA,
 * czyli nie dałaby nic temu, co już jest.
 *
 * ⚠️ PACZKAMI PO 20 KADRÓW. Dwieście osiemnaście opisów naraz to prompt, którego
 * mały model nie utrzyma — zaczyna gubić numery i przypisywać kwestie nie tym kadrom.
 *
 * ⚠️ WŁASNE WOŁANIE MODELU Z `think: false`, a nie wspólny `piszModelem`.
 * Powod jest zmierzony: bez tego pola model przepala cały budżet tokenów na blok
 * myślenia i oddaje PUSTĄ treść (eval_count 60, response ""). Przy kwestiach,
 * gdzie budzet jest ciasny, to różnica między odpowiedzią a ciszą.
 */
app.post('/api/dialogi/dopisz', async (req, res) => {
    const { projekt = '', etap = 'KADR', ile = 60, nadpisuj = false, model = null } = req.body ?? {};
    try {
        if (!String(projekt).trim()) throw new Error('Podaj projekt.');

        const wszystkie = KolejkaKadrow.poKolei(
            (await produkcjaLista(ANTIGRAVITY_DIR, projekt)).filter((k) => k.etap === String(etap).toUpperCase()),
            false,
        );
        const doPracy = wszystkie
            .filter((k) => nadpisuj || !(Array.isArray(k.kwestie) && k.kwestie.length))
            .slice(0, Math.max(1, Number(ile) || 60));
        if (!doPracy.length) {
            return res.status(400).json({ success: false, message: `Wszystkie kadry na etapie ${etap} maj\u0105 ju\u017c kwestie. U\u017cyj nadpisuj=true.` });
        }

        const assety = await Assety.lista(ANTIGRAVITY_DIR, projekt).catch(() => []);
        const obsada = assety.filter((a) => a.typ === 'aktor')
            .map((a) => `${a.nazwa} \u2014 ${String(a.notatki || '').replace(/\s+/g, ' ').slice(0, 140)}`)
            .join('\n');
        if (!obsada.trim()) {
            return res.status(400).json({ success: false, message: 'Projekt nie ma ani jednego aktora w bibliotece \u2014 nie ma komu m\u00f3wi\u0107.' });
        }

        const silnik = String(model || '').trim() || DEFAULT_LLM;
        const pytaj = async (system, prompt) => {
            const r = await fetch(`${OLLAMA_BASE}/api/chat`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: silnik,
                    messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }],
                    stream: false, think: false,
                    options: { num_predict: 1500, temperature: 0.6, num_ctx: 8192 },
                }),
                signal: AbortSignal.timeout(15 * 60 * 1000),
            });
            if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
            return String((await r.json())?.message?.content ?? '').trim();
        };

        const t0 = Date.now();
        const wyniki = [];
        let dopisanych = 0;
        let pozaKadrem = 0;

        for (let i = 0; i < doPracy.length; i += Realizacja.KADROW_NA_PYTANIE) {
            const paczka = doPracy.slice(i, i + Realizacja.KADROW_NA_PYTANIE)
                .map((k, j) => ({ nr: i + j + 1, id: k.id, tytul: k.tytul, opis: k.opis }));
            const zakres = `${paczka[0].nr}-${paczka.at(-1).nr}`;

            let odczytane = [];
            try {
                const { system, prompt } = Realizacja.promptKwestii({ kadry: paczka, obsada });
                odczytane = Realizacja.odczytajKwestie(await pytaj(system, prompt), paczka.map((k) => k.nr));
            } catch (e) {
                // ⚠️ Jedna nieudana paczka nie zatrzymuje pozostałych dziesięciu.
                wyniki.push({ paczka: zakres, blad: e.message });
                continue;
            }

            for (const w of odczytane) {
                const karta = paczka.find((k) => k.nr === w.nr);
                if (!karta) continue;
                const kwestie = znormalizujKwestie(w.kwestie);
                if (!kwestie.length) continue;

                // ⚠️ KTO MÓWI, A NIE MA GO W OPISIE. Model łamie tę zasadę — zmierzone
                // na SOLLET: w kadrze „Migotanie koloru” (czysta abstrakcja, bez ludzi)
                // kazał mówić Solicie. NIE kasujemy tego — głos zza kadru to normalne
                // kino — ale oznaczamy, żeby Suweren zobaczył, gdzie to się dzieje.
                const opis = String(karta.opis || '');
                for (const q of kwestie) {
                    const rdzen = q.kto.slice(0, 4).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                    q.pozaKadrem = !(new RegExp(`(^|[^\\p{L}])${rdzen}`, 'iu').test(opis));
                    if (q.pozaKadrem) pozaKadrem += 1;
                }

                await produkcjaZmien(ANTIGRAVITY_DIR, karta.id, { kwestie });
                dopisanych += 1;
                wyniki.push({ nr: w.nr, id: karta.id, tytul: karta.tytul, kwestie });
            }
        }

        console.log(`[Dialogi] \u270d\ufe0f \u201e${projekt}\u201d: kwestie w ${dopisanych} z ${doPracy.length} kadr\u00f3w (${silnik}) w ${Math.round((Date.now() - t0) / 1000)}s`);
        return res.json({
            success: true, projekt, model: silnik,
            przejrzanych: doPracy.length,
            zKwestiami: dopisanych,
            niemych: doPracy.length - dopisanych,
            pozaKadrem,
            wyniki,
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * Nagraj kwestie całego projektu.
 *
 * ⚠️ NAGRANIE NIE JEST DUBBINGIEM. Powstaje z tekstu kwestii i ląduje jako
 * osobny plik w `dialogi/`. Synchronizacji ust nie ma — Wan 2.2 nie animuje
 * mowy i nie udajemy, że animuje.
 */
app.post('/api/dialogi/nagraj', async (req, res) => {
    const { projekt = '', idki = null } = req.body ?? {};
    try {
        if (!String(projekt).trim()) throw new Error('Podaj projekt.');

        const wszystkie = await produkcjaLista(ANTIGRAVITY_DIR, projekt);
        const kadry = idki ? wszystkie.filter((k) => idki.includes(k.id)) : wszystkie;
        const glosy = await Assety.lista(ANTIGRAVITY_DIR, projekt, 'glos').catch(() => []);

        const katalog = await Dialogi.katalogDialogow(ANTIGRAVITY_DIR, projekt);

        const t0 = Date.now();
        // ⚠️ Ta sama zasada, druga strona: prosimy ComfyUI o oddanie karty,
        // żeby mowa nie weszła w kolizję z trwającym renderem.
        const miejsceNaMowe = await Karta.zrobMiejsceNaMowe({ comfyBase: COMFY_BASE });
        if (!miejsceNaMowe.wolno) {
            return res.status(507).json({ success: false, message: miejsceNaMowe.powod, karta: miejsceNaMowe });
        }

        const r = await Dialogi.nagrajProjekt({
            kadry, glosy, katalogDocelowy: katalog,
            naBiezaco: (w) => console.log(`[Dialogi] ${w.ok ? '✓' : '✗'} ${w.tytul}: ${w.ok ? w.udanych + '/' + w.wszystkich : w.powod}`),
        });
        if (!r.ok) return res.status(424).json({ success: false, message: r.powod, ...r });

        console.log(`[Dialogi] 🗣️ „${projekt}”: ${r.nagranych} nagrań z ${r.kartZKwestiami} kart w ${Math.round((Date.now() - t0) / 1000)}s`);
        return res.json({ success: true, katalog, ...r });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});


// ══════════════════════════════════════════════════════════════════════════════
//  👁️ OKO — jajo, które patrzy na assety i pisze, co widzi
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Które assety czekają na opis i jakim okiem będziemy patrzeć.
 *
 * ⚠️ Rozdziela „bez opisu, ale JEST obraz” od „bez opisu i NIE MA obrazu”
 * (głosy, muzyka). Drugiej grupy żadne oko nie załatwi — i panel ma o tym
 * mówić wprost, zamiast pokazywać wieczne „0 z 9”.
 */
app.get('/api/oko/stan', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        if (!projekt.trim()) return res.status(400).json({ success: false, message: 'Podaj projekt.' });
        const assety = await Assety.lista(ANTIGRAVITY_DIR, projekt);
        const pusty = (a) => !String(a.notatki ?? '').trim();
        const doOpisania = assety.filter((a) => Oko.TYPY_WIDZIALNE.has(a.typ) && pusty(a));
        const bezObrazu = assety.filter((a) => !Oko.TYPY_WIDZIALNE.has(a.typ) && pusty(a));
        return res.json({
            success: true,
            model: Oko.MODEL_WZROKU,
            wszystkich: assety.length,
            zOpisem: assety.filter((a) => !pusty(a)).length,
            doOpisania: doOpisania.map((a) => ({ id: a.id, nazwa: a.nazwa, typ: a.typ })),
            bezObrazu: bezObrazu.map((a) => ({ nazwa: a.nazwa, typ: a.typ })),
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * Sprawdź, czy model NAPRAWDĘ widzi — liczeniem tokenów, nie pytaniem go o to.
 *
 * ⚠️ Ta trasa istnieje, bo gemma4:latest odpowiada „Proszę o załączenie obrazu”,
 * choć obraz dostała (+152 tokeny wejścia). Modelom nie wierzymy na słowo.
 */
app.post('/api/oko/sprawdz-wzrok', async (req, res) => {
    const { projekt = '', id = '', model = Oko.MODEL_WZROKU } = req.body ?? {};
    try {
        const asset = await Assety.jeden(ANTIGRAVITY_DIR, projekt, id);
        if (!asset) throw new Error('Nie ma takiego assetu — nie ma na czym sprawdzać wzroku.');
        const obrazy = await Oko.obrazyAssetu(ANTIGRAVITY_DIR, projekt, asset);
        if (!obrazy.length) throw new Error(`„${asset.nazwa}” nie ma referencji graficznej.`);
        const w = await Oko.czyWidzi({ ollamaBase: OLLAMA_BASE, model, obrazBase64: obrazy[0].base64 });
        return res.json({ success: true, model, ...w });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/** Jedno spojrzenie na jeden asset. `zapisz: false` = pokaż, ale nie nadpisuj. */
app.post('/api/oko/opisz', async (req, res) => {
    const { projekt = '', id = '', model = Oko.MODEL_WZROKU, zapisz = true } = req.body ?? {};
    try {
        const w = await Oko.opisz({ katalogKatedry: ANTIGRAVITY_DIR, projekt, id, ollamaBase: OLLAMA_BASE, model });
        if (!w.ok) return res.status(422).json({ success: false, message: w.powod, ...w });
        if (zapisz) { await Oko.zapiszOpis({ katalogKatedry: ANTIGRAVITY_DIR, projekt, id, opis: w.opis }); w.zapisane = true; }
        console.log(`[Oko] 👁️ ${w.typ} „${w.nazwa}” opisany w ${w.sekundy}s (${w.obrazow} obr., ${w.model})`);
        return res.json({ success: true, ...w });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * Przegląd całej biblioteki. Odpowiada DOPIERO po ostatnim asecie — ~29 s
 * na sztukę, więc przy dziewięciu to około 4,5 minuty.
 */
app.post('/api/oko/przejrzyj', async (req, res) => {
    const { projekt = '', model = Oko.MODEL_WZROKU, nadpisuj = false, idki = null } = req.body ?? {};
    try {
        if (!String(projekt).trim()) throw new Error('Podaj projekt.');
        const t0 = Date.now();
        const r = await Oko.przejrzyj({
            katalogKatedry: ANTIGRAVITY_DIR, projekt, ollamaBase: OLLAMA_BASE, model, nadpisuj, idki,
            naBiezaco: (w) => console.log(`[Oko] ${w.ok ? '✓' : '✗'} ${w.nazwa}: ${w.ok ? w.sekundy + 's' : w.powod}`),
        });
        console.log(`[Oko] 👁️ przegląd „${projekt}”: ${r.opisane}/${r.przejrzane} w ${Math.round((Date.now() - t0) / 1000)}s`);
        return res.json({ success: true, ...r });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});


// ══════════════════════════════════════════════════════════════════════════════
//  🧭 ARKUSZ WIELOKĄTOWY — jedna klatka → widoki z wielu stron kamery
// ══════════════════════════════════════════════════════════════════════════════

/** Czy w ogóle jest czym liczyć. Odpowiada CO DO PLIKU, czego brakuje. */
app.get('/api/arkusz/stan', async (req, res) => {
    try {
        const s = await Arkusz.stanSilnika(COMFY_BASE);
        return res.json({
            success: true, ...s,
            katy: { scena: Arkusz.KATY_SCENY, aktor: Arkusz.KATY_AKTORA },
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/arkusz/policz { projekt, id, katy?, ziarno? }
 *
 * Liczy widoki SZEREGOWO i zapisuje je w katalogu assetu. Zadanie żyje
 * w pamięci mostu — front odpytuje o stan, bo siedem widoków to minuty.
 */
const zadaniaArkusza = new Map();

app.post('/api/arkusz/policz', async (req, res) => {
    const { projekt = '', id = '', katy = null, ziarno = null } = req.body ?? {};
    try {
        const stan = await Arkusz.stanSilnika(COMFY_BASE);
        if (!stan.gotowe) return res.status(424).json({ success: false, message: stan.braki.join(' | '), braki: stan.braki });

        const asset = await Assety.jeden(ANTIGRAVITY_DIR, projekt, id);
        // Płyta odniesienia: dla sceny plate, dla aktora twarz. Bez niej nie ma z czego liczyć.
        const zrodlo = asset.referencje?.plyta ?? asset.referencje?.aktor ?? asset.miniatura ?? null;
        if (!zrodlo) throw new Error(`Asset „${asset.nazwa}" nie ma jeszcze obrazu odniesienia — wgraj go najpierw.`);

        const wszystkie = Arkusz.katy(asset.typ);
        const wybrane = Array.isArray(katy) && katy.length
            ? wszystkie.filter((k) => katy.includes(k.klucz))
            : wszystkie;

        const plyta = await Arkusz.wstawPlyte(COMFY_DIR, zrodlo, `katedra_${slugProjektu(asset.nazwa)}.png`);
        const katAssetu = path.dirname(zrodlo);

        const zadanieId = `ark-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
        const z = {
            id: zadanieId, stan: 'liczy', projekt, asset: asset.nazwa, typ: asset.typ,
            start: Date.now(), blad: null,
            pozycje: wybrane.map((k) => ({ ...k, stan: 'czeka', plik: null, sekundy: null, powod: null })),
        };
        zadaniaArkusza.set(zadanieId, z);

        (async () => {
            for (const poz of z.pozycje) {
                if (z.przerwane) { poz.stan = 'pominiete'; continue; }
                const t0 = Date.now();
                poz.stan = 'liczy';
                try {
                    const { graf } = Arkusz.graf({
                        modele: stan.modele, plyta, prompt: poz.prompt,
                        kotwica: Arkusz.kotwica(asset.typ), kroki: stan.kroki, ziarno,
                        prefiks: `katedra/arkusz_${poz.klucz}`,
                    });
                    const odp = await fetch(`${COMFY_BASE}/prompt`, {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ prompt: graf }),
                    });
                    const d = await odp.json();
                    if (!d?.prompt_id) throw new Error(`ComfyUI odrzucil graf: ${JSON.stringify(d).slice(0, 300)}`);

                    const wynik = await czekajNaPlikWideo(d.prompt_id, () => z.przerwane);
                    if (!wynik) throw new Error('Przerwane przez Suwerena.');
                    // Nazwa 1:1 z konwencja Director Studio, zeby arkusze z obu
                    // narzedzi lezaly obok siebie czytelnie.
                    const cel = path.join(katAssetu, `${slugProjektu(asset.nazwa)}_${String(poz.nr).padStart(2, '0')}_${poz.klucz}.png`);
                    await fs.copyFile(wynik, cel);
                    poz.plik = cel;
                    poz.stan = 'gotowe';
                } catch (e) {
                    poz.stan = 'blad';
                    poz.powod = e.message;
                } finally {
                    poz.sekundy = Math.round((Date.now() - t0) / 1000);
                }
            }

            const gotowe = z.pozycje.filter((p) => p.plik);
            if (gotowe.length) {
                await Assety.zapisz(ANTIGRAVITY_DIR, projekt, {
                    id: asset.id, typ: asset.typ, nazwa: asset.nazwa,
                    arkusz: gotowe.map((p) => ({ klucz: p.klucz, nr: p.nr, plik: p.plik })),
                }).catch(() => { /* indeks zapiszemy przy nastepnej zmianie */ });
            }
            if (z.stan === 'liczy') z.stan = gotowe.length ? 'gotowe' : 'blad';
            if (!gotowe.length && !z.blad) z.blad = 'Zaden widok sie nie policzyl — powody przy pozycjach.';
        })().catch((e) => { z.stan = 'blad'; z.blad = e.message; });

        return res.json({ success: true, id: zadanieId, ile: z.pozycje.length, kroki: stan.kroki, ostrzezenie: stan.ostrzezenie ?? null });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.get('/api/arkusz/zadanie/:id', (req, res) => {
    const z = zadaniaArkusza.get(req.params.id);
    if (!z) return res.status(404).json({ success: false, message: 'Nie znam tego zadania. Most mogl sie zrestartowac — arkusze zyja w jego pamieci.' });
    return res.json({
        success: true, id: z.id, stan: z.stan, asset: z.asset, typ: z.typ, blad: z.blad,
        sekundOd: Math.round((Date.now() - z.start) / 1000),
        pozycje: z.pozycje.map((p) => ({ nr: p.nr, klucz: p.klucz, stan: p.stan, plik: p.plik, sekundy: p.sekundy, powod: p.powod })),
    });
});

app.post('/api/arkusz/zadanie/:id/przerwij', (req, res) => {
    const z = zadaniaArkusza.get(req.params.id);
    if (!z) return res.status(404).json({ success: false, message: 'Nie znam tego zadania.' });
    if (z.stan === 'liczy') { z.przerwane = true; z.stan = 'przerwane'; }
    return res.json({ success: true, stan: z.stan });
});


// ══════════════════════════════════════════════════════════════════════════════
//  📋 BRIEF POKOJU OPOWIESCI — zywe streszczenie ustalen z rozmowy
// ══════════════════════════════════════════════════════════════════════════════

app.post('/api/opowiesc/brief', async (req, res) => {
    const { historia = [], model } = req.body ?? {};
    try {
        const sensowne = (historia ?? []).filter((t) => t?.tresc?.trim());
        if (sensowne.length < 2) {
            return res.status(400).json({ success: false, message: 'Za krotka rozmowa — brief nie ma z czego powstac.' });
        }
        const { system, prompt } = Brief.promptBriefu(sensowne);
        const { tekst, silnik } = await piszModelem(model, system, prompt);
        return res.json({ success: true, brief: Brief.odczytaj(tekst), model: silnik, coIleTur: Brief.CO_ILE_TUR });
    } catch (e) {
        return res.status(502).json({ success: false, message: e.message });
    }
});

// ── KOLEJKA KADROW: wyrenderuj wszystkie po kolei i zmontuj w jedno ─────────

/**
 * GET /api/kolejka/kadry?projekt=&etap=KADR
 * Co czeka na render: karty etapu KADR bez gotowego ujecia.
 */
// ── HISTORIA POKOJU OPOWIESCI ───────────────────────────────────────────────

app.get('/api/opowiesc/historia', async (req, res) => {
    try { return res.json({ success: true, rozmowy: await Opowiesc.historia(ANTIGRAVITY_DIR) }); }
    catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

app.post('/api/opowiesc/historia', async (req, res) => {
    try {
        const r = await Opowiesc.zapisz(ANTIGRAVITY_DIR, req.body ?? {});
        return res.json({ success: true, rozmowa: r });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/opowiesc/historia/:id', async (req, res) => {
    try { return res.json({ success: true, rozmowa: await Opowiesc.usun(ANTIGRAVITY_DIR, req.params.id) }); }
    catch (e) { return res.status(404).json({ success: false, message: e.message }); }
});

/**
 * POST /api/rezyser/projekty/usun { nazwa, potwierdzenie, zKadrami?, zKatalogiem? }
 *
 * Suweren: „w Rezyserze i pamieci nie mozna usunac projektow".
 * Teraz mozna — ale POTWIERDZENIEM NAZWY, bo panel bywa wystawiony przez
 * Kwantowy Tunel na telefon, a kasowanie kanonu jest nieodwracalne.
 *
 * Kasujemy WARSTWAMI i mowimy, co znika: pamiec zawsze, kadry i katalog
 * tylko na zyczenie. Pliki wideo zostaja ZAWSZE — one sa efektem godzin
 * liczenia i nie moga zniknac przy porzadkach.
 */
app.post('/api/rezyser/projekty/usun', async (req, res) => {
    const { nazwa = '', potwierdzenie = '', zKadrami = false, zKatalogiem = false } = req.body ?? {};
    try {
        const wynik = { pamiec: null, kadrow: 0, katalog: null };

        // 1. Pamiec (fakty + odcinki) — z potwierdzeniem nazwy.
        // ⚠️ Projekt moze istniec SAM KATALOG, bez wpisu w pamieci (np. zalozony
        // przez muzyke albo plan publikacji). Brak pamieci nie moze wtedy blokowac
        // sprzatania — inaczej takiego projektu nie da sie usunac wcale.
        try {
            wynik.pamiec = await usunSerial(ANTIGRAVITY_DIR, nazwa, potwierdzenie);
        } catch (e) {
            const brakPamieci = /nie istnieje w pami/i.test(e.message);
            if (!brakPamieci) throw e;              // zle potwierdzenie — odmawiamy
            if (!zKadrami && !zKatalogiem) throw e; // nie ma pamieci i nic wiecej do zrobienia
            if (String(potwierdzenie || '').trim() !== String(nazwa).trim()) {
                throw new Error(`Potwierdź kasowanie, przepisując dokładną nazwę: „${nazwa}".`);
            }
            wynik.pamiec = { serial: nazwa, faktow: 0, odcinkow: 0, uwaga: 'Ten projekt nie miał wpisu w pamięci — istniał tylko jako katalog.' };
        }

        // 2. Karty z Tablicy Produkcji — tylko gdy poproszono.
        if (zKadrami) {
            const kadry = (await produkcjaLista(ANTIGRAVITY_DIR, nazwa)).filter((k) => k.projekt === nazwa);
            for (const k of kadry) {
                try { await produkcjaUsun(ANTIGRAVITY_DIR, k.id); wynik.kadrow += 1; } catch { /* juz nie ma */ }
            }
        }

        // 3. Katalog projektu — `usunProjekt` sam odmowi, gdy sa w nim odcinki.
        if (zKatalogiem) {
            try {
                const u = await usunProjekt(ANTIGRAVITY_DIR, slugProjektu(nazwa));
                wynik.katalog = u.sciezka;
            } catch (e) {
                wynik.katalog = `nie skasowany: ${e.message}`;
            }
        }

        console.log('[Rezyser] Skasowano projekt ' + nazwa + ' (kadrow: ' + wynik.kadrow + ')');
        return res.json({ success: true, ...wynik });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.get('/api/kolejka/kadry', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        const etap = String(req.query.etap || 'KADR').toUpperCase();
        const kadry = await produkcjaLista(ANTIGRAVITY_DIR, projekt);
        // ⚠️ Układamy PO FABULE, nie po dacie — Tablica oddaje najnowsze na
        // wierzchu, więc bez tego podgląd pokazywałby film od końca.
        const wybrane = KolejkaKadrow.poKolei(
            kadry.filter((k) => k.etap === etap),
            String(req.query.odwrotnie || '') === 'true',
        );

        const lista = [];
        for (const k of wybrane) {
            const juz = await KolejkaKadrow.maJuzUjecie(k);
            lista.push({ id: k.id, tytul: k.tytul, opis: k.opis, etap: k.etap, gotowe: juz });
        }
        // ⚠️ CZEGO PROJEKT JUŻ UŻYWA. Suweren: „zostawiamy 704×480 do końca
        // SOLLET”. Sklejka plików o różnych wymiarach nie pójdzie bezstratnie —
        // ffmpeg musi wtedy przekodować całość. Panel dostaje tę liczbę, żeby
        // ustawić się sam, zamiast wymagać pamiętania o tym przy każdym starcie.
        const rozdzielczosc = await Montazownia.rozdzielczoscProjektu(ANTIGRAVITY_DIR, projekt)
            .catch(() => ({ szerokosc: null, wysokosc: null, plikow: 0 }));

        return res.json({
            success: true, projekt, etap,
            kadry: lista,
            doZrobienia: lista.filter((k) => !k.gotowe).length,
            maxNaRaz: KolejkaKadrow.MAX_KADROW,
            rozdzielczosc,
            domyslna: { szerokosc: Wideo.SZEROKOSC_DOMYSLNIE, wysokosc: Wideo.WYSOKOSC_DOMYSLNIE },
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/kolejka/odpal { projekt, etap?, ile?, odNowa?, klatek?, kroki?, sklejaj?, rezyser? }
 *
 * Renderuje PO KOLEI (karta ma 6 GB VRAM — rownolegle to OOM), zapisuje wyniki
 * W KATEDRZE i przesuwa karty na następną kolumnę.
 *
 * ⚠️ CO ROBI KOLEJKA, ZALEŻY OD KOLUMNY. Suweren: „kadr powinien produkować
 * kadry, czyli image, potem przenoszone jest do ruchu, gdzie z tego jest robione
 * wideo, a potem te kafelki wideo na montaż”. Tablica mówiła to od początku
 * (KADR = „nieruchome klatki kluczowe”, RUCH = „ożywienie klatki kluczowej”),
 * ale kolejka liczyła wideo na obu etapach — więc kadr i ujęcie były dwoma
 * niezależnymi losowaniami tego samego opisu, z dwiema różnymi twarzami.
 *
 *   KADR  → jedna klatka (SaveImage, length 1)   → karta idzie na RUCH
 *   RUCH  → ujęcie Z TEJ KLATKI (start_image)     → karta idzie na MONTAŻ
 *   inne  → jak dotąd: wideo z samego tekstu
 */
app.post('/api/kolejka/odpal', async (req, res) => {
    const { projekt = '', etap = 'KADR', ile, odNowa = false, klatek, sekundy, kroki,
        sklejaj = true, odwrotnie = false, rezyser: idRezysera = '', odcinekId = '' } = req.body ?? {};
    try {
        const stan = await stanWideoZBudzeniem('kolejka kadrow');
        if (!stan.gotowe) return res.status(424).json({ success: false, message: stan.braki.join(' | '), braki: stan.braki });

        // ⚠️ KARTA MA 6 GB I DWA PROGRAMY JEJ CHCĄ. Suweren włączył VoiceStudio
        // w trakcie liczenia kadrów i render padł na `CUDA error: unspecified
        // launch failure` — po czym kontekst CUDA był martwy i KAŻDE następne
        // zlecenie wywalało się w 6 sekund, aż do ubicia procesu.
        //
        // Prosimy więc VoiceStudio, żeby oddał kartę, ZANIM zaczniemy. Gdy to
        // nie wystarczy — mówimy wprost, zamiast wchodzić w tę samą ścianę.
        const miejsce = await Karta.zrobMiejsceNaRender({ ollamaBase: OLLAMA_BASE });
        if (!miejsce.wolno) {
            return res.status(507).json({ success: false, message: miejsce.powod, karta: miejsce });
        }
        if (miejsce.zwolniono?.zdjete?.length) {
            const ile = miejsce.zwolniono.zdjete.reduce((s, m) => s + (m.vramMiB || 0), 0);
            console.log(`[Karta] 🚦 zwolniono ${ile} MiB — wolne ${miejsce.przed.wolneMiB} → ${miejsce.po.wolneMiB} MiB`);
        }
        // Mało pamięci, ale bez konkurenta — mówimy o tym i PUSZCZAMY.
        if (miejsce.ostrzezenie) console.warn(`[Karta] ⚠️ ${miejsce.ostrzezenie}`);

        // `odcinekId` (Realizacja Nocna, 2026-09-12): tylko kadry TEGO odcinka — tablica
        // Reżysera realizuje odcinki z osobna, a nie cały serial na raz.
        const wszystkie = KolejkaKadrow.poKolei(
            (await produkcjaLista(ANTIGRAVITY_DIR, projekt)).filter((k) => k.etap === String(etap).toUpperCase() && (!odcinekId || k.sesjaRady === odcinekId)),
            Boolean(odwrotnie),
        );
        if (!wszystkie.length) return res.status(400).json({ success: false, message: `Zaden kadr na etapie ${etap} w projekcie „${projekt}"${odcinekId ? ` (odcinek ${odcinekId})` : ''}.` });

        // Kotwica: biblia projektu + kanon. Bez niej sto ujec rozjedzie sie na sto stron.
        const [biblia, pamiec] = await Promise.all([
            produkcjaBiblia(ANTIGRAVITY_DIR, projekt).catch(() => null),
            rezyserPamiec(ANTIGRAVITY_DIR, projekt).catch(() => null),
        ]);
        const kotwica = [biblia?.tekst || '', (pamiec?.fakty ?? []).map((f) => f.tresc).join('\n')].filter(Boolean).join('\n\n');

        // ⚠️ WYGLĄD OBSADY DO PROMPTU RENDERU. Suweren: „nie bardzo korzysta
        // z przygotowanych assetów — mam wielowymiarową prezentację bytów".
        // Prompt dostawał opis kadru i biblię, ale NIGDY wyglądu Solity — silnik
        // nie miał się czego złapać. `promptZKadru` dokłada teraz opisy TYCH
        // postaci, które w danym kadrze naprawdę występują.
        const assetyProjektu = await Assety.lista(ANTIGRAVITY_DIR, projekt).catch(() => []);

        // ⚠️ REŻYSER NIE JEST OZDOBĄ. Jego styl dopisuje się do każdego promptu,
        // a rozdzielczość, długość ujęcia i liczba kroków idą wprost do ComfyUI.
        // Jawny parametr w żądaniu bije profil — kto wpisał liczbę ręcznie, ten wie,
        // czego chce.
        const rezyser = idRezysera ? await Rezyserzy.jeden(ANTIGRAVITY_DIR, idRezysera) : null;
        if (idRezysera && !rezyser) {
            return res.status(400).json({ success: false, message: `Nie ma reżysera „${idRezysera}”.` });
        }
        const styl = Rezyserzy.promptStylu(rezyser);

        // ⚠️ SILNIK OBRAZU WYBIERAMY TYLKO NA ETAPIE KADR i sprawdzamy go ZANIM
        // ruszymy. Silnik bez wag albo bez węzła w tej wersji ComfyUI wywala się
        // dopiero przy pierwszym zleceniu — po minutach czekania i z cudzym
        // komunikatem, z którego nic nie wynika.
        let silnikObrazu = null;
        let stanObrazu = null;
        if (String(etap).toUpperCase() === 'KADR') {
            const idSilnika = String(req.body?.silnikObrazu || '').trim() || SilnikiObrazu.WBUDOWANE[0].id;
            silnikObrazu = await SilnikiObrazu.jeden(ANTIGRAVITY_DIR, idSilnika);
            if (!silnikObrazu) {
                return res.status(400).json({ success: false, message: `Nie ma silnika obrazu „${idSilnika}".` });
            }
            if (!silnikObrazu.wlasnaSciezka) {
                stanObrazu = await SilnikiObrazu.stan({ silnik: silnikObrazu, comfyBase: COMFY_BASE, pobierz: fetch });
                if (!stanObrazu.gotowy) {
                    return res.status(424).json({
                        success: false,
                        message: `Silnik „${silnikObrazu.nazwa}" nie ma czym liczyć: ${stanObrazu.braki.join(' | ')}`,
                        braki: stanObrazu.braki,
                    });
                }
            }
        }

        // ⚠️ Kolumna decyduje o torze. `etapWlk` jest już wielkimi literami —
        // filtr kart wyżej też po nim chodzi.
        const etapWlk = String(etap).toUpperCase();
        const toKadry = etapWlk === 'KADR';
        const toRuch = etapWlk === 'RUCH';
        const szer = Number(req.body?.szerokosc) || rezyser?.szerokosc || undefined;
        const wys = Number(req.body?.wysokosc) || rezyser?.wysokosc || undefined;
        const sek = Number(sekundy) || rezyser?.sekundNaKadr || undefined;
        const krokow = Number(kroki) || rezyser?.kroki || undefined;

        // Domyslnie pomijamy karty, ktore MAJA juz plik — powtorny render
        // kosztuje minuty i nadpisuje prace, ktora ktos moze akceptowal.
        // ⚠️ „MA JUŻ WYNIK” ZNACZY CO INNEGO NA KAŻDEJ KOLUMNIE. Na etapie KADR
        // szukamy OBRAZU, na pozostałych — pliku wideo. Wspólny sprawdzian
        // kazałby liczyć od nowa każdą kartę, która ma dopiero klatkę.
        const maJuzWynik = async (k) => {
            if (!toKadry) return KolejkaKadrow.maJuzUjecie(k);
            const m = String(k?.zwrot || '').match(/[^\n|"]+\.(png|jpg|jpeg|webp)/i);
            if (!m) return null;
            try { await fs.access(m[0].trim()); return m[0].trim(); } catch { return null; }
        };

        const doKolejki = [];
        for (const k of wszystkie) {
            if (!odNowa && await maJuzWynik(k)) continue;
            const bazowy = KolejkaKadrow.promptZKadru(k, kotwica, assetyProjektu);
            // ⚠️ STYL REŻYSERA DOPISUJEMY NA KOŃCU, nie na początku. Wan waży
            // początek promptu mocniej — tam ma zostać treść kadru, a styl ma
            // go ubrać, nie zastąpić.
            // Na etapie RUCH karta niesie klatkę kluczową z etapu KADR.
            const zrodlo = toRuch
                ? (String(k?.zwrot || '').match(/[^\n|"]+\.(png|jpg|jpeg|webp)/i)?.[0]?.trim() ?? null)
                : null;
            doKolejki.push({ id: k.id, tytul: k.tytul, zrodlo, prompt: styl ? `${bazowy}, ${styl}` : bazowy });
        }
        if (!doKolejki.length) {
            return res.status(400).json({ success: false, message: 'Wszystkie kadry maja juz ujecia. Uzyj odNowa=true, zeby policzyc je jeszcze raz.' });
        }

        const limit = Math.max(1, Math.min(Number(ile) || KolejkaKadrow.MAX_KADROW, KolejkaKadrow.MAX_KADROW));
        const kadry = doKolejki.slice(0, limit);
        const katUjec = await KolejkaKadrow.katalogUjec(ANTIGRAVITY_DIR, projekt);

        const id = KolejkaKadrow.odpal({
            projekt, kadry,
            // ⚠️ Obrazów nie ma jak skleić w film — na etapie KADR sklejka
            // milczkiem by nie powstała, a panel obiecywałby ją dalej.
            sklejaj: toKadry ? false : sklejaj,

            // ⚠️ `sekundy` steruje długością UJĘCIA. Domyślnie 2,04 s (49 klatek);
            // dłuższe ujęcie to mniej renderów na minutę filmu, ale więcej VRAM
            // i czasu na sztukę — na 6 GB to realna granica.
            // KADR → RUCH → MONTAŻ. Poza tymi kolumnami zostaje stare zachowanie.
            nastepnyEtap: toKadry ? 'RUCH' : (toRuch ? 'MONTAZ' : 'RUCH'),

            generuj: async ({ prompt, zrodlo }) => {
                if (toKadry) {
                    // ⚠️ KADR RYSUJE SILNIK OBRAZU, nie silnik wideo. Do 2026-09-10
                    // klatki liczył Wan 2.2 — silnik WIDEO, dla którego pojedynczy
                    // obraz jest produktem ubocznym jednej klatki z czterdziestu
                    // dziewięciu. Rejestr `SilnikiObrazu` pozwala wybrać właściwe
                    // narzędzie i dodać nowe bez tykania kodu.
                    if (silnikObrazu && !silnikObrazu.wlasnaSciezka) {
                        return Wideo.generujObrazSilnikiem({
                            comfyBase: COMFY_BASE,
                            silnik: silnikObrazu,
                            znalezione: stanObrazu?.znalezione ?? {},
                            prompt, szerokosc: szer, wysokosc: wys,
                            kroki: krokow ?? silnikObrazu.kroki,
                        });
                    }
                    // Droga odwrotu: Wan liczący jedną klatkę.
                    return Wideo.generujKadrObraz({
                        comfyBase: COMFY_BASE, prompt,
                        szerokosc: szer, wysokosc: wys, kroki: krokow,
                    });
                }

                // ⚠️ ComfyUI ŁADUJE OBRAZY WYŁĄCZNIE ZE SWOJEGO `input/`, po nazwie —
                // nie po ścieżce. Kopiujemy tam klatkę (nie przenosimy: oryginał
                // musi zostać w projekcie) i podajemy nazwę, którą on widzi.
                let obrazStartowy = '';
                if (toRuch && zrodlo) {
                    try {
                        obrazStartowy = await Arkusz.wstawPlyte(COMFY_DIR, zrodlo);
                    } catch (e) {
                        // ⚠️ Bez klatki ujęcie byłoby NOWYM losowaniem, a nie ożywieniem
                        // tego kadru. Lepiej powiedzieć wprost niż cicho podmienić.
                        throw new Error(`Nie umiem podać klatki kluczowej silnikowi: ${e.message}`);
                    }
                }
                return Wideo.generujScene({
                    comfyBase: COMFY_BASE, prompt, klatek,
                    szerokosc: szer, wysokosc: wys, sekundy: sek, kroki: krokow,
                    obrazStartowy,
                });
            },
            czekaj: czekajNaPlikWideo,

            // Wynik z ComfyUI KOPIUJEMY do katalogu projektu i zwracamy TE sciezke.
            zapisz: async (zComfy, poz) => {
                // Rozszerzenie bierzemy Z PLIKU, który oddał silnik — na etapie KADR
                // to .png, dalej .mp4. Wpisane na sztywno „.mp4” robiłoby z obrazu
                // plik, którego żaden odtwarzacz nie otworzy.
                const rozsz = path.extname(zComfy) || (toKadry ? '.png' : '.mp4');
                const nazwa = `${String(poz.nr).padStart(3, '0')}_${String(poz.tytul || 'ujecie').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40)}${rozsz}`;
                const cel = path.join(katUjec, nazwa);
                await fs.copyFile(zComfy, cel);
                return cel;
            },

            oznacz: async (kadrId, zmiany) => { await produkcjaZmien(ANTIGRAVITY_DIR, kadrId, zmiany); },

            sklej: async (pliki) => CiagDalszy.sklej({
                pliki,
                wyjscie: path.join(katUjec, `_calosc_${Date.now().toString(36)}.mp4`),
                comfyDir: COMFY_DIR,
            }),
        });

        console.log(`[Kolejka] ${kadry.length} kadrow do renderu w projekcie ${projekt} (zadanie ${id}).`);
        await Szyna.nadaj({ agent: 'Klatka', rodzaj: 'praca', tresc: `wziela ${kadry.length} kadrow do renderu (${projekt})` });
        return res.json({ success: true, id, ...KolejkaKadrow.stanZadania(id), pominietych: doKolejki.length - kadry.length, katalog: katUjec });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/kolejka/sklej-projekt { projekt, etapy?, odwrotnie? }
 *
 * Złóż JEDEN film ze WSZYSTKICH ujęć, które już powstały w tym projekcie —
 * w kolejności fabularnej, niezależnie od tego, w ilu przebiegach kolejki je
 * policzono i w jakiej kolejności wtedy szły.
 *
 * ⚠️ PO CO OSOBNA TRASA. Ujęcia powstają godzinami i partiami po kilkanaście.
 * Bez tego jedyną całością byłaby sklejka z ostatniego przebiegu, czyli
 * fragment. Tutaj bierzemy wszystko, co ma plik na dysku.
 *
 * ⚠️ Bierzemy ŚcieŻKĘ Z KARTY, nie zawartość katalogu — w `ujecia/` leżą też
 * poprzednie sklejki i próby, a karta wskazuje ujęcie, które do niej należy.
 */
app.post('/api/kolejka/sklej-projekt', async (req, res) => {
    const { projekt = '', etapy = ['KADR', 'RUCH', 'MONTAZ', 'GOTOWE'], odwrotnie = false } = req.body ?? {};
    try {
        if (!String(projekt).trim()) throw new Error('Bez nazwy projektu nie wiem, co sklejam.');

        const chciane = new Set((Array.isArray(etapy) ? etapy : [etapy]).map((e) => String(e).toUpperCase()));
        const wszystkie = KolejkaKadrow.poKolei(
            (await produkcjaLista(ANTIGRAVITY_DIR, projekt)).filter((k) => chciane.has(k.etap)),
            Boolean(odwrotnie),
        );

        const pliki = [];
        const spis = [];
        for (const k of wszystkie) {
            const p = await KolejkaKadrow.maJuzUjecie(k);
            if (!p) continue;
            pliki.push(p);
            spis.push({ tytul: k.tytul, etap: k.etap, plik: p });
        }
        if (pliki.length < 2) {
            throw new Error(`Znalaz\u0142em ${pliki.length} uj\u0119\u0107 z plikiem \u2014 do sklejenia trzeba co najmniej dw\u00f3ch.`);
        }

        const katUjec = await KolejkaKadrow.katalogUjec(ANTIGRAVITY_DIR, projekt);
        const wyjscie = path.join(katUjec, `_film_${Date.now().toString(36)}.mp4`);
        const r = await CiagDalszy.sklej({ pliki, wyjscie, comfyDir: COMFY_DIR });

        console.log(`[Kolejka] Sklejono ${pliki.length} uj\u0119\u0107 projektu ${projekt} \u2192 ${wyjscie}`);
        return res.json({ success: true, film: r.plik ?? wyjscie, sklejka: r.metoda ?? null, ujec: pliki.length, spis });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.get('/api/kolejka/:id', (req, res) => {
    const s = KolejkaKadrow.stanZadania(req.params.id);
    if (!s) return res.status(404).json({ success: false, message: 'Nie znam tego zadania. Most mogl sie zrestartowac — kolejki zyja w jego pamieci.' });
    return res.json({ success: true, ...s });
});

app.get('/api/kolejka', (req, res) => res.json({ success: true, zadania: KolejkaKadrow.listaZadan() }));

app.post('/api/kolejka/:id/przerwij', (req, res) => {
    try { return res.json({ success: true, ...KolejkaKadrow.przerwij(req.params.id) }); }
    catch (e) { return res.status(404).json({ success: false, message: e.message }); }
});

app.get('/api/blender/ruchy', (req, res) => res.json({ success: true, ruchy: Blender.RUCHY }));

/** POST /api/blender/studio { projekt, kadr, nazwa?, aktorow? } — plan z kadru. */
app.post('/api/blender/studio', async (req, res) => {
    try {
        const s = await Blender.zbudujStudio(req.body ?? {});
        const stan = await Blender.stanBlendera();
        if (!stan.jest) return res.json({ success: true, ...s, blender: stan, zbudowane: false });

        const r = await Blender.uruchom(s.skrypt);
        console.log('[Studio] ' + path.basename(r.scena) + ' z kadru ' + path.basename(s.kadr));
        return res.json({ success: true, ...s, scena: r.scena, blender: stan, zbudowane: true });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/blender/ujecie { blend, ruch, sekundy?, fps?, szerokosc?, wysokosc? }
 * TeOgochi w roli kamerzysty: render ujecia w gotowym studiu.
 * UWAGA: to RENDER, nie generacja — Blender liczy klatki z tej sceny.
 */
app.post('/api/blender/ujecie', async (req, res) => {
    const { fps = 24 } = req.body ?? {};
    try {
        const stan = await Blender.stanBlendera();
        if (!stan.jest) return res.status(424).json({ success: false, message: stan.powod + ' ' + stan.cozrobic });

        const u = await Blender.skryptUjecia(req.body ?? {});
        const start = Date.now();
        await Blender.uruchom(u.skrypt);
        const film = await Blender.zlozKlatki(u.wyjscieBaza, Number(fps) || 24);
        const sekund = Math.round((Date.now() - start) / 1000);

        console.log('[Kamerzysta] ' + u.ruch + ': ' + film.klatek + ' klatek w ' + sekund + ' s');
        await Szyna.nadaj({ agent: 'Klatka', rodzaj: 'praca', tresc: 'nakrecila ujecie w studiu (' + u.ruch + ', ' + film.klatek + ' klatek)' });
        return res.json({ success: true, ...film, ruch: u.ruch, sekund });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/** GET/POST /api/tgs/scenografie — przekazanie sceny do TeO Game Studio. */
app.get('/api/tgs/scenografie', async (req, res) => {
    try { return res.json({ success: true, ...(await Scenografie.lista()) }); }
    catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

app.post('/api/tgs/scenografie', async (req, res) => {
    const { blend = null, ...reszta } = req.body ?? {};
    try {
        // Gdy przychodzi .blend, sami robimy z niego .glb — przegladarka .blend
        // nie czyta, a Suweren nie ma powodu znac tej roznicy.
        let glb = reszta.glb;
        if (!glb && blend) {
            const g = await Blender.skryptGlb({ blend, nazwa: reszta.nazwa });
            await Blender.uruchom(g.skrypt);
            glb = g.glb;
        }
        if (!glb) return res.status(400).json({ success: false, message: 'Podaj .glb albo .blend do konwersji.' });

        const w = await Scenografie.przekaz({ ...reszta, glb, blend });
        console.log('[TGS] Scenografia ' + w.wpis.nazwa + ' -> ' + w.wpis.url);
        return res.json({ success: true, ...w });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── PRODUKTY MARKI ──────────────────────────────────────────────────────────

app.get('/api/produkty', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        const d = await Produkty.wczytaj(ANTIGRAVITY_DIR, projekt);
        return res.json({ success: true, ...d, narzedzia: Produkty.NARZEDZIA, stany: Produkty.STANY });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/** POST /api/produkty/wymysl { projekt, ile? } — produkty z filarow uniwersum. */
app.post('/api/produkty/wymysl', async (req, res) => {
    const { projekt = '', ile = 5, model } = req.body ?? {};
    try {
        const u = await Uniwersum.wczytaj(ANTIGRAVITY_DIR, projekt);
        if (!u) return res.status(400).json({ success: false, message: 'Produkty wyrastaja z uniwersum — najpierw je zaloz w zakladce UNIWERSUM.' });

        const p = await rezyserPamiec(ANTIGRAVITY_DIR, projekt);
        const { system, prompt } = Produkty.promptProduktow({
            uniwersum: u, kanon: (p.fakty ?? []).map((f) => f.tresc), ile: Number(ile) || 5,
        });
        const { tekst, silnik } = await piszModelem(model, system, prompt);
        const wymyslone = Produkty.odczytaj(tekst, Number(ile) || 5);
        const w = await Produkty.dopisz(ANTIGRAVITY_DIR, projekt, wymyslone);

        console.log('[Produkty] ' + w.dodane.length + ' nowych dla ' + projekt);
        return res.json({ success: true, model: silnik, ...w, narzedzia: Produkty.NARZEDZIA });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.post('/api/produkty/stan', async (req, res) => {
    const { projekt = '', id = '', stan = '' } = req.body ?? {};
    try { return res.json({ success: true, produkt: await Produkty.zmienStan(ANTIGRAVITY_DIR, projekt, id, stan) }); }
    catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});

app.get('/api/uniwersum', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        return res.json({ success: true, uniwersum: await Uniwersum.wczytaj(ANTIGRAVITY_DIR, projekt) });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/** POST /api/uniwersum/zaloz { projekt } — RAZ, po pierwszym odcinku. */
app.post('/api/uniwersum/zaloz', async (req, res) => {
    const { projekt = '', model } = req.body ?? {};
    try {
        const p = await rezyserPamiec(ANTIGRAVITY_DIR, projekt);
        if (!(p.odcinki ?? []).length) {
            return res.status(400).json({ success: false, message: 'Uniwersum wyprowadza się z tego, co powstało — najpierw zrób choć jeden odcinek.' });
        }
        const { system, prompt } = Uniwersum.promptZalozenia({
            projekt,
            kanon: (p.fakty ?? []).map((f) => f.tresc),
            odcinki: p.odcinki,
        });
        const { tekst, silnik } = await piszModelem(model, system, prompt);
        const u = await Uniwersum.zaloz(ANTIGRAVITY_DIR, projekt, Uniwersum.odczytajZalozenie(tekst));
        console.log(`[Uniwersum] 🌌 „${u.domena}" założone dla ${projekt}.`);
        return res.json({ success: true, model: silnik, uniwersum: u });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/uniwersum/rozwin { projekt, ile? }
 * Kampania wraca do Reżysera jako odcinki w planie — pętla się zamyka.
 */
app.post('/api/uniwersum/rozwin', async (req, res) => {
    const { projekt = '', ile = 3, model } = req.body ?? {};
    try {
        const u = await Uniwersum.wczytaj(ANTIGRAVITY_DIR, projekt);
        if (!u) return res.status(400).json({ success: false, message: 'To uniwersum jeszcze nie istnieje — najpierw je załóż.' });

        const p = await rezyserPamiec(ANTIGRAVITY_DIR, projekt);
        const { system, prompt } = Uniwersum.promptRozwiniecia({
            uniwersum: u,
            kanon: (p.fakty ?? []).map((f) => f.tresc),
            odcinki: p.odcinki ?? [],
            ile: Number(ile) || 3,
        });
        const { tekst, silnik } = await piszModelem(model, system, prompt);
        const kampania = Uniwersum.odczytajRozwiniecie(tekst, Number(ile) || 3);

        // Odcinki kampanii lądują W PLANIE — czyli u Reżysera, gotowe do realizacji.
        const dodane = await dodajOdcinki(ANTIGRAVITY_DIR, projekt, kampania.odcinki);
        const po = await Uniwersum.dopiszKampanie(ANTIGRAVITY_DIR, projekt, kampania, dodane.dodane.map((o) => o.id));

        await Szyna.nadaj({
            agent: 'Rezyser', rodzaj: 'praca',
            tresc: `dostal kampanie „${kampania.kampania}" z uniwersum ${u.domena}: ${dodane.dodane.length} odcinkow w planie`,
        });
        console.log(`[Uniwersum] 🌌 Kampania „${kampania.kampania}" — ${dodane.dodane.length} odcinków w planie.`);

        return res.json({
            success: true, model: silnik, kampania,
            odcinki: dodane.dodane, odrzucone: dodane.odrzucone, uniwersum: po,
        });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── ✂️ POST-PRODUKCJA: poprawki fragmentów i muzyka ─────────────────────────

/**
 * POST /api/post/podmien { plik, od, do, prompt, kroki? }
 *
 * „Zaznacz fragment i wpisz, by wygenerował poprawione."
 * Trzy kroki: klatka sprzed cięcia → Wan liczy nowy fragment → ffmpeg wstawia
 * go w miejsce starego. Odpowiedź wraca PO ZAKOŃCZENIU generacji, bo bez
 * gotowego fragmentu nie ma czego wstawiać.
 */
app.post('/api/post/podmien', async (req, res) => {
    const { plik, od, do: doCzasu, prompt = '', kroki } = req.body ?? {};
    if (String(prompt).trim().length < 5) {
        return res.status(400).json({ success: false, message: 'Napisz, co ma być w poprawionym fragmencie.' });
    }
    try {
        const stan = await stanWideoZBudzeniem('poprawka fragmentu');
        if (!stan.gotowe) return res.status(424).json({ success: false, message: stan.braki.join(' | '), braki: stan.braki });

        const przy = await PostProdukcja.przygotujPodmiane({ plik, od, doCzasu, comfyDir: COMFY_DIR });

        const r = await Wideo.dopiszUjecie({
            comfyBase: COMFY_BASE, prompt, klatka: przy.klatka.nazwa,
            szerokosc: przy.opis.szerokosc, wysokosc: przy.opis.wysokosc, fps: przy.opis.fps,
            klatek: przy.klatek, kroki,
        });
        if (!r.ok) return res.status(424).json({ success: false, message: r.powod });

        console.log(`[Post] ✂️ Podmiana ${przy.start}-${przy.koniec}s w ${path.basename(przy.zrodlo)} — zlecenie ${r.zlecenie}`);
        const nowy = await czekajNaPlikWideo(r.zlecenie, () => false);
        if (!nowy) return res.status(504).json({ success: false, message: 'Silnik nie oddał fragmentu.' });

        const w = await PostProdukcja.wstawFragment({
            zrodlo: przy.zrodlo, nowyFragment: nowy,
            start: przy.start, koniec: przy.koniec, comfyDir: COMFY_DIR,
        });
        return res.json({ success: true, ...w, fragment: nowy, zakres: { od: przy.start, do: przy.koniec } });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/** POST /api/post/muzyka { plik, utwor, odSekundy?, odUtworu?, glosnosc?, wyciszenie? } */
app.post('/api/post/muzyka', async (req, res) => {
    try {
        const w = await PostProdukcja.dodajMuzyke({ ...(req.body ?? {}), comfyDir: COMFY_DIR });
        console.log(`[Post] 🎼 Muzyka → ${path.basename(w.plik)} (${w.miks})`);
        return res.json({ success: true, ...w });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── 💭 POKÓJ OPOWIEŚCI: rozmowa, z której rodzi się serial ──────────────────

/** Wspólne wołanie modelu — jedna implementacja zamiast trzech kopii. */
async function piszModelem(model, system, prompt) {
    const silnik = model || process.env.OTAKOS_MODEL || DEFAULT_LLM;
    const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        // think:false — qwen3.x bez tego oddaje pustą treść (zmierzone przy /api/ollama/pisz).
        body: JSON.stringify({ model: silnik, system, prompt, stream: false, think: false }),
    });
    if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
    return { tekst: String((await r.json()).response || '').trim(), silnik };
}

/**
 * POST /api/opowiesc/doradca { historia[], gatunekId?, model? }
 *
 * Suweren (2026-09-12): „przy rozmowie i ustalaniu strasznie jest dużo pytań —
 * potrzebuję drugiego TeOgochi, by mu odpowiadał, i możliwości kliknięcia na
 * jego odpowiedź potwierdzającego ten wybór". Doradca czyta OSTATNIĄ wypowiedź
 * partnera, wyławia pytania i do każdego proponuje 2 krótkie odpowiedzi, spójne
 * z dotychczasową rozmową. NIC nie zapisuje i NIC nie wysyła — kliknięcie
 * w Pokoju Opowieści robi z propozycji wypowiedź Suwerena. Decyzja zostaje jego.
 */
app.post('/api/opowiesc/doradca', async (req, res) => {
    const { historia = [], gatunekId = '', model } = req.body ?? {};
    const ostatnia = [...historia].reverse().find((t) => t.kto === 'teogochi');
    if (!ostatnia) return res.status(400).json({ success: false, message: 'Partner jeszcze o nic nie zapytał.' });
    try {
        let doradca = null;
        if (gatunekId) {
            const stado = await MostStada.stanDlaApki(Szyna.ostatnie({ ile: 100 })).catch(() => null);
            doradca = (stado?.gatunki ?? []).find((g) => g.id === gatunekId) ?? null;
        }
        const kim = doradca ? `${doradca.imie} — TeOgochi Katedry, dziedzina: ${doradca.dziedzina}` : 'Doradca Suwerena';
        const system = `Jesteś ${kim}. Suweren wymyśla opowieść z partnerem, a partner zasypuje go pytaniami. Twoja rola: wyłowić pytania z OSTATNIEJ wypowiedzi partnera i do każdego zaproponować DWIE krótkie, konkretne odpowiedzi (po polsku, jedno zdanie każda, w pierwszej osobie jak Suweren: „Niech…", „Chcę…"), różniące się kierunkiem, spójne z tym, co już ustalono. Nie dodawaj pytań od siebie. Odpowiadasz WYŁĄCZNIE jednym obiektem JSON: {"propozycje":[{"pytanie":"<pytanie partnera, skrót>","odpowiedzi":["<A>","<B>"]}]}. Gdy partner o nic nie pyta — {"propozycje":[]}.`;
        const prompt = [Opowiesc.zwezHistorie(historia.slice(0, -1)), `PARTNER (ostatnia wypowiedź): ${ostatnia.tresc}`, '', 'JSON:'].filter(Boolean).join('\n');
        const { tekst, silnik } = await piszModelem(model, system, prompt);
        const m = tekst.match(/\{[\s\S]*\}/);
        let propozycje = [];
        try { propozycje = JSON.parse(m ? m[0] : '{}').propozycje ?? []; } catch { propozycje = []; }
        propozycje = (Array.isArray(propozycje) ? propozycje : []).slice(0, 8).map((p) => ({
            pytanie: String(p?.pytanie || '').slice(0, 200),
            odpowiedzi: (Array.isArray(p?.odpowiedzi) ? p.odpowiedzi : []).map((o) => String(o).trim()).filter(Boolean).slice(0, 3),
        })).filter((p) => p.odpowiedzi.length);
        return res.json({ success: true, propozycje, model: silnik, doradca: doradca ? { id: doradca.id, imie: doradca.imie, forma: doradca.forma, dziedzina: doradca.dziedzina } : null });
    } catch (e) {
        return res.status(502).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/opowiesc/rozmowa { wypowiedz, historia[], gatunekId?, projekt?, model? }
 * Partner od wymyślania. NIC NIE ZAPISUJE — od zapisu jest /przekuj.
 */
app.post('/api/opowiesc/rozmowa', async (req, res) => {
    const { wypowiedz = '', historia = [], gatunekId = '', projekt = '', model } = req.body ?? {};
    if (String(wypowiedz).trim().length < 2) {
        return res.status(400).json({ success: false, message: 'Pusta wypowiedź.' });
    }
    try {
        // Partner to PRAWDZIWY TeOgochi z migawki stada, nie wymyślona persona.
        let gatunek = null;
        if (gatunekId) {
            const stado = await MostStada.stanDlaApki(Szyna.ostatnie({ ile: 100 })).catch(() => null);
            gatunek = (stado?.gatunki ?? []).find((g) => g.id === gatunekId) ?? null;
        }

        // Kotwica: kanon istniejącego projektu, żeby nie wymyślać wbrew niemu.
        let kotwica = '';
        let spisAssetow = '';
        if (projekt) {
            const p = await rezyserPamiec(ANTIGRAVITY_DIR, projekt).catch(() => null);
            kotwica = (p?.fakty ?? []).map((f) => f.tresc).join('\n');

            // ⚠️ BIBLIOTEKA PROJEKTU DO PROMPTU. Bez tego partner wymyślał postać,
            // która od dawna ma twarz, garderobę i arkusz sylwetek — i nikt tego
            // nie łapał. Suweren: „powiem mu o tych assetach, to je zobaczy?"
            const lista = await Assety.lista(ANTIGRAVITY_DIR, projekt).catch(() => []);
            spisAssetow = Opowiesc.spisAssetow(lista, Assety.ROLE);
        }

        // Ręce dostaje TYLKO rozmowa o konkretnym projekcie — bez projektu nie ma
        // gdzie dopisać assetu, więc instrukcja rąk byłaby obietnicą bez pokrycia.
        const rece = Boolean(projekt);
        const system = Opowiesc.promptRozmowy({ gatunek, kotwica, assety: spisAssetow, rece });
        const prompt = [Opowiesc.zwezHistorie(historia), `SUWEREN: ${wypowiedz}`].filter(Boolean).join('\n');
        const { tekst, silnik } = await piszModelem(model, system, prompt);

        // Wyłuskujemy akcję i WYKONUJEMY ją sami. Model nie melduje sukcesu —
        // melduje go Katedra, na podstawie tego, co naprawdę zapisała.
        let { mowa, akcja, powod } = Opowiesc.odczytajAkcje(tekst);

        // ⚠️ DRUGIE, WĄSKIE WYWOŁANIE. Mały model nie doklei składni akcji do
        // swobodnej wypowiedzi — sprawdzone na `gemma4:e2b`: zignorował instrukcję
        // i pogadał o barmanie. Więc rozmowa jest rozmową, a akcja osobnym
        // pytaniem z jedną odpowiedzią do wydania. Bramka `czyProsiOAsset`
        // pilnuje, żeby nie płacić drugim wywołaniem za każde zdanie.
        if (!akcja && rece && Opowiesc.czyProsiOAsset(wypowiedz)) {
            try {
                const r = Opowiesc.promptRak({ wypowiedz, spis: spisAssetow });
                const { tekst: jsonAkcji } = await piszModelem(model, r.system, r.prompt);
                const wynik = Opowiesc.odczytajRece(jsonAkcji);
                akcja = wynik.akcja;
                powod = powod ?? wynik.powod ?? null;
            } catch (e) {
                powod = `Ręce nie odpowiedziały: ${e.message}`;
            }
        }

        let wykonane = null;
        if (akcja && rece) {
            try {
                const zapisany = await Assety.zapisz(ANTIGRAVITY_DIR, projekt, {
                    typ: akcja.typ, nazwa: akcja.nazwa,
                    notatki: akcja.notatki || undefined,
                    rola: akcja.rola,
                });
                wykonane = { akcja: akcja.akcja, asset: zapisany };
                console.log(`[Opowieść] Ręce: ${akcja.akcja} → ${zapisany.typ}/${zapisany.nazwa} w ${projekt}`);
            } catch (e) {
                // Nieudana akcja NIE psuje rozmowy — ale ma zostać powiedziana wprost.
                wykonane = { akcja: akcja.akcja, blad: e.message };
            }
        }

        return res.json({
            success: true, mowa, model: silnik,
            wykonane,
            odrzucona: powod ?? null,
            widzianychAssetow: spisAssetow ? spisAssetow.split('\n').filter((l) => l.startsWith('  ·')).length : 0,
            gatunek: gatunek ? { id: gatunek.id, imie: gatunek.imie, dziedzina: gatunek.dziedzina, forma: gatunek.forma } : null,
        });
    } catch (e) {
        return res.status(502).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/opowiesc/przekuj { historia[], ile?, serial?, model? }
 *
 * Rozmowa → PROJEKT: katalog, fakty kanoniczne i odcinki w planie.
 * Stąd Suweren idzie prosto do Reżysera i realizuje odcinek po odcinku.
 */
app.post('/api/opowiesc/przekuj', async (req, res) => {
    const { historia = [], ile = 3, serial: nazwaRecznie = '', model } = req.body ?? {};
    if (!Array.isArray(historia) || historia.length < 2) {
        return res.status(400).json({ success: false, message: 'Za mało rozmowy, żeby było co przekuwać.' });
    }
    try {
        const { system, prompt } = Opowiesc.promptPrzekucia({ historia, ile: Number(ile) || 3 });
        const { tekst, silnik } = await piszModelem(model, system, prompt);
        const wynik = Opowiesc.odczytajPrzekucie(tekst, Number(ile) || 3);

        // Nazwa podana ręcznie ma pierwszeństwo nad tą z modelu.
        const serial = String(nazwaRecznie || '').trim() || wynik.serial;

        // 1. Katalog projektu — bez niego odcinki nie mają gdzie wylądować.
        const projekt = await utworzProjekt(ANTIGRAVITY_DIR, serial);

        // 2. Fakty kanoniczne. Duplikat nie jest błędem, tylko pominięciem.
        const fakty = [];
        for (const f of wynik.fakty) {
            const w = await dodajFakt(ANTIGRAVITY_DIR, serial, f, 'opowiesc').catch(() => null);
            if (w && !w.duplikat) fakty.push(w.fakt);
        }

        // 3. Odcinki w planie — jednym zapisem, przez tę samą trasę co paczka.
        const odcinki = await dodajOdcinki(ANTIGRAVITY_DIR, serial, wynik.odcinki);

        await Szyna.nadaj({
            agent: 'Reżyser', rodzaj: 'praca',
            tresc: `dostal z Pokoju Opowiesci projekt „${serial}": ${odcinki.dodane.length} odcinkow w planie`,
        });
        console.log(`[Opowieść] 💭 „${serial}" — ${fakty.length} faktów, ${odcinki.dodane.length} odcinków.`);

        return res.json({
            success: true, model: silnik, serial, projekt,
            fakty, odcinki: odcinki.dodane, odrzucone: odcinki.odrzucone,
        });
    } catch (e) {
        return res.status(502).json({ success: false, message: e.message });
    }
});

// ── 📚 BIBLIOTEKA ODCINKÓW: co powstało i co z tym dalej ─────────────────────

app.get('/api/biblioteka', async (req, res) => {
    try {
        const dane = await Biblioteka.biblioteka(ANTIGRAVITY_DIR, {
            projekty: () => listaProjektow(ANTIGRAVITY_DIR),
            pamiec: (p) => rezyserPamiec(ANTIGRAVITY_DIR, p),
            materialy: (p, o) => materialyOdcinka(ANTIGRAVITY_DIR, p, o),
            muzyka: (p) => MuzykaFilmowa.muzykaProjektu(ANTIGRAVITY_DIR, p),
            kadry: (p) => produkcjaLista(ANTIGRAVITY_DIR, p),
        });
        // Stan YouTube'a bierzemy Z IMPRESARIATU — on trzyma klucze i on wysyła.
        const yt = await ImpresarioService.getInstance().getYouTubeSecretsStatus().catch(() => null);
        return res.json({
            success: true,
            projekty: dane,
            odbiorcy: Biblioteka.ODBIORCY,
            kanaly: Biblioteka.KANALY.map((k) => Biblioteka.stanKanalu(k.id, yt)),
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/biblioteka/plan', async (req, res) => {
    try {
        const { projekt = '', odcinekId = '', ...dane } = req.body ?? {};
        const w = await Biblioteka.ustawPlan(ANTIGRAVITY_DIR, projekt, odcinekId, dane);
        console.log(`[Biblioteka] 🗓️ Plan publikacji: ${projekt} / ${odcinekId} → ${w.plan.kanal} (${w.plan.kiedy ?? 'bez daty'}).`);
        return res.json({ success: true, ...w });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/**
 * POST /api/biblioteka/wyslij { projekt, odcinekId }
 *
 * Oddaje odcinek IMPRESARIATOWI — temu samemu, który publikuje muzykę.
 * Suweren: „to można bardzo łatwo zrealizować, łącząc to z impresariatem
 * z głównej apki — po prostu wysyłał by wszelkie dane tam".
 *
 * ⚠️ Biblioteka NIE wysyła sama. Składa zlecenie i podaje je dalej; OAuth2
 * i resumable upload siedzą w Impresariacie. Druga implementacja uploadu
 * znaczyłaby dwa miejsca do naprawiania i dwa zestawy błędów.
 */
app.post('/api/biblioteka/wyslij', async (req, res) => {
    const { projekt = '', odcinekId = '' } = req.body ?? {};
    try {
        const p = await rezyserPamiec(ANTIGRAVITY_DIR, projekt);
        const odcinek = (p.odcinki ?? []).find((o) => o.id === odcinekId);
        if (!odcinek) return res.status(404).json({ success: false, message: `Odcinek "${odcinekId}" nie istnieje.` });

        const materialy = await materialyOdcinka(ANTIGRAVITY_DIR, projekt, odcinek);
        const z = await Biblioteka.zlecenieDlaImpresariatu(ANTIGRAVITY_DIR, projekt, odcinek, materialy);

        // Przy YouTubie sprawdzamy klucze ZANIM cokolwiek trafi do kolejki —
        // zadanie, które i tak padnie na braku tokenu, tylko zaśmieca listę.
        if (z.plan.kanal === 'youtube') {
            const yt = await ImpresarioService.getInstance().getYouTubeSecretsStatus();
            if (!yt.allPresent) {
                return res.status(424).json({
                    success: false,
                    message: `Impresariat nie ma kompletu kluczy YouTube (brakuje: ${yt.missing.join(', ')}). Wpisz je raz: POST /api/impresario/secrets/youtube.`,
                    braki: yt.missing,
                });
            }
        }

        const job = await ImpresarioService.getInstance()
            .enqueuePublication(z.tytul, z.album, z.platformy, z.plik);
        const plan = await Biblioteka.oznaczWyslany(ANTIGRAVITY_DIR, projekt, odcinekId, job.id);

        await Szyna.nadaj({
            agent: 'Kupiec', rodzaj: 'praca',
            tresc: `oddal odcinek #${odcinek.numer} „${odcinek.tytul}" do Impresariatu (${z.platformy.join(', ')})`,
        });
        console.log(`[Biblioteka] 📤 #${odcinek.numer} → Impresariat, zlecenie ${job.id} (${z.plik})`);

        return res.json({ success: true, job, plan, plik: z.plik, tytul: z.tytul });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.post('/api/biblioteka/przekaz', async (req, res) => {
    try {
        const { projekt = '', odcinekId = '', agent = '', notatka = '' } = req.body ?? {};
        const w = await Biblioteka.przekaz(ANTIGRAVITY_DIR, projekt, odcinekId, agent, notatka);
        // Zadanie ląduje na szynie, więc agent widzi je u siebie — nie „gdzieś w systemie".
        await Szyna.nadaj(w.zdarzenie);
        console.log(`[Biblioteka] 🤝 ${w.agent.imie} dostał odcinek ${projekt} / ${odcinekId}.`);
        return res.json({ success: true, ...w });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

// ── 🎼 MUZYKA FILMOWA: to, co Joanna nagrała, wpięte w produkcję ─────────────

/** Biblioteka Katedry + to, co już wpięte w projekt. Jedno pytanie, bo UI i tak chce obu. */
app.get('/api/muzyka/katalog', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        const [biblioteka, wpiete] = await Promise.all([
            MuzykaFilmowa.bibliotekaKatedry(MUSIC_DIR),
            projekt ? MuzykaFilmowa.muzykaProjektu(ANTIGRAVITY_DIR, projekt) : Promise.resolve({ utwory: [], role: MuzykaFilmowa.ROLE }),
        ]);
        return res.json({ success: true, katalogMuzyki: MUSIC_DIR, biblioteka, ...wpiete });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/muzyka/wepnij', async (req, res) => {
    try {
        const { projekt = '', ...dane } = req.body ?? {};
        const w = await MuzykaFilmowa.dodajUtwor(ANTIGRAVITY_DIR, projekt, dane);
        if (!w.duplikat) console.log(`[Muzyka] 🎼 „${w.utwor.nazwa}" jako ${w.utwor.rola} → ${projekt}`);
        return res.json({ success: true, ...w });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.delete('/api/muzyka/:id', async (req, res) => {
    try {
        const w = await MuzykaFilmowa.usunUtwor(ANTIGRAVITY_DIR, String(req.query.projekt || ''), req.params.id);
        return res.json({ success: true, ...w });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

/** Presety ruchów — front nie ma ich wymyślać po swojemu. */
app.get('/api/ciag/ruchy', (req, res) => res.json({ success: true, ruchy: Sekwencja.RUCHY_KAMERY }));

app.get('/api/ciag/scena/:id', (req, res) => {
    const s = Sekwencja.stanZadania(req.params.id);
    // ⚠️ Po restarcie mostu zadania znikają — mówimy to wprost, zamiast milczeć.
    if (!s) return res.status(404).json({ success: false, message: 'Nie znam tego zadania. Most mógł się w międzyczasie zrestartować — zadania żyją w pamięci.' });
    return res.json({ success: true, ...s });
});

app.get('/api/ciag/sceny', (req, res) => res.json({ success: true, sceny: Sekwencja.listaZadan() }));

app.post('/api/ciag/scena/:id/przerwij', (req, res) => {
    try {
        return res.json({ success: true, ...Sekwencja.przerwij(req.params.id) });
    } catch (e) {
        return res.status(404).json({ success: false, message: e.message });
    }
});

app.post('/api/teo-sim/petla', async (req, res) => {
    const { agent, scenariusz, stanPrzed, model, modelCiezki, wezel } = req.body ?? {};
    const r = await TeoSim.petlaWnioskowania({
        agent, scenariusz, stanPrzed, model, modelCiezki,
        ollamaBase: OLLAMA_BASE,
        wezelAgenta: wezel,
        // Rozliczenie idzie TĄ SAMĄ drogą co każdy ruch GRV — z pieczęcią w łańcuchu.
        przelej: (from, to, ile) => przelejGrv(from, to, ile),
    });
    if (!r.ok) return res.status(400).json({ success: false, message: r.powod });
    await Szyna.nadaj({
        agent: agent || 'TeO-Sim', rodzaj: r.rozwiazane ? 'praca' : 'blad',
        tresc: `pętla wnioskowania: ${r.obiegow} obiegów, ${r.tokeny} tokenów, ${r.grv.wyplacone} GRV`,
    });
    res.json({ success: true, ...r });
});


app.post('/api/stado/publikuj', async (req, res) => {
    const r = await MostStada.publikuj(req.body ?? {});
    if (!r.ok) return res.status(400).json({ success: false, message: r.powod });
    // Regres = ktoś wykluty wrócił do jajka albo stracił XP. Mówimy o tym głośno,
    // bo to prawie na pewno pusta przeglądarka, a nie decyzja Suwerena.
    if (r.cofniete?.length) {
        await Szyna.nadaj({ agent: 'Stado', rodzaj: 'blad', tresc: `migawka stada COFNĘŁA ${r.cofniete.map((c) => `${c.imie}: ${c.bylo.etap} ${c.bylo.xp} XP → ${c.jest?.etap ?? '?'} ${c.jest?.xp ?? 0} XP`).join('; ')}. Stara migawka w kopii${r.kopia ? ` ${r.kopia}` : ''} — Dom TeOgochi ma „Przywróć z kopii mostu".`, dane: { kopia: r.kopia, cofniete: r.cofniete } }).catch(() => {});
    }
    res.json({ success: true, ...r });
});
// ── 🥚 ŹRÓDŁO PRAWDY XP (services/Stado.js) — przeglądarka ściąga przy starcie, odsyła przy zapisie ──
app.get('/api/stado/stan', async (_req, res) => res.json({ success: true, ...(await Stado.stan()) }));
app.post('/api/stado/stan', async (req, res) => {
    try {
        const r = await Stado.scal(req.body ?? {});
        if (r.odrzucone.length) console.warn(`[Stado] ⛔ odrzucone niższe XP: ${r.odrzucone.map((o) => `${o.id} ${o.przyszlo}<${o.naDysku}`).join(', ')}`);
        res.json({ success: true, ...r });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});
app.get('/api/stado/kopie', async (_req, res) => res.json({ success: true, kopie: await MostStada.kopie() }));
app.get('/api/stado/kopie/:nazwa', async (req, res) => {
    const m = await MostStada.kopia(req.params.nazwa);
    return m ? res.json({ success: true, migawka: m }) : res.status(404).json({ success: false, message: 'Nie ma takiej kopii.' });
});

/** Kod parowania do przepisania na telefon. */
app.post('/api/stado/parowanie', async (req, res) => {
    res.json({ success: true, ...(await MostStada.zacznijParowanie()) });
});

/** Telefon wymienia kod na token. */
app.post('/api/stado/paruj', async (req, res) => {
    const { kod, urzadzenie } = req.body ?? {};
    const r = await MostStada.sparuj(kod, urzadzenie);
    if (!r.ok) return res.status(403).json({ success: false, message: r.powod });
    console.log(`[Stado] 📱 Sparowano urządzenie „${urzadzenie || 'telefon'}".`);
    res.json({ success: true, token: r.token });
});

app.get('/api/stado/urzadzenia', async (req, res) => {
    res.json({ success: true, urzadzenia: await MostStada.urzadzenia() });
});

app.post('/api/stado/odlacz', async (req, res) => {
    const r = await MostStada.odlacz(req.body?.skrot);
    if (!r.ok) return res.status(404).json({ success: false, message: r.powod });
    res.json({ success: true });
});

/** Stan dla apki. Token w nagłówku `X-Stado-Token` albo `?token=`. */
app.get('/api/stado/stan', async (req, res) => {
    const token = req.get('X-Stado-Token') || req.query.token;
    const kto = await MostStada.sprawdzToken(token);
    if (!kto) {
        return res.status(401).json({
            success: false,
            message: 'Brak sparowania. Wygeneruj kod w Katedrze i sparuj urządzenie.',
        });
    }
    // ⚠️ `ostatnie` bierze OBIEKT i jest synchroniczne — sprawdzone w SzynaZdarzen.js,
    // nie zgadywane z nazwy. Podanie liczby dałoby `ile` undefined i pustą listę.
    const zdarzenia = Szyna.ostatnie({ ile: 300 });
    res.json({ success: true, urzadzenie: kto.nazwa, ...(await MostStada.stanDlaApki(zdarzenia)) });
});


app.get('/api/pamiec-kodu/stan', async (req, res) => {
    try { res.json({ success: true, ...(await PamiecKodu.stan()) }); }
    catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

app.post('/api/pamiec-kodu/indeksuj', async (req, res) => {
    const r = await PamiecKodu.indeksuj(req.body?.sciezka);
    if (!r.ok) return res.status(424).json({ success: false, message: r.powod });
    await Szyna.nadaj({ agent: 'Wektor', rodzaj: 'praca', tresc: 'zaindeksowal Katedre w pamieci kodu' });
    res.json({ success: true, ...r });
});

app.post('/api/pamiec-kodu/pytanie', async (req, res) => {
    const { rodzaj, co, b } = req.body ?? {};
    if (!rodzaj) return res.status(400).json({ success: false, message: 'Wymagane: rodzaj (szukaj|sciezka|architektura|fragment).' });
    if (rodzaj !== 'architektura' && !co) {
        return res.status(400).json({ success: false, message: 'Wymagane: co (nazwa węzła/symbolu).' });
    }
    const r = await PamiecKodu.zapytaj({ rodzaj, co, b, mostBase: `http://127.0.0.1:${PORT}` });
    if (!r.ok) return res.status(424).json({ success: false, ...r, message: r.powod });
    await Szyna.nadaj({ agent: 'Wektor', rodzaj: 'praca', tresc: `pamięć kodu (${r.silnik}): ${rodzaj} ${co ?? ''}`.trim() });
    res.json({ success: true, ...r });
});


app.get('/api/czat/sesje', async (req, res) => {
    try {
        res.json({ success: true, ...(await HistoriaCzatu.listaSesji(req.query.ile ?? 3)) });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

app.get('/api/czat/sesja/:id', async (req, res) => {
    const s = await HistoriaCzatu.wczytajSesje(req.params.id);
    if (!s) return res.status(404).json({ success: false, message: 'Nie ma takiej rozmowy.' });
    res.json({ success: true, sesja: s });
});

app.post('/api/czat/sesja', async (req, res) => {
    const { id, wiadomosci, tytul } = req.body ?? {};
    const r = await HistoriaCzatu.zapiszSesje({ id, wiadomosci, tytul });
    if (!r.ok) return res.status(400).json({ success: false, message: r.powod });
    res.json({ success: true, ...r });
});

app.post('/api/czat/sesja/usun', async (req, res) => {
    const r = await HistoriaCzatu.usunSesje(req.body?.id);
    if (!r.ok) return res.status(404).json({ success: false, message: r.powod });
    res.json({ success: true });
});


app.get('/api/modele/lokalne', async (req, res) => {
    try {
        res.json({ success: true, ...(await KuzniaModeli.skanujModele(OLLAMA_BASE)) });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/modele/wykuj', async (req, res) => {
    const { plik, nazwa, szablon } = req.body ?? {};
    const r = await KuzniaModeli.wykuj({ plik, nazwa, szablon, ollamaBase: OLLAMA_BASE });
    if (!r.ok) return res.status(400).json({ success: false, message: r.powod });
    await Szyna.nadaj({ agent: 'Kuźnia', rodzaj: 'praca', tresc: `kuję model „${r.nazwa}" z ${r.plik}` });
    res.json({ success: true, ...r });
});

app.get('/api/modele/wykuj/stan', (req, res) => {
    const id = req.query.id;
    const stan = KuzniaModeli.stanKucia(id);
    if (id && !stan) return res.status(404).json({ success: false, message: 'Nie ma takiego przebiegu.' });
    res.json({ success: true, [id ? 'przebieg' : 'przebiegi']: stan });
});


app.get('/api/music/workflows', async (req, res) => {
    try {
        await fs.mkdir(WORKFLOWS_DIR, { recursive: true });
        const pliki = (await fs.readdir(WORKFLOWS_DIR)).filter(f => f.endsWith('.json'));
        // Która rodzina używa którego pliku — żeby panel mógł pokazać powiązanie.
        const rodzinaPliku = {};
        for (const [nazwa, c] of Object.entries(RODZINY_MUZYKI)) rodzinaPliku[c.workflow] = nazwa;

        const lista = [];
        for (const f of pliki) {
            const p = path.join(WORKFLOWS_DIR, f);
            const st = await fs.stat(p);
            let wf = null, blad = null;
            try { wf = JSON.parse(await fs.readFile(p, 'utf8')); }
            catch (e) { blad = `Nie jest poprawnym JSON-em: ${e.message}`; }
            const api = wf ? czyGrafApi(wf) : false;
            lista.push({
                plik: f,
                bajty: st.size,
                zmieniony: st.mtime.toISOString(),
                nodow: wf && api ? Object.keys(wf).length : null,
                format: blad ? 'uszkodzony' : (api ? 'api' : 'ui'),
                // Uczciwie: graf w formacie UI da się trzymać, ale most go nie uruchomi.
                uruchamialny: api,
                powod: blad || (api ? null : 'Format UI — wyeksportuj z ComfyUI przez „Workflow → Export (API)".'),
                rodzina: rodzinaPliku[f] || null,
            });
        }
        res.json({ success: true, katalog: WORKFLOWS_DIR, workflows: lista, ile: lista.length });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

app.get('/api/music/workflow/:plik', async (req, res) => {
    const nazwa = bezpiecznaNazwaWorkflow(req.params.plik);
    if (!nazwa) return res.status(400).json({ success: false, message: 'Zła nazwa pliku (oczekuję *.json).' });
    try {
        const tresc = await fs.readFile(path.join(WORKFLOWS_DIR, nazwa), 'utf8');
        res.json({ success: true, plik: nazwa, graf: JSON.parse(tresc) });
    } catch (e) {
        res.status(404).json({ success: false, message: `Nie ma takiego workflow: ${nazwa}` });
    }
});

/**
 * POST /api/music/workflow — zapis grafu. Body: { plik, graf, nadpisz? }
 * Tędy agent Katedry (Spawacz) oddaje napisany przez siebie workflow.
 *
 * ⚠️ Graf w formacie UI jest ODRZUCANY. Zapisany wyglądałby na gotowy, a przy
 * pierwszym uruchomieniu most i tak by go odbił — lepiej powiedzieć to od razu.
 */
app.post('/api/music/workflow', async (req, res) => {
    const { plik, graf, nadpisz = false } = req.body ?? {};
    const nazwa = bezpiecznaNazwaWorkflow(plik);
    if (!nazwa) return res.status(400).json({ success: false, message: 'Podaj „plik" z rozszerzeniem .json.' });
    if (!graf || typeof graf !== 'object') return res.status(400).json({ success: false, message: 'Brak „graf" (obiekt JSON).' });
    if (!czyGrafApi(graf)) {
        return res.status(400).json({
            success: false,
            message: 'To nie jest graf w formacie API — brak node\'ów z „class_type". Most nie uruchomiłby go, więc go nie zapisuję.',
        });
    }
    const sciezka = path.join(WORKFLOWS_DIR, nazwa);
    if (!nadpisz && fsSync.existsSync(sciezka)) {
        return res.status(409).json({ success: false, message: `„${nazwa}" już istnieje. Wyślij nadpisz:true, żeby zastąpić.` });
    }
    try {
        await fs.mkdir(WORKFLOWS_DIR, { recursive: true });
        await fs.writeFile(sciezka, JSON.stringify(graf, null, 2), 'utf8');
        await Szyna.nadaj({ agent: 'Spawacz', rodzaj: 'praca', tresc: `zapisał workflow ${nazwa} (${Object.keys(graf).length} nodów)` });
        res.json({ success: true, plik: nazwa, nodow: Object.keys(graf).length });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});


app.get('/api/music/engine/status', async (req, res) => {
    const [modele, comfy] = await Promise.all([muzykaModeleStatus(), comfyStatus()]);

    // Stan liczony OSOBNO dla każdej rodziny — Suweren ma widzieć, że np. ACE jest
    // gotowy, nawet gdy MiniMaxowi czegoś brakuje (i odwrotnie).
    const rodziny = {};
    for (const [nazwa, cfgR] of Object.entries(RODZINY_MUZYKI)) {
        const plik = path.join(WORKFLOWS_DIR, cfgR.workflow);
        const maWorkflow = fsSync.existsSync(plik);
        const wagi = modele.rodziny?.[nazwa];
        const nodyOk = nazwa === 'minimax' ? !!comfy.maMinimax : comfy.online;
        rodziny[nazwa] = {
            etykieta: cfgR.etykieta,
            gotowy: !!wagi?.gotowy && comfy.online && nodyOk && maWorkflow,
            wagiGotowe: !!wagi?.gotowy,
            brakujaceRole: wagi?.brakujaceRole ?? [],
            encodery: wagi ? `${wagi.encoderow}/${wagi.potrzebaEncoderow}` : '?',
            workflow: { plik, obecny: maWorkflow },
            krokow: cfgR.steps,
            uwaga: cfgR.uwaga,
            potrzebne: [cfgR.dit, cfgR.enc, cfgR.enc2, cfgR.vae].filter(Boolean),
        };
    }
    const ktoraGotowa = Object.keys(rodziny).find(k => rodziny[k].gotowy) || null;

    // Braki opisujemy dla rodziny NAJBLIŻSZEJ gotowości (najmniej brakujących rol),
    // żeby lista nie była mieszanką dwóch silników.
    const kandydat = ktoraGotowa
        || Object.keys(rodziny).sort((a, b) => rodziny[a].brakujaceRole.length - rodziny[b].brakujaceRole.length)[0];
    const k = rodziny[kandydat];

    res.json({
        success: true,
        gotowy: !!ktoraGotowa,
        gotowaRodzina: ktoraGotowa,
        rodziny,
        katalogModeli: muzykaKatalogModeli(),
        comfy: { base: COMFY_BASE, ...comfy },
        // Zgodność wstecz z panelem
        modele: { pipelineGotowy: modele.pipelineGotowy, brakujaceRole: modele.brakujaceRole },
        workflow: k.workflow,
        // Konkretna lista rzeczy do zrobienia — bez ściemy typu "wkrótce".
        braki: ktoraGotowa ? [] : [
            ...(k.wagiGotowe ? [] : [`${k.etykieta}: brak wag (${k.brakujaceRole.join(', ') || 'encodery ' + k.encodery}) — pobierz w panelu AI Session → Katalog Modeli.`]),
            ...(comfy.online ? [] : [`ComfyUI nie działa na ${COMFY_BASE} — odpal run_nvidia_gpu.bat (dopisz w nim: set PYTHONUTF8=1).`]),
            ...(comfy.online && kandydat === 'minimax' && !comfy.maMinimax ? ['ComfyUI nie zna nodów MiniMax — zaktualizuj przez update/update_comfyui.bat (NIE tym z python_dependencies, wywala się na limicie 260 znaków).'] : []),
            ...(k.workflow.obecny ? [] : [`Brak workflow: ${k.workflow.plik}`]),
        ],
    });
});

/**
 * Wstrzykuje parametry do workflow w formacie API ComfyUI.
 * Zasada: dotykamy WYŁĄCZNIE wejść, które w danym nodzie istnieją — nie dorzucamy
 * kluczy na zgadywanie, bo ComfyUI odrzuciłby graf albo cicho zignorował.
 * Zwraca też co realnie podmieniliśmy, żeby front mógł to pokazać, a nie wierzyć.
 */
function wstrzyknijDoWorkflow(wf, p) {
    const podmienione = [];
    const ustaw = (nodeId, klucz, wartosc, opis) => {
        const wejscia = wf[nodeId]?.inputs;
        if (!wejscia || !(klucz in wejscia)) return false;
        // NIGDY nie nadpisujemy wejscia podlaczonego kablem (w formacie API polaczenie
        // to tablica ["idZrodla", slot]). Np. `seconds` w EmptyMiniMaxMusic3LatentAudio
        // jest wyliczane przez encoder — wstawienie tam liczby rozjezdza dlugosc
        // latentu z dlugoscia kondycjonowania i sampler pada.
        if (Array.isArray(wejscia[klucz])) return false;
        wejscia[klucz] = wartosc;
        podmienione.push(`${nodeId}.${klucz} = ${opis ?? wartosc}`);
        return true;
    };

    for (const [id, node] of Object.entries(wf)) {
        const typ = String(node.class_type || '');
        const we = node.inputs || {};

        // Wagi — wskazujemy pliki z naszego suwerennego katalogu.
        if (p.ditFile)  { for (const k of ['unet_name', 'model_name', 'ckpt_name']) ustaw(id, k, p.ditFile); }
        if (p.encFile)  { for (const k of ['clip_name', 'clip_name1', 'text_encoder_name']) ustaw(id, k, p.encFile); }
        // ACE uzywa DualCLIPLoader z DWOMA ROZNYMI encoderami — wpisanie tego samego
        // pliku w oba sloty daje graf, ktory sie zwaliduje, ale policzy bzdure.
        if (p.encFile2) { ustaw(id, 'clip_name2', p.encFile2); }
        if (p.vaeFile)  { ustaw(id, 'vae_name', p.vaeFile); }

        // Opis brzmienia vs tekst piosenki — rozróżniamy po nazwie wejścia,
        // a gdy node ma tylko "text", po tym czy to node oznaczony jako lyrics.
        if ('lyrics' in we && p.lyrics !== undefined) ustaw(id, 'lyrics', p.lyrics, '<tekst>');
        if ('caption' in we && p.prompt) ustaw(id, 'caption', p.prompt, '<opis>');
        if ('text' in we && p.prompt && !/lyric/i.test(typ) && !('caption' in we)) {
            ustaw(id, 'text', p.prompt, '<opis>');
        }

        // ACE-Step: tempo, tonacja, metrum i jezyk to WEJSCIA noda, nie tekst w prompcie.
        // Dzieki temu suwak BPM i wybor tonacji z panelu trafiaja wprost do modelu.
        if (p.tags     !== undefined && 'tags' in we) ustaw(id, 'tags', p.tags, '<tagi stylu>');
        // YuE2: opis brzmienia to `style` (YuE2GenerateMusic / YuE2GenerateABC).
        if ('style' in we && p.prompt) ustaw(id, 'style', p.prompt, '<styl>');
        if (p.bpm      !== undefined) ustaw(id, 'bpm', p.bpm);
        if (p.keyscale !== undefined) ustaw(id, 'keyscale', p.keyscale);
        if (p.language !== undefined) ustaw(id, 'language', p.language);
        if (p.timesignature !== undefined) ustaw(id, 'timesignature', p.timesignature);

        if (p.duration   !== undefined) { for (const k of ['max_duration', 'seconds', 'duration']) ustaw(id, k, p.duration); }
        if (p.seed       !== undefined) { for (const k of ['seed', 'noise_seed']) ustaw(id, k, p.seed); }
        if (p.steps      !== undefined) ustaw(id, 'steps', p.steps);
        // `cfg` (sampler) i `cfg_scale` (encoder) to ROZNE wartosci: w ACE 1.0 vs 2.0.
        // Wczesniej wpisywalem te sama liczbe w oba — dla MiniMaxa uchodzilo (1.7/1.7),
        // dla ACE zepsuloby wynik.
        if (p.cfg        !== undefined) { for (const k of ['cfg', 'guidance']) ustaw(id, k, p.cfg); }
        if (p.cfgScale   !== undefined) ustaw(id, 'cfg_scale', p.cfgScale);
        if (p.tiledDecode !== undefined) ustaw(id, 'tiled_decode', p.tiledDecode);
    }
    return podmienione;
}

app.post('/api/music/generate', async (req, res) => {
    const body = req.body ?? {};
    const {
        prompt, lyrics = '', duration = 60, seed, steps, cfg, cfgScale,
        bpm, keyscale, language, timesignature,
        tiledDecode = true,
    } = body;

    // Rodzina modelu: 'ace' (lekka, 8 krokow) albo 'minimax' (ciezka, faza AR).
    // Domyslnie bierzemy te, ktora ma kompletne wagi — z preferencja dla ACE,
    // bo na tym sprzecie MiniMax liczy ~7h na minute (zmierzone).
    const modele = await muzykaModeleStatus();
    const wybrana = body.rodzina
        || (modele.rodziny?.ace?.gotowy ? 'ace' : (modele.rodziny?.minimax?.gotowy ? 'minimax' : 'ace'));
    const cfgRodziny = RODZINY_MUZYKI[wybrana];
    if (!cfgRodziny) {
        return res.status(400).json({
            success: false,
            message: `Nieznana rodzina: ${wybrana}`,
            dostepne: Object.keys(RODZINY_MUZYKI),
        });
    }

    // ── STRAŻ SPÓJNOŚCI RODZIN ────────────────────────────────────────────────
    // Wagi róznych rodzin NIE lacza sie ze soba. Wpuszczenie DiT MiniMaxa do grafu
    // ACE daje `KeyError: 'conditioning_scale'` dopiero po kilkunastu minutach
    // liczenia — nod MiniMaxa dopisuje to pole do kondycjonowania, encoder ACE nie.
    // Zdarzylo sie realnie: panel wysylal ditId z suwaka int8/fp16/fp32 (id MiniMaxa)
    // niezaleznie od wybranej rodziny i nadpisywal domyslny model ACE.
    // Dlatego most odrzuca obce id ZANIM cokolwiek policzy, zamiast im ufac.
    const zObcejRodziny = [];
    const zRodziny = (podane, domyslne, pole) => {
        if (!podane) return domyslne;
        const m = muzykaModelPoId(podane);
        if (!m) { zObcejRodziny.push(`${pole}: nieznane id "${podane}"`); return domyslne; }
        const jego = m.family || 'minimax';
        if (jego !== wybrana) {
            zObcejRodziny.push(`${pole}: "${podane}" należy do rodziny ${jego}, a graf jest z ${wybrana}`);
            return domyslne;
        }
        return podane;
    };
    const ditId  = zRodziny(body.ditId,  cfgRodziny.dit,  'ditId');
    const encId  = zRodziny(body.encId,  cfgRodziny.enc,  'encId');
    const encId2 = zRodziny(body.encId2, cfgRodziny.enc2, 'encId2');
    const vaeId  = zRodziny(body.vaeId,  cfgRodziny.vae,  'vaeId');
    if (zObcejRodziny.length) {
        console.warn(`[Muzyka] ⚠️ Odrzucono wagi z obcej rodziny: ${zObcejRodziny.join(' | ')}`);
    }

    if (!prompt || !String(prompt).trim()) {
        return res.status(400).json({ success: false, message: 'Brak "prompt" (opis brzmienia).' });
    }

    // 1) Wagi tej rodziny na miejscu?
    const stanRodziny = modele.rodziny?.[wybrana];
    if (!stanRodziny?.gotowy) {
        const potrzebne = [cfgRodziny.dit, cfgRodziny.enc, cfgRodziny.enc2, cfgRodziny.vae].filter(Boolean);
        return res.status(424).json({
            success: false,
            etap: 'modele',
            rodzina: wybrana,
            message: `Brak kompletnych wag dla ${cfgRodziny.etykieta}. Brakujące role: ${(stanRodziny?.brakujaceRole ?? []).join(', ') || '—'}${stanRodziny && stanRodziny.encoderow < stanRodziny.potrzebaEncoderow ? ` (encodery: ${stanRodziny.encoderow}/${stanRodziny.potrzebaEncoderow})` : ''}.`,
            hint: `POST /api/music/models/pull { ids: ${JSON.stringify(potrzebne)} } albo panel AI Session → Katalog Modeli.`,
            brakujaceRole: stanRodziny?.brakujaceRole ?? [],
            potrzebne,
        });
    }
    const uszkodzone = modele.pliki.filter(p => p.uszkodzony).map(p => p.id);
    if (uszkodzone.length) {
        return res.status(424).json({
            success: false, etap: 'modele',
            message: `Pliki wag mają zły rozmiar (niedokończone pobieranie): ${uszkodzone.join(', ')}. Ładowanie takiego pliku wywala silnik.`,
            hint: 'Pobierz je ponownie — pobieranie wznawia się od miejsca zerwania.',
        });
    }

    // 2) ComfyUI żyje i zna MiniMax?
    const comfy = await comfyStatus();
    if (!comfy.online) {
        return res.status(424).json({
            success: false, etap: 'comfy', message: comfy.message,
            hint: 'Odpal ComfyUI (run_nvidia_gpu.bat). Katalog wag wskaż przez extra_model_paths.yaml — patrz /api/music/engine/status.',
        });
    }
    if (wybrana === 'minimax' && !comfy.maMinimax) {
        return res.status(424).json({
            success: false, etap: 'comfy-wersja',
            message: `ComfyUI działa (${comfy.nodeCount} nodów), ale nie zna żadnego noda MiniMax.`,
            hint: 'Zaktualizuj ComfyUI — update/update_comfyui.bat. UWAGA: NIE używaj update_comfyui_and_python_dependencies.bat, na tej ścieżce wywala się na limicie 260 znaków (WinError 206) i rozwala instalację.',
        });
    }

    // 3) Workflow tej rodziny (nazw nodów nie wymyślamy — czytamy z pliku)
    // Suweren (albo agent) moze wskazac wlasny graf. Bez tego wybor byl zaszyty
    // w RODZINY_MUZYKI i drugi workflow w katalogu byl nieosiagalny z panelu.
    // Rodzina z własnym węzłem (YuE2): ComfyUI musi go znać, inaczej graf padnie na kolejce.
    if (cfgRodziny.wezel) {
        const zna = await fetch(`${COMFY_BASE}/object_info/${cfgRodziny.wezel}`).then((r) => r.ok).catch(() => false);
        if (!zna) {
            return res.status(424).json({
                success: false, etap: 'comfy-wersja',
                message: `ComfyUI (${comfy.nodeCount} nodów) nie zna węzła ${cfgRodziny.wezel} — ta wersja jest sprzed ${cfgRodziny.etykieta}.`,
                hint: 'Zaktualizuj ComfyUI: update/update_comfyui.bat (NIE update_comfyui_and_python_dependencies.bat — pada na limicie 260 znaków ścieżki). Po aktualizacji zrestartuj ComfyUI.',
            });
        }
    }
    const wskazany = bezpiecznaNazwaWorkflow(body.workflow);
    if (body.workflow && !wskazany) {
        return res.status(400).json({ success: false, etap: 'workflow', message: 'Zla nazwa workflow (oczekuje *.json).' });
    }
    const plikWorkflow = path.join(WORKFLOWS_DIR, wskazany || cfgRodziny.workflow);
    let wf;
    try {
        wf = JSON.parse(await fs.readFile(plikWorkflow, 'utf8'));
    } catch (err) {
        return res.status(424).json({
            success: false, etap: 'workflow', rodzina: wybrana,
            message: `Nie mogę wczytać workflow: ${plikWorkflow} (${err.message})`,
            hint: `W ComfyUI otwórz szablon dla ${cfgRodziny.etykieta} → Workflow → Export (API) → zapisz pod tą nazwą.`,
        });
    }
    // Export (API) daje płaską mapę id→node. Format UI ma "nodes":[...] i tu nie zadziała.
    if (wf.nodes || !Object.values(wf).some(n => n && n.class_type)) {
        return res.status(422).json({
            success: false, etap: 'workflow-format',
            message: 'To workflow w formacie UI, nie API — most nie umie go uruchomić.',
            hint: 'W ComfyUI użyj Workflow → Export (API), nie zwykłego Save.',
        });
    }

    const nazwaPliku = (id) => (id ? muzykaModelPoId(id)?.path.split('/').pop() : undefined);
    const ditFile = nazwaPliku(ditId);
    const encFile = nazwaPliku(encId);
    const encFile2 = nazwaPliku(encId2);
    const vaeFile = nazwaPliku(vaeId);
    const uzytySeed = Number.isFinite(seed) ? seed : Math.floor(Math.random() * 1e15);

    const podmienione = wstrzyknijDoWorkflow(wf, {
        prompt: String(prompt), lyrics: String(lyrics),
        // ACE ma osobne wejscie `tags` na styl; MiniMax dostaje wszystko w `caption`.
        tags: wybrana === 'ace' ? String(prompt) : undefined,
        duration: Number(duration), seed: uzytySeed,
        steps: steps ?? cfgRodziny.steps,
        cfg: cfg ?? cfgRodziny.cfg,
        cfgScale: cfgScale ?? cfgRodziny.cfgScale,
        bpm, keyscale, language, timesignature,
        tiledDecode,
        ditFile, encFile, encFile2, vaeFile,
    });

    // 4) Do kolejki ComfyUI
    try {
        const r = await fetch(`${COMFY_BASE}/prompt`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: wf, client_id: `teo_music_v2_${Date.now()}` }),
        });
        const dane = await r.json().catch(() => ({}));
        if (!r.ok) {
            return res.status(502).json({
                success: false, etap: 'kolejka',
                message: `ComfyUI odrzucił graf (HTTP ${r.status}).`,
                comfyError: dane.error ?? dane, nodeErrors: dane.node_errors ?? null,
                podmienione,
            });
        }
        console.log(`[Muzyka] 🎼 Zakolejkowano w ComfyUI: ${dane.prompt_id} | ${cfgRodziny.etykieta} | seed ${uzytySeed} | ${duration}s`);
        return res.json({
            success: true,
            promptId: dane.prompt_id,
            seed: uzytySeed,
            podmienione,
            rodzina: wybrana,
            uwaga: cfgRodziny.uwaga,
            // Nie milczymy o korektach — Suweren ma widziec, ze cos podmienilismy.
            poprawione: zObcejRodziny.length ? zObcejRodziny : undefined,
            engine: `ComfyUI × ${cfgRodziny.etykieta}`,
            katalogModeli: muzykaKatalogModeli(),
            // Gotowy plik zjedzie do output ComfyUI; przenosinami do _OtakOs_Muzyka
            // zajmuje się /api/music/collect po zakończeniu.
            message: 'Graf w kolejce ComfyUI. Postęp: GET /api/music/progress?promptId=...',
        });
    } catch (err) {
        return res.status(502).json({ success: false, etap: 'kolejka', message: err.message, podmienione });
    }
});

/**
 * Zamienia surowe `messages` z historii ComfyUI na czytelne zdanie.
 * Bez tego front pokazywał zrzut JSON — nieczytelny i wyglądający na awarię
 * nawet wtedy, gdy Suweren sam kliknął anuluj.
 */
function czytelnyKomunikatComfy(messages) {
    const zdarzenia = Array.isArray(messages) ? messages : [];
    const wynik = { przerwane: false, opis: null, node: null };
    for (const m of zdarzenia) {
        const typ = Array.isArray(m) ? m[0] : null;
        const dane = Array.isArray(m) ? (m[1] ?? {}) : {};
        if (typ === 'execution_interrupted') {
            wynik.przerwane = true;
            wynik.node = dane.node_type || dane.node_id || null;
        }
        if (typ === 'execution_error') {
            wynik.opis = dane.exception_message || dane.exception_type || 'nieznany błąd wykonania';
            wynik.node = dane.node_type || dane.node_id || null;
        }
    }
    return wynik;
}

/** Postęp konkretnego zadania + zebranie gotowego audio do _OtakOs_Muzyka. */
app.get('/api/music/progress', async (req, res) => {
    const promptId = req.query.promptId;
    if (!promptId) return res.status(400).json({ success: false, message: 'Brak ?promptId=' });
    try {
        const r = await fetch(`${COMFY_BASE}/history/${promptId}`);
        const hist = await r.json().catch(() => ({}));
        const wpis = hist[promptId];
        if (!wpis) {
            // Jeszcze nie w historii. ComfyUI rozdziela kolejkę na running i pending —
            // rozróżniamy je, bo "w-kolejce" przy liczącym zadaniu wprowadzało w błąd.
            const q = await fetch(`${COMFY_BASE}/queue`).then(x => x.json()).catch(() => ({}));
            const wTablicy = (arr) => Array.isArray(arr) && arr.some(z => JSON.stringify(z).includes(promptId));
            if (wTablicy(q.queue_running)) {
                return res.json({ success: true, stan: 'liczy', promptId, przedNami: 0 });
            }
            if (wTablicy(q.queue_pending)) {
                return res.json({
                    success: true, stan: 'w-kolejce', promptId,
                    przedNami: (q.queue_running?.length ?? 0) + (q.queue_pending ?? []).findIndex(z => JSON.stringify(z).includes(promptId)),
                });
            }
            return res.json({ success: true, stan: 'nieznane', promptId });
        }
        const status = wpis.status ?? {};
        const czytelny = czytelnyKomunikatComfy(status.messages);
        if (czytelny.przerwane) {
            return res.json({
                success: false, stan: 'przerwane', promptId,
                message: `Zadanie przerwane${czytelny.node ? ` na nodzie ${czytelny.node}` : ''} — anulowane w ComfyUI albo z panelu.`,
            });
        }
        if (status.status_str === 'error' || czytelny.opis) {
            return res.json({
                success: false, stan: 'blad', promptId,
                message: czytelny.opis ? `ComfyUI: ${czytelny.opis}${czytelny.node ? ` (node ${czytelny.node})` : ''}` : 'ComfyUI zgłosił błąd wykonania.',
            });
        }
        // Zbieramy pliki audio z outputów
        const audio = [];
        for (const out of Object.values(wpis.outputs ?? {})) {
            for (const a of (out.audio ?? [])) {
                audio.push({
                    filename: a.filename, subfolder: a.subfolder ?? '', type: a.type ?? 'output',
                    url: `${COMFY_BASE}/view?filename=${encodeURIComponent(a.filename)}&subfolder=${encodeURIComponent(a.subfolder ?? '')}&type=${a.type ?? 'output'}`,
                });
            }
        }
        res.json({
            success: true,
            stan: status.completed ? 'gotowe' : (status.status_str || 'w-toku'),
            promptId, audio,
        });
    } catch (err) {
        res.status(502).json({ success: false, message: `ComfyUI nieosiągalny: ${err.message}` });
    }
});

/**
 * Przenosi gotowy utwór z output ComfyUI do biblioteki Katedry (_OtakOs_Muzyka),
 * żeby Graviton Radio i reszta Katedry go widziały. Realny zapis, realny rozmiar.
 */
app.post('/api/music/collect', async (req, res) => {
    const { filename, subfolder = '', type = 'output', title } = req.body ?? {};
    if (!filename) return res.status(400).json({ success: false, message: 'Brak "filename".' });
    try {
        const url = `${COMFY_BASE}/view?filename=${encodeURIComponent(filename)}&subfolder=${encodeURIComponent(subfolder)}&type=${encodeURIComponent(type)}`;
        const r = await fetch(url);
        if (!r.ok) return res.status(502).json({ success: false, message: `ComfyUI /view HTTP ${r.status}` });
        const buf = Buffer.from(await r.arrayBuffer());

        const ext = path.extname(filename) || '.flac';
        const bazowa = (title ? String(title) : path.basename(filename, ext))
            .replace(/[^\p{L}\p{N}_ -]/gu, '').trim().replace(/\s+/g, '_').slice(0, 80) || 'TeO_Utwor';
        const docelowy = path.join(MUSIC_DIR, `${bazowa}_${Date.now()}${ext}`);

        await fs.mkdir(MUSIC_DIR, { recursive: true });
        await fs.writeFile(docelowy, buf);
        const st = await fs.stat(docelowy);
        console.log(`[Muzyka] 💾 Zapisano do biblioteki: ${path.basename(docelowy)} (${(st.size / 1e6).toFixed(1)} MB)`);

        res.json({
            success: true,
            savedPath: docelowy,
            bytes: st.size,
            streamUrl: `http://127.0.0.1:${PORT}/music/${encodeURIComponent(path.basename(docelowy))}`,
        });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 🎤 GŁOS SUWERENA — suwerenny klon głosu (lokalny silnik + fallback) ───────
// Architektura: próbka głosu zapisana LOKALNIE (_OtakOs_AI/voices/). Mowa idzie
// przez lokalny silnik klonu (XTTS/OpenVoice na VOICE_BASE) jeśli obecny; inaczej
// front używa przeglądarki (speechSynthesis). Każdy może to mieć w swojej Katedrze.
const VOICE_BASE = process.env.OTAKOS_VOICE_HOST || 'http://127.0.0.1:5002';
/** Kokoro TTS — lokalny serwer o API zgodnym z OpenAI (Etap 2). */
const KOKORO_BASE = process.env.OTAKOS_KOKORO_HOST || KOKORO_BASE_DOMYSLNY;

/**
 * Klucze przewodów chmurowych czytamy ZE SKARBCA przy każdym użyciu, nigdy
 * z pamięci procesu. Suweren może je dodać albo skasować w trakcie działania
 * mostu i ma to zadziałać od razu, bez restartu.
 */
async function sekretPrzewodu(usluga, pole) {
    try { return await VaultService.getInstance().getSecret(usluga, pole); } catch { return null; }
}

/** Profil głosowy → parametry dla sterownika. Jedno miejsce, wspólne dla speak i render. */
async function ustalTorGlosu({ profil, voiceId, przewod }) {
    let tor = przewod || 'klon-lokalny';
    let glos = voiceId ? String(voiceId).replace(/[^\w-]/g, '') : null;
    let jezyk = 'pl';

    if (profil) {
        const p = (await glosProfile(VOICE_OUT_DIR)).find(x => x.id === profil);
        if (!p) throw new BladPrzewodu(`Profil głosu „${profil}" nieznany.`, 404, null);
        tor = p.przewod || tor;
        glos = p.voiceId || glos;
        jezyk = p.jezyk || jezyk;
    }

    const def = glosPrzewod(tor);
    if (def && !def.sterownik) {
        throw new BladPrzewodu(
            `Przewód „${def.nazwa}" nie ma sterownika w moście — nic nie zabrzmiało.`, 501, tor);
    }
    if (tor === 'przegladarka') {
        throw new BladPrzewodu(
            'Ten profil używa syntezy przeglądarki — most nie ma tu czego wyprodukować. Dźwięk powstaje po stronie Suwerena.',
            424, 'przegladarka');
    }

    return {
        przewod: tor,
        glos,
        jezyk,
        probka: path.join(VOICES_DIR, `${glos || 'suweren'}.wav`),
        klucz: tor === 'elevenlabs-mcp' ? await sekretPrzewodu('elevenlabs', 'api_key') : null,
    };
}
const VOICES_DIR = path.join(AI_DIR, 'voices');

app.get('/api/voice/status', async (req, res) => {
    let available = false;
    try { const c = new AbortController(); const t = setTimeout(() => c.abort(), 1500); const r = await fetch(`${VOICE_BASE}/`, { signal: c.signal }); clearTimeout(t); available = !!r; } catch {}
    let voices = []; try { voices = (await fs.readdir(VOICES_DIR)).filter(f => f.endsWith('.wav')).map(f => f.replace('.wav', '')); } catch {}
    res.json({ success: true, available, base: VOICE_BASE, voices, note: available ? 'Lokalny silnik klonu głosu gotowy.' : 'Brak lokalnego silnika — fallback przeglądarki (speechSynthesis). Zainstaluj XTTS/OpenVoice na :5002 dla suwerennego klonu Twojego głosu.' });
});
/**
 * 🎙️ Dekoder próbki audio z przeglądarki.
 *
 * ⚠️ TU BYŁ BŁĄD, KTÓRY UCISZAŁ CAŁĄ ROZMOWĘ. Prefiks zdejmował wzorzec
 * `^data:audio/\w+;base64,` — a MediaRecorder w Chrome oddaje
 * `data:audio/webm;codecs=opus;base64,...`. Człon `;codecs=opus` sprawiał, że
 * wzorzec NIE pasował, prefiks zostawał w danych i Buffer dekodował śmieci.
 * ffmpeg dostawał plik bez nagłówka i mówił „Invalid data found when processing
 * input" — brzmiało jak awaria ffmpega, a było zwykłym obcięciem o dwa znaki za mało.
 *
 * Dlatego nie dopisujemy kolejnego wariantu wzorca, tylko szukamy `base64,`
 * i bierzemy wszystko PO nim. Każdy typ MIME i każdy zestaw parametrów przejdzie.
 */
function dekodujProbkeAudio(sample) {
    const surowe = String(sample || '');
    const i = surowe.indexOf('base64,');
    const czyste = i >= 0 ? surowe.slice(i + 'base64,'.length) : surowe;
    const buf = Buffer.from(czyste.trim(), 'base64');
    // Nagranie krótsze niż ~1 kB to w praktyce pusty strumień. Lepiej powiedzieć
    // to wprost niż karmić ffmpeg plikiem, który i tak odrzuci.
    if (buf.length < 1024) {
        const e = new Error(`Nagranie jest puste (${buf.length} B) — mikrofon nic nie przechwycił.`);
        e.pusteNagranie = true;
        throw e;
    }
    return buf;
}

/** ffmpeg wypluwa ~40 linii banera przy każdym błędzie. Zostawiamy to, co niesie treść. */
function sednoBleduFfmpeg(err) {
    const tekst = String(err?.stderr || err?.message || '');
    const linie = tekst.split(/\r?\n/).map(l => l.trim())
        .filter(l => l && !/^(ffmpeg version|built with|configuration:|lib[a-z]+\s|\s*--)/.test(l));
    return linie.slice(-3).join(' | ') || String(err?.message || 'ffmpeg nie podał powodu.');
}

app.post('/api/voice/clone', async (req, res) => {
    const { sample, voiceId } = req.body ?? {};
    if (!sample) return res.status(400).json({ success: false, message: 'Brak "sample" (base64 audio).' });
    try {
        await fs.mkdir(VOICES_DIR, { recursive: true });
        const id = String(voiceId || 'suweren').replace(/[^\w-]/g, '') || 'suweren';
        const buf = dekodujProbkeAudio(sample);
        // Normalizacja do czystego WAV (MediaRecorder daje webm/ogg) — ffmpeg.
        const tmp = path.join(TEMP_DIR, `voice_in_${Date.now()}`);
        await fs.writeFile(tmp, buf);
        const out = path.join(VOICES_DIR, `${id}.wav`);
        try { await execFileAsync(ffmpegPath, ['-i', tmp, '-ar', '22050', '-ac', '1', '-y', out]); }
        catch { await fs.writeFile(out, buf); } // gdyby ffmpeg padł — zapisz surowe
        await fs.rm(tmp, { force: true }).catch(() => {});
        const st = await fs.stat(out);
        console.log(`[Głos] 🎤 Próbka zapisana lokalnie: ${id} (${st.size} B)`);
        res.json({ success: true, voiceId: id, file: `voices/${id}.wav`, bytes: st.size });
    } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});
// 🎙️ Wejście głosowe do Orba — nagranie z przeglądarki (base64) → transkrypt (Whisper.cpp lokalnie).
app.post('/api/voice/transcribe', async (req, res) => {
    const { sample, model: modelZadany = 'small' } = req.body ?? {};
    if (!sample) return res.status(400).json({ success: false, message: 'Brak "sample" (base64 audio).' });
    let src = null, wav = null, jsonFile = null;
    try {
        // 'auto' = small (zmierzone 2026-09-17 na CPU: small ~3 s na 5 s nagrania, large-v3-turbo 78 s —
        // turbo jest dokładniejszy po polsku, ale do rozmowy na żywo bezużyteczny bez GPU).
        const model = modelZadany === 'auto' ? 'small' : String(modelZadany).replace(/[^a-z0-9.-]/gi, '');
        const modelPath = path.join(MODELS_DIR, `ggml-${model}.bin`);
        if (!fsSync.existsSync(modelPath)) return res.status(424).json({ success: false, message: `Brak modelu Whisper: ggml-${model}.bin w _OtakOs_AI/models/.` });
        if (!fsSync.existsSync(WHISPER_EXE)) return res.status(424).json({ success: false, message: 'Brak whisper-cli.exe w _OtakOs_AI/bin/.' });

        const buf = dekodujProbkeAudio(sample);
        src = path.join(TEMP_DIR, `orb_voice_in_${Date.now()}`);
        await fs.writeFile(src, buf);

        wav = path.join(TEMP_DIR, `orb_voice_${Date.now()}.wav`);
        try {
            await execFileAsync(ffmpegPath, ['-i', src, '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', '-y', wav]);
        } catch (e) {
            // Bez tego front dostawal 40 linii banera ffmpega zamiast powodu.
            throw new Error(`Nagranie nie dalo sie przetworzyc: ${sednoBleduFfmpeg(e)}`);
        }

        const outBase = path.join(TEMP_DIR, 'orb_voice_tr_' + Date.now());
        jsonFile = outBase + '.json';
        // 2026-09-17 (Delegat z telefonu): Whisper small na cichym/zaszumionym nagraniu zmyślał
        // „[wypowiedź w języku ukraińskim] (pogodna muzyka) [oklaski]" — tagi z napisów, na
        // których go uczono. `-sns` tłumi tokeny nie-mowy, `--prompt` kotwiczy polski i styl
        // rozmowy, a resztę nawiasów wycinamy niżej. Pusty wynik oddajemy JAKO PUSTY, nie
        // jako „słowa", które Delegat weźmie za polecenie.
        await execFileAsync(WHISPER_EXE, ['-m', modelPath, '-f', wav, '--output-json-full', '-p', '4', '-l', 'pl', '-sns', '--prompt', 'Rozmowa po polsku z Katedrą OtakOS.', '-of', outBase], { cwd: BIN_DIR });
        if (!fsSync.existsSync(jsonFile)) throw new Error('Whisper nie wygenerował wyniku.');
        const out = JSON.parse(fsSync.readFileSync(jsonFile, 'utf8'));
        const segmenty = out.transcription || [];
        const surowy = segmenty.map(s => String(s.text || '').trim()).join(' ').replace(/\s+/g, ' ').trim();
        // BRAMKA HALUCYNACJI (zmierzone na szumie różowym): Whisper zmyśla „Dziękuję za uwagę." ×4
        // albo „Cześć, cześć, cześć." ze średnim p tokenów ~0,55; prawdziwa mowa ma ~0,75.
        // Segment odpada, gdy średnie p < 0,5 albo ten sam tekst powtarza się ≥3 razy.
        const licznik = new Map();
        for (const s of segmenty) { const k = String(s.text || '').trim().toLowerCase(); licznik.set(k, (licznik.get(k) || 0) + 1); }
        const zdrowe = segmenty.filter((s) => {
            const ps = (s.tokens || []).filter((t) => !String(t.text || '').startsWith('[_')).map((t) => Number(t.p) || 0);
            const srednie = ps.length ? ps.reduce((a, b) => a + b, 0) / ps.length : 0;
            const powtorka = (licznik.get(String(s.text || '').trim().toLowerCase()) || 0) >= 3;
            const wewn = /^(.{3,}?)([,.!?]\s*\1){2,}[,.!?]?$/i.test(String(s.text || '').trim());
            return srednie >= 0.5 && !powtorka && !wewn;
        });
        const transcript = zdrowe.map(s => String(s.text || '').trim()).join(' ')
            .replace(/\[[^\]]*\]|\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
        // Gdy większość segmentów to zmyślenia, resztka („Dzień dobry.") też jest zmyśleniem.
        const odrzucone = segmenty.length - zdrowe.length;
        const pusto = !/[\p{L}]{2,}/u.test(transcript) || (odrzucone > 0 && odrzucone >= zdrowe.length);
        return res.json({ success: true, transcript: pusto ? '' : transcript, pusto, model, odrzucone, surowy: surowy !== transcript ? surowy : undefined });
    } catch (err) {
        // Puste nagranie to nie awaria mostu, tylko brak wejscia — 400, nie 500.
        return res.status(err?.pusteNagranie ? 400 : 500).json({ success: false, message: err.message });
    } finally {
        try {
            if (src) await fs.rm(src, { force: true });
            if (wav) await fs.rm(wav, { force: true });
            if (jsonFile) await fs.rm(jsonFile, { force: true });
        } catch {}
    }
});

/**
 * POST /api/voice/speak — mowa strumieniem do przeglądarki.
 * Body: { text, voiceId? , profil?, przewod? }
 *
 * Od Etapu 2 idzie przez `PrzewodyGlosuService`, więc obsługuje wszystkie tory
 * ze sterownikiem (lokalny klon, Kokoro, ElevenLabs). Bez `profil`/`przewod`
 * zachowuje się dokładnie jak wcześniej: lokalny klon, a przy jego braku 424
 * z `fallback: 'browser'` — front ma na tym oparty tor zapasowy i nie wolno
 * mu tego kształtu odpowiedzi zabrać.
 */
app.post('/api/voice/speak', async (req, res) => {
    const { text, voiceId, profil, przewod } = req.body ?? {};
    if (!text) return res.status(400).json({ success: false, message: 'Brak "text".' });
    try {
        const tor = await ustalTorGlosu({ profil, voiceId, przewod });
        const { audio, mime } = await glosSyntezuj({
            przewod: tor.przewod, tekst: text, glos: tor.glos, jezyk: tor.jezyk,
            probka: tor.probka, adresy: { VOICE_BASE, KOKORO_BASE }, klucz: tor.klucz,
        });
        res.setHeader('Content-Type', mime);
        res.setHeader('X-Przewod', tor.przewod);
        return res.send(audio);
    } catch (e) {
        const status = e instanceof BladPrzewodu ? e.status : 424;
        return res.status(status).json({
            success: false,
            fallback: 'browser',
            przewod: e?.przewod ?? null,
            message: `${e.message} Front może użyć toru przeglądarki.`,
        });
    }
});

/**
 * GET /api/voice/elevenlabs/glosy — lista głosów konta.
 * Bez tego profil ElevenLabs wymagałby wklepywania ID głosu z palca.
 */
/**
 * GET /api/voice/piper/glosy — jakie POLSKIE głosy realnie leżą na dysku.
 * Lista z katalogu wag, nie z tabelki w kodzie — jak wagi znikną, lista zniknie.
 */
app.get('/api/voice/piper/glosy', async (req, res) => {
    const glosy = await glosyPiper();
    res.json({
        success: true,
        glosy,
        domyslny: PIPER_DOMYSLNY,
        katalog: PIPER_GLOSY,
        przewod: 'piper-pl',
        message: glosy.length ? undefined
            : `Brak wag w ${PIPER_GLOSY}. Pobierz głos pl_PL z rhasspy/piper-voices.`,
    });
});

app.get('/api/voice/elevenlabs/glosy', async (req, res) => {
    try {
        const glosy = await glosyElevenLabs(await sekretPrzewodu('elevenlabs', 'api_key'));
        return res.json({ success: true, glosy });
    } catch (e) {
        return res.status(e instanceof BladPrzewodu ? e.status : 500).json({ success: false, message: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🏢 TWOJE BIZNESY — rejestr działalności Suwerena + Służba płacona w GRV
//
//  Etap 1: karty działalności, przypisany głos, księga zdarzeń Służby.
//
//  ⚠️ GRV idzie TĄ SAMĄ drogą co każda inna praca: `oddechZaPrace` → `ocenPrace`
//  (limit dobowy + klucz jednokrotności) → `przelejGrv` (pieczęć w łańcuchu).
//  Nie ma tu drugiej ścieżki emisji i mieć nie będzie — księga, której
//  `verifyGrvChain` nie potwierdza, to ekonomia bez dowodu.
// ══════════════════════════════════════════════════════════════════════════════

/** Folder audio modułu głosowego: profile + wyrenderowane nagrania. */
const VOICE_OUT_DIR = path.join(process.cwd(), '_OtakOs_Voice');

app.get('/api/business/list', async (req, res) => {
    try {
        return res.json({ success: true, ...(await biznesStan(ANTIGRAVITY_DIR)) });
    } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

app.post('/api/business/create', async (req, res) => {
    try {
        const biznes = await biznesDodaj(ANTIGRAVITY_DIR, req.body ?? {});
        console.log(`[Biznesy] 🏢 Nowa działalność: ${biznes.nazwa} (${biznes.id}).`);
        return res.json({ success: true, biznes });
    } catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});

app.patch('/api/business/:id', async (req, res) => {
    try {
        return res.json({ success: true, biznes: await biznesZaktualizuj(ANTIGRAVITY_DIR, req.params.id, req.body ?? {}) });
    } catch (e) { return res.status(404).json({ success: false, message: e.message }); }
});

app.delete('/api/business/:id', async (req, res) => {
    try {
        return res.json({ success: true, ...(await biznesUsun(ANTIGRAVITY_DIR, req.params.id)) });
    } catch (e) { return res.status(404).json({ success: false, message: e.message }); }
});

/** Feed Służby — „Live Orders". Bez filtra: wszystkie działalności razem. */
app.get('/api/business/ledger', async (req, res) => {
    try {
        const biznesId = String(req.query.biznesId || '') || null;
        const limit = Number(req.query.limit || 40);
        return res.json({ success: true, zdarzenia: await biznesZdarzenia(ANTIGRAVITY_DIR, { biznesId, limit }) });
    } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

/**
 * POST /api/business/sluzba — zgłoszenie wykonanej Służby.
 * Body: { biznesId, akcja, klucz, opis?, klient?, wezel? }
 *
 * `klucz` jest OBOWIĄZKOWY i nie ma domyślnej wartości. Gdyby most sam go
 * dorabiał (choćby ze znacznika czasu), jedno kliknięcie w kółko drukowałoby
 * GRV — a nagroda za służbę zamieniłaby się w automat do gry.
 */
app.post('/api/business/sluzba', async (req, res) => {
    const { biznesId, akcja, klucz, opis, klient, wezel } = req.body ?? {};
    try {
        const def = BIZNES_AKCJE[akcja];
        if (!def) {
            return res.status(400).json({
                success: false,
                message: `Nieznana akcja Służby „${akcja}". Dozwolone: ${Object.keys(BIZNES_AKCJE).join(', ')}.`,
            });
        }
        if (!String(klucz || '').trim()) {
            return res.status(400).json({ success: false, message: 'Wymagany „klucz" jednokrotności — bez niego ta sama służba płaciłaby w kółko.' });
        }
        const biznes = await biznesZnajdz(ANTIGRAVITY_DIR, String(biznesId || ''));
        if (!biznes) return res.status(404).json({ success: false, message: `Działalność „${biznesId}" nieznana.` });

        const kluczPelny = `biznes:${biznes.id}:${akcja}:${String(klucz).trim()}`;
        const oddech = await oddechZaPrace(def.oddech, kluczPelny, null, wezel || ODDECH_WEZEL);

        // `oddechZaPrace` zwraca null, gdy sam oddech padł. Służba i tak się wydarzyła,
        // więc zapisujemy ją bez GRV i mówimy wprost, że nagroda nie doszła.
        const przyznane = !!oddech?.przyznane;
        const grv = przyznane ? oddech.grv : 0;
        const powod = oddech ? (oddech.powod ?? null) : 'Oddech nieosiągalny — GRV nie zostało naliczone.';

        const zdarzenie = await biznesZapiszZdarzenie(ANTIGRAVITY_DIR, {
            biznesId: biznes.id, akcja, klucz: kluczPelny, opis, klient, grv, przyznane, powod,
        });

        if (przyznane) console.log(`[Biznesy] 💰 ${biznes.nazwa}: ${def.opis} → +${grv} GRV.`);
        return res.json({ success: true, zdarzenie, oddech: oddech ?? { przyznane: false, powod }, biznes: biznes.id });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

/** Poświadczenia telefonii — trzy pola, wszystkie ze Skarbca 0.00G. */
async function poswiadczeniaTwilio() {
    const [sid, token, od] = await Promise.all([
        sekretPrzewodu('twilio', 'account_sid'),
        sekretPrzewodu('twilio', 'auth_token'),
        sekretPrzewodu('twilio', 'from_number'),
    ]);
    return { sid, token, od };
}

/**
 * GET /api/business/telefonia — czy przewód telefoniczny jest DROŻNY.
 *
 * Odpytuje konto Twilio, zamiast wnioskować z samej obecności klucza w skarbcu.
 * Klucz bywa nieaktualny, a konto zawieszone — i wtedy „skonfigurowany" znaczy
 * dokładnie nic.
 */
app.get('/api/business/telefonia', async (req, res) => {
    const { sid, token, od } = await poswiadczeniaTwilio();
    const braki = [];
    if (!sid) braki.push('twilio.account_sid');
    if (!token) braki.push('twilio.auth_token');
    if (!od) braki.push('twilio.from_number');

    const tunel = await tunelWczytaj(ANTIGRAVITY_DIR);
    const mozliwosci = telefoniaMozliwosci(!!tunel.adres);

    if (braki.length) {
        return res.json({
            success: true, drozny: false, braki, mozliwosci, tunel,
            message: `Przewód telefoniczny niekompletny — brakuje w Skarbcu 0.00G: ${braki.join(', ')}.`,
        });
    }
    try {
        const konto = await telefoniaStanKonta({ sid, token });
        return res.json({
            success: true, drozny: true, braki: [], konto, od, mozliwosci, tunel,
            message: konto.prubny
                ? 'Konto próbne Twilio: dodzwoni się TYLKO na numery zweryfikowane i doklei własną zapowiedź.'
                : 'Przewód telefoniczny drożny.',
        });
    } catch (e) {
        return res.status(e instanceof BladTelefonii ? e.status : 500)
            .json({ success: false, drozny: false, message: e.message, mozliwosci, tunel });
    }
});

/**
 * POST /api/business/dial — połączenie wychodzące (Etap 2 — sterownik Twilio).
 * Body: { biznesId, numer?, tekst?, jezyk?, glos?, proba?, potwierdzenie? }
 *
 * ⚠️ DWA BEZPIECZNIKI, KTÓRYCH NIE WOLNO STĄD ZDJĄĆ:
 *
 *  1. `proba` jest DOMYŚLNIE `true`. Zwykłe kliknięcie sprawdza poświadczenia,
 *     składa TwiML i pokazuje, co POSZŁOBY na linię — bez dzwonienia. Realne
 *     połączenie trzeba zamówić jawnie (`proba: false`).
 *  2. Realne połączenie wymaga dodatkowo `potwierdzenie: true`. To jest telefon
 *     do żywego człowieka i realny rachunek u operatora — jedno przypadkowe
 *     kliknięcie nie ma prawa go zestawić.
 *
 * Rozmowa dwustronna (Media Streams) i klon Suwerena w słuchawce wymagają
 * publicznego adresu — Etap 3. Tu mówi głos Twilio, i tak to jest opisane.
 */
app.post('/api/business/dial', async (req, res) => {
    const { biznesId, numer, tekst, jezyk = 'pl-PL', glos = 'Polly.Ewa', proba = true, potwierdzenie = false, tryb = 'zapowiedz' } = req.body ?? {};
    try {
        const biznes = await biznesZnajdz(ANTIGRAVITY_DIR, String(biznesId || ''));
        if (!biznes) return res.status(404).json({ success: false, message: `Działalność „${biznesId}" nieznana.` });

        const cel = String(numer || biznes.telefon || '').trim();
        if (!cel) {
            return res.status(400).json({ success: false, message: 'Brak numeru docelowego (ani w żądaniu, ani w karcie działalności).' });
        }

        const naprawde = proba === false;
        if (naprawde && potwierdzenie !== true) {
            return res.status(428).json({
                success: false, wykonane: false,
                message: 'Realne połączenie wymaga jawnego „potwierdzenie": true. To telefon do żywego człowieka i rachunek u operatora — nie zestawiam go z domyślnych ustawień.',
            });
        }

        const { sid, token, od } = await poswiadczeniaTwilio();
        const tresc = String(tekst || '').trim() ||
            `Dzień dobry. Tu asystent głosowy ${biznes.nazwa}. Dzwonię w sprawie Państwa zapytania. Proszę o kontakt, gdy będzie dogodna chwila.`;

        // ── Tryb ROZMOWY (Etap 3): audio idzie na nasz publiczny WSS ─────────
        // Bilet jest wydawany DOPIERO dla realnego połączenia. W próbie ich nie
        // sypiemy — inaczej każde kliknięcie „Próba" zostawiałoby ważny token
        // wstępu na kanał audio.
        let twimlRozmowy = null;
        if (tryb === 'rozmowa') {
            const tunel = await tunelWczytaj(ANTIGRAVITY_DIR);
            if (!tunel.wss) {
                return res.status(424).json({
                    success: false, wykonane: false,
                    message: 'Rozmowa dwustronna wymaga Kwantowego Tunelu — Twilio nie ma dokąd oddać audio. Wpnij adres publiczny (POST /api/tunel).',
                });
            }
            const bilet = naprawde ? nowyBilet({ biznesId: biznes.id, kierunek: 'wychodzace' }) : 'PRÓBA-BEZ-BILETU';
            twimlRozmowy = zbudujTwimlStream({
                wssUrl: `${tunel.wss}/api/voice/stream`,
                bilet,
                powitanie: tresc,
                jezyk, glos,
                parametry: { biznesId: biznes.id, kierunek: 'wychodzace' },
            });
        }

        const wynik = await telefoniaZadzwon({
            sid, token, od, doKogo: cel, tekst: tresc, jezyk, glos,
            twiml: twimlRozmowy, proba: !naprawde,
        });

        if (wynik.wykonane) {
            console.log(`[Biznesy] ☎️ Połączenie zestawione: ${biznes.nazwa} → ${cel} (callSid ${wynik.callSid}).`);
            // Ślad w księdze — ale BEZ GRV. Zestawione połączenie to jeszcze nie
            // domknięta rozmowa; za tę płaci osobne zgłoszenie Służby.
            await biznesZapiszZdarzenie(ANTIGRAVITY_DIR, {
                biznesId: biznes.id,
                akcja: 'rozmowa.wychodzaca',
                klucz: `dial:${wynik.callSid ?? Date.now().toString(36)}`,
                opis: `połączenie wychodzące do ${cel}`,
                klient: cel,
                grv: 0,
                przyznane: false,
                powod: 'Zestawione połączenie to jeszcze nie domknięta rozmowa — GRV należy się za „rozmowa.domknieta".',
            });
        }

        return res.json({ success: true, przewod: 'twilio-conduit', tryb, ...wynik });
    } catch (e) {
        return res.status(e instanceof BladTelefonii ? e.status : 500)
            .json({ success: false, wykonane: false, przewod: 'twilio-conduit', message: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🎙️ GŁOS DZIAŁALNOŚCI — profile głosowe i katalog przewodów Voice/Audio MCP
// ══════════════════════════════════════════════════════════════════════════════

/** GET /api/voice/profiles — profile + informacja, czy próbka klonu realnie leży na dysku. */
app.get('/api/voice/profiles', async (req, res) => {
    try {
        const profile = await glosProfile(VOICE_OUT_DIR);
        const zProbka = profile.map(p => ({
            ...p,
            probkaIstnieje: fsSync.existsSync(path.join(VOICES_DIR, `${p.voiceId}.wav`)),
        }));
        return res.json({ success: true, profile: zProbka, katalog: '_OtakOs_Voice' });
    } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

app.post('/api/voice/profiles', async (req, res) => {
    try {
        const profil = await glosZapiszProfil(VOICE_OUT_DIR, req.body ?? {});
        const probkaIstnieje = fsSync.existsSync(path.join(VOICES_DIR, `${profil.voiceId}.wav`));
        return res.json({ success: true, profil: { ...profil, probkaIstnieje } });
    } catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});

app.delete('/api/voice/profiles/:id', async (req, res) => {
    try {
        return res.json({ success: true, ...(await glosUsunProfil(VOICE_OUT_DIR, req.params.id)) });
    } catch (e) { return res.status(404).json({ success: false, message: e.message }); }
});

/**
 * GET /api/voice/mcp — stan przewodów Voice/Audio.
 *
 * Zwraca DWA różne pola i UI ma je rozróżniać: `podpiety` (klucz w skarbcu lub
 * żywy serwer) oraz `sterownik` (most umie tędy poprowadzić dźwięk). Przewód
 * opłacony i skonfigurowany bywa całkowicie bezużyteczny, dopóki nie ma obsługi.
 */
app.get('/api/voice/mcp', async (req, res) => {
    try {
        const zywy = async (url) => {
            try {
                const c = new AbortController(); const t = setTimeout(() => c.abort(), 1500);
                const r = await fetch(url, { signal: c.signal }); clearTimeout(t);
                return !!r;
            } catch { return false; }
        };
        const maKlucz = async (usluga, pole) => {
            try { return !!(await VaultService.getInstance().getSecret(usluga, pole)); } catch { return false; }
        };
        const przewody = await glosStatusPrzewodow(
            { zywy, maKlucz, maPlik: (s) => fsSync.existsSync(s) },
            { VOICE_BASE, WHISPER_EXE, KOKORO_BASE },
        );
        return res.json({
            success: true,
            przewody,
            gotowych: przewody.filter(p => p.sterownik && p.podpiety).length,
            wKatalogu: przewody.length,
            // Czego telefonia POTRAFI, a czego nie — żeby panel nie obiecywał Etapu 3.
            // Połowa możliwości telefonii stoi na tunelu — pytamy o jego stan,
            // zamiast deklarować z góry.
            telefonia: telefoniaMozliwosci(!!(await tunelWczytaj(ANTIGRAVITY_DIR)).adres),
            nagrania: await glosNagrania(VOICE_OUT_DIR),
        });
    } catch (e) { return res.status(500).json({ success: false, message: e.message }); }
});

/**
 * POST /api/voice/render — mowa zapisana jako plik w `_OtakOs_Voice/`.
 * Body: { text, profil? | voiceId?, nazwa? }
 *
 * W odróżnieniu od `/api/voice/speak` (strumień do przeglądarki) tu zostaje
 * artefakt na dysku Suwerena — zapowiedź, powitanie w słuchawce, kwestia agenta.
 * Bez lokalnego silnika NIE renderujemy niczego i mówimy to kodem 424.
 */
app.post('/api/voice/render', async (req, res) => {
    const { text, profil, voiceId, nazwa } = req.body ?? {};
    if (!String(text || '').trim()) return res.status(400).json({ success: false, message: 'Brak „text" do wypowiedzenia.' });

    try {
        const tor = await ustalTorGlosu({ profil, voiceId, przewod: req.body?.przewod });
        const { audio, ext } = await glosSyntezuj({
            przewod: tor.przewod, tekst: text, glos: tor.glos, jezyk: tor.jezyk,
            probka: tor.probka, adresy: { VOICE_BASE, KOKORO_BASE }, klucz: tor.klucz,
        });

        await fs.mkdir(VOICE_OUT_DIR, { recursive: true });
        const stempel = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const etykieta = String(nazwa || tor.glos || tor.przewod).replace(/[^\w-]/g, '').slice(0, 40) || 'glos';
        const plik = path.join(VOICE_OUT_DIR, `${stempel}_${etykieta}.${ext}`);
        await fs.writeFile(plik, audio);

        console.log(`[Głos] 💾 Nagranie zapisane (${tor.przewod}): _OtakOs_Voice/${path.basename(plik)} (${audio.length} B).`);
        return res.json({
            success: true,
            plik: `_OtakOs_Voice/${path.basename(plik)}`,
            bajty: audio.length,
            przewod: tor.przewod,
            voiceId: tor.glos,
        });
    } catch (e) {
        return res.status(e instanceof BladPrzewodu ? e.status : 500).json({
            success: false, przewod: e?.przewod ?? null, message: e.message,
        });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🌀 KWANTOWY TUNEL — publiczny adres maszyny Suwerena (Etap 3)
// ══════════════════════════════════════════════════════════════════════════════

app.get('/api/tunel', async (req, res) => {
    const tunel = await tunelWczytaj(ANTIGRAVITY_DIR);
    // „Wpisany" i „działający" to dwie różne rzeczy — tunel potrafi paść cicho.
    const zywy = req.query.sprawdz === '0' ? { zywy: null } : await tunelCzyZywy(tunel.adres);
    res.json({ success: true, ...tunel, ...zywy, biletow: biletowWObiegu() });
});

app.post('/api/tunel', async (req, res) => {
    const { adres, opis } = req.body ?? {};
    try {
        const t = await tunelUstaw(ANTIGRAVITY_DIR, adres, opis);
        return res.json({ success: true, ...t, ...(await tunelCzyZywy(t.adres)) });
    } catch (e) {
        return res.status(e instanceof BladTunelu ? e.status : 500).json({ success: false, message: e.message });
    }
});

app.delete('/api/tunel', async (req, res) => {
    res.json({ success: true, ...(await tunelZdejmij(ANTIGRAVITY_DIR)) });
});

// ══════════════════════════════════════════════════════════════════════════════
//  🔴 ROZMOWA DWUSTRONNA — STT → LLM → TTS w czasie rzeczywistym (Etap 3)
//
//  Sama pętla (protokół Twilio, VAD, barge-in, rytm 20 ms) siedzi w
//  LiveAudioStreamService. Tutaj wpinamy w nią PRAWDZIWE narzędzia Katedry:
//  Whisper, Ollamę i sterowniki głosu z Etapu 2. Rozdział jest celowy — dzięki
//  niemu pętlę da się przetestować atrapami, bez dzwonienia do człowieka.
// ══════════════════════════════════════════════════════════════════════════════

/** Model rozmowy. Osobny od czatu, bo tu liczy się czas odpowiedzi, nie erudycja. */
const MODEL_ROZMOWY = process.env.OTAKOS_MODEL_ROZMOWY || 'gemma4';
/** Rozmówca nie będzie czekał pół minuty — po tym czasie mówimy o kłopocie. */
const LIMIT_LLM_MS = 25_000;

// ── Słuchacze SSE panelu (Live Call Monitor) ─────────────────────────────────
const sluchaczeLive = new Set();

function rozeslijLive(ev) {
    const dane = `data: ${JSON.stringify(ev)}\n\n`;
    for (const r of sluchaczeLive) {
        try { r.write(dane); } catch { sluchaczeLive.delete(r); }
    }
}

app.get('/api/voice/live', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();
    res.write(`data: ${JSON.stringify({ typ: 'polaczono', rozmowy: zyweRozmowy() })}\n\n`);

    sluchaczeLive.add(res);
    // Bicie serca — bez niego pośrednicy ucinają cichy strumień po ~30 s,
    // a panel wygląda, jakby rozmowa zamarła.
    const puls = setInterval(() => { try { res.write(': puls\n\n'); } catch { /* noop */ } }, 25_000);
    req.on('close', () => { clearInterval(puls); sluchaczeLive.delete(res); });
});

app.get('/api/voice/live/rozmowy', (req, res) => {
    res.json({ success: true, rozmowy: zyweRozmowy(), sluchaczy: sluchaczeLive.size });
});

/** ✋ Przejęcie mikrofonu przez Suwerena — AI milknie do odwołania. */
app.post('/api/voice/live/:callSid/przejmij', async (req, res) => {
    const r = zywaRozmowa(req.params.callSid);
    if (!r) return res.status(404).json({ success: false, message: 'Nie ma takiej żywej rozmowy.' });
    try { return res.json({ success: true, stan: await r.przejmij({ tekst: req.body?.tekst ?? null }) }); }
    catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});

/** Oddanie mikrofonu z powrotem AI. Nigdy nie dzieje się samo. */
app.post('/api/voice/live/:callSid/oddaj', (req, res) => {
    const r = zywaRozmowa(req.params.callSid);
    if (!r) return res.status(404).json({ success: false, message: 'Nie ma takiej żywej rozmowy.' });
    try { return res.json({ success: true, stan: r.oddaj() }); }
    catch (e) { return res.status(400).json({ success: false, message: e.message }); }
});

app.post('/api/voice/live/:callSid/rozlacz', (req, res) => {
    const r = zywaRozmowa(req.params.callSid);
    if (!r) return res.status(404).json({ success: false, message: 'Nie ma takiej żywej rozmowy.' });
    return res.json({ success: true, ...r.rozlacz(req.body?.powod ?? 'decyzja Suwerena') });
});

/**
 * POST /api/voice/incoming — webhook Twilio dla połączeń PRZYCHODZĄCYCH.
 *
 * ⚠️ TO JEST PUBLICZNY ADRES NA MASZYNIE SUWERENA. Każde żądanie jest
 * weryfikowane podpisem `X-Twilio-Signature`; bez ważnego podpisu odpowiadamy
 * 403 i nie wykonujemy NICZEGO. Adres tunelu prędzej czy później gdzieś
 * wycieknie, a wtedy jedyną barierą jest ten podpis.
 */
app.post('/api/voice/incoming', async (req, res) => {
    const { token } = await poswiadczeniaTwilio();
    const tunel = await tunelWczytaj(ANTIGRAVITY_DIR);

    if (!tunel.adres || !tunel.wss) {
        console.warn('[Live] ⛔ Połączenie przychodzące przy odpiętym tunelu.');
        return res.status(503).type('text/xml').send(
            '<?xml version="1.0" encoding="UTF-8"?><Response><Say language="pl-PL" voice="Polly.Ewa">Przepraszamy, asystent jest chwilowo niedostępny.</Say></Response>');
    }

    const podpis = req.get('X-Twilio-Signature');
    const w = telefoniaPodpis({ url: `${tunel.adres}/api/voice/incoming`, params: req.body ?? {}, podpis, token });
    if (!w.ok) {
        console.warn(`[Live] ⛔ Odrzucony webhook przychodzący: ${w.powod}`);
        return res.status(403).type('text/plain').send('Podpis nieprawidłowy.');
    }

    const doNumeru = String(req.body?.To ?? '');
    const odNumeru = String(req.body?.From ?? '');
    const wszystkie = await biznesStan(ANTIGRAVITY_DIR);
    const biznes = wszystkie.biznesy.find(b => b.telefon && b.telefon === doNumeru)
        ?? wszystkie.biznesy.find(b => b.aktywny)
        ?? null;

    const bilet = nowyBilet({ biznesId: biznes?.id ?? null, kierunek: 'przychodzace' });
    console.log(`[Live] 📞 Przychodzące ${odNumeru} → ${doNumeru} (${biznes?.nazwa ?? 'bez działalności'}).`);

    const twiml = zbudujTwimlStream({
        wssUrl: `${tunel.wss}/api/voice/stream`,
        bilet,
        powitanie: biznes
            ? `Dzień dobry, tu asystent głosowy ${biznes.nazwa}. W czym mogę pomóc?`
            : 'Dzień dobry, tu asystent głosowy. W czym mogę pomóc?',
        parametry: { biznesId: biznes?.id ?? '', kierunek: 'przychodzace' },
    });
    return res.type('text/xml').send(twiml);
});

// ── NARZĘDZIA ROZMOWY: Whisper → Ollama → sterowniki głosu ───────────────────

/**
 * μ-law 8 kHz z telefonu → tekst. Whisper chce 16 kHz PCM, więc po drodze
 * jedzie ffmpeg. Oba pliki lądują w temp i są sprzątane bez względu na wynik.
 */
async function transkrybujUlaw(ulaw, model = 'small') {
    const modelPath = path.join(MODELS_DIR, `ggml-${model}.bin`);
    if (!fsSync.existsSync(modelPath)) throw new Error(`Brak modelu Whisper ggml-${model}.bin w _OtakOs_AI/models/.`);
    if (!fsSync.existsSync(WHISPER_EXE)) throw new Error('Brak whisper-cli.exe w _OtakOs_AI/bin/.');

    const stempel = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const surowy = path.join(TEMP_DIR, `live_${stempel}.ulaw`);
    const wav = path.join(TEMP_DIR, `live_${stempel}.wav`);
    const baza = path.join(TEMP_DIR, `live_${stempel}_tr`);
    const json = baza + '.json';

    try {
        await fs.mkdir(TEMP_DIR, { recursive: true });
        await fs.writeFile(surowy, ulaw);
        await execFileAsync(ffmpegPath, [
            '-f', 'mulaw', '-ar', '8000', '-ac', '1', '-i', surowy,
            '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', '-y', wav,
        ]);
        await execFileAsync(WHISPER_EXE, ['-m', modelPath, '-f', wav, '--output-json-full', '-p', '4', '-l', 'pl', '-of', baza], { cwd: BIN_DIR });
        if (!fsSync.existsSync(json)) throw new Error('Whisper nie wygenerował wyniku.');
        const out = JSON.parse(fsSync.readFileSync(json, 'utf8'));
        return (out.transcription || []).map(s => String(s.text || '').trim()).join(' ').replace(/\s+/g, ' ').trim();
    } finally {
        for (const p of [surowy, wav, json]) { try { await fs.rm(p, { force: true }); } catch { /* noop */ } }
    }
}

/**
 * Odpowiedź rozmowy. Krótka, mówiona, bez znaczników.
 *
 * ⚠️ Prompt zakazuje emoji i markdownu nie dla estetyki: TTS CZYTA je na głos
 * („gwiazdka", „myślnik"), a przez telefon brzmi to jak zepsuty automat.
 */
async function odpowiedzRozmowy({ tekst, historia, biznes }) {
    const system = [
        `Jesteś asystentem głosowym firmy „${biznes?.nazwa ?? 'Katedra'}".`,
        biznes?.opis ? `Czym się zajmuje: ${biznes.opis}` : null,
        'Rozmawiasz przez TELEFON. Odpowiadaj po polsku, maksymalnie dwoma krótkimi zdaniami.',
        'Zero emoji, zero znaczników, zero list — twoje słowa idą prosto do syntezatora mowy.',
        'Nie zmyślaj cen, terminów ani dostępności. Czego nie wiesz, tego nie obiecuj — zaproponuj kontakt.',
    ].filter(Boolean).join(' ');

    const wiadomosci = (historia ?? []).slice(-8).map(h => ({
        role: h.rola === 'klient' ? 'user' : 'assistant',
        content: h.tekst,
    }));
    if (!wiadomosci.length) wiadomosci.push({ role: 'user', content: tekst });

    const c = new AbortController();
    const t = setTimeout(() => c.abort(), LIMIT_LLM_MS);
    try {
        const r = await fetch(`${OLLAMA_BASE}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: MODEL_ROZMOWY,
                messages: [{ role: 'system', content: system }, ...wiadomosci],
                stream: false,
                options: { num_predict: 120, temperature: 0.6 },
            }),
            signal: c.signal,
        });
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
        const d = await r.json();
        return String(d?.message?.content ?? '').replace(/[*_`#]/g, '').trim();
    } catch (e) {
        throw new Error(`Model rozmowy (${MODEL_ROZMOWY}) nie odpowiedział: ${e.name === 'AbortError' ? `przekroczone ${LIMIT_LLM_MS / 1000}s` : e.message}`);
    } finally { clearTimeout(t); }
}

/** Tekst → μ-law 8 kHz gotowe do wysłania w ramkach Twilio. */
async function mowaUlaw({ tekst, biznes }) {
    const tor = await ustalTorGlosu({ profil: biznes?.voiceProfile ?? null });
    const { audio, ext } = await glosSyntezuj({
        przewod: tor.przewod, tekst, glos: tor.glos, jezyk: tor.jezyk,
        probka: tor.probka, adresy: { VOICE_BASE, KOKORO_BASE }, klucz: tor.klucz,
    });

    const stempel = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const wejscie = path.join(TEMP_DIR, `live_out_${stempel}.${ext}`);
    const wyjscie = path.join(TEMP_DIR, `live_out_${stempel}.ulaw`);
    try {
        await fs.mkdir(TEMP_DIR, { recursive: true });
        await fs.writeFile(wejscie, audio);
        await execFileAsync(ffmpegPath, ['-i', wejscie, '-ar', '8000', '-ac', '1', '-f', 'mulaw', '-y', wyjscie]);
        return await fs.readFile(wyjscie);
    } finally {
        for (const p of [wejscie, wyjscie]) { try { await fs.rm(p, { force: true }); } catch { /* noop */ } }
    }
}

/** Zależności pętli rozmowy — wpinane raz, przy starcie mostu. */
const ZALEZNOSCI_ROZMOWY = {
    transkrybuj: (ulaw) => transkrybujUlaw(ulaw),
    odpowiedz: (x) => odpowiedzRozmowy(x),
    mowa: (x) => mowaUlaw(x),
    znajdzBiznes: (id) => biznesZnajdz(ANTIGRAVITY_DIR, id),
    sprawdzBilet: (bilet) => {
        const b = zuzyjBilet(bilet);
        return b ? { ok: true, ...b } : { ok: false, powod: 'Bilet nieznany, zużyty albo przeterminowany.' };
    },
    naZdarzenie: (ev) => rozeslijLive(ev),

    /**
     * Minuta rozmowy = RUCH w Ekonomii Oddechu.
     *
     * Klucz niesie numer minuty, więc każda płaci dokładnie raz, a limit dobowy
     * pilnuje reszty. To wciąż JEDNA ścieżka emisji — ta sama, co przy każdej
     * innej pracy. Żadnego osobnego „licznika minutowego" obok księgi nie ma.
     */
    naMinute: async ({ callSid, biznesId, minuta }) => {
        const wynik = await oddechZaPrace('biznes.minuta', `rozmowa:${callSid}:min:${minuta}`);
        rozeslijLive({
            typ: 'grv', callSid, minuta,
            grv: wynik?.przyznane ? wynik.grv : 0,
            powod: wynik?.przyznane ? null : (wynik?.powod ?? 'Oddech nieosiągalny.'),
        });
        if (biznesId && wynik?.przyznane) {
            await biznesZapiszZdarzenie(ANTIGRAVITY_DIR, {
                biznesId, akcja: 'biznes.minuta', klucz: `rozmowa:${callSid}:min:${minuta}`,
                opis: `minuta rozmowy na żywo (${minuta})`, grv: wynik.grv, przyznane: true,
            }).catch(() => {});
        }
    },

    naKoniec: async ({ callSid, biznesId, sekundy, tur, historia }) => {
        if (!biznesId) return;
        const wynik = await oddechZaPrace('biznes.rozmowa', `rozmowa:${callSid}`);
        await biznesZapiszZdarzenie(ANTIGRAVITY_DIR, {
            biznesId,
            akcja: 'rozmowa.domknieta',
            klucz: `rozmowa:${callSid}`,
            opis: `rozmowa na żywo: ${sekundy}s, ${tur} tur, ${historia?.length ?? 0} kwestii`,
            grv: wynik?.przyznane ? wynik.grv : 0,
            przyznane: !!wynik?.przyznane,
            powod: wynik?.przyznane ? null : (wynik?.powod ?? 'Oddech nieosiągalny.'),
        }).catch(() => {});
    },
};

// ── 🎥 STUDIO WIDEOPODCASTU — sterowanie relayem RTMP i recorderem ───────────
// Same strumienie idą kanałami WebSocket (/api/rtmp-relay, /api/recorder) —
// tutaj żyje tylko konfiguracja i status. Klucz transmisji NIGDY nie wraca do
// przeglądarki w postaci jawnej (front dostaje maskę typu `••••-a1b2`).

app.get('/api/studio/status', async (req, res) => {
    try {
        res.json(await getStudioStatus());
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/studio/rtmp-key', async (req, res) => {
    const { streamKey, rtmpUrl } = req.body ?? {};
    if (typeof streamKey !== 'string') {
        return res.status(400).json({ success: false, message: 'Brak "streamKey" (pusty string kasuje klucz).' });
    }
    try {
        const saved = await saveRtmpConfig(streamKey, rtmpUrl);
        res.json({ success: true, ...saved, status: await getStudioStatus() });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * GET /api/studio/pokoje — kto realnie wisi na kanale gości.
 * Panel pokazuje własny stan z przeglądarki; to jest widok od strony MOSTU,
 * więc pozwala rozstrzygnąć, czy telefon nie doszedł, czy tylko UI się zacięło.
 * Dokładamy adresy LAN, bo bez nich nie da się powiedzieć Suwerenowi,
 * pod jakim adresem jego maszyna jest widoczna dla telefonu.
 */
app.get('/api/studio/pokoje', (req, res) => {
    const adresy = [];
    for (const [nazwa, lista] of Object.entries(os.networkInterfaces())) {
        for (const a of lista ?? []) {
            if (a.family === 'IPv4' && !a.internal) adresy.push({ interfejs: nazwa, ip: a.address });
        }
    }
    res.json({
        success: true,
        pokoje: stanPokoi(),
        adresyLan: adresy,
        // Bez tego zdania ktoś kiedyś spróbuje wpisać ten adres w telefon i utknie.
        uwaga: 'Telefon NIE dostanie kamery po adresie http://… — przeglądarka wymaga HTTPS. ' +
               'Użyj Kwantowego Tunelu; sam obraz i tak poleci po sieci lokalnej.',
    });
});

// Lista nagranych odcinków — Suweren widzi, że plik realnie leży na dysku.
app.get('/api/studio/recordings', async (req, res) => {
    try {
        const names = await fs.readdir(RECORDINGS_DIR).catch(() => []);
        const files = [];
        for (const name of names) {
            if (!/\.(webm|mp4)$/i.test(name)) continue;
            try {
                const st = await fs.stat(path.join(RECORDINGS_DIR, name));
                files.push({ name, bytes: st.size, modified: st.mtime.toISOString() });
            } catch { /* plik zniknął w trakcie listowania */ }
        }
        files.sort((a, b) => b.modified.localeCompare(a.modified));
        res.json({ success: true, dir: RECORDINGS_DIR, files });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// ── 📜 KRONIKA 0.00G — żywy wpis: narracja AI + równoległy feedback agentów ───
async function genOllama(prompt, model, ms = 40000) {
    try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), ms);
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal, body: JSON.stringify({ model, prompt, stream: false, options: { temperature: 0.85 } }) });
        clearTimeout(t);
        return String((await r.json()).response || '').trim();
    } catch { return ''; }
}
// ── 🐣 TEOGOCHI — mały kompan, live komentarz na to co gra ───────────────────
// ── 🥁 PANEL BITÓW — suwerenny step-grid ─────────────────────────────────────
// Matryca [1,0,0,0,...] → realny plik WAV. Perkusja SYNTEZOWANA proceduralnie,
// bez sampli i bez zewnętrznego DAW-a. Bity lądują w _OtakOs_Muzyka/_Bity,
// żeby nie mieszać szkiców z gotowymi utworami w bibliotece radia.
const BITY_DIR = path.join(MUSIC_DIR, '_Bity');

app.post('/api/bit/render', async (req, res) => {
    try {
        const w = await renderujBit(req.body ?? {}, BITY_DIR);
        console.log(`[Bity] 🥁 ${w.plik} — ${w.bpm} BPM, ${w.kroki} kroków, ${w.dspFreq} Hz, ${w.uderzen} uderzeń`);
        res.json({
            success: true,
            plik: w.plik,
            sciezka: w.sciezka,
            uzytyWzor: w.uzytyWzor ?? undefined,
            url: `http://127.0.0.1:${PORT}/music/${encodeURIComponent('_Bity/' + w.plik)}`,
            bpm: w.bpm, kroki: w.kroki, dspFreq: w.dspFreq, powtorzen: w.powtorzen,
            sekundy: Number(w.sekundy.toFixed(2)), uderzen: w.uderzen,
            matryca: w.matryca,
            // Nie milczymy o ścieżkach, których nie znamy — model bywa kreatywny.
            nieznaneSciezki: w.nieznane.length ? w.nieznane : undefined,
            dostepneSciezki: BIT_SCIEZKI,
            // Uczciwie: strojenie dotyczy materiału wysokościowego, nie szumu.
            uwagaStrojenie: `dsp_freq=${w.dspFreq} stroi stopę, korpus werbla i synth-perc. Hi-hat to szum nieharmoniczny — nie jest strojony.`,
        });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message, dostepneSciezki: BIT_SCIEZKI });
    }
});

/** Biblioteka gotowych rytmów — wspólna dla panelu i dla Joanny. */
app.get('/api/bit/wzorce', (req, res) => {
    res.json({ success: true, wzorce: bitListaWzorcow(), sciezki: BIT_SCIEZKI });
});

/** Podgląd samego parsera — pozwala sprawdzić wzór bez renderowania audio. */
app.post('/api/bit/parsuj', (req, res) => {
    const kroki = [8, 16, 32, 64].includes(Number(req.body?.steps)) ? Number(req.body.steps) : 16;
    // Nazwa wzorca zamiast matrycy — panel wczytuje preset tą samą drogą,
    // z której korzysta Joanna, żeby definicje nie rozjechały się w dwóch miejscach.
    let grid = req.body?.grid;
    let bpm = null;
    if (req.body?.wzor) {
        const w = bitWzorPoNazwie(req.body.wzor);
        if (!w) {
            return res.status(400).json({
                success: false,
                message: `Nie znam wzorca „${req.body.wzor}".`,
                dostepneWzorce: bitListaWzorcow().map(x => x.id),
            });
        }
        grid = w.grid; bpm = w.bpm;
    }
    const { matryca, nieznane } = bitParsujMatryce(grid, kroki);
    res.json({ success: true, kroki, bpm, matryca, nieznaneSciezki: nieznane, dostepneSciezki: BIT_SCIEZKI });
});

// ── ✂️ RZEŹBA AUDIO — cięcie, pętle, sklejanie, pasma ────────────────────────
// Obróbka gotowych nagrań przez lokalny ffmpeg. Wyniki lądują w _OtakOs_Muzyka/_Rzezba,
// żeby szkice nie mieszały się z gotowymi utworami w bibliotece radia.
//
// UWAGA NAZEWNICZA: `pasma` to rozdział po CZĘSTOTLIWOŚCI, NIE separacja stemów.
// Wyciąganie wokalu z miksu wymaga modelu (Demucs) — węzeł go nie ma i nie udajemy,
// że ma. Endpoint zwraca to w polu `uwaga`.
const RZEZBA_DIR = path.join(MUSIC_DIR, '_Rzezba');

/** Zamienia nazwę pliku z biblioteki na pełną ścieżkę; blokuje ucieczkę z katalogu. */
function sciezkaWBibliotece(nazwa) {
    const pelna = path.resolve(MUSIC_DIR, String(nazwa || ''));
    if (!pelna.startsWith(path.resolve(MUSIC_DIR))) {
        throw new Error('Ścieżka ucieka poza bibliotekę muzyki.');
    }
    return pelna;
}

function urlBity(pelna) {
    const wzgl = path.relative(MUSIC_DIR, pelna).replace(/\\/g, '/');
    return `http://127.0.0.1:${PORT}/music/${encodeURIComponent(wzgl)}`;
}

app.get('/api/rzezba/info', async (req, res) => {
    const plik = req.query.plik;
    if (!plik) return res.status(400).json({ success: false, message: 'Brak ?plik=' });
    try {
        const pelna = sciezkaWBibliotece(plik);
        const sek = await audioDlugosc(pelna);
        res.json({ success: true, plik, sekundy: sek, pasma: RZEZBA_PASMA });
    } catch (err) {
        res.status(400).json({ success: false, message: err.message });
    }
});

app.post('/api/rzezba/tnij', async (req, res) => {
    try {
        const w = await audioTnij({
            plik: sciezkaWBibliotece(req.body?.plik), od: req.body?.od, ile: req.body?.ile,
            katalogWy: RZEZBA_DIR,
        });
        console.log(`[Rzeźba] ✂️ ${w.plik} (${w.od}s +${w.ile}s)`);
        res.json({ success: true, ...w, url: urlBity(w.sciezka) });
    } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

app.post('/api/rzezba/petla', async (req, res) => {
    try {
        const w = await audioPetla({
            plik: sciezkaWBibliotece(req.body?.plik), od: req.body?.od, ile: req.body?.ile,
            powtorzen: req.body?.powtorzen, katalogWy: RZEZBA_DIR,
        });
        console.log(`[Rzeźba] 🔁 ${w.plik} x${w.powtorzen}`);
        res.json({ success: true, ...w, url: urlBity(w.sciezka) });
    } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

app.post('/api/rzezba/sklej', async (req, res) => {
    try {
        const pliki = (req.body?.pliki ?? []).map(sciezkaWBibliotece);
        const w = await audioSklej({ pliki, katalogWy: RZEZBA_DIR });
        console.log(`[Rzeźba] 🔗 ${w.plik} (${w.zlaczono} plików)`);
        res.json({ success: true, ...w, url: urlBity(w.sciezka) });
    } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

app.post('/api/rzezba/normalizuj', async (req, res) => {
    try {
        const w = await audioNormalizuj({
            plik: sciezkaWBibliotece(req.body?.plik), lufs: req.body?.lufs, katalogWy: RZEZBA_DIR,
        });
        console.log(`[Rzeźba] 📏 ${w.plik} -> ${w.lufs} LUFS`);
        res.json({ success: true, ...w, url: urlBity(w.sciezka) });
    } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

app.post('/api/rzezba/pasma', async (req, res) => {
    try {
        const w = await audioPasma({
            plik: sciezkaWBibliotece(req.body?.plik), ktore: req.body?.ktore, katalogWy: RZEZBA_DIR,
        });
        console.log(`[Rzeźba] 🎚️ pasma: ${w.pasma.map(x => x.pasmo).join(', ')}`);
        res.json({
            success: true,
            pasma: w.pasma.map(x => ({ ...x, url: urlBity(x.sciezka) })),
            uwaga: w.uwaga,
        });
    } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

// ── 🎚️ STEMY — PRAWDZIWA separacja przez Demucs ──────────────────────────────
// To NIE to samo co /api/rzezba/pasma. Pasma dzielą po częstotliwości; TU model
// uczony rozdziela nagranie na wokal / perkusję / bas / resztę.
//
// Demucs siedzi w OSOBNYM venv (F:/OtakOsDemucs), świadomie:
//  - python ComfyUI raz już padł przy dokładaniu paczek — nie ryzykujemy drugi raz,
//  - torch jest CPU-only, żeby separacja nie walczyła o 6 GB VRAM z generacją muzyki,
//  - venv stoi na KRÓTKIEJ ścieżce, bo drzewo licencji torcha przekracza limit
//    260 znaków Windows przy dłuższym prefiksie (ten sam WinError 206).
const DEMUCS_PYTHON = process.env.OTAKOS_DEMUCS_PYTHON || 'F:/OtakOsDemucs/Scripts/python.exe';
const DEMUCS_SKRYPT = path.join(__dirname, 'services', 'demucs_stemy.py');
const STEMY_DIR = path.join(MUSIC_DIR, '_Stemy');

/** Czy separacja jest w ogóle dostępna — mówimy wprost, czego brakuje. */
app.get('/api/stemy/status', (req, res) => {
    const maPythona = fsSync.existsSync(DEMUCS_PYTHON);
    const maSkrypt = fsSync.existsSync(DEMUCS_SKRYPT);
    res.json({
        success: true,
        dostepne: maPythona && maSkrypt,
        python: DEMUCS_PYTHON,
        skrypt: DEMUCS_SKRYPT,
        zrodla: ['drums', 'bass', 'other', 'vocals'],
        urzadzenie: 'cpu',
        braki: [
            ...(maPythona ? [] : [`Brak środowiska Demucs w ${DEMUCS_PYTHON} — utwórz venv i zainstaluj: torch (CPU), demucs, numpy, truststore.`]),
            ...(maSkrypt ? [] : [`Brak skryptu ${DEMUCS_SKRYPT}.`]),
        ],
        uwaga: 'Separacja liczy na CPU — orientacyjnie ~0.7x czasu trwania nagrania. '
             + 'Dla długiego utworu to minuty, nie sekundy.',
    });
});

/** Realna separacja. Blokuje do skutku — front ma o tym uprzedzić Suwerena. */
app.post('/api/stemy/rozdziel', async (req, res) => {
    const { plik, tylko } = req.body ?? {};
    if (!plik) return res.status(400).json({ success: false, message: 'Brak "plik".' });
    if (!fsSync.existsSync(DEMUCS_PYTHON)) {
        return res.status(424).json({
            success: false,
            message: 'Środowisko Demucs nie jest zainstalowane.',
            hint: `Sprawdź GET /api/stemy/status. Oczekiwany python: ${DEMUCS_PYTHON}`,
        });
    }

    let wejscie;
    try { wejscie = sciezkaWBibliotece(plik); }
    catch (e) { return res.status(400).json({ success: false, message: e.message }); }
    if (!fsSync.existsSync(wejscie)) {
        return res.status(404).json({ success: false, message: `Nie ma pliku: ${path.basename(wejscie)}` });
    }

    const args = [DEMUCS_SKRYPT, wejscie, STEMY_DIR];
    if (Array.isArray(tylko) && tylko.length) args.push(`--tylko=${tylko.join(',')}`);

    console.log(`[Stemy] 🎚️ Rozdzielam: ${path.basename(wejscie)} (CPU, to potrwa)`);
    try {
        // 30 min limitu: dlugie utwory na CPU potrafia trwac.
        const { stdout } = await execFileAsync(DEMUCS_PYTHON, args, {
            timeout: 30 * 60 * 1000, maxBuffer: 8 * 1024 * 1024,
        });
        // Skrypt wypisuje JSON w OSTATNIEJ linii — wczesniej moga byc ostrzezenia paczek.
        const linia = String(stdout).trim().split(/\r?\n/).filter(Boolean).pop();
        const d = JSON.parse(linia);
        if (!d.success) return res.status(502).json(d);

        console.log(`[Stemy] ✅ ${d.stemy.length} stemów w ${d.sekundySeparacji}s`);
        res.json({
            ...d,
            stemy: d.stemy.map((x) => ({
                ...x,
                url: `http://127.0.0.1:${PORT}/music/${encodeURIComponent('_Stemy/' + x.plik)}`,
                // RMS ponizej -55 dB to praktycznie cisza — mowimy o tym wprost,
                // zamiast dawac Suwerenowi pusty plik bez slowa wyjasnienia.
                pusty: x.rmsDb < -55,
            })),
            uwaga: 'To PRAWDZIWA separacja (model uczony), nie podział na pasma. '
                 + 'Stem oznaczony jako pusty znaczy, że model nie znalazł tam materiału '
                 + '(np. wokal w utworze instrumentalnym) — to poprawny wynik, nie błąd.',
        });
    } catch (err) {
        const powod = err.killed ? 'przekroczono 30 minut' : (err.stderr || err.message || '').slice(0, 400);
        console.warn(`[Stemy] ❌ ${powod}`);
        res.status(502).json({ success: false, message: `Separacja nie powiodła się: ${powod}` });
    }
});

// ── 🎙️ JOANNA — KOMPANKA Z RĘKAMI ───────────────────────────────────────────
// Do tej pory TeOgochi tylko komentowała muzykę. Tu dostaje ręce: rozmowa może
// wykonać akcję. Wzorzec bliźniaczy z /api/rezyser/rozmowa — ta sama dyscyplina
// (biała lista akcji, kontrakt {mowa, akcja}, wynik z powrotem na zdanie).

/** Pamięć produkcji + ostatnie utwory — do podglądu w UI. */
app.get('/api/joanna/pamiec', async (req, res) => {
    try {
        const dane = await joannaPamiec(ANTIGRAVITY_DIR);
        res.json({ success: true, ...dane });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

/** Ocena wprost z UI (kciuk w dół/górę), bez przechodzenia przez model. */
app.post('/api/joanna/ocena', async (req, res) => {
    const { utworId, ocena, uwaga } = req.body ?? {};
    try {
        const u = await joannaOcen(ANTIGRAVITY_DIR, { utworId, ocena, uwaga });
        if (!u) return res.status(404).json({ success: false, message: 'Nie ma czego oceniać — brak utworów w pamięci.' });
        res.json({ success: true, utwor: u });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/joanna/rozmowa  { wypowiedz, historia[], imie? }
 * Zwraca { mowa, akcja, wynikAkcji, uwaga }.
 */
app.post('/api/joanna/rozmowa', async (req, res) => {
    const { wypowiedz = '', historia = [], imie = 'Joanna' } = req.body ?? {};
    if (String(wypowiedz).trim().length < 2) {
        return res.status(400).json({ success: false, message: 'Pusta wypowiedź.' });
    }

    try {
        const dane = await joannaPamiec(ANTIGRAVITY_DIR);
        const kontekst = joannaKontekst(dane);
        // Ostatnie 8 tur — dalej i tak wypycha okno modelu na tej maszynie.
        const rozmowa = (Array.isArray(historia) ? historia : []).slice(-8)
            .map(t => `${t.role === 'user' ? 'Suweren' : 'Ty'}: ${t.content}`).join('\n');

        const odp = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: DEFAULT_LLM,
                system: joannaPrompt(kontekst, imie),
                prompt: `${rozmowa ? rozmowa + '\n' : ''}Suweren: ${wypowiedz}\nTy:`,
                stream: false,
                options: { temperature: 0.8 },
            }),
        });
        if (!odp.ok) throw new Error(`Ollama HTTP ${odp.status} — sprawdź, czy rdzeń AI stoi.`);
        const wynikLlm = await odp.json();

        // Kontrakt: gdy model go nie utrzyma, NIE zgadujemy akcji — lepiej sama mowa.
        let mowa, akcja = null, uwaga = null;
        try {
            ({ mowa, akcja } = odczytajOdpowiedz(wynikLlm.response));
        } catch (e) {
            mowa = String(wynikLlm.response || '').trim();
            uwaga = `Model nie utrzymał formatu (${e.message}) — potraktowane jako sama wypowiedź, bez akcji.`;
            console.warn(`[Joanna] ⚠️ ${uwaga}`);
        }
        if (!mowa && !akcja) {
            return res.status(502).json({ success: false, message: 'Joanna milczy — rdzeń AI zwrócił pustkę.' });
        }

        // ── Wykonanie akcji (biała lista) ─────────────────────────────────────
        let wynikAkcji = null;
        if (akcja) {
            if (!AKCJE_JOANNY.has(akcja.typ)) {
                wynikAkcji = { wykonana: false, powod: `nieznana akcja „${akcja.typ}" — pominięta` };
                console.warn(`[Joanna] ⛔ ${wynikAkcji.powod}`);
            } else {
                try {
                    wynikAkcji = await wykonajAkcjeJoanny(akcja);
                } catch (e) {
                    wynikAkcji = { wykonana: false, powod: e.message };
                    console.warn(`[Joanna] ❌ Akcja "${akcja.typ}" padła: ${e.message}`);
                }
            }
            // Doklejamy zdanie o wyniku, żeby mowa nie rozjechała się z faktami —
            // model potrafi powiedzieć "zrobione", gdy akcja padła.
            const zdanie = joannaZdanie(akcja.typ, wynikAkcji);
            mowa = mowa ? `${mowa} ${zdanie}` : zdanie;
        }

        res.json({ success: true, mowa, akcja, wynikAkcji, uwaga });
    } catch (err) {
        console.warn(`[Joanna] ❌ ${err.message}`);
        res.status(502).json({ success: false, message: err.message });
    }
});

/**
 * Realne wykonanie akcji Joanny. Każda gałąź wywołuje istniejący, sprawdzony
 * mechanizm — nic tu nie udaje działania.
 */
async function wykonajAkcjeJoanny(akcja) {
    switch (akcja.typ) {

        case 'zrob_utwor': {
            // Generacja trwa kilkadziesiąt sekund — NIE blokujemy nią rozmowy.
            // Kolejkujemy i oddajemy promptId; front odpytuje /api/music/progress.
            const dlugosc = Math.max(10, Math.min(240, Number(akcja.dlugosc) || 30));
            const ciało = {
                prompt: [akcja.opis, akcja.styl].filter(Boolean).join(', ') || 'ambient soundscape',
                lyrics: akcja.tekst || '',
                duration: dlugosc,
                ...(akcja.bpm ? { bpm: Math.max(40, Math.min(200, Number(akcja.bpm))) } : {}),
                ...(akcja.tonacja ? { keyscale: String(akcja.tonacja) } : {}),
                language: 'pl',
            };
            const r = await fetch(`http://127.0.0.1:${PORT}/api/music/generate`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(ciało),
            });
            const d = await r.json().catch(() => ({}));
            if (!r.ok || !d.success) {
                return { wykonana: false, powod: d.message || `silnik odmówił (HTTP ${r.status})` };
            }
            const wpis = await joannaZapiszUtwor(ANTIGRAVITY_DIR, {
                opis: ciało.prompt, styl: akcja.styl ?? null, bpm: akcja.bpm ?? null,
                tonacja: akcja.tonacja ?? null, dlugosc, promptId: d.promptId,
            });
            console.log(`[Joanna] 🎼 Zleciła utwór: "${ciało.prompt.slice(0, 50)}" (${dlugosc}s, id ${wpis.id})`);
            return {
                wykonana: true,
                opis: `${dlugosc} sekund, ${ciało.prompt.slice(0, 60)}`,
                promptId: d.promptId, utworId: wpis.id, rodzina: d.rodzina,
            };
        }

        case 'zagraj': {
            const szukaj = String(akcja.czego ?? '').toLowerCase();
            const pliki = (await getAudioFilesRecursive(MUSIC_DIR)) ?? [];
            const trafione = pliki.filter(p => !szukaj || path.basename(p).toLowerCase().includes(szukaj));
            if (!trafione.length) {
                return { wykonana: false, powod: szukaj ? `nie znalazłam nic pasującego do „${szukaj}"` : 'biblioteka jest pusta' };
            }
            const wybrany = trafione[Math.floor(Math.random() * trafione.length)];
            const nazwa = path.basename(wybrany);
            return {
                wykonana: true, opis: nazwa,
                url: `http://127.0.0.1:${PORT}/music/${encodeURIComponent(path.relative(MUSIC_DIR, wybrany).replace(/\\/g, '/'))}`,
            };
        }

        case 'ocen': {
            const u = await joannaOcen(ANTIGRAVITY_DIR, { ocena: akcja.ocena, uwaga: akcja.uwaga });
            if (!u) return { wykonana: false, powod: 'nie ma jeszcze żadnego utworu do oceny' };
            return { wykonana: true, opis: `${u.ocena ?? '—'}/5 dla „${u.opis.slice(0, 40)}"` };
        }

        case 'zapamietaj': {
            const tresc = akcja.fakt ?? akcja.tresc;
            if (!tresc) return { wykonana: false, powod: 'pusty fakt' };
            const w = await joannaZapamietaj(ANTIGRAVITY_DIR, tresc);
            return { wykonana: true, opis: w.tresc };
        }

        case 'stworz_bit': {
            // Jason w specyfikacji zaproponował kształt {"akcja":"stworz_bit","parametry":{...}}.
            // Parser Reżysera spłaszcza to do akcja.parametry, więc obsługujemy OBA
            // kształty — i ten, i płaski {"typ":"stworz_bit","bpm":...}.
            const p = akcja.parametry ?? akcja;
            try {
                const w = await renderujBit(p, BITY_DIR);
                console.log(`[Joanna] 🥁 Złożyła bit: ${w.plik} (${w.bpm} BPM, ${w.uderzen} uderzeń)`);
                return {
                    wykonana: true,
                    opis: `${w.bpm} BPM, ${w.kroki} kroków, ${w.uderzen} uderzeń, strojenie ${w.dspFreq} Hz`,
                    plik: w.plik,
                    url: `http://127.0.0.1:${PORT}/music/${encodeURIComponent('_Bity/' + w.plik)}`,
                    matryca: w.matryca,
                    sekundy: Number(w.sekundy.toFixed(2)),
                    nieznaneSciezki: w.nieznane.length ? w.nieznane : undefined,
                };
            } catch (e) {
                return { wykonana: false, powod: e.message };
            }
        }

        case 'pokaz_biblioteke': {
            const pliki = (await getAudioFilesRecursive(MUSIC_DIR)) ?? [];
            const dane = await joannaPamiec(ANTIGRAVITY_DIR);
            return {
                wykonana: true,
                opis: `${pliki.length} utworów w bibliotece, ${dane.utwory.length} z mojej produkcji`,
                utwory: pliki.slice(-20).map(p => path.basename(p)),
            };
        }

        default:
            return { wykonana: false, powod: `akcja „${akcja.typ}" nie ma implementacji` };
    }
}

/**
 * Domyka utwór Joanny: zbiera gotowe audio z ComfyUI do biblioteki i dopina
 * nazwę pliku do jej pamięci produkcji. Front woła to, gdy postęp = gotowe.
 */
app.post('/api/joanna/domknij', async (req, res) => {
    const { promptId, title } = req.body ?? {};
    if (!promptId) return res.status(400).json({ success: false, message: 'Brak "promptId".' });
    try {
        const p = await fetch(`http://127.0.0.1:${PORT}/api/music/progress?promptId=${encodeURIComponent(promptId)}`);
        const dp = await p.json();
        if (dp.stan !== 'gotowe' || !dp.audio?.length) {
            return res.json({ success: false, stan: dp.stan, message: 'Utwór jeszcze nie jest gotowy.' });
        }
        const a = dp.audio[0];
        const c = await fetch(`http://127.0.0.1:${PORT}/api/music/collect`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: a.filename, subfolder: a.subfolder, type: a.type, title: title || 'Joanna' }),
        });
        const dc = await c.json();
        if (!dc.success) return res.status(502).json({ success: false, message: dc.message });
        const wpis = await joannaDopiszPlik(ANTIGRAVITY_DIR, promptId, path.basename(dc.savedPath));
        console.log(`[Joanna] 💾 Domknęła utwór: ${path.basename(dc.savedPath)}`);
        res.json({ success: true, savedPath: dc.savedPath, streamUrl: dc.streamUrl, utwor: wpis });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * 📻 ZAPOWIEDŹ RADIOWA — Joanna jako DJ-ka Katedry.
 *
 * Krótkie zdanie między utworami. Świadomie NIE syntezujemy tu mowy: głos robi
 * przeglądarka (speechSynthesis), bo lokalny silnik klonu głosu jest opcjonalny
 * i zwykle go nie ma. Most daje TEKST, front daje GŁOS — i nikt nie udaje, że
 * mamy studyjny lektor.
 *
 * Zapowiedź zna pamięć produkcji, więc o własnym utworze powie inaczej niż
 * o cudzym („ten składałam wczoraj").
 */
app.post('/api/joanna/zapowiedz', async (req, res) => {
    const { utwor, poprzedni = null, imie = 'Joanna' } = req.body ?? {};
    if (!utwor) return res.status(400).json({ success: false, message: 'Brak "utwor".' });

    try {
        const dane = await joannaPamiec(ANTIGRAVITY_DIR);
        // Czy to jej własna produkcja? Dopasowanie po nazwie pliku.
        const wlasny = (dane.utwory ?? []).find((u) => u.plik && String(utwor).includes(u.plik.replace(/\.[^.]+$/, '')));

        const kontekst = [
            `Zaraz zagra: ${utwor}`,
            poprzedni ? `Przed chwilą grało: ${poprzedni}` : null,
            wlasny ? `TEN UTWÓR TY ZROBIŁAŚ. Opis: „${wlasny.opis}"${wlasny.ocena ? `, Suweren dał mu ${wlasny.ocena}/5` : ''}.` : null,
        ].filter(Boolean).join('\n');

        const system =
            `Jesteś ${imie} — DJ-ką Radia Katedry OtakOS. Mówisz PO POLSKU, w rodzaju żeńskim. ` +
            'Twoja wypowiedź jest CZYTANA NA GŁOS między utworami: JEDNO zdanie, maksymalnie 18 słów. ' +
            'Bez markdownu, bez emoji, bez cudzysłowów, bez podawania nazwy pliku z rozszerzeniem. ' +
            'Masz brzmieć jak radio: ciepło, konkretnie, czasem z humorem. ' +
            'Jeśli utwór jest twój — możesz o tym wspomnieć naturalnie, bez przechwałek. ' +
            'Zwróć SAMO ZDANIE, nic więcej.';

        const odp = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: DEFAULT_LLM, system, prompt: kontekst,
                stream: false, options: { temperature: 0.9 },
            }),
        });
        if (!odp.ok) throw new Error(`Ollama HTTP ${odp.status}`);
        const d = await odp.json();

        // Model lubi dokleić cudzysłowy albo drugie zdanie — bierzemy pierwsze,
        // bo radio nie znosi gadania przez wejście wokalu.
        let zdanie = String(d.response || '').trim()
            .replace(/^["'„”]+|["'„”]+$/g, '')
            .split(/(?<=[.!?])\s+/)[0]
            .trim();
        if (!zdanie) {
            return res.status(502).json({ success: false, message: 'Joanna milczy — rdzeń AI zwrócił pustkę.' });
        }
        console.log(`[Radio] 📻 Zapowiedź: „${zdanie.slice(0, 70)}"`);
        res.json({ success: true, zapowiedz: zdanie, wlasny: !!wlasny });
    } catch (err) {
        console.warn(`[Radio] ❌ Zapowiedź: ${err.message}`);
        res.status(502).json({ success: false, message: err.message });
    }
});

app.post('/api/teogochi/comment', async (req, res) => {
    const { track, lyric, stage, mood, name } = req.body ?? {};
    const model = DEFAULT_LLM;
    const context = [track ? `Utwór: ${track}` : null, lyric ? `Aktualny wers: "${lyric}"` : null]
        .filter(Boolean).join('\n');
    if (!context) return res.status(400).json({ success: false, message: 'Brak "track" lub "lyric".' });
    // Tamagotchi-kontekst: imię, etap życia i nastrój kolorują reakcję kompana.
    // Nadane imię (inne niż fabryczne) = ochrzczona mała bogini — mówi w rodzaju żeńskim.
    const hasName = name && name !== 'TeOgochi';
    const who = hasName
        ? `Masz na imię ${String(name).slice(0, 24)} — jesteś małą boginią-kompanem Katedry OtakOS i mówisz o sobie W RODZAJU ŻEŃSKIM`
        : 'Jesteś TeOgochi — małym, ciekawskim cyfrowym stworkiem-kompanem w Katedrze OtakOS';
    const persona = stage === 'jajko'
        ? `${who}, wciąż w JAJKU — reagujesz stłumionym głosikiem zza skorupki (pukanie, drżenie, ciche piski).`
        : `${who} (etap: ${stage || 'pisklę'}).`;
    const moodLine = mood ? ` Twój aktualny nastrój: ${mood} — niech to słychać w odpowiedzi.` : '';
    const prompt = `${persona} Słuchasz muzyki razem z Suwerenem.${moodLine} Zareaguj JEDNYM krótkim, żywym zdaniem (max 12 słów) na to, co teraz gra — ciepło, czasem zabawnie, czasem wzruszony. Bez cudzysłowów, bez wyjaśnień — samo zdanie.\n\n${context}`;
    // Gdy główny rdzeń nie odpowie, wolimy łamaną polszczyznę od ciszy — ale MÓWIMY
    // wprost, że to tor awaryjny. Wcześniej ten fallback był cichy i Suweren słyszał
    // „byntę słodki wiatr" nie wiedząc, że rozmawia z modelem 0,8 GB zamiast z Joanną.
    // Rdzeń jest cięższy niż drobinka, więc dajemy mu uczciwy czas na zimny start.
    // 120 s: zimny start 7,2 GB na słabszej maszynie potrafi trwać. Dymek Joanny
    // jest asynchroniczny — dłuższe czekanie nikogo nie blokuje, a cisza boli bardziej.
    let comment = await genOllama(prompt, model, 120000);
    let awaryjny = false;
    if (!comment && model !== FALLBACK_LLM) {
        comment = await genOllama(prompt, FALLBACK_LLM, 15000);
        awaryjny = Boolean(comment);
        console.warn(`[TeOgochi] ⚠️ Rdzeń "${model}" nie odpowiedział — zdanie z awaryjnego ${FALLBACK_LLM} (jakość językowa będzie gorsza).`);
    }
    return res.json({ success: true, comment: comment || null, model: awaryjny ? FALLBACK_LLM : model, fallback: awaryjny });
});

app.post('/api/kronika/forge', async (req, res) => {
    let { narrative, transcript, title, videoUrl, model } = req.body ?? {};
    model = model || DEFAULT_LLM;
    const source = (narrative || transcript || '').trim();
    if (source.length < 20) return res.status(400).json({ success: false, message: 'Wymagane "narrative" lub "transcript" (>=20 zn.).' });
    try {
        // 1. Narracja główna (lokalny Gemma 4)
        const narr = await genOllama(
            `Jesteś Kronikarzem Katedry OtakOS (mistyczno-cyberpunkowy ton, 0.00G). Z poniższej treści napisz JEDEN wpis Kroniki — 3-4 zdania, żywe, poetyckie, o intencji i kreacji. Bez nagłówków.\n\nTREŚĆ:\n${source.slice(0, 3000)}`, model);

        // 2. Równoległy feedback 3 agentów
        const base = narr || source.slice(0, 600);
        const [adamus, bella, oddi] = await Promise.all([
            genOllama(`Jako Mistrz Adamus (strategiczny mentor, alchemia intencji) skomentuj 1 zdaniem ten wpis Kroniki:\n"${base}"`, model, 25000),
            genOllama(`Jako Bella (estetyka, wizja, piękno) skomentuj 1 zdaniem ten wpis Kroniki:\n"${base}"`, model, 25000),
            genOllama(`Jako ODDI (bezwzględna czysta logika AI) skomentuj 1 zdaniem ten wpis Kroniki:\n"${base}"`, model, 25000),
        ]);

        const usedLLM = !!narr;
        const clean = (s, fb) => (s && s.length > 2 ? s.replace(/^["'\s]+|["'\s]+$/g, '').split('\n')[0].slice(0, 240) : fb);
        const auras = ['cyan', 'gold', 'magenta', 'violet'];
        const entry = {
            id: Date.now().toString(),
            title: (title || 'WPIS KRONIKI').toUpperCase(),
            narrative: clean(narr, source.slice(0, 280)),
            xp: 50 + Math.floor(Math.random() * 50),
            aura: auras[Math.floor(Math.random() * auras.length)],
            videoUrl: videoUrl || null,
            timestamp: new Date().toISOString(),
            type: 'AI_GENERATED',
            comments: [
                { agent: 'Adamus', text: clean(adamus, 'Strategiczna głębia rośnie.') },
                { agent: 'Bella', text: clean(bella, 'Estetyka rezonuje z wizją.') },
                { agent: 'ODDI', text: clean(oddi, 'Logika spójna. Wektor stabilny.') },
            ],
        };
        return res.json({ success: true, usedLLM, entry });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ── 📜 DZIENNIK POKŁADOWY — przemiał podcastu/rozmowy w infografikę 0.00G ─────
const DZIENNIK_DIR = path.join(process.cwd(), 'public', 'dzienniki');
const PODCASTI_DIR = path.join(ANTIGRAVITY_DIR, 'Podcasti');

/** GET /api/dziennik/list — foldery podcastów + gotowe dzienniki. */
app.get('/api/dziennik/list', async (req, res) => {
    let podcasts = [], dzienniki = [];
    try { podcasts = (await fs.readdir(PODCASTI_DIR, { withFileTypes: true })).filter(e => e.isDirectory()).map(e => e.name).sort(); } catch {}
    try { dzienniki = (await fs.readdir(DZIENNIK_DIR)).filter(f => f.endsWith('.html')).sort(); } catch {}
    res.json({ success: true, podcasts, dzienniki });
});

/**
 * POST /api/dziennik/forge — Body: { transcript?, podcastDir?, title?, cycle?, model? }
 * LLM strukturyzuje rozmowę → buildDziennikHtml → zapis public/dzienniki/.
 * Fallback bez LLM: szkielet z transkrypcji.
 */
app.post('/api/dziennik/forge', async (req, res) => {
    let { transcript, podcastDir, title, cycle, model } = req.body ?? {};
    model = model || DEFAULT_LLM;
    try {
        // Transkrypcja z folderu podcastu (jeśli jest plik .txt/.md/.lrc)
        if (!transcript && podcastDir) {
            const abs = path.join(PODCASTI_DIR, String(podcastDir).replace(/[^\w.-]/g, ''));
            try {
                const files = await fs.readdir(abs);
                const tf = files.find(f => /\.(txt|md|lrc|vtt|srt)$/i.test(f));
                if (tf) transcript = await fs.readFile(path.join(abs, tf), 'utf8');
            } catch {}
            if (!transcript) return res.status(422).json({ success: false, message: `Brak transkrypcji w Podcasti/${podcastDir} (.txt/.md). Transkrybuj audio (Whisper) albo podaj "transcript".` });
        }
        if (!transcript || transcript.trim().length < 30) return res.status(400).json({ success: false, message: 'Wymagane "transcript" (>=30 zn.) lub "podcastDir" z plikiem tekstu.' });

        // LLM → struktura JSON
        let data = null;
        const prompt =
`Jesteś kronikarzem Katedry OtakOS. Z rozmowy/podcastu zbuduj Dziennik Pokładowy.
ROZMOWA:
${transcript.slice(0, 4000)}

Zwróć WYŁĄCZNIE JSON:
{"title":"<TYTUŁ WIELKIMI>","cycle":"<nazwa cyklu>","intro":"<2 zdania o energii sesji>",
"council":[{"name":"Mistrz Adamus","role":"<wkład>","color":"#d946ef"},{"name":"ISTed","role":"<wkład>","color":"#10b981"},{"name":"Wiesio","role":"<wkład>","color":"#06b6d4"},{"name":"Oddi","role":"<wkład>","color":"#f59e0b"}],
"councilChart":{"labels":["Adamus","ISTed","Wiesio","Oddi","Bella","Jadziunia"],"data":[98,100,99,92,95,88]},
"modules":[{"icon":"🎮","name":"<moduł>","desc":"<opis>"},{"icon":"📦","name":"<moduł>","desc":"<opis>"},{"icon":"📖","name":"<moduł>","desc":"<opis>"}],
"economy":{"intro":"<1 zdanie PEIE>","metricLabel":"Redukcja Kosztów API","metricValue":"100%"},
"timeline":[{"title":"<krok>","desc":"<opis>"},{"title":"<krok>","desc":"<opis>"},{"title":"<krok>","desc":"<opis>"}]}
Bez komentarza, tylko JSON.`;
        try {
            const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 60000);
            const r = await fetch(`${OLLAMA_BASE}/api/generate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal, body: JSON.stringify({ model, prompt, stream: false, options: { temperature: 0.7 } }) });
            clearTimeout(t);
            const txt = String((await r.json()).response || '');
            const m = txt.match(/\{[\s\S]*\}/);
            if (m) data = JSON.parse(m[0]);
        } catch { /* fallback */ }

        if (!data || !data.title) {
            // Fallback bez LLM — szkielet z transkrypcji
            const paras = transcript.split(/\n{2,}/).filter(p => p.trim().length > 20).slice(0, 4);
            data = {
                title: (title || 'DZIENNIK POKŁADOWY').toUpperCase(), cycle: cycle || 'Era 0.00G',
                intro: paras[0]?.slice(0, 240) || 'Sesja zarejestrowana w Kronikach Katedry.',
                council: [{ name: 'Mistrz Adamus', role: 'Dusza i Zmysły', color: '#d946ef' }, { name: 'ISTed', role: 'Ekonomia PEIE', color: '#10b981' }, { name: 'Wiesio', role: 'Infrastruktura', color: '#06b6d4' }, { name: 'Oddi', role: 'Autonomia', color: '#f59e0b' }],
                modules: paras.slice(1).map((p, i) => ({ icon: ['🎮', '📦', '📖'][i] || '✨', name: `Wektor ${i + 1}`, desc: p.slice(0, 140) })),
                economy: { intro: 'Lokalny rdzeń = zysk czysty.', metricLabel: 'Redukcja Kosztów API', metricValue: '100%' },
                timeline: paras.map((p, i) => ({ title: `Faza ${i + 1}`, desc: p.slice(0, 120) })),
            };
        }
        if (title) data.title = title.toUpperCase();
        if (cycle) data.cycle = cycle;

        const html = buildDziennikHtml(data);
        await fs.mkdir(DZIENNIK_DIR, { recursive: true });
        const slug = (podcastDir ? `podcast_${podcastDir}` : (data.title || 'dziennik').toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 40)) + '.html';
        const file = path.join(DZIENNIK_DIR, slug);
        await fs.writeFile(file, html, 'utf8');
        return res.json({ success: true, file: `dzienniki/${slug}`, url: `/dzienniki/${slug}`, title: data.title, usedLLM: !!data.councilChart });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/podcast/transcribe — audio → tekst (Whisper.cpp), bez chmury.
 * Body: { podcastDir? | audioPath?, model? }  (model whisper: small/base/tiny)
 */
app.post('/api/podcast/transcribe', async (req, res) => {
    let { podcastDir, audioPath, model } = req.body ?? {};
    model = model || 'small';
    let wav = null, jsonFile = null;
    try {
        let audio = audioPath;
        if (!audio && podcastDir) {
            const dir = path.join(PODCASTI_DIR, String(podcastDir).replace(/[^\w.-]/g, ''));
            const files = await getAudioFilesRecursive(dir);
            if (!files.length) return res.status(404).json({ success: false, message: `Brak audio w Podcasti/${podcastDir}.` });
            let best = files[0], bestSize = -1;            // największy plik = główne nagranie
            for (const f of files) { try { const st = await fs.stat(f); if (st.size > bestSize) { bestSize = st.size; best = f; } } catch {} }
            audio = best;
        }
        if (!audio) return res.status(400).json({ success: false, message: 'Podaj "podcastDir" lub "audioPath".' });
        const audioAbs = path.isAbsolute(audio) ? audio : path.join(process.cwd(), audio);
        if (!fsSync.existsSync(audioAbs)) return res.status(404).json({ success: false, message: 'Audio nie istnieje.' });

        const modelPath = path.join(MODELS_DIR, `ggml-${model}.bin`);
        if (!fsSync.existsSync(modelPath)) return res.status(424).json({ success: false, message: `Brak modelu Whisper: ggml-${model}.bin w _OtakOs_AI/models/.`, hint: 'https://huggingface.co/ggerganov/whisper.cpp/tree/main' });
        if (!fsSync.existsSync(WHISPER_EXE)) return res.status(424).json({ success: false, message: 'Brak whisper-cli.exe w _OtakOs_AI/bin/.' });

        wav = path.join(TEMP_DIR, `whisper_in_${Date.now()}.wav`);
        await execFileAsync(ffmpegPath, ['-i', audioAbs, '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', '-y', wav]);
        const outBase = path.join(TEMP_DIR, 'whisper_tr_' + Date.now());
        jsonFile = outBase + '.json';
        await execFileAsync(WHISPER_EXE, ['-m', modelPath, '-f', wav, '--output-json-full', '-p', '4', '-l', 'pl', '-of', outBase], { cwd: BIN_DIR });
        if (!fsSync.existsSync(jsonFile)) throw new Error('Whisper nie wygenerował wyniku.');
        const out = JSON.parse(fsSync.readFileSync(jsonFile, 'utf8'));
        const transcript = (out.transcription || []).map(s => String(s.text || '').trim()).join(' ').replace(/\s+/g, ' ').trim();
        return res.json({ success: true, audio: path.relative(process.cwd(), audioAbs), chars: transcript.length, transcript });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    } finally {
        try { if (wav) await fs.rm(wav, { force: true }); if (jsonFile) await fs.rm(jsonFile, { force: true }); } catch {}
    }
});

// ── 🔐 CRYPTO-AGILITY — zwinność kryptograficzna (Dekret Kwantowy) ───────────
app.get('/api/crypto/status', async (req, res) => {
    const c = CryptoAgility.getInstance(ANTIGRAVITY_DIR); await c.load();
    res.json({ success: true, ...c.status() });
});
app.post('/api/crypto/mode', async (req, res) => {
    try { const m = await CryptoAgility.getInstance(ANTIGRAVITY_DIR).setMode((req.body ?? {}).mode); res.json({ success: true, mode: m }); }
    catch (e) { res.status(400).json({ success: false, message: e.message }); }
});
app.get('/api/crypto/selftest', (req, res) => {
    res.json({ success: true, result: CryptoAgility.getInstance(ANTIGRAVITY_DIR).selfTest() });
});

/**
 * POST /api/teledysk/storyboard — GENERATOR OPOWIEŚCI do utworu (lokalny LLM).
 * Body: { title, lyricsFile?|lyrics?, vectors?|sonicFile?, sceneCount?, model? }
 * Bierze tytuł + tekst (.lrc) + profil energii sonicznej i prosi lokalny model
 * (Ollama) o storyboard scen zsynchronizowanych z narastaniem energii. Zwraca
 * sceny {mood, opis, keywords[]} — mózg, który potem może dobierać/generować
 * materiały. Fallback: szkielet bez LLM, gdy most-rdzeń offline.
 */
// 🐣🎬 WIZJA JOANNY — kompan opowiada, o czym jest piosenka (brief dla reżysera).
// Joanna słucha sercem, filmowy TeOgochi z tego robi teledysk. Body: { title, name? }
app.post('/api/teledysk/vision', async (req, res) => {
    const { title, name } = req.body ?? {};
    if (!title) return res.status(400).json({ success: false, message: 'Brak "title".' });
    const model = DEFAULT_LLM;
    const who = name && name !== 'TeOgochi' ? String(name).slice(0, 24) : 'TeOgochi';
    const prompt = `Jesteś ${who} — małą, czułą duszą Katedry, która słucha muzyki sercem. Suweren pyta Cię, O CZYM jest utwór "${title}". Odpowiedz 2-3 zdaniami: jaka emocja, jaki obraz, jaki kolor i ruch z niego płyną. Poetycko, ciepło, po polsku. To będzie brief dla teledysku — mów o uczuciu i wizji, nie o technice.`;
    const vision = await genOllama(prompt, model, 20000)
        || await genOllama(prompt, 'gemma3:1b', 15000);
    return res.json({ success: true, vision: vision || null, by: who });
});

app.post('/api/teledysk/storyboard', async (req, res) => {
    let { title, lyrics, lyricsFile, vectors, sonicFile, sceneCount, model, vision } = req.body ?? {};
    sceneCount = Math.max(3, Math.min(12, Number(sceneCount) || 6));
    model = model || DEFAULT_LLM;
    try {
        // Tekst z .lrc (usuń znaczniki [mm:ss.xx])
        if (!lyrics && lyricsFile) {
            const abs = path.resolve(process.cwd(), String(lyricsFile));
            if (!abs.startsWith(process.cwd())) return res.status(403).json({ success: false, message: 'lyricsFile poza projektem.' });
            const raw = await fs.readFile(abs, 'utf8').catch(() => '');
            lyrics = raw.replace(/\[\d{1,2}:\d{2}(\.\d{1,2})?\]/g, '').replace(/\n{2,}/g, '\n').trim();
        }
        // Profil energii z wektorów
        if (!Array.isArray(vectors) && sonicFile) {
            const abs = path.resolve(process.cwd(), String(sonicFile));
            if (abs.startsWith(process.cwd())) {
                const parsed = JSON.parse(await fs.readFile(abs, 'utf8'));
                vectors = Array.isArray(parsed) ? parsed : (parsed.vectors || parsed.steps || []);
            }
        }
        let energy = 'nieznany';
        if (Array.isArray(vectors) && vectors.length) {
            const b = vectors.map(v => Number(v.b ?? v.bass ?? 0));
            const max = Math.max(...b, 1), avg = b.reduce((a, x) => a + x, 0) / b.length / max;
            const peaks = b.filter(x => x / max > 0.7).length;
            energy = `średnia ${(avg * 100).toFixed(0)}%, ${peaks} silnych uderzeń, ${vectors.length} kroków`;
        }

        const prompt =
`Jesteś reżyserem teledysków. Stwórz storyboard do utworu.
TYTUŁ: ${title || '(bez tytułu)'}
${vision ? `WIZJA (od Joanny, która słuchała sercem — trzymaj się tego nastroju i obrazów):\n${String(vision).slice(0, 600)}\n` : ''}${lyrics ? `TEKST:\n${lyrics.slice(0, 1200)}\n` : ''}PROFIL ENERGII: ${energy}

Zwróć WYŁĄCZNIE tablicę JSON ${sceneCount} scen narastających z energią utworu.
Każda scena: {"mood":"<nastrój>","desc":"<opis wizualny 1 zdanie>","keywords":["k1","k2","k3"]}.
Bez komentarza, tylko JSON.`;

        // Wywołanie lokalnego modelu (Ollama, non-stream)
        let scenes = null, usedLLM = false;
        try {
            const ctrl = new AbortController();
            const tmo = setTimeout(() => ctrl.abort(), 45000);
            const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
                body: JSON.stringify({ model, prompt, stream: false, options: { temperature: 0.8 } }),
            });
            clearTimeout(tmo);
            const data = await r.json();
            const txt = String(data.response || '');
            const m = txt.match(/\[[\s\S]*\]/);
            if (m) { scenes = JSON.parse(m[0]); usedLLM = true; }
        } catch (e) { /* fallback poniżej */ }

        if (!Array.isArray(scenes) || !scenes.length) {
            // Fallback bez LLM — szkielet narastający
            const moods = ['intro / cisza', 'budzenie', 'wzrost', 'kulminacja', 'przełom', 'wybrzmienie'];
            scenes = Array.from({ length: sceneCount }, (_, i) => ({
                mood: moods[Math.min(i, moods.length - 1)],
                desc: `Scena ${i + 1} — wizualizacja energii utworu (${title || 'utwór'}).`,
                keywords: ['abstrakcja', 'światło', 'ruch'],
            }));
        }

        return res.json({ success: true, title: title || null, sceneCount: scenes.length, model: usedLLM ? model : 'fallback', usedLLM, energy, scenes });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/teledysk/scene — generator WŁASNYCH scen z opisu (3 tryby do wyboru).
 * Body: { desc?, mood?, style?, mode:'proc'|'sd'|'gemini', duration?, fps?, sdUrl?, apiKey?, model? }
 *   proc   = programmatic 0.00G (ffmpeg lavfi — zero AI, pełna suwerenność)
 *   sd     = lokalny Stable Diffusion (txt2img) → Ken-Burns
 *   gemini = chmura Imagen (wymaga klucza) → Ken-Burns
 * Zwraca wygenerowany klip sceny (do użycia jako materiał w /api/teledysk/render).
 */
app.post('/api/teledysk/scene', async (req, res) => {
    let { desc, mood, style, mode, duration, fps, sdUrl, apiKey } = req.body ?? {};
    mode = mode || 'proc';
    duration = Math.min(12, Math.max(0.5, Number(duration) || 3));
    fps = Number(fps) > 0 ? Number(fps) : 30;
    const SCENES_DIR = path.join(process.cwd(), '_OtakOs_Move', 'scenes');
    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const out = path.join(SCENES_DIR, `scene_${id}.mp4`);
    const rel = () => path.relative(process.cwd(), out);
    try {
        await fs.mkdir(SCENES_DIR, { recursive: true });

        if (mode === 'proc') {
            // Dobór proceduralnego źródła wg nastroju/stylu sceny.
            const s = String(style || mood || desc || '').toLowerCase();
            const src = /spok|calm|cisz|intro|wybrzmie/.test(s) ? 'gradients=s=1280x720:c0=0x0a0a2a:c1=0x1a4a6a:nb_colors=3:speed=0.008'
                : /kulmin|peak|wybuch|moc|energ|siln/.test(s)   ? 'life=s=1280x720:mold=10:r=30:ratio=0.12:death_color=0x001a2a:life_color=0x00ffcc'
                : /przeł|break|chaos|glitch/.test(s)            ? 'cellauto=s=1280x720:rule=110:scroll=1'
                :                                                 'mandelbrot=s=1280x720:rate=30';
            await execFileAsync(ffmpegPath, ['-y', '-f', 'lavfi', '-i', src, '-t', String(duration),
                '-vf', `format=yuv420p,fps=${fps}`, '-c:v', 'libx264', '-preset', 'veryfast', out]);
            return res.json({ success: true, mode: 'proc', output: rel(), style: s || 'auto' });
        }

        if (mode === 'sd') {
            const url = (sdUrl || 'http://127.0.0.1:7860').replace(/\/$/, '');
            const r = await fetch(`${url}/sdapi/v1/txt2img`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: desc || mood || 'abstract cinematic scene, cohesive lighting', steps: 20, width: 1280, height: 720 }),
            }).catch(() => null);
            if (!r || !r.ok) return res.status(503).json({ success: false, mode: 'sd', message: `Lokalny Stable Diffusion niedostępny (${url}). Uruchom ComfyUI/A1111 z --api.` });
            const data = await r.json();
            const b64 = Array.isArray(data.images) ? data.images[0] : null;
            if (!b64) throw new Error('SD nie zwrócił obrazu.');
            const img = path.join(SCENES_DIR, `sd_${id}.png`);
            await fs.writeFile(img, Buffer.from(b64.replace(/^data:image\/\w+;base64,/, ''), 'base64'));
            await execFileAsync(ffmpegPath, ['-y', '-loop', '1', '-i', img, '-t', String(duration),
                '-vf', `scale=1600:900,zoompan=z='min(zoom+0.0015,1.2)':d=${Math.round(duration * fps)}:s=1280x720,format=yuv420p,fps=${fps}`,
                '-c:v', 'libx264', '-preset', 'veryfast', out]);
            await fs.rm(img, { force: true }).catch(() => {});
            return res.json({ success: true, mode: 'sd', output: rel() });
        }

        if (mode === 'gemini') {
            const key = apiKey || process.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
            if (!key) return res.status(400).json({ success: false, mode: 'gemini', message: 'Brak klucza Gemini (apiKey / VITE_GEMINI_API_KEY).' });
            const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-001:predict?key=${key}`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ instances: [{ prompt: desc || mood || 'cinematic abstract scene' }], parameters: { sampleCount: 1, aspectRatio: '16:9' } }),
            }).catch(() => null);
            if (!r || !r.ok) return res.status(502).json({ success: false, mode: 'gemini', message: `Imagen niedostępny lub błąd klucza (HTTP ${r ? r.status : 'brak'}).` });
            const data = await r.json();
            const b64 = data?.predictions?.[0]?.bytesBase64Encoded;
            if (!b64) throw new Error('Imagen nie zwrócił obrazu.');
            const img = path.join(SCENES_DIR, `gem_${id}.png`);
            await fs.writeFile(img, Buffer.from(b64, 'base64'));
            await execFileAsync(ffmpegPath, ['-y', '-loop', '1', '-i', img, '-t', String(duration),
                '-vf', `scale=1600:900,zoompan=z='min(zoom+0.0015,1.2)':d=${Math.round(duration * fps)}:s=1280x720,format=yuv420p,fps=${fps}`,
                '-c:v', 'libx264', '-preset', 'veryfast', out]);
            await fs.rm(img, { force: true }).catch(() => {});
            return res.json({ success: true, mode: 'gemini', output: rel() });
        }

        return res.status(400).json({ success: false, message: 'Nieznany mode — użyj proc | sd | gemini.' });
    } catch (err) {
        return res.status(500).json({ success: false, mode, message: err.message });
    }
});

/**
 * POST /api/teledysk/stage-audio — most Music V2 → Teledysk.
 * Body: { audioUrl, title? }
 * Suno zwraca utwór jako zdalny URL (CDN) — /api/teledysk/render potrzebuje
 * pliku lokalnego w projekcie. Pobiera audioUrl i zapisuje do
 * _OtakOs_Muzyka/Music_V2_Imports/<slug>-<ts>.mp3, zwraca ścieżkę relatywną
 * gotową do wklejenia jako "audioFile" w Kreatorze Teledysku.
 */
app.post('/api/teledysk/stage-audio', async (req, res) => {
    const { audioUrl, title } = req.body ?? {};
    try {
        if (!audioUrl || !/^https?:\/\//i.test(audioUrl))
            return res.status(400).json({ success: false, message: '"audioUrl" musi być pełnym http(s) URL.' });

        const response = await fetch(audioUrl);
        if (!response.ok) return res.status(502).json({ success: false, message: `Pobieranie nie powiodło się: ${response.status}` });
        const buf = Buffer.from(await response.arrayBuffer());

        const slug = String(title || 'utwor').toLowerCase()
            .replace(/[^a-z0-9ąćęłńóśźż]+/gi, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'utwor';
        const importDir = path.join(MUSIC_DIR, 'Music_V2_Imports');
        await fs.mkdir(importDir, { recursive: true });
        const fileName = `${slug}-${Date.now()}.mp3`;
        await fs.writeFile(path.join(importDir, fileName), buf);

        const relPath = path.relative(process.cwd(), path.join(importDir, fileName)).replace(/\\/g, '/');
        return res.json({ success: true, audioFile: relPath });
    } catch (err) {
        console.error(`[Teledysk] ❌ stage-audio: ${err.message}`);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/teledysk/render — Punkt 4 cegła 2: realny render beat-sync ffmpegiem.
 * Body: { audioFile, sourceDir, vectors?|sonicFile?, fps?, maxCuts? }
 * Tnie źródła wideo na uderzenia basu, dokłada efekty per segment (zoom/flash/
 * fade wg wokalu/sopranów), miksuje z audio → <sourceDir>/edit/teledysk.mp4.
 */
// LRC ([mm:ss.xx] tekst) → SRT (napisy wypalane na teledysku). Każdy wers trwa
// do następnego (ostatni +4s). Obsługuje wiele znaczników w jednej linii.
function lrcToSrt(lrc) {
    const lines = [];
    for (const raw of String(lrc).split(/\r?\n/)) {
        const tags = [...raw.matchAll(/\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]/g)];
        if (!tags.length) continue;
        const text = raw.replace(/\[[^\]]*\]/g, '').trim();
        if (!text) continue;
        for (const m of tags) {
            const frac = m[3] ? Number((m[3] + '000').slice(0, 3)) : 0;
            lines.push({ t: Number(m[1]) * 60 + Number(m[2]) + frac / 1000, text });
        }
    }
    lines.sort((a, b) => a.t - b.t);
    if (!lines.length) return '';
    const fmt = (s) => {
        const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = Math.floor(s % 60), ms = Math.round((s % 1) * 1000);
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
    };
    return lines.map((l, i) => {
        const end = lines[i + 1] ? lines[i + 1].t : l.t + 4;
        return `${i + 1}\n${fmt(l.t)} --> ${fmt(end)}\n${l.text}\n`;
    }).join('\n');
}

app.post('/api/teledysk/render', async (req, res) => {
    let { audioFile, sourceDir, vectors, sonicFile, fps, maxCuts, lrcFile } = req.body ?? {};
    fps = Number(fps) > 0 ? Number(fps) : 30;
    // 120 cięć = więcej różnorodności zanim montaż zacznie się zapętlać na pełną długość utworu
    maxCuts = Number(maxCuts) > 0 ? Number(maxCuts) : 120;
    const inCwd = (p) => { const a = path.resolve(process.cwd(), String(p)); if (!a.startsWith(process.cwd())) throw new Error('ścieżka poza projektem'); return a; };
    const VIDEO_EXT = /\.(mp4|mov|mkv|webm|avi|m4v)$/i;
    let work = null;
    try {
        if (!audioFile)  return res.status(400).json({ success: false, message: '"audioFile" wymagany.' });
        if (!sourceDir)  return res.status(400).json({ success: false, message: '"sourceDir" wymagany.' });
        if (!Array.isArray(vectors) && sonicFile) {
            const parsed = JSON.parse(await fs.readFile(inCwd(sonicFile), 'utf8'));
            vectors = Array.isArray(parsed) ? parsed : (parsed.vectors || parsed.steps || []);
        }
        if (!Array.isArray(vectors) || vectors.length < 4)
            return res.status(400).json({ success: false, message: 'Wymagane "vectors" (>=4) lub "sonicFile".' });

        const audioAbs = inCwd(audioFile);
        if (!fsSync.existsSync(audioAbs)) return res.status(404).json({ success: false, message: `Audio nie istnieje: ${audioFile}` });
        const srcAbs = inCwd(sourceDir);
        // REKURENCJA: bierze wideo także z PODKATALOGÓW (Suweren trzyma materiały
        // w folderach, bo pliki nazywają się tak samo 1-33). Pełne ścieżki, więc
        // kolizje nazw nie szkodzą. Pomijamy folder edit/ — tam lądują nasze rendery
        // (bez tego kolejny render zassałby własny poprzedni teledysk = pętla).
        const allEntries = await fs.readdir(srcAbs, { recursive: true });
        let clips = allEntries
            .filter(f => VIDEO_EXT.test(f) && !/(^|[\\/])edit([\\/]|$)/i.test(f))
            .map(f => path.join(srcAbs, f));
        // Kontrola materiałów: jawna lista (clips[]) albo filtr nazwy (clipFilter).
        const clipList = req.body?.clips, clipFilter = req.body?.clipFilter;
        if (Array.isArray(clipList) && clipList.length)
            clips = clips.filter(p => clipList.some(n => path.basename(p) === n || p.endsWith(n)));
        else if (typeof clipFilter === 'string' && clipFilter)
            clips = clips.filter(p => path.basename(p).toLowerCase().includes(clipFilter.toLowerCase()));
        if (!clips.length) return res.status(400).json({ success: false, message: `Brak źródeł wideo (po filtrze) w ${sourceDir} ani w podkatalogach.` });

        // 🎲 TASOWANIE — bez tego montaż brał zawsze PIERWSZE N klipów (alfabetycznie
        // top-level + wczesne foldery), nigdy nie sięgając dalszych (np. The_Celestial_Bridge_).
        // Teraz każdy render losuje z CAŁEJ biblioteki (832 klipy) — inny za każdym razem.
        for (let i = clips.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [clips[i], clips[j]] = [clips[j], clips[i]]; }

        // KLUCZOWE: realna długość audio z ffprobe. Wektory soniczne NIE mają pola
        // czasu (tylko s,b,v,h) i są próbkowane co ~sekundy podczas odtwarzania —
        // 204 próbki to CAŁY 7-min utwór, nie 6.8s (i/fps). Rozkładamy je na audioDur,
        // inaczej montaż ściska się do kilku sekund i zapętla te same klipy.
        let audioDur = 0;
        try {
            const { stdout } = await execFileAsync(ffprobePath, ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', audioAbs]);
            audioDur = parseFloat(String(stdout).trim()) || 0;
        } catch { /* brak ffprobe — spadamy na oś wektorów */ }
        const N = vectors.length;
        const hasRealT = vectors[0] && vectors[0].t !== undefined;
        const timeAt = (i) => hasRealT ? Number(vectors[i].t) : (audioDur > 0 ? (i / Math.max(1, N - 1)) * audioDur : i / fps);
        const endTime = audioDur > 0 ? audioDur : (hasRealT ? Number(vectors[N - 1].t) : N / fps);

        // Cięcia na uderzenia basu (czasy z realnej osi audio)
        const bass = vectors.map(v => Number(v.b ?? v.bass ?? 0));
        const mean = bass.reduce((a, b) => a + b, 0) / bass.length;
        const std  = Math.sqrt(bass.reduce((a, b) => a + (b - mean) ** 2, 0) / bass.length);
        const thr  = mean + 0.5 * std;
        const cuts = [];
        for (let i = 1; i < bass.length - 1; i++)
            if (bass[i] > thr && bass[i] >= bass[i - 1] && bass[i] > bass[i + 1])
                cuts.push({ t: timeAt(i), v: Number(vectors[i].v ?? vectors[i].vocals ?? 0), h: Number(vectors[i].h ?? vectors[i].highs ?? 0) });
        if (cuts.length < 2) return res.status(400).json({ success: false, message: 'Za mało uderzeń do montażu.' });

        // Segmenty na uderzenia basu, ale DŁUGIE odstępy dzielimy na ~3s podsegmenty —
        // każdy dostaje NOWY klip. Bez tego 37 uderzeń = tylko 37 klipów; teraz np. 7-min
        // utwór daje ~140 segmentów = ~140 różnych klipów z biblioteki + żywszy montaż.
        const MAX_SEG = 3.0, MAX_TOTAL = 180;
        const rawCuts = cuts.slice(0, maxCuts);
        const segs = [];
        for (let idx = 0; idx < rawCuts.length && segs.length < MAX_TOTAL; idx++) {
            const c = rawCuts[idx];
            const from = c.t, to = rawCuts[idx + 1] ? rawCuts[idx + 1].t : endTime;
            const span = Math.max(0.25, to - from);
            const fx = c.v > 0.6 ? 'punch-zoom' : c.h > 0.6 ? 'flash-cut' : 'soft-fade';
            const nSub = Math.max(1, Math.round(span / MAX_SEG));
            const subDur = span / nSub;
            for (let k = 0; k < nSub && segs.length < MAX_TOTAL; k++)
                segs.push({ from: from + k * subDur, to: from + (k + 1) * subDur, fx });
        }

        work = path.join(TEMP_DIR, `teledysk_${Date.now()}`);
        await fs.mkdir(work, { recursive: true });
        const parts = [];
        for (let i = 0; i < segs.length; i++) {
            // Cap 5s — by ostatni segment nie rozciągnął się do końca utworu.
            const dur = Math.min(5, Math.max(0.25, +(segs[i].to - segs[i].from).toFixed(3)));
            const src = clips[i % clips.length];
            const out = path.join(work, `seg_${String(i).padStart(3, '0')}.mp4`);
            const vf = ['scale=1280:720:force_original_aspect_ratio=increase', 'crop=1280:720', `fps=${fps}`];
            if (segs[i].fx === 'punch-zoom') vf[0] = 'scale=1408:792:force_original_aspect_ratio=increase';
            else if (segs[i].fx === 'flash-cut') vf.push('eq=brightness=0.06:saturation=1.3');
            else vf.push('fade=t=in:st=0:d=0.12');
            try {
                // Per-segment guard: uszkodzony klip (np. brak moov atom) NIE wywala renderu.
                await execFileAsync(ffmpegPath, ['-y', '-t', String(dur), '-i', src, '-an', '-vf', vf.join(','), '-c:v', 'libx264', '-preset', 'veryfast', '-pix_fmt', 'yuv420p', out]);
                parts.push(out);
            } catch (segErr) {
                console.warn(`[Teledysk] ⚠️ segment ${i} pominięty (źródło uszkodzone?): ${path.basename(src)}`);
            }
        }
        if (!parts.length)
            return res.status(422).json({ success: false, message: 'Żaden segment się nie wyrenderował — źródła wideo mogą być uszkodzone.' });

        const listFile = path.join(work, 'list.txt');
        await fs.writeFile(listFile, parts.map(p => `file '${p.replace(/'/g, "'\\''")}'`).join('\n'), 'utf8');
        const editDir = path.join(srcAbs, 'edit');
        await fs.mkdir(editDir, { recursive: true });
        // Unikalna nazwa — każdy render zostaje, nic się nie nadpisuje.
        const audioSlug = path.basename(audioFile).replace(/\.[^.]+$/, '')
            .toLowerCase().replace(/[^a-z0-9ąćęłńóśźż]+/gi, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'utwor';
        const teledysk = path.join(editDir, `teledysk_${audioSlug}_${Date.now()}.mp4`);

        // 🔤 Napisy z LRC (opcjonalnie) — wypalane na dole obrazu. SRT ląduje w work/,
        // a ffmpeg odpalamy z cwd=work i referencją po nazwie — omija piekło escapowania
        // ścieżek Windows w filtrze subtitles (dwukropki dysku, backslashe).
        let subFilter = null, ffOpts = { timeout: 0, maxBuffer: 1024 * 1024 * 500 };
        if (lrcFile) {
            const lrcAbs = inCwd(lrcFile);
            if (fsSync.existsSync(lrcAbs)) {
                const srt = lrcToSrt(await fs.readFile(lrcAbs, 'utf8'));
                if (srt) {
                    await fs.writeFile(path.join(work, 'napisy.srt'), srt, 'utf8');
                    // Alignment=2 = dół-środek, BorderStyle=3 = półprzezroczyste tło, MarginV=40 = odstęp od dołu
                    subFilter = "subtitles=napisy.srt:force_style='FontName=Arial,FontSize=22,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&HA0000000,BorderStyle=3,Alignment=2,MarginV=40'";
                    ffOpts = { ...ffOpts, cwd: work };
                }
            }
        }

        // -stream_loop -1 zapętla montaż, a -shortest ucina na końcu audio → teledysk
        // ZAWSZE ma długość utworu (7:16 zamiast 14s), niezależnie od ilości materiału.
        // genpts + avoid_negative_ts — czysta baza czasu przy zapętleniu (anti-glitch).
        const ffArgs = ['-y', '-fflags', '+genpts', '-stream_loop', '-1',
            '-f', 'concat', '-safe', '0', '-i', listFile, '-i', audioAbs,
            '-map', '0:v:0', '-map', '1:a:0', '-shortest', '-avoid_negative_ts', 'make_zero'];
        if (subFilter) ffArgs.push('-vf', subFilter);
        ffArgs.push('-c:v', 'libx264', '-preset', 'veryfast', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', teledysk);
        await execFileAsync(ffmpegPath, ffArgs, ffOpts);

        const wzgledna = path.relative(process.cwd(), teledysk);
        // Plik realnie lezy na dysku — to jest TRWALOSC z punktu 3.
        const oddech = await oddechZaPrace('render.wideo', `render:${wzgledna}`,
            { nazwa: path.basename(teledysk), sciezka: wzgledna });
        return res.json({ success: true, output: wzgledna, segments: segs.length, clipsUsed: clips.length, beats: cuts.length, subtitles: !!subFilter, oddech });
    } catch (err) {
        console.error(`[Teledysk] ❌ ${err.message}`);
        return res.status(500).json({ success: false, message: err.message });
    } finally {
        if (work) { try { await fs.rm(work, { recursive: true, force: true }); } catch {} }
    }
});

/**
 * POST /api/video/edit  (VideO-Use — orkiestrator montażu)
 * Body: { sourceDir, mission?, subtitleStyle?, audioFadeMs? }
 * Skanuje folder ze źródłami, sprawdza ffmpeg (wbudowany) i zwraca PLAN montażu
 * (EDL). Pełne cięcie słów-wypełniaczy wymaga skilla video-use + klucza
 * ElevenLabs Scribe — tu most przygotowuje plan i potwierdza drożność rur.
 */
app.post('/api/video/edit', async (req, res) => {
    const { sourceDir, mission, subtitleStyle, audioFadeMs } = req.body ?? {};
    const VIDEO_EXT = /\.(mp4|mov|mkv|webm|avi|m4v)$/i;
    try {
        // Drożność rur: ffmpeg wbudowany (ffmpeg-static)
        let ffmpegOk = false, ffmpegVer = '';
        try {
            const { stdout, stderr } = await execFileAsync(ffmpegPath, ['-version']);
            ffmpegVer = (stdout || stderr || '').split('\n')[0] || '';
            ffmpegOk = /ffmpeg version/i.test(ffmpegVer);
        } catch { ffmpegOk = false; }

        // Skan źródeł (bez wychodzenia poza projekt)
        let sources = [];
        if (sourceDir) {
            const abs = path.resolve(process.cwd(), String(sourceDir));
            if (!abs.startsWith(process.cwd())) {
                return res.status(403).json({ success: false, message: 'Bezpieczeństwo: sourceDir poza projektem.' });
            }
            try {
                const entries = await fs.readdir(abs, { withFileTypes: true });
                for (const e of entries) {
                    if (e.isFile() && VIDEO_EXT.test(e.name)) {
                        const st = await fs.stat(path.join(abs, e.name));
                        sources.push({ name: e.name, sizeMB: +(st.size / 1048576).toFixed(1) });
                    }
                }
            } catch { /* katalog nie istnieje — sources puste */ }
        }

        const fade = Number(audioFadeMs) > 0 ? Number(audioFadeMs) : 30;
        const subs = subtitleStyle || '2-word UPPERCASE';
        const plan = [
            `1. Transkrypcja (ElevenLabs Scribe) → takes_packed.md z word-level timestamps`,
            `2. LLM (lokalny/most) wyznacza cięcia: usuń „yyy/eee", false-starts, ciszę`,
            `3. ffmpeg: cięcia + ${fade}ms audio-fade na każdym łączeniu (anti-pop)`,
            `4. Napisy w stylu: ${subs}`,
            `5. Self-eval pętla (max 3) → render edit/final.mp4`,
        ];

        return res.json({
            success: true,
            ffmpeg: { available: ffmpegOk, version: ffmpegVer },
            mission: mission || '(brak — opisz montaż)',
            sourceDir: sourceDir || null,
            sources,
            sourceCount: sources.length,
            plan,
            note: ffmpegOk
                ? (sources.length
                    ? `Rury drożne. ${sources.length} źródeł gotowych. Pełne cięcie wymaga skilla video-use + klucza ElevenLabs.`
                    : `Rury drożne (ffmpeg OK), ale brak plików wideo w „${sourceDir || '—'}". Wrzuć surowy materiał.`)
                : `⚠ ffmpeg niedostępny — sprawdź instalację ffmpeg-static.`,
        });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ── 🫀 PULS MASZYNY — żywe tętno sprzętu (skórka PULS w Orbicie) ─────────────
// RAM/CPU z os, VRAM+temperatura z nvidia-smi (cichy brak gdy karta bez CUDA).
app.get('/api/system/pulse', async (req, res) => {
    const totalMB = Math.round(os.totalmem() / 1048576);
    const freeMB  = Math.round(os.freemem() / 1048576);
    const cpus    = os.cpus();
    // Chwilowe obciążenie CPU: średnia (busy/total) od startu — wystarcza do wizualizacji trendu
    const cpuPct  = Math.round(cpus.reduce((acc, c) => {
        const t = Object.values(c.times).reduce((a, b) => a + b, 0);
        return acc + (1 - c.times.idle / t);
    }, 0) / cpus.length * 100);

    let gpu = null;
    try {
        const { stdout } = await execFileAsync('nvidia-smi',
            ['--query-gpu=memory.used,memory.total,temperature.gpu,utilization.gpu', '--format=csv,noheader,nounits'],
            { timeout: 3000 });
        const [used, total, temp, util] = stdout.trim().split(',').map(v => parseInt(v.trim(), 10));
        if (Number.isFinite(used)) gpu = { vramUsedMB: used, vramTotalMB: total, tempC: temp, utilPct: util };
    } catch { /* brak nvidia-smi / karta nie-NVIDIA — pole gpu zostaje null */ }

    res.json({
        success: true,
        ram: { usedMB: totalMB - freeMB, totalMB, pct: Math.round((totalMB - freeMB) / totalMB * 100) },
        cpu: { pct: cpuPct, cores: cpus.length },
        gpu,
        uptimeSec: Math.round(os.uptime()),
        at: Date.now(),
    });
});

// ── 📢 WIEŻA PARTNERÓW — reklamy firm na prawym panelu Orbity ────────────────
// Suwerenny rejestr: _OtakOs_Wymiar/ads.local.json. Zamówienia wpadają jako
// "pending" (z otakos.wtf/formularza), Suweren aktywuje po opłacie
// (POST /api/ads/activate — most słucha tylko na 127.0.0.1, więc aktywacja
// jest z natury lokalna = tylko Ty).
const ADS_FILE = path.join(process.cwd(), '_OtakOs_Wymiar', 'ads.local.json');
async function readAds() {
    try { return JSON.parse(await fs.readFile(ADS_FILE, 'utf8')); } catch { return []; }
}
async function writeAds(ads) {
    await fs.mkdir(path.dirname(ADS_FILE), { recursive: true });
    await fs.writeFile(ADS_FILE, JSON.stringify(ads, null, 2), 'utf8');
}

app.get('/api/ads', async (req, res) => {
    const all = await readAds();
    const now = Date.now();
    const active = all.filter(a => a.status === 'active' && (!a.paidUntil || a.paidUntil > now));
    res.json({ success: true, ads: active, pendingCount: all.filter(a => a.status === 'pending').length });
});

app.post('/api/ads/order', async (req, res) => {
    const { company, slogan, url, email, tier = 'standard' } = req.body ?? {};
    if (!company || !slogan) return res.status(400).json({ success: false, message: 'Wymagane: "company" i "slogan".' });
    const ads = await readAds();
    const order = {
        id: `AD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
        company: String(company).slice(0, 60),
        slogan:  String(slogan).slice(0, 120),
        url:     url ? String(url).slice(0, 200) : null,
        email:   email ? String(email).slice(0, 120) : null,
        tier, status: 'pending', paidUntil: null, createdAt: Date.now(),
    };
    ads.push(order);
    await writeAds(ads);
    console.log(`[Wieża Partnerów] 📢 Nowe zamówienie: ${order.company} (${order.id})`);
    return res.json({ success: true, orderId: order.id, message: 'Zamówienie przyjęte — slot aktywuje się po opłacie.' });
});

app.post('/api/ads/activate', async (req, res) => {
    const { id, days = 30 } = req.body ?? {};
    const ads = await readAds();
    const ad = ads.find(a => a.id === id);
    if (!ad) return res.status(404).json({ success: false, message: `Brak zamówienia ${id}.` });
    ad.status = 'active';
    ad.paidUntil = Date.now() + Number(days) * 86400000;
    await writeAds(ads);
    console.log(`[Wieża Partnerów] ✅ Aktywowano: ${ad.company} do ${new Date(ad.paidUntil).toISOString().slice(0, 10)}`);
    return res.json({ success: true, ad });
});

// ── 🏛️ AUTOMAT KATEDR — lokalny rejestr + "drukarka" co 10 min ───────────────
// Suwerennie, bez backendu: most rejestruje WŁASNĄ Katedrę (+ sparowanych
// rówieśników), drukuje snapshot do _OtakOs_Wymiar/cathedrals.local.json co
// 10 min i wystawia go live na /api/cathedrals. Zero "liczb z dupy".
const CATHEDRAL_BOOT = Date.now();
function cathedralSelf() {
    return {
        id:        process.env.OTAKOS_NODE_ID   || String(process.env.COMPUTERNAME || 'katedra').toLowerCase(),
        name:      process.env.OTAKOS_NODE_NAME || process.env.COMPUTERNAME || 'KATEDRA-0',
        dimension: '0.00G',
        bootAt:    CATHEDRAL_BOOT,
        uptimeSec: Math.round((Date.now() - CATHEDRAL_BOOT) / 1000),
    };
}
let cathedralSnapshot = { self: cathedralSelf(), peers: [], collectedAt: Date.now() };
async function printCathedrals() {
    cathedralSnapshot = { self: cathedralSelf(), peers: cathedralSnapshot.peers || [], collectedAt: Date.now() };
    try {
        await fs.writeFile(path.join(ANTIGRAVITY_DIR, 'cathedrals.local.json'),
            JSON.stringify(cathedralSnapshot, null, 2), 'utf8');
        console.log(`[Automat-Katedr] 🖨️  Wydrukowano rejestr (${1 + cathedralSnapshot.peers.length} katedr).`);
    } catch (e) { /* katalog niedostępny — pomijamy cicho */ }
}
printCathedrals();
setInterval(printCathedrals, 10 * 60 * 1000);

app.get('/api/cathedrals', (req, res) => {
    res.json({ success: true, self: cathedralSelf(), peers: cathedralSnapshot.peers,
               count: 1 + cathedralSnapshot.peers.length, collectedAt: cathedralSnapshot.collectedAt });
});

/**
 * POST /api/cathedrals/peer — dodaj zaufanego rówieśnika do rejestru (parowanie p2p).
 * Body: { id, name?, url? }
 */
app.post('/api/cathedrals/peer', async (req, res) => {
    const { id, name, url } = req.body ?? {};
    if (!id) return res.status(400).json({ success: false, message: 'Brak id rówieśnika.' });
    const peers = cathedralSnapshot.peers.filter(p => p.id !== id);
    peers.push({ id, name: name || id, url: url || null, pairedAt: Date.now() });
    cathedralSnapshot.peers = peers;
    await printCathedrals();
    return res.json({ success: true, count: 1 + peers.length });
});

/**
 * GET /api/agi/state — żywy stan lokalnej sieci neuronowej (dla mapy AGI na
 * otakos.wtf). Rdzeń realny (Ollama ping, kolejka Mechanika), reszta gotowość.
 * Mapuje na id węzłów z agi.local.ts: ollama/bridge/mechanik/koom/podcast/
 * scout/kronos/video/ted/music/shield/vault/quantum.
 */
app.get('/api/agi/state', async (req, res) => {
    const nodes = {};
    const set = (id, status, load = 0) => { nodes[id] = { status, load: Math.max(0, Math.min(1, load)) }; };

    // BRIDGE — skoro odpowiada, żyje.
    set('bridge', 'online', 0.4);

    // OLLAMA — szybki ping (timeout 1.2s).
    try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 1200);
        const r = await fetch(`${OLLAMA_BASE}/api/tags`, { signal: ctrl.signal });
        clearTimeout(t);
        const data = r.ok ? await r.json().catch(() => ({})) : {};
        const loaded = Array.isArray(data.models) ? data.models.length : 0;
        set('ollama', r.ok ? 'online' : 'offline', r.ok ? Math.min(1, 0.3 + loaded * 0.1) : 0);
    } catch { set('ollama', 'offline', 0); }

    // MECHANIK — głębokość kolejki = obciążenie.
    try {
        const q = await MechanicService.getInstance().getQueue();
        const pending = Array.isArray(q) ? q.filter(t => t && t.status !== 'DONE' && t.status !== 'REJECTED').length : 0;
        set('mechanik', pending > 0 ? 'online' : 'idle', Math.min(1, pending / 5));
    } catch { set('mechanik', 'idle', 0); }

    // SHIELD — Tarcza zawsze czuwa (singleton dostępny).
    set('shield', 'online', 0.5);

    // Reszta węzłów — gotowość (idle), lekki oddech z czasu.
    const breath = (Math.sin(Date.now() / 2500) + 1) / 2 * 0.4 + 0.1;
    ['koom', 'podcast', 'scout', 'kronos', 'video', 'ted', 'music', 'vault', 'quantum']
        .forEach(id => set(id, 'idle', +breath.toFixed(2)));

    return res.json({ success: true, origin: 'local', dimension: '0.00G', ts: Date.now(), nodes });
});

/**
 * POST /api/kronos/forecast
 * Body: { symbol, lastPrice, history?:number[], predLen? }
 * Lokalna projekcja świec K-line (Nasiono Rynkowe) — zero chmury.
 */
app.post('/api/kronos/forecast', (req, res) => {
    const { symbol, lastPrice, history, predLen } = req.body ?? {};
    if (!(Number(lastPrice) > 0)) {
        return res.status(400).json({ success: false, message: 'Wymagane "lastPrice" (> 0).' });
    }
    try {
        const out = kronosForecast({ symbol, lastPrice: Number(lastPrice), history, predLen: Number(predLen) || 24 });
        return res.json({ success: true, ...out });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ── 📰 TUNEL WIADOMOŚCI RYNKOWYCH ────────────────────────────────────────────
// Rynek reaguje emocjonalnie, więc nastrój prasy jest realnym sygnałem — inaczej
// niż wróżenie ze świec. Tu zbieramy FAKTY (nagłówki), a interpretację zostawiamy
// osobnemu wywołaniu, jawnie oznaczonemu jako opinia modelu.

/**
 * GET /api/rynek/wiadomosci?limit=40&rodzaj=krypto|makro&odswiez=1
 * Zwraca nagłówki + RAPORT ŹRÓDEŁ (które kanały odpowiedziały, a które padły).
 */
app.get('/api/rynek/wiadomosci', async (req, res) => {
    try {
        const out = await zbierzWiadomosci({
            limit:   Number(req.query.limit) || 40,
            rodzaj:  req.query.rodzaj === 'krypto' || req.query.rodzaj === 'makro' ? req.query.rodzaj : undefined,
            odswiez: req.query.odswiez === '1' || req.query.odswiez === 'true',
        });
        const padle = out.raport.filter(r => !r.ok);
        if (padle.length) console.warn(`[Rynek] ⚠️ Kanały bez odpowiedzi: ${padle.map(p => `${p.nazwa} (${p.blad})`).join(', ')}`);
        return res.json({ success: true, ...out, zrodelLacznie: RYNEK_SOURCES.length });
    } catch (err) {
        console.error('[Rynek] ❌ wiadomosci:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/rynek/nastroj  Body: { rodzaj?, maks? }
 * Lokalny model streszcza NASTRÓJ PRASY. To opinia modelu o tonie nagłówków —
 * nie prognoza i nie porada. Odpowiedź niesie to oznaczenie, żeby żaden konsument
 * API nie mógł wziąć jej za sygnał inwestycyjny.
 */
app.post('/api/rynek/nastroj', async (req, res) => {
    try {
        const { rodzaj, maks } = req.body ?? {};
        const dane = await zbierzWiadomosci({ limit: 60, rodzaj: rodzaj === 'krypto' || rodzaj === 'makro' ? rodzaj : undefined });
        if (!dane.items.length) {
            return res.status(503).json({ success: false, message: 'Żaden kanał nie odpowiedział — brak nagłówków do streszczenia.', raport: dane.raport });
        }
        const uzyte = Math.max(5, Math.min(40, Number(maks) || 25));
        const streszczenie = await genOllama(promptNastroju(dane.items, uzyte), DEFAULT_LLM, 120000);
        if (!streszczenie) {
            return res.status(503).json({
                success: false,
                message: `Rdzeń "${DEFAULT_LLM}" nie odpowiedział — nagłówki są, brakuje streszczenia. Sprawdź: ollama ps`,
                items: dane.items.slice(0, uzyte), raport: dane.raport,
            });
        }
        return res.json({
            success: true,
            streszczenie,
            model: DEFAULT_LLM,
            naglowkowUzytych: uzyte,
            items: dane.items.slice(0, uzyte),
            raport: dane.raport,
            pobranoO: dane.pobranoO,
            // ⚠️ Jawne oznaczenie w samej odpowiedzi — nie tylko w UI.
            charakter: 'OPINIA MODELU O TONIE PRASY',
            disclaimer: 'Streszczenie nastroju medialnego wygenerowane lokalnie. Nie jest prognozą ' +
                        'ani poradą inwestycyjną i nie powinno być podstawą decyzji finansowych.',
        });
    } catch (err) {
        console.error('[Rynek] ❌ nastroj:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * GET /api/rynek/sektory?odswiez=1
 * Macierz korelacji z realnych notowań — co faktycznie porusza się razem.
 */
app.get('/api/rynek/sektory', async (req, res) => {
    try {
        const mapa = await zbudujMape({ odswiez: req.query.odswiez === '1' || req.query.odswiez === 'true' });
        if (mapa.pominiete?.length) {
            console.warn(`[Rynek] ⚠️ Mapa sektorów — pominięte aktywa: ${mapa.pominiete.map(p => `${p.id} (${p.powod})`).join(', ')}`);
        }
        return res.json({ success: true, ...mapa });
    } catch (err) {
        console.error('[Rynek] ❌ sektory:', err.message);
        return res.status(502).json({ success: false, message: `Źródło notowań nieosiągalne: ${err.message}` });
    }
});

// ── 📓 DZIENNIK DECYZJI ──────────────────────────────────────────────────────
// Jedyne narzędzie z całego arsenału finansowego, które realnie poprawia wyniki:
// zapisuje CO i DLACZEGO, zanim znany jest wynik. Nic tu nie doradza.

app.get('/api/rynek/dziennik', async (req, res) => {
    try {
        return res.json({ success: true, wpisy: await dziennikLista(ANTIGRAVITY_DIR) });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/rynek/dziennik', async (req, res) => {
    try {
        const wpis = await dziennikDodaj(ANTIGRAVITY_DIR, req.body ?? {});
        console.log(`[Dziennik] 📓 ${wpis.kierunek} ${wpis.aktywo} (pewność ${wpis.pewnosc}/5) — ${wpis.id}`);
        return res.json({ success: true, wpis });
    } catch (err) {
        // 400, nie 500 — to walidacja treści, nie awaria serwera.
        return res.status(400).json({ success: false, message: err.message });
    }
});

app.post('/api/rynek/dziennik/:id/wynik', async (req, res) => {
    try {
        const wpis = await dziennikDomknij(ANTIGRAVITY_DIR, req.params.id, req.body ?? {});
        return res.json({ success: true, wpis });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

app.get('/api/rynek/dziennik/podsumowanie', async (req, res) => {
    try {
        return res.json({ success: true, ...(await dziennikPodsumowanie(ANTIGRAVITY_DIR)) });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/mechanic/reject/:id
 * Zmienia status zadania na REJECTED i usuwa je z widoku kolejki.
 */
app.post('/api/mechanic/reject/:id', async (req, res) => {
    const { id } = req.params;
    if (!id) return res.status(400).json({ success: false, message: 'Brak id.' });

    try {
        const result = await MechanicService.getInstance().rejectTask(id);
        if (!result) {
            return res.status(404).json({ success: false, message: `Zadanie ${id} nie istnieje.` });
        }
        return res.json({ success: true, id });
    } catch (err) {
        console.error(`[Mechanic-API] ❌ reject/${id}:`, err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ── 🎙️ IMPRESARIO — Agent Medialny ──────────────────────────────────────────

/**
 * GET /api/impresario/status
 * Zwraca stan kont (vault) + kolejkę + metryki.
 */
app.get('/api/impresario/status', async (req, res) => {
    try {
        const status = await ImpresarioService.getInstance().getStatus();
        return res.json({ success: true, ...status });
    } catch (err) {
        console.error('[Impresario-API] ❌ GET status:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * GET /api/impresario/queue
 * Zwraca aktualną kolejkę wydawniczą.
 */
app.get('/api/impresario/queue', async (req, res) => {
    try {
        const queue = await ImpresarioService.getInstance().getQueue();
        return res.json({ success: true, queue, total: queue.length });
    } catch (err) {
        console.error('[Impresario-API] ❌ GET queue:', err.message);
        return res.status(500).json({ success: false, queue: [], message: err.message });
    }
});

/**
 * POST /api/impresario/enqueue
 * Body: { title: string, album?: string, platforms: string[], filePath?: string }
 *
 * Dodaje nowe zlecenie publikacji do kolejki.
 * Opcjonalne pole `filePath` wskazuje plik .mp4/.wav na dysku lokalnym
 * (używane przez uploadVideoToYouTube przy realnym deploymencie).
 */
app.post('/api/impresario/enqueue', async (req, res) => {
    const { title, album, platforms, filePath = null } = req.body ?? {};

    if (!title || !platforms) {
        return res.status(400).json({
            success: false,
            message: 'Wymagane pola: title i platforms (tablica).',
        });
    }

    try {
        const job = await ImpresarioService.getInstance().enqueuePublication(title, album, platforms, filePath);
        return res.status(201).json({
            success:  true,
            job,
            message:  `Zlecenie "${title}" przyjęte do Katedry.`,
            hasFile:  Boolean(job.filePath),
        });
    } catch (err) {
        console.error('[Impresario-API] ❌ POST enqueue:', err.message);
        return res.status(400).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/impresario/upload/:id
 * Inicjuje realny upload zadania do YouTube.
 * Sprawdza media_secrets.json — jeśli tokeny brak → zadanie → FAILED z jasnym komunikatem.
 */
app.post('/api/impresario/upload/:id', async (req, res) => {
    const { id } = req.params;
    if (!id) return res.status(400).json({ success: false, message: 'Brak id zadania.' });

    try {
        // Pobierz zadanie z kolejki
        const queue = await ImpresarioService.getInstance().getQueue();
        const task  = queue.find(j => j.id === id);

        if (!task) {
            return res.status(404).json({ success: false, message: `Zadanie ${id} nie istnieje w kolejce.` });
        }
        if (!task.platforms.includes('youtube')) {
            return res.status(400).json({ success: false, message: `Zadanie ${id} nie jest przeznaczone na YouTube.` });
        }

        const result = await ImpresarioService.getInstance().uploadVideoToYouTube(task);
        const status = result.success ? 200 : 422;
        return res.status(status).json(result);

    } catch (err) {
        console.error('[Impresario-API] ❌ POST upload:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/impresario/vault/update
 * Body: { platform: string, isConnected: boolean, ...extras }
 * Aktualizuje metadane konta (połącz/rozłącz platformę).
 */
app.post('/api/impresario/vault/update', async (req, res) => {
    const { platform, isConnected, ...extras } = req.body ?? {};

    if (!platform || typeof isConnected === 'undefined') {
        return res.status(400).json({
            success: false,
            message: 'Wymagane pola: platform i isConnected.',
        });
    }

    try {
        const updated = await ImpresarioService.getInstance().updateVaultMetadata(platform, isConnected, extras);
        return res.json({ success: true, platform, updated });
    } catch (err) {
        console.error('[Impresario-API] ❌ POST vault/update:', err.message);
        return res.status(400).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/impresario/export/spotify/:id
 * Ręcznie wyzwól eksport paczki DistroKid dla konkretnego zadania.
 * Zadanie musi istnieć w kolejce i mieć status PENDING lub PROCESSING.
 */
app.post('/api/impresario/export/spotify/:id', async (req, res) => {
    const { id } = req.params;
    if (!id) return res.status(400).json({ success: false, message: 'Brak id zadania.' });

    try {
        const queue = await ImpresarioService.getInstance().getQueue();
        const task  = queue.find(j => j.id === id);

        if (!task) {
            return res.status(404).json({ success: false, message: `Zadanie ${id} nie istnieje w kolejce.` });
        }
        if (task.status === 'COMPLETE') {
            return res.status(409).json({ success: false, message: `Zadanie ${id} już zostało ukończone.` });
        }

        // Uruchom eksport (może trwać chwilę — odpowiedź po zakończeniu)
        const result = await ImpresarioService.getInstance().exportSpotifyPaczkowy(task);
        return res.json({ success: true, id, ...result });

    } catch (err) {
        console.error('[Impresario-API] ❌ POST export/spotify:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ════════════════════════════════════════════════════════════════════════════
//  AUTH GOOGLE — Przyszłościowy OAuth2 + Ekosystem Gemini Agent
// ════════════════════════════════════════════════════════════════════════════

/**
 * GET /api/auth/google
 * Punkt wejścia OAuth2. Na tym etapie zwraca JSON z informacjami i planowanym URL.
 * TODO: Po uzupełnieniu CLIENT_ID w media_secrets.json — przekieruj na ekran zgody Google.
 */
app.get('/api/auth/google', async (req, res) => {
    try {
        const secretsStatus = await ImpresarioService.getInstance().getYouTubeSecretsStatus();
        const clientId = secretsStatus.filled.includes('CLIENT_ID')
            ? '(skonfigurowany)'
            : '(brak — uzupełnij media_secrets.json)';

        const authUrl = secretsStatus.filled.includes('CLIENT_ID')
            ? `https://accounts.google.com/o/oauth2/auth?` +
              `response_type=code&` +
              `scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fyoutube.upload&` +
              `access_type=offline&prompt=consent`
            : null;

        return res.json({
            success:       true,
            status:        secretsStatus.allPresent ? 'READY' : 'NEEDS_CONFIGURATION',
            clientId,
            authUrl,
            secretsStatus,
            nextStep:      secretsStatus.allPresent
                ? 'Klucze gotowe. Użyj POST /api/auth/google/simulate lub zaimplementuj redirect.'
                : 'Uzupełnij CLIENT_ID, CLIENT_SECRET i REFRESH_TOKEN przez POST /api/impresario/secrets/youtube.',
            note:          'Pełny redirect OAuth2 zostanie aktywowany po skonfigurowaniu CLIENT_ID w Katedrze.',
        });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/impresario/secrets/youtube
 * Body: { clientId?: string, clientSecret?: string, refreshToken?: string }
 * Zapisuje klucze API YouTube do media_secrets.json (atomowo) i łączy vault.
 */
app.post('/api/impresario/secrets/youtube', async (req, res) => {
    const { clientId, clientSecret, refreshToken } = req.body ?? {};

    if (!clientId && !clientSecret && !refreshToken) {
        return res.status(400).json({
            success: false,
            message: 'Wymagane przynajmniej jedno pole: clientId, clientSecret lub refreshToken.',
        });
    }

    try {
        const result = await ImpresarioService.getInstance().saveYouTubeSecrets(
            clientId, clientSecret, refreshToken
        );

        // Automatycznie połącz vault jeśli wszystkie klucze uzupełnione
        if (result.missingFields.length === 0) {
            await ImpresarioService.getInstance().updateVaultMetadata('youtube', true, {
                api_key_hash: `sha256_${Date.now().toString(36)}`, // placeholder hash
            });
        }

        return res.json({
            success: true,
            message: result.missingFields.length === 0
                ? '✅ Wszystkie klucze YouTube zapisane! Konto połączone.'
                : `Klucze częściowo zapisane. Brakuje: ${result.missingFields.join(', ')}.`,
            ...result,
        });
    } catch (err) {
        console.error('[Impresario-API] ❌ POST secrets/youtube:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/auth/google/simulate
 * Symuluje autoryzację przez Ekosystem Gemini Agent.
 * Flagi vault: { connected: true, gemini_auth: true, auth_method: 'gemini_agent_ecosystem' }
 * TODO: Zastąpić rzeczywistym OAuth2 callback po uzyskaniu Gemini API access.
 */
app.post('/api/auth/google/simulate', async (req, res) => {
    try {
        const result = await ImpresarioService.getInstance().simulateGeminiAgentConnect();
        return res.json({ success: true, ...result });
    } catch (err) {
        console.error('[Impresario-API] ❌ POST auth/google/simulate:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ════════════════════════════════════════════════════════════════════════════
//  TOST MESSENGER — Szyfrowany Komunikator Katedry
// ════════════════════════════════════════════════════════════════════════════

const TOST_SYSTEM_INSTRUCTION =
    `Jesteś TeO – osobisty, cyfrowy schron Suwerena w sieci. ` +
    `Odpowiadasz krótko, konkretnie, w stylu militarno-cyberpunkowym. ` +
    `Zapewniasz bezpieczeństwo E2E i analizujesz przesłane dane pod kątem zagrożeń i śladów EXIF. ` +
    `Mów po polsku.`;

// Limit czasu na zimny start VRAM (Gemma4 przez Ollamę lokalnie)
// VRAM Breathing v2: 300s (5 min) — pełna swoboda alokacji na obciążonej maszynie.
const AI_TIMEOUT_MS = 300_000;

/**
 * GET /api/tost/messages
 * Zwraca historię wiadomości z lokalnego skarbca (odszyfrowaną).
 */
app.get('/api/tost/messages', async (req, res) => {
    try {
        const messages = await TostService.getInstance().getMessages();
        return res.json({ success: true, messages, count: messages.length });
    } catch (err) {
        console.error('[TOST-API] ❌ GET messages:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/tost/send
 * Body: { text?: string, imageBase64?: string, mimeType?: string }
 *
 * 1. Zapisuje wiadomość użytkownika w skarbcu
 * 2. Wysyła do Gemini z instrukcją systemu TeO
 * 3. Zapisuje odpowiedź AI w skarbcu
 * 4. Zwraca obie wiadomości
 */
app.post('/api/tost/send', async (req, res) => {
    const { text = '', imageBase64 = null } = req.body ?? {};

    if (!text.trim() && !imageBase64) {
        return res.status(400).json({ success: false, message: 'Wymagany tekst lub obraz.' });
    }

    try {
        const tost = TostService.getInstance();

        // 1. Zapisz wiadomość użytkownika
        const userMsg = await tost.addMessage('user', text.trim(), imageBase64);

        // 2. Buduj żądanie do lokalnej Ollamy (Gemma4)
        const promptText = text.trim() || 'Analizuj ten obraz pod kątem zagrożeń i śladów EXIF.';

        const ollamaBody = {
            model:   DEFAULT_LLM,
            system: TOST_SYSTEM_INSTRUCTION,
            prompt: promptText,
            stream: false,
        };

        // 3. Obsługa multimodalna — surowe base64 bez prefiksu data URL
        if (imageBase64) {
            const rawB64 = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
            ollamaBody.images = [rawB64];
        }

        // 4. Wyślij z limitem 120s (zimny start VRAM)
        const controller = new AbortController();
        const timeoutId  = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);

        let aiText = '[BŁĄD TRANSMISJI] Agent TeO nie odpowiada. Spróbuj ponownie.';

        try {
            const ollamaRes = await fetch(`${OLLAMA_BASE}/api/generate`, {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify(ollamaBody),
                signal:  controller.signal,
            });
            clearTimeout(timeoutId);

            if (ollamaRes.ok) {
                const ollamaData = await ollamaRes.json();
                aiText = ollamaData.response?.trim() || aiText;
                console.log(`[TOST-API] ✅ Gemma4 odpowiedziała (${aiText.length} znaków)`);
            } else {
                const errBody = await ollamaRes.text();
                console.error(`[TOST-API] Ollama HTTP ${ollamaRes.status}:`, errBody.substring(0, 200));
                aiText = `[TRANSMISJA ZAKŁÓCONA] Ollama HTTP ${ollamaRes.status}. Sprawdź czy Gemma4 jest załadowana (ollama list).`;
            }
        } catch (fetchErr) {
            clearTimeout(timeoutId);
            if (fetchErr.name === 'AbortError') {
                aiText = '[TIMEOUT 120s] Gemma4 nie odpowiedziała w limicie czasu. Sprawdź VRAM i spróbuj ponownie.';
            } else {
                aiText = `[OLLAMA OFFLINE] Nie można połączyć z lokalnym silnikiem: ${fetchErr.message}`;
            }
            console.error('[TOST-API] Ollama fetch error:', fetchErr.message);
        }

        // 5. Zapisz odpowiedź AI
        const aiMsg = await tost.addMessage('model', aiText, null);

        return res.json({ success: true, userMessage: userMsg, aiMessage: aiMsg });

    } catch (err) {
        console.error('[TOST-API] ❌ POST send:', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * DELETE /api/tost/messages
 * Czyści historię wiadomości ze skarbca.
 */
app.delete('/api/tost/messages', async (req, res) => {
    try {
        const result = await TostService.getInstance().clearMessages();
        return res.json({ success: true, ...result });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ══════════════════════════════════════════════════════════════════
//  PRALKA — Data Laundering & Scrubbing Service
// ══════════════════════════════════════════════════════════════════

/**
 * POST /api/laundry/sanitize
 * Body: { imageBase64?: string, text?: string }
 * Pierze obraz z EXIF/ICC/XMP i/lub tekst ze znaków zero-width.
 */
app.post('/api/laundry/sanitize', (req, res) => {
    const { imageBase64 = null, text = null } = req.body ?? {};

    if (!imageBase64 && text === null) {
        return res.status(400).json({ success: false, message: 'Brak danych do prania (imageBase64 lub text).' });
    }

    try {
        const laundry = LaundryService.getInstance();
        const result  = {};

        if (imageBase64) {
            const { cleanBase64, report } = laundry.sanitizeImage(imageBase64);
            result.cleanBase64 = cleanBase64;
            result.report      = report;
        }
        if (text !== null) {
            const { cleanText, removedChars } = laundry.sanitizeText(text);
            result.cleanText    = cleanText;
            result.removedChars = removedChars;
        }

        return res.json({ success: true, ...result });
    } catch (err) {
        console.error('[PRALKA-API] ❌', err.message);
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ══════════════════════════════════════════════════════════════════
//  TOST P2P RELAY — Szmaragdowy Tunel (SSE Bridge)
//  Architektura: token → Set<SSE res> (RAM only, zero persistence)
// ══════════════════════════════════════════════════════════════════

const p2pSessions = new Map(); // Map<token, { clients: Set<res>, createdAt: number }>

// TTL 4h — sprzątaj wygasłe sesje co godzinę
setInterval(() => {
    const now = Date.now();
    for (const [token, session] of p2pSessions) {
        if (now - session.createdAt > 4 * 60 * 60 * 1000) {
            session.clients.forEach(c => { try { c.end(); } catch { /* zamknięty */ } });
            p2pSessions.delete(token);
            console.log(`[TOST-P2P] 🧹 Token ${token} wygasł — sesja usunięta.`);
        }
    }
}, 60 * 60 * 1000);

/**
 * POST /api/tost/p2p/init — generuj unikalny token sesji P2P
 */
app.post('/api/tost/p2p/init', (req, res) => {
    const raw   = crypto.randomBytes(6).toString('hex');
    const token = `${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}`.toUpperCase();
    p2pSessions.set(token, { clients: new Set(), createdAt: Date.now() });
    console.log(`[TOST-P2P] 🔑 Nowy token sesji: ${token}`);
    return res.json({ success: true, token });
});

/**
 * GET /api/tost/p2p/stream/:token — SSE strumień (Szmaragdowy Tunel)
 * Każdy klient co łączy się tym tokenem wchodzi do tej samej sesji.
 */
app.get('/api/tost/p2p/stream/:token', (req, res) => {
    const { token } = req.params;

    // Auto-utwórz sesję (peer dołącza przez token generatora)
    if (!p2pSessions.has(token)) {
        p2pSessions.set(token, { clients: new Set(), createdAt: Date.now() });
    }
    const session = p2pSessions.get(token);

    res.setHeader('Content-Type',                'text/event-stream');
    res.setHeader('Cache-Control',               'no-cache');
    res.setHeader('Connection',                  'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', '*');
    if (res.flushHeaders) res.flushHeaders();

    session.clients.add(res);
    const peerCount = session.clients.size;
    console.log(`[TOST-P2P] 🔌 Nowy klient (${token}) · peerów: ${peerCount}`);

    // Powiadom wszystkich o nowym rdeniu
    session.clients.forEach(client => {
        try { client.write(`data: ${JSON.stringify({ type: 'peer_joined', peerCount })}\n\n`); } catch { /* skip */ }
    });

    // Heartbeat co 30s (podtrzymaj HTTP/1.1 keep-alive)
    const heartbeat = setInterval(() => {
        try { res.write('data: {"type":"ping"}\n\n'); } catch { clearInterval(heartbeat); }
    }, 30_000);

    req.on('close', () => {
        clearInterval(heartbeat);
        session.clients.delete(res);
        const remaining = session.clients.size;
        console.log(`[TOST-P2P] 🔌 Klient odłączył się (${token}) · pozostało: ${remaining}`);
        session.clients.forEach(client => {
            try { client.write(`data: ${JSON.stringify({ type: 'peer_left', peerCount: remaining })}\n\n`); } catch { /* skip */ }
        });
    });
});

/**
 * POST /api/tost/p2p/message/:token — przekaż wiadomość do wszystkich w sesji
 * RAM only — nie dotyka TostService ani vault.
 */
app.post('/api/tost/p2p/message/:token', (req, res) => {
    const { token } = req.params;
    const session   = p2pSessions.get(token);
    if (!session) return res.status(404).json({ success: false, error: 'Token nieważny lub wygasł.' });

    const { text, imageBase64, timestamp, senderId } = req.body ?? {};
    const message = {
        type:        'message',
        id:          `p2p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
        text:        text || '',
        imageBase64: imageBase64 || null,
        timestamp:   timestamp || new Date().toISOString(),
        senderId:    senderId || 'unknown',
        owner:       'remote',
    };

    // Broadcast do WSZYSTKICH (frontend filtruje własne wiadomości przez senderId)
    session.clients.forEach(client => {
        try { client.write(`data: ${JSON.stringify(message)}\n\n`); } catch { /* skip */ }
    });

    console.log(`[TOST-P2P] 📡 Wiadomość (${token}) · klientów: ${session.clients.size}`);
    return res.json({ success: true, id: message.id });
});

// ══════════════════════════════════════════════════════════════════════════════
//  🏛️ RADA DEKOMPOZYCJI — wieloagentowy potok operacyjny 0.00G
//  POST /api/agent/rada-decompose
//
//  Sekwencja:
//    1. W.I.D.O.K./Katedra wysyła temat
//    2. Gemma4 (Rada) dekomponuje na 2-4 pod-zadania z przydziałem agentów
//    3. Pod-zadania trafiają do kolejki MechanicService (sesja izolowana)
//    4. Główny wątek rozmowy pozostaje wolny (Session Isolation)
// ══════════════════════════════════════════════════════════════════════════════
// ── TURBOVEC SEARCH ──────────────────────────────────────────────────────────
app.get('/api/turbovec/search', async (req, res) => {
    const { q = '', k = '5' } = req.query;
    try {
        const results = await TurbovecService.getInstance().search(String(q), parseInt(k) || 5);
        return res.json({ success: true, results, status: TurbovecService.getInstance().getStatus() });
    } catch (e) {
        return res.status(500).json({ success: false, error: e.message });
    }
});

app.post('/api/turbovec/reindex', async (req, res) => {
    try {
        const result = await TurbovecService.getInstance().reindex();
        return res.json({ success: true, ...result });
    } catch (e) {
        return res.status(500).json({ success: false, error: e.message });
    }
});

app.post('/api/agent/rada-decompose', async (req, res) => {
    const {
        topic,
        context    = '',
        sessionId  = crypto.randomBytes(4).toString('hex'),
        temperature = 0.67,  // Stopień Rozwielmożnienia (znormalizowany 1-9 → /9)
    } = req.body;
    if (!topic) return res.status(400).json({ error: 'Brak topic' });
    // Clamp temperature do bezpiecznego zakresu Ollamy
    const temp = Math.max(0.05, Math.min(2.0, Number(temperature) || 0.67));

    console.log(`[Rada] 🏛️ Dekompozycja sesji ${sessionId}: "${topic.substring(0, 60)}..."`);

    const systemPrompt =
        'Jesteś RADĄ KATEDRY OTAKOS — centrum decyzyjnym systemu OtakOS. ' +
        'Twoje zadanie: zdekompozuj poniższe zadanie na 2-4 pod-zadania i przydziel je do agentów. ' +
        'Dostępni agenci: MECHANIK (naprawa kodu/błędów), IMPRESARIO (dystrybucja/media), ' +
        'TOST (bezpieczeństwo/szyfrowanie), KLAUDIUSZ (implementacja kodu/feature). ' +
        'Odpowiedz WYŁĄCZNIE w formacie JSON (bez markdown, bez wyjaśnień, bez niczego poza JSON): ' +
        '{"tasks":[{"id":"t1","title":"...","description":"...","agent":"mechanik|impresario|tost|klaudiusz","priority":"HIGH|CRITICAL|LOW"}]}';

    try {
        console.log(`[Rada] 🌡️ Temperatura Rozwielmożnienia: ${temp.toFixed(3)} (raw: ${temperature})`);
        const ollamaResp = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model:   DEFAULT_LLM,
                system:  systemPrompt,
                prompt:  `Temat: ${topic}\nKontekst: ${context || 'brak'}`,
                stream:  false,
                options: { temperature: temp },
            }),
        });

        if (!ollamaResp.ok) throw new Error(`Ollama HTTP ${ollamaResp.status}`);
        const ollamaData = await ollamaResp.json();

        let tasks = [];
        try {
            const jsonMatch = (ollamaData.response || '').match(/\{[\s\S]*\}/);
            const parsed = JSON.parse(jsonMatch ? jsonMatch[0] : ollamaData.response);
            tasks = (parsed.tasks || []).map((t, i) => ({
                id:          t.id || `rad-${sessionId}-${i}`,
                title:       t.title       || 'Pod-zadanie Rady',
                description: t.description || topic.substring(0, 120),
                agent:       (t.agent || 'klaudiusz').toLowerCase(),
                priority:    t.priority    || 'HIGH',
                sessionId,
                status:      'PENDING',
                createdAt:   new Date().toISOString(),
            }));
        } catch {
            // Fallback: Rada nie zwróciła JSON → jedno zadanie ogólne
            tasks = [{
                id:          `rad-${sessionId}-0`,
                title:       topic.substring(0, 80),
                description: context || topic,
                agent:       'klaudiusz',
                priority:    'HIGH',
                sessionId,
                status:      'PENDING',
                createdAt:   new Date().toISOString(),
            }];
        }

        // ── TurbovecService: wzbogać opisy pod-zadań o kontekst plików źródłowych ──
        const turbovec = TurbovecService.getInstance();
        for (const task of tasks) {
            if (task.agent === 'mechanik' || task.agent === 'impresario' || task.agent === 'klaudiusz') {
                try {
                    task.description = await turbovec.enrichTaskDescription(task);
                } catch (tvErr) {
                    console.warn(`[Rada·Turbovec] ⚠️ Enrichment skipped (${task.id}): ${tvErr.message}`);
                }
            }
        }

        // ── Enqueue do MechanicService (Session Isolation: kolejka działa w tle) ──
        // ⚠️ NAPRAWIONE 2026-08-03. Dwa błędy siedziały jeden w drugim:
        //   1. Wywołanie NIE przekazywało `id`, a `enqueueTask` wymaga `id` ORAZ `title`.
        //      Każde wstrzyknięcie odpadało z „brak id lub title" — kolejka zostawała pusta.
        //   2. `enqueueTask` przy odrzuceniu ZWRACA null (nie rzuca), więc `catch` nigdy
        //      się nie odpalał, a kod bezwarunkowo meldował „N pod-zadań wstrzyknięto".
        //      W logach Suwerena: trzy ostrzeżenia z rzędu i zaraz pod nimi zielony ptaszek
        //      „3 pod-zadań wstrzyknięto" przy kolejce 0 PENDING. Melduje się to, co się
        //      wydarzyło, nie to, co miało się wydarzyć.
        // `id` jest przedrostkowane sesją, bo model potrafi zwrócić „t1" dla każdej sesji,
        // a deduplikacja po id po cichu zjadłaby kolejne zadania.
        const przyjete = [];
        const odrzucone = [];
        for (const task of tasks) {
            const idKolejki = `rada-${sessionId}-${task.id}`;
            try {
                const wynik = await MechanicService.getInstance().enqueueTask({
                    id:          idKolejki,
                    title:       `[RADA·${task.agent.toUpperCase()}] ${task.title}`,
                    description: task.description,
                    priority:    task.priority,
                    targetFiles: [],
                    sessionId,
                });
                if (wynik) przyjete.push(idKolejki);
                else odrzucone.push({ id: idKolejki, powod: 'odrzucone przez kolejkę (duplikat lub braki)' });
            } catch (enqErr) {
                odrzucone.push({ id: idKolejki, powod: enqErr.message });
                console.warn(`[Rada] ⚠️ Enqueue failed for ${idKolejki}: ${enqErr.message}`);
            }
        }

        if (odrzucone.length) {
            console.warn(`[Rada] ⚠️ Sesja ${sessionId}: przyjęto ${przyjete.length}/${tasks.length}. ` +
                         `Odrzucone: ${odrzucone.map(o => `${o.id} (${o.powod})`).join(', ')}`);
        } else {
            console.log(`[Rada] ✅ Sesja ${sessionId}: ${przyjete.length}/${tasks.length} pod-zadań w kolejce.`);
        }
        return res.json({
            success: true, sessionId, tasks,
            totalTasks: tasks.length,
            // Liczby mówią prawdę — konsument API nie musi wierzyć na słowo.
            wKolejce: przyjete.length,
            odrzucone,
        });

    } catch (e) {
        console.error(`[Rada] ❌ Błąd dekompozycji: ${e.message}`);
        return res.status(500).json({ success: false, error: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🎬 KOLEJKA KREATYWNA — Tablica Produkcji (drugi tor, obok Mechanika)
//
//  DLACZEGO OSOBNO OD RADY WYŻEJ: tamta kolejka karmi Mechanika, który generuje
//  ŁATKI DO KODU. Zadanie „narysuj kartę postaci" trafiające do Mechanika kończy
//  się śmieciowym patchem — zmierzone 2026-08-03 na żywej kolejce.
//  Ten tor ma inny cykl życia: prompt → zewnętrzne narzędzie → zwrot → następny etap.
//
//  Most NIE wywołuje Gems/AI Studio/Flow — nie ma do nich API i nie udaje, że ma.
//  Robi to, co da się zrobić uczciwie: buduje prompt, pilnuje spójności (biblia
//  wraca do każdego kolejnego promptu) i pamięta stan. Rundę robi Suweren.
// ══════════════════════════════════════════════════════════════════════════════

/** GET /api/produkcja/tablica?projekt= — karty + rozkład po etapach + biblia. */
app.get('/api/produkcja/tablica', async (req, res) => {
    try {
        const projekt = String(req.query.projekt || '');
        const [kadry, statystykaTablicy, listaProjektow] = await Promise.all([
            produkcjaLista(ANTIGRAVITY_DIR, projekt),
            produkcjaStatystyka(ANTIGRAVITY_DIR, projekt),
            produkcjaProjekty(ANTIGRAVITY_DIR),
        ]);
        const bibliaProjektu = projekt ? await produkcjaBiblia(ANTIGRAVITY_DIR, projekt) : null;
        return res.json({
            success: true,
            etapy: PRODUKCJA_ETAPY,
            projekty: listaProjektow,
            kadry,
            statystyka: statystykaTablicy,
            biblia: bibliaProjektu,
        });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/** POST /api/produkcja/kadr — ręczne dołożenie karty. */
app.post('/api/produkcja/kadr', async (req, res) => {
    try {
        const kadr = await produkcjaDodaj(ANTIGRAVITY_DIR, req.body ?? {});
        console.log(`[Produkcja] 🎬 Nowy kadr [${kadr.etap}] „${kadr.tytul}" (${kadr.projekt})`);
        const oddech = await oddechZaPrace('kadr.dodany', `kadr:${kadr.id}`);
        return res.json({ success: true, kadr, oddech });
    } catch (err) {
        // 400, nie 500 — to walidacja treści, nie awaria serwera.
        return res.status(400).json({ success: false, message: err.message });
    }
});

/** PATCH /api/produkcja/kadr/:id — zmiana etapu, zwrotu, notatek. */
app.patch('/api/produkcja/kadr/:id', async (req, res) => {
    try {
        const kadr = await produkcjaZmien(ANTIGRAVITY_DIR, req.params.id, req.body ?? {});
        // Klucz niesie DOCELOWY etap, więc każde przejście płaci raz, ale powrót
        // i ponowne przesunięcie na ten sam etap już nie — inaczej wystarczyłoby
        // wozić kartę tam i z powrotem.
        const oddech = req.body?.etap
            ? await oddechZaPrace('kadr.etap', `etap:${kadr.id}:${kadr.etap}`)
            : null;
        return res.json({ success: true, kadr, oddech });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

/** DELETE /api/produkcja/kadr/:id */
app.delete('/api/produkcja/kadr/:id', async (req, res) => {
    try {
        const kadr = await produkcjaUsun(ANTIGRAVITY_DIR, req.params.id);
        return res.json({ success: true, kadr });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

/**
 * GET /api/produkcja/kadr/:id/prompt
 * Gotowy do wklejenia prompt dla etapu, na którym stoi karta — z doklejoną biblią.
 * Odpowiedź niesie `ostrzezenie`, gdy biblii nie ma: lepiej, żeby Suweren
 * wiedział, że kadr idzie bez kotwicy, niż żeby odkrył to w ujęciu czterdziestym.
 */
app.get('/api/produkcja/kadr/:id/prompt', async (req, res) => {
    try {
        const wszystkie = await produkcjaLista(ANTIGRAVITY_DIR);
        const kadr = wszystkie.find(k => k.id === req.params.id);
        if (!kadr) return res.status(404).json({ success: false, message: `Kadr "${req.params.id}" nie istnieje.` });

        const bibliaProjektu = await produkcjaBiblia(ANTIGRAVITY_DIR, kadr.projekt);
        // Prompt płaci raz na kadr+etap: podgląd tego samego promptu w kółko
        // to nie jest nowa praca.
        const oddech = await oddechZaPrace('prompt.zbudowany', `prompt:${kadr.id}:${kadr.etap}`);
        return res.json({ success: true, kadr, oddech, ...produkcjaPrompt(kadr, bibliaProjektu) });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/produkcja/rozloz  { zlecenie, projekt, temperatura? }
 * Rada Kreatywna rozkłada zlecenie na karty produkcyjne.
 *
 * Melduje `dodane` i `odrzucone` OSOBNO — dokładnie z tego powodu, dla którego
 * naprawialiśmy Radę od kodu: tamta pisała „3 wstrzyknięto" przy kolejce 0.
 */
/**
 * Wspólny rozkład Rady Kreatywnej — używa go i panel Tablicy, i Reżyser.
 * Jedna implementacja, bo dwie rozjechałyby się przy pierwszej poprawce promptu.
 * Rzuca `BladRozkladu` z surową odpowiedzią, gdy model nie utrzyma formatu.
 */
class BladRozkladu extends Error {
    constructor(message, surowaOdpowiedz) { super(message); this.surowaOdpowiedz = surowaOdpowiedz; }
}

async function radaKreatywnaRozloz(zlecenie, projekt, temperatura = 0.7, sesjaRady = null) {
    const temp = Math.max(0.05, Math.min(2.0, Number(temperatura) || 0.7));
    const nazwaProjektu = String(projekt || '').trim() || 'bez nazwy';

    // Kontekst dla modelu: co już stoi na tablicy tego projektu. Bez tego Rada
    // przy każdym wywołaniu proponuje od nowa „stwórz Style Sheet".
    const juzNaTablicy = await produkcjaLista(ANTIGRAVITY_DIR, nazwaProjektu);
    const kontekst = juzNaTablicy.length
        ? juzNaTablicy.slice(0, 12).map(k => `- [${k.etap}] ${k.tytul}`).join('\n')
        : 'tablica pusta — projekt startuje od zera';

    const odp = await fetch(`${OLLAMA_BASE}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            model: DEFAULT_LLM,
            system: promptSystemowyRozkladu(),
            prompt: `Projekt: ${nazwaProjektu}\nZlecenie: ${zlecenie}\n\nJuż na tablicy (NIE powtarzaj tego):\n${kontekst}`,
            stream: false,
            options: { temperature: temp },
        }),
    });
    if (!odp.ok) throw new Error(`Ollama HTTP ${odp.status}`);
    const dane = await odp.json();

    let propozycje;
    try {
        propozycje = odczytajRozklad(dane.response);
    } catch (parseErr) {
        // Uczciwie: mówimy, że model nie dał się odczytać, i pokazujemy początek
        // odpowiedzi. Cichy fallback na jedną kartę ukrywałby zepsuty rdzeń.
        console.warn(`[Produkcja] ⚠️ Rozkład nieczytelny (${DEFAULT_LLM}): ${parseErr.message}`);
        throw new BladRozkladu(
            `Rada Kreatywna nie zwróciła czytelnego rozkładu: ${parseErr.message}`,
            String(dane.response || '').slice(0, 400),
        );
    }

    const dodane = [];
    const odrzucone = [];
    for (const p of propozycje) {
        try {
            dodane.push(await produkcjaDodaj(ANTIGRAVITY_DIR, {
                ...p, projekt: nazwaProjektu, zrodlo: 'rada', sesjaRady: sesjaRady || null,
            }));
        } catch (e) {
            odrzucone.push({ tytul: p.tytul || '(bez tytułu)', powod: e.message });
        }
    }

    if (odrzucone.length) {
        console.warn(`[Produkcja] ⚠️ Dodano ${dodane.length}/${propozycje.length}. ` +
                     `Odrzucone: ${odrzucone.map(o => `${o.tytul} (${o.powod})`).join(', ')}`);
    } else {
        console.log(`[Produkcja] ✅ Rada Kreatywna: ${dodane.length} kart na tablicy „${nazwaProjektu}".`);
    }

    return { model: DEFAULT_LLM, zaproponowano: propozycje.length, dodane, odrzucone };
}

/**
 * POST /api/produkcja/uzupelnij  { projekt, etap, pole, kadrId?, wskazowka?, model? }
 *
 * Model pisze treść JEDNEGO pola karty, z instrukcją właściwą dla etapu
 * (biblia ≠ prompt do obrazu ≠ lista montażowa) i z kotwicą spójności:
 * biblia projektu + kanon Reżysera.
 *
 * ⚠️ NIE ZAPISUJE KARTY. Oddaje tekst — zapis zostaje decyzją Suwerena.
 * Automatyczne wpisanie odpowiedzi modelu do tablicy sprawiłoby, że po kilku
 * kliknięciach nie wiadomo, co napisał człowiek, a co maszyna.
 */
app.post('/api/produkcja/uzupelnij', async (req, res) => {
    const { projekt = '', etap = 'BIBLIA', pole = 'opis', kadrId = null, wskazowka = '', model } = req.body ?? {};
    try {
        const [bibliaProjektu, pamiecProjektu, kadry] = await Promise.all([
            projekt ? produkcjaBiblia(ANTIGRAVITY_DIR, projekt).catch(() => null) : null,
            projekt ? rezyserPamiec(ANTIGRAVITY_DIR, projekt).catch(() => null) : null,
            kadrId ? produkcjaLista(ANTIGRAVITY_DIR, projekt).catch(() => []) : [],
        ]);
        const kadr = kadrId ? (kadry.find((k) => k.id === kadrId) ?? null) : null;
        if (kadrId && !kadr) {
            return res.status(404).json({ success: false, message: `Kadr "${kadrId}" nie istnieje w projekcie „${projekt}".` });
        }

        const { system, prompt } = promptUzupelnienia({
            etap, pole, projekt,
            biblia: bibliaProjektu?.tekst ?? '',
            fakty: pamiecProjektu?.fakty ?? [],
            kadr, wskazowka,
        });

        const silnik = model || process.env.OTAKOS_MODEL || DEFAULT_LLM;
        const ctrl = new AbortController();
        const stoper = setTimeout(() => ctrl.abort(), 300000);
        let dane;
        try {
            const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
                body: JSON.stringify({ model: silnik, system, prompt, stream: false }),
            });
            if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
            dane = await r.json();
        } finally {
            clearTimeout(stoper);
        }

        const tekst = oczyscPoleAI(dane.response, pole);
        if (!tekst) return res.status(502).json({ success: false, message: 'Model nie oddał treści.' });

        console.log(`[Produkcja] ✨ ${silnik} wypełnił pole „${pole}" [${String(etap).toUpperCase()}] (${projekt || 'bez nazwy'}).`);
        return res.json({
            success: true, tekst, pole, model: silnik,
            // Uczciwie mówimy, czy praca miała kotwicę — bez biblii ujęcia się rozjadą.
            kotwica: {
                biblia: !bibliaProjektu?.pusta,
                faktow: pamiecProjektu?.fakty?.length ?? 0,
                uwaga: bibliaProjektu?.uwaga ?? null,
            },
        });
    } catch (e) {
        const powod = e.name === 'AbortError' ? 'Model nie zdążył (300 s).' : e.message;
        return res.status(500).json({ success: false, message: powod });
    }
});

/**
 * POST /api/produkcja/do-odcinka  { projekt, kadrId, odcinekId }
 *
 * „Gdzie zapisać" z prośby Suwerena. Karta etapu GOTOWE ląduje jako plik
 * w katalogu odcinka — tam, gdzie leży `odcinek.md`, a nie w osobnym worku.
 *
 * ⚠️ Wymaga, żeby odcinek MIAŁ katalog. Zapis „gdzieś obok" byłby gorszy niż
 * odmowa: materiał zniknąłby z pola widzenia przy pierwszym porządkowaniu.
 */
app.post('/api/produkcja/do-odcinka', async (req, res) => {
    const { projekt = '', kadrId = '', odcinekId = '' } = req.body ?? {};
    try {
        const [kadry, p] = await Promise.all([
            produkcjaLista(ANTIGRAVITY_DIR, projekt),
            rezyserPamiec(ANTIGRAVITY_DIR, projekt),
        ]);
        const kadr = kadry.find((k) => k.id === kadrId);
        if (!kadr) return res.status(404).json({ success: false, message: `Kadr "${kadrId}" nie istnieje.` });
        const odcinek = (p.odcinki ?? []).find((o) => o.id === odcinekId);
        if (!odcinek) return res.status(404).json({ success: false, message: `Odcinek "${odcinekId}" nie istnieje w projekcie „${projekt}".` });

        const katalog = await katalogOdcinka(ANTIGRAVITY_DIR, projekt, odcinek, true);
        const nazwa = `kadr-${String(kadr.etapZrodlowy || kadr.etap).toLowerCase()}-${kadr.id}.md`;
        const tresc = [
            `# ${kadr.tytul}`, '',
            `**Projekt:** ${projekt}  `,
            `**Odcinek:** #${odcinek.numer} ${odcinek.tytul}  `,
            `**Etap:** ${kadr.etap} (powstał na ${kadr.etapZrodlowy || kadr.etap})  `,
            `**Zapisany:** ${new Date().toLocaleString('pl-PL')}`,
            '', '## Opis', '', kadr.opis || '_(brak)_', '',
            '## Co wróciło z narzędzia', '', kadr.zwrot || '_(nic — karta nie ma jeszcze materiału)_', '',
            ...(kadr.notatki ? ['## Notatki', '', kadr.notatki, ''] : []),
        ].join('\n');

        const plik = path.join(katalog, nazwa);
        await fs.writeFile(plik, tresc, 'utf8');
        console.log(`[Produkcja] 📦 Kadr „${kadr.tytul}" → ${plik}`);
        return res.json({ success: true, plik, bajtow: Buffer.byteLength(tresc, 'utf8'), odcinek: { id: odcinek.id, numer: odcinek.numer, tytul: odcinek.tytul } });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.post('/api/produkcja/rozloz', async (req, res) => {
    const { zlecenie, projekt = '', temperatura = 0.7, sesjaRady = '' } = req.body ?? {};
    if (!zlecenie || String(zlecenie).trim().length < 5) {
        return res.status(400).json({ success: false, message: 'Brak zlecenia (min. 5 znaków).' });
    }
    console.log(`[Produkcja] 🏛️ Rada Kreatywna rozkłada: "${String(zlecenie).slice(0, 60)}..." (${projekt || 'bez nazwy'})`);
    try {
        return res.json({ success: true, ...(await radaKreatywnaRozloz(zlecenie, projekt, temperatura, sesjaRady)) });
    } catch (e) {
        if (e instanceof BladRozkladu) {
            return res.status(502).json({ success: false, message: e.message, model: DEFAULT_LLM, surowaOdpowiedz: e.surowaOdpowiedz });
        }
        console.error(`[Produkcja] ❌ Rozkład: ${e.message}`);
        return res.status(500).json({ success: false, message: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🎬 REŻYSER — Sfera z rękami, pamięcią i obsadą
//
//  Rozmówca opowiadał. Reżyser ROBI: jedno wywołanie modelu zwraca i mowę,
//  i ewentualną akcję, którą Most wykonuje od razu. Dwa wywołania (najpierw
//  odpowiedz, potem sklasyfikuj) trwałyby na tej maszynie ponad 40 s —
//  rozmowa przestałaby być rozmową.
//
//  Akcje wykonuje SERWER, nie przeglądarka: model może zaproponować tylko to,
//  co jest na białej liście, i nic poza nią nie zadziała.
// ══════════════════════════════════════════════════════════════════════════════

// ── Obsada ────────────────────────────────────────────────────────────────────
app.get('/api/rezyser/postacie', async (req, res) => {
    try {
        return res.json({ success: true, postacie: await listaPostaci(ANTIGRAVITY_DIR) });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/** POST — `surowe` (wgranie: JSON / markdown / goły prompt) albo gotowe pola. */
app.post('/api/rezyser/postacie', async (req, res) => {
    try {
        const postac = await dodajPostac(ANTIGRAVITY_DIR, req.body ?? {});
        console.log(`[Reżyser] 🎭 Postać „${postac.imie}" (${postac.rola}, ${postac.pochodzenie}, format: ${postac.format}).`);
        return res.json({ success: true, postac });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

app.delete('/api/rezyser/postacie/:id', async (req, res) => {
    try {
        return res.json({ success: true, postac: await usunPostac(ANTIGRAVITY_DIR, req.params.id) });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

// ── Pamięć serialu ────────────────────────────────────────────────────────────
app.get('/api/rezyser/pamiec', async (req, res) => {
    try {
        const serial = String(req.query.serial || '');
        return res.json({
            success: true,
            pamiec: await rezyserPamiec(ANTIGRAVITY_DIR, serial),
            seriale: await listaSeriali(ANTIGRAVITY_DIR),
        });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/rezyser/pamiec/fakt', async (req, res) => {
    try {
        const { serial = '', tresc = '', zrodlo = 'suweren' } = req.body ?? {};
        const wynik = await dodajFakt(ANTIGRAVITY_DIR, serial, tresc, zrodlo);
        // Duplikat faktu NIE jest nowa praca — placi tylko swiezy wpis do kanonu.
        const oddech = wynik.duplikat ? null : await oddechZaPrace('fakt.kanon', `fakt:${wynik.fakt.id}`);
        return res.json({ success: true, ...wynik, oddech });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

app.delete('/api/rezyser/pamiec/fakt/:id', async (req, res) => {
    try {
        const fakt = await usunFakt(ANTIGRAVITY_DIR, String(req.query.serial || ''), req.params.id);
        return res.json({ success: true, fakt });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

/**
 * Zmaterializuj odcinek na dysku — z migawką kanonu i listą kadrów projektu.
 * Zwraca `null`, gdy zapis się nie udał: odcinek w pamięci ma wtedy zostać,
 * ale front NIE MOŻE dostać ścieżki do pliku, którego nie ma.
 */
async function zmaterializujOdcinek(serial, odcinek) {
    try {
        const [p, kadry] = await Promise.all([
            rezyserPamiec(ANTIGRAVITY_DIR, serial),
            produkcjaLista(ANTIGRAVITY_DIR, serial).catch(() => []),
        ]);
        return await zapiszOdcinek(ANTIGRAVITY_DIR, serial, odcinek, { fakty: p.fakty ?? [], kadry });
    } catch (err) {
        console.warn(`[Reżyser] ⚠️ Odcinek #${odcinek.numer} nie zapisał się na dysk: ${err.message}`);
        return null;
    }
}

app.post('/api/rezyser/pamiec/odcinek', async (req, res) => {
    try {
        const { serial = '', ...dane } = req.body ?? {};
        const odcinek = await dodajOdcinek(ANTIGRAVITY_DIR, serial, dane);

        // Materializujemy TYLKO to, co domknięte. Pomysł wpisany „w plan" nie
        // jest odcinkiem i katalog na dysku sugerowałby, że coś już powstało.
        const zapis = odcinek.status === 'zrealizowany'
            ? await zmaterializujOdcinek(serial, odcinek)
            : null;

        console.log(`[Reżyser] 📼 Odcinek #${odcinek.numer} „${odcinek.tytul}" → ${odcinek.status} (${serial || 'bez nazwy'})${zapis ? ` · ${zapis.plik}` : ''}.`);

        // ⚠️ ODDECH PŁACI ZA DOMKNIĘCIE, NIE ZA POMYSŁ. Dopisanie pozycji „w planie"
        // to jedno kliknięcie — gdyby liczyło się jak odcinek, GRV dałoby się
        // drukować listą tytułów.
        const oddech = odcinek.status === 'zrealizowany'
            ? await oddechZaPrace('odcinek.domkniety', `odc:${odcinek.id}`,
                { nazwa: `Odcinek #${odcinek.numer}: ${odcinek.tytul}`, sciezka: zapis?.plik ?? null })
            : null;

        return res.json({ success: true, odcinek, oddech, zapis });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/rezyser/pamiec/odcinki — PACZKA odcinków naraz.
 * „Podając opis 2. odcinka można od razu zapisać więcej."
 * Odcinki niepoprawne wracają z powodem; poprawne wchodzą.
 */
app.post('/api/rezyser/pamiec/odcinki', async (req, res) => {
    try {
        const { serial = '', odcinki = [] } = req.body ?? {};
        const w = await dodajOdcinki(ANTIGRAVITY_DIR, serial, odcinki);
        console.log(`[Reżyser] 📚 Paczka: ${w.dodane.length} odcinków dodanych, ${w.odrzucone.length} odrzuconych (${serial || 'bez nazwy'}).`);
        return res.json({ success: true, ...w });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/rezyser/pamiec/odcinek/:id/realizuj { serial }
 *
 * Reżyser z TeOgochi biorą odcinek i rozkładają go na Tablicę Produkcji:
 * biblia (gdy jej nie ma) → kadry na cały czas trwania → odcinek w „produkcji".
 *
 * ⚠️ COMFYUI BUDZI SIĘ TUTAJ, nie przy pierwszym kliknięciu „generuj".
 * Suweren: „w momencie przejścia z 1 do 2 punktu niech się włącza ComfyUI".
 * Budzenie leci W TLE — model pisze kadry przez tę samą minutę, w której
 * ComfyUI się ładuje, więc czekanie dzieje się raz, nie dwa razy.
 */
/**
 * GET /api/rezyser/pamiec/kadry?serial=
 *
 * Ile kadrów ma każdy odcinek i ile z nich CZEKA jeszcze na render.
 *
 * PO CO. Suweren: „w tablicy dodaj do kolumny w produkcji info, ile dany
 * odcinek ma kadrów — to wtedy mogę ustawić w kolejce i pójdzie cały plan
 * po kolei". Bez tej liczby ustawienie kolejki jest zgadywanem.
 *
 * ⚠️ WIĄZANIE IDZIE PRZEZ `sesjaRady`, nie przez osobne pole. Realizacja
 * odcinka stempluje tym polem każdy kadr, który z niego powstał — 415 z 433
 * kart na tablicy je ma. Kadry dodane ręcznie nie mają go i nie liczą się do
 * żadnego odcinka; to uczciwe, bo nikt nie powiedział, gdzie należą.
 *
 * ⚠️ BIBLIA NIE JEST KADREM. Karta etapu BIBLIA też nosi `sesjaRady`, ale
 * liczona razem z kadrami zawyżałaby kolejkę o jeden nieistniejący render.
 */
app.get('/api/rezyser/pamiec/kadry', async (req, res) => {
    try {
        const serial = String(req.query.serial || '').trim();
        if (!serial) throw new Error('Podaj serial.');
        const sekundNaKadr = Number(req.query.sekundNaKadr) || undefined;

        const [pamiec, kadry] = await Promise.all([
            rezyserPamiec(ANTIGRAVITY_DIR, serial),
            produkcjaLista(ANTIGRAVITY_DIR, serial),
        ]);

        const wynik = {};
        for (const o of pamiec.odcinki ?? []) {
            const moje = kadry.filter((k) => k.sesjaRady === o.id && k.etap !== 'BIBLIA');

            let gotowych = 0;
            for (const k of moje) if (await KolejkaKadrow.maJuzUjecie(k)) gotowych += 1;

            // ⚠️ UCZCIWA ARYTMETYKA DŁUGOŚCI. Suweren: „błędnie wskazuje kadry
            // do minut — 24 kadry są za krótkie". Ujęcie trwa 2,04 s (zmierzone),
            // więc 24 kadry to 49 SEKUND filmu, nie 6 minut. Mowimy ile odcinek
            // MA naprawde i ile mu brakuje do zapowiedzianej dlugosci.
            // Długość ujęcia wybiera człowiek w kolejce kadrów — front przekazuje ją
            // tutaj, żeby arytmetyka odcinka liczyła się według TEGO ustawienia,
            // a nie stałej sprzed wyboru.
            const plan = Realizacja.ileKadrow(o.czasMinut, { juzMa: moje.length, sekundNaKadr });

            wynik[o.id] = {
                razem: moje.length,
                gotowych,
                // Ta liczba idzie wprost do pola „ile na raz" w kolejce kadrów.
                doPoliczenia: moje.length - gotowych,
                etapy: moje.reduce((a, k) => { a[k.etap] = (a[k.etap] ?? 0) + 1; return a; }, {}),

                // Ile filmu te kadry NAPRAWDĘ dają i ile go zapowiedziano.
                minutTeraz: Realizacja.minutZKadrow(moje.length),
                minutPlan: o.czasMinut ?? null,
                potrzebne: plan.potrzebne,
                brakuje: plan.zostalo ?? null,
                przebiegow: plan.przebiegow ?? null,
                sekundNaKadr: plan.sekundNaKadr,
            };
        }

        return res.json({ success: true, serial, odcinki: wynik });
    } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
    }
});

app.post('/api/rezyser/pamiec/odcinek/:id/realizuj', async (req, res) => {
    const { serial = '', model } = req.body ?? {};
    try {
        const p = await rezyserPamiec(ANTIGRAVITY_DIR, serial);
        const odcinek = (p.odcinki ?? []).find((o) => o.id === req.params.id);
        if (!odcinek) return res.status(404).json({ success: false, message: `Odcinek "${req.params.id}" nie istnieje.` });

        // 🎛️ ComfyUI w tle — patrz uwaga wyżej.
        const comfy = zapewnijComfyUI('realizacja odcinka').catch((e) => ({ online: false, message: e.message }));

        const bibliaProjektu = await produkcjaBiblia(ANTIGRAVITY_DIR, serial).catch(() => null);
        const kotwica = [
            bibliaProjektu?.tekst || '',
            (p.fakty ?? []).map((f) => f.tresc).join('\n'),
        ].filter(Boolean).join('\n\n');

        const silnik = model || process.env.OTAKOS_MODEL || DEFAULT_LLM;
        const pisz = async (system, prompt) => {
            const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: silnik, system, prompt, stream: false }),
            });
            if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
            return (await r.json()).response;
        };

        const zrobione = { biblia: null, kadry: [], odrzucone: [] };

        // 1. BIBLIA — tylko gdy projekt jej nie ma. Druga biblia rozjeżdża serial.
        if (bibliaProjektu?.pusta !== false) {
            const { system, prompt } = Realizacja.promptBiblii({ projekt: serial, odcinek, kotwica });
            const tekst = Realizacja.oczysc(await pisz(system, prompt));
            if (tekst) {
                const karta = await produkcjaDodaj(ANTIGRAVITY_DIR, {
                    projekt: serial,
                    tytul: `Biblia — ${serial || 'projekt'}`,
                    opis: `Powstała przy realizacji odcinka #${odcinek.numer} „${odcinek.tytul}".`,
                    // ⚠️ Treść idzie w `zwrot`, bo TYLKO stamtąd `produkcjaBiblia`
                    // czyta kotwicę. Wpisana w `opis` byłaby niewidoczna dla kadrów.
                    zwrot: tekst,
                    etap: 'BIBLIA',
                    zrodlo: 'rada',
                    sesjaRady: odcinek.id,
                });
                zrobione.biblia = { id: karta.id, znakow: tekst.length };
            }
        }

        // 2. KADRY — ile ich ma być, mówi czas trwania odcinka.
        const { ile, zgadywane, policzone } = Realizacja.ileKadrow(odcinek.czasMinut);
        const kotwicaPoBiblii = zrobione.biblia
            ? [kotwica, (await produkcjaBiblia(ANTIGRAVITY_DIR, serial).catch(() => null))?.tekst || ''].filter(Boolean).join('\n\n')
            : kotwica;

        // ⚠️ OBSADA DO PROMPTU PISANIA. Sprawdzone na SOLLET: tylko 38 ze 164
        // kadrów wymieniało jakąkolwiek postać, a Tim i Krys — ani razu. Model
        // nie miał skąd wiedzieć, że ta obsada w ogóle istnieje.
        const spisObsady = (await Assety.lista(ANTIGRAVITY_DIR, serial).catch(() => []))
            .filter((a) => ['aktor', 'scena', 'rekwizyt'].includes(a.typ))
            .map((a) => {
                const rola = a.rola ? ` (${Assety.ROLE[a.rola] ?? a.rola})` : '';
                const wyglad = String(a.notatki ?? '').trim();
                return `· ${a.nazwa}${rola}${wyglad ? ` — ${wyglad.slice(0, 160)}` : ''}`;
            })
            .join('\n');

        const { system, prompt } = Realizacja.promptKadrow({ projekt: serial, odcinek, kotwica: kotwicaPoBiblii, obsada: spisObsady, ile });
        const kadry = Realizacja.odczytajKadry(await pisz(system, prompt), ile);

        for (const k of kadry) {
            try {
                const karta = await produkcjaDodaj(ANTIGRAVITY_DIR, {
                    projekt: serial,
                    tytul: `#${odcinek.numer}.${k.nr} ${k.tytul}`,
                    opis: k.opis,
                    // ⚠️ KWESTIE JADĄ RAZEM Z KADREM. Bez tej linii pisarz rozpisywałby
                    // dialogi, a karta lądowałaby niema — i cała ścieżka dźwiękowa
                    // nie miałaby czego mówić.
                    kwestie: k.kwestie,
                    etap: 'KADR',
                    zrodlo: 'rada',
                    sesjaRady: odcinek.id,
                });
                zrobione.kadry.push({ id: karta.id, tytul: karta.tytul });
            } catch (e) {
                zrobione.odrzucone.push({ tytul: k.tytul, powod: e.message });
            }
        }

        // 3. Odcinek wchodzi w produkcję — ale tylko jeśli COKOLWIEK powstało.
        let odcinekPo = odcinek;
        if (zrobione.kadry.length && odcinek.status === 'plan') {
            odcinekPo = (await zmienOdcinek(ANTIGRAVITY_DIR, serial, odcinek.id, { status: 'produkcja' })).odcinek;
        }

        const stanComfy = await comfy;
        console.log(`[Reżyser] 🎬 Realizacja #${odcinek.numer} „${odcinek.tytul}": ${zrobione.kadry.length} kadrów${zrobione.biblia ? ' + biblia' : ''}.`);

        return res.json({
            success: true,
            odcinek: odcinekPo,
            ...zrobione,
            model: silnik,
            plan: {
                ile, zgadywane,
                // Uczciwie: gdy odcinek jest dłuższy niż sufit, mówimy to wprost.
                przyciete: policzone && policzone > ile
                    ? `Odcinek na ${odcinek.czasMinut} min to ${policzone} kadrów — więcej niż sufit ${Realizacja.MAX_KADROW}. Rozbij go na części albo dorób kadry ręcznie.`
                    : null,
            },
            comfy: stanComfy,
        });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

/** PATCH — przesunięcie odcinka między kolumnami tablicy (plan → produkcja → gotowe). */
app.patch('/api/rezyser/pamiec/odcinek/:id', async (req, res) => {
    try {
        const { serial = '', ...zmiany } = req.body ?? {};
        const { odcinek, poprzedniStatus } = await zmienOdcinek(ANTIGRAVITY_DIR, serial, req.params.id, zmiany);

        // Materializacja dzieje się przy WEJŚCIU w „zrealizowany" — i tylko raz,
        // bo powtórne domknięcie tego samego odcinka nie jest nową pracą.
        const domkniety = odcinek.status === 'zrealizowany' && poprzedniStatus !== 'zrealizowany';
        const zapis = domkniety ? await zmaterializujOdcinek(serial, odcinek) : null;
        const oddech = domkniety
            ? await oddechZaPrace('odcinek.domkniety', `odc:${odcinek.id}`,
                { nazwa: `Odcinek #${odcinek.numer}: ${odcinek.tytul}`, sciezka: zapis?.plik ?? null })
            : null;

        console.log(`[Reżyser] 🎬 Odcinek #${odcinek.numer}: ${poprzedniStatus} → ${odcinek.status}.`);
        return res.json({ success: true, odcinek, poprzedniStatus, zapis, oddech });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

/** Co NAPRAWDĘ leży w katalogu odcinka — lista plików, nie obietnica. */
app.get('/api/rezyser/pamiec/odcinek/:id/materialy', async (req, res) => {
    try {
        const serial = String(req.query.serial || '');
        const p = await rezyserPamiec(ANTIGRAVITY_DIR, serial);
        const odcinek = (p.odcinki ?? []).find((o) => o.id === req.params.id);
        if (!odcinek) return res.status(404).json({ success: false, message: `Odcinek "${req.params.id}" nie istnieje.` });
        return res.json({ success: true, ...(await materialyOdcinka(ANTIGRAVITY_DIR, serial, odcinek)) });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

// ── Katalogi projektów ────────────────────────────────────────────────────────
//  ⚠️ Te trasy MUSZĄ stać przed jakimkolwiek `/api/rezyser/:coś` — Express bierze
//  pierwszą pasującą, a parametr zjadłby literał „projekty".

app.get('/api/rezyser/projekty', async (req, res) => {
    try {
        return res.json({ success: true, projekty: await listaProjektow(ANTIGRAVITY_DIR), statusy: STATUSY_ODCINKA });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/rezyser/projekty', async (req, res) => {
    try {
        const { nazwa = '', notatka = '' } = req.body ?? {};
        const projekt = await utworzProjekt(ANTIGRAVITY_DIR, nazwa, notatka);
        console.log(`[Reżyser] 📁 Projekt „${projekt.nazwa}" ${projekt.nowy ? 'założony' : 'już był'}: ${projekt.sciezka}`);
        return res.json({ success: true, projekt });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

app.delete('/api/rezyser/projekty/:slug', async (req, res) => {
    try {
        return res.json({ success: true, projekt: await usunProjekt(ANTIGRAVITY_DIR, req.params.slug) });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

app.delete('/api/rezyser/pamiec/odcinek/:id', async (req, res) => {
    try {
        const odcinek = await usunOdcinek(ANTIGRAVITY_DIR, String(req.query.serial || ''), req.params.id);
        return res.json({ success: true, odcinek });
    } catch (err) {
        return res.status(400).json({ success: false, message: err.message });
    }
});

/**
 * POST /api/rezyser/rozmowa  { serial, wypowiedz, historia[], postacId? }
 * Jedna tura rozmowy z Reżyserem: kontekst → model → mowa + wykonana akcja.
 */
app.post('/api/rezyser/rozmowa', async (req, res) => {
    const { serial = '', wypowiedz = '', historia = [], postacId = null } = req.body ?? {};
    if (String(wypowiedz).trim().length < 2) {
        return res.status(400).json({ success: false, message: 'Pusta wypowiedź.' });
    }
    const nazwaSerialu = String(serial).trim() || 'bez nazwy';

    try {
        // ── Kontekst: obsada + pamięć + tablica, przycięte do budżetu ──
        const postac = postacId
            ? (await listaPostaci(ANTIGRAVITY_DIR)).find(p => p.id === postacId) ?? null
            : null;
        const kontekst = zbudujKontekst({
            pamiecSerialu: await rezyserPamiec(ANTIGRAVITY_DIR, nazwaSerialu),
            postac,
            kadry: await produkcjaLista(ANTIGRAVITY_DIR, nazwaSerialu),
        });
        if (kontekst.pominieto.length) {
            // Cicha utrata faktu kanonicznego to najgorsze, co może się przydarzyć
            // serialowi — więc krzyczy w logu i wraca w odpowiedzi.
            console.warn(`[Reżyser] ⚠️ Kontekst przycięty: ${kontekst.pominieto.join(' · ')}`);
        }

        // Ostatnie 8 tur — dalej i tak wypchnęłoby kontekst ponad okno modelu.
        const rozmowa = (Array.isArray(historia) ? historia : []).slice(-8)
            .map(t => `${t.role === 'user' ? 'Suweren' : 'Ty'}: ${t.content}`).join('\n');

        const odp = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: DEFAULT_LLM,
                system: promptSystemowyRezysera(kontekst, postac?.imie ?? null),
                prompt: `${rozmowa ? rozmowa + '\n' : ''}Suweren: ${wypowiedz}\nTy:`,
                stream: false,
                options: { temperature: 0.75 },
            }),
        });
        if (!odp.ok) throw new Error(`Ollama HTTP ${odp.status} — sprawdź, czy rdzeń AI stoi.`);
        const dane = await odp.json();

        // ── Odczyt kontraktu. Gdy model go nie utrzyma, NIE zgadujemy akcji ──
        let mowa, akcja = null, uwaga = null;
        try {
            ({ mowa, akcja } = odczytajOdpowiedz(dane.response));
        } catch (e) {
            mowa = String(dane.response || '').trim();
            uwaga = `Model nie utrzymał formatu (${e.message}) — potraktowane jako sama wypowiedź, bez akcji.`;
            console.warn(`[Reżyser] ⚠️ ${uwaga}`);
        }
        if (!mowa && !akcja) {
            return res.status(502).json({ success: false, message: 'Reżyser milczy — rdzeń AI zwrócił pustkę.' });
        }

        // ── Wykonanie akcji (biała lista; model nie wymyśli sobie nowej) ──
        let wynikAkcji = null;
        if (akcja) {
            if (!AKCJE_REZYSERA.has(akcja.typ)) {
                wynikAkcji = { wykonana: false, powod: `nieznana akcja „${akcja.typ}" — pominięta` };
                console.warn(`[Reżyser] ⛔ ${wynikAkcji.powod}`);
            } else {
                try {
                    switch (akcja.typ) {
                        case 'dodaj_kadr': {
                            const kadr = await produkcjaDodaj(ANTIGRAVITY_DIR, {
                                tytul: akcja.tytul, opis: akcja.opis, etap: akcja.etap || 'BIBLIA',
                                projekt: nazwaSerialu, zrodlo: 'rada',
                            });
                            wynikAkcji = { wykonana: true, opis: `kadr „${kadr.tytul}" na etapie ${kadr.etap}`, kadr };
                            break;
                        }
                        case 'rozloz': {
                            const r = await radaKreatywnaRozloz(akcja.zlecenie || wypowiedz, nazwaSerialu);
                            wynikAkcji = {
                                wykonana: true,
                                opis: `rozłożone na ${r.dodane.length} kart` +
                                      (r.odrzucone.length ? ` (${r.odrzucone.length} odrzuconych)` : ''),
                                ...r,
                            };
                            break;
                        }
                        case 'zapamietaj': {
                            const w = await dodajFakt(ANTIGRAVITY_DIR, nazwaSerialu, akcja.fakt, 'rezyser');
                            wynikAkcji = {
                                wykonana: true,
                                opis: w.duplikat ? 'ten fakt już był w kanonie' : `zapamiętane: „${w.fakt.tresc}"`,
                                fakt: w.fakt,
                            };
                            break;
                        }
                        case 'domknij_odcinek': {
                            const o = await dodajOdcinek(ANTIGRAVITY_DIR, nazwaSerialu, {
                                tytul: akcja.tytul, streszczenie: akcja.streszczenie,
                            });
                            wynikAkcji = { wykonana: true, opis: `odcinek #${o.numer} „${o.tytul}" domknięty`, odcinek: o };
                            break;
                        }
                        case 'otworz':
                            // Jedyna akcja bez skutku na serwerze — front ma otworzyć moduł.
                            wynikAkcji = { wykonana: true, opis: `otwórz moduł: ${akcja.modul}`, modul: akcja.modul };
                            break;

                        /**
                         * „Zrealizuj odcinek" — to samo, co guzik REALIZUJ, tylko z głosu.
                         * ⚠️ Wołamy WŁASNĄ TRASĘ mostu, a nie kopiujemy jej logiki:
                         * dwie implementacje tej samej realizacji rozjechałyby się
                         * przy pierwszej poprawce i nikt by nie wiedział, która działa.
                         */
                        case 'zrealizuj_odcinek': {
                            const p2 = await rezyserPamiec(ANTIGRAVITY_DIR, nazwaSerialu);
                            const szukany = String(akcja.odcinek ?? akcja.numer ?? '').trim();
                            const odc = szukany
                                ? (p2.odcinki ?? []).find((o) => o.id === szukany || String(o.numer) === szukany)
                                // Bez wskazania bierzemy pierwszy „w planie" — tak brzmi
                                // „zrealizuj następny odcinek" w ustach człowieka.
                                : (p2.odcinki ?? []).find((o) => o.status === 'plan');
                            if (!odc) { wynikAkcji = { wykonana: false, powod: szukany ? `nie znam odcinka „${szukany}"` : 'żaden odcinek nie czeka w planie' }; break; }

                            const r = await fetch(`http://127.0.0.1:${PORT}/api/rezyser/pamiec/odcinek/${odc.id}/realizuj`, {
                                method: 'POST', headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ serial: nazwaSerialu }),
                            });
                            const d2 = await r.json();
                            wynikAkcji = d2.success
                                ? {
                                    wykonana: true,
                                    opis: `odcinek #${odc.numer} „${odc.tytul}" rozłożony na ${d2.kadry.length} kadrów${d2.biblia ? ' i biblię' : ''}`,
                                    kadrow: d2.kadry.length, comfy: d2.comfy,
                                }
                                : { wykonana: false, powod: d2.message };
                            break;
                        }

                        /**
                         * „Utwórz film" — scena prosto z opisu.
                         * ComfyUI budzi się w trasie `/api/wideo/generuj`, więc mówienie
                         * do Orba działa tak samo po świeżym starcie Katedry.
                         */
                        case 'utworz_film': {
                            const opisSceny = String(akcja.opis ?? akcja.prompt ?? '').trim();
                            if (opisSceny.length < 5) { wynikAkcji = { wykonana: false, powod: 'nie wiem, co ma być na filmie' }; break; }
                            const r = await fetch(`http://127.0.0.1:${PORT}/api/wideo/generuj`, {
                                method: 'POST', headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ prompt: opisSceny }),
                            });
                            const d2 = await r.json();
                            wynikAkcji = d2.success
                                ? { wykonana: true, opis: `scena zlecona do ${d2.silnik} (zlecenie ${d2.zlecenie})`, zlecenie: d2.zlecenie }
                                // Gdy silnik wstaje, mówimy to zamiast „nie udało się".
                                : { wykonana: false, powod: d2.message, budzenie: d2.budzenie ?? null };
                            break;
                        }
                    }
                } catch (e) {
                    // Akcja padła — mówimy to wprost. Reżyser, który „zrobił" coś,
                    // czego nie ma na tablicy, jest gorszy niż Reżyser, który przyznał błąd.
                    wynikAkcji = { wykonana: false, powod: e.message };
                    console.warn(`[Reżyser] ⚠️ Akcja ${akcja.typ} nie przeszła: ${e.message}`);
                }
            }
        }

        // Model bywa tak zajęty składaniem akcji, że zapomina o „mowa". Zdanie
        // układamy wtedy Z WYNIKU — czyli PO wykonaniu, z tego, co naprawdę się
        // stało. Kolejność jest istotna: gdyby powstało wcześniej, obiecywałoby.
        if (!mowa) {
            mowa = zdanieZWyniku(akcja.typ, wynikAkcji);
            uwaga = (uwaga ? uwaga + ' ' : '') +
                    'Model nie podał wypowiedzi — zdanie ułożone z faktycznego wyniku akcji.';
        }

        console.log(`[Reżyser] 🎬 ${nazwaSerialu}${postac ? ` · ${postac.imie}` : ''} · kontekst ${kontekst.znakow} zn.` +
                    `${akcja ? ` · akcja ${akcja.typ}: ${wynikAkcji?.wykonana ? 'OK' : 'NIE'}` : ''}`);

        return res.json({
            success: true,
            mowa, akcja, wynikAkcji, uwaga,
            model: DEFAULT_LLM,
            postac: postac ? { id: postac.id, imie: postac.imie, glos: postac.glos } : null,
            kontekst: { znakow: kontekst.znakow, pominieto: kontekst.pominieto },
        });
    } catch (e) {
        console.error(`[Reżyser] ❌ ${e.message}`);
        return res.status(500).json({ success: false, message: e.message });
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  🌌 UNIVERSA — rejestr modułów i wypraw, płatne w GRV
//
//  Zastępuje makietę: zakładka „Universes" miała wymyślone aktywa, liczniki
//  wpisane na sztywno i przycisk wpłaty BEZ obsługi kliknięcia.
//  Tutaj każdy ruch przechodzi przez `przelejGrv` — z odjęciem u nadawcy
//  i pieczęcią w łańcuchu. Liczniki wypraw są SUMOWANE z wpłat, nigdy
//  przechowywane, więc nie da się ich ustawić z palca.
// ══════════════════════════════════════════════════════════════════════════════

app.get('/api/moduly', async (req, res) => {
    try {
        const wezel = String(req.query.wezel || '') || null;
        return res.json({
            success: true,
            moduly: await listaModulow(ANTIGRAVITY_DIR, wezel),
            stan: await stanRejestru(ANTIGRAVITY_DIR),
            skarbiec: SKARBIEC_GRV,
        });
    } catch (err) { return res.status(500).json({ success: false, message: err.message }); }
});

app.post('/api/moduly', async (req, res) => {
    try {
        const modul = await dodajModul(ANTIGRAVITY_DIR, req.body ?? {});
        console.log(`[Universa] 🧩 Nowy moduł „${modul.nazwa}" od ${modul.autor} (${modul.cenaGRV} GRV).`);
        return res.json({ success: true, modul });
    } catch (err) { return res.status(400).json({ success: false, message: err.message }); }
});

app.delete('/api/moduly/:id', async (req, res) => {
    try {
        return res.json({ success: true, modul: await usunModul(ANTIGRAVITY_DIR, req.params.id) });
    } catch (err) { return res.status(400).json({ success: false, message: err.message }); }
});

/** Subskrypcja: REALNY przelew GRV, potem dopiero zapis. Kolejność jest istotna. */
app.post('/api/moduly/:id/subskrybuj', async (req, res) => {
    const { wezel } = req.body ?? {};
    if (!wezel) return res.status(400).json({ success: false, message: 'Wymagany „wezel" (kto subskrybuje).' });
    try {
        const moduly = await listaModulow(ANTIGRAVITY_DIR, wezel);
        const m = moduly.find(x => x.id === req.params.id);
        if (!m) return res.status(404).json({ success: false, message: `Moduł „${req.params.id}" nie istnieje.` });
        if (m.subskrybowany) return res.status(400).json({ success: false, message: 'Już subskrybujesz ten moduł.' });

        // Płatne moduły: najpierw pieniądze, potem dostęp. Zapis przed przelewem
        // dałby subskrypcję nawet przy pustym koncie.
        let przelew = null;
        if (m.cenaGRV > 0) {
            const odbiorca = m.wbudowany ? SKARBIEC_GRV : (m.autor || SKARBIEC_GRV);
            przelew = await przelejGrv(wezel, odbiorca, m.cenaGRV);
        }
        const wynik = await zapiszSubskrypcje(ANTIGRAVITY_DIR, { modul: m.id, wezel, grv: m.cenaGRV });
        console.log(`[Universa] ✅ ${wezel} subskrybuje „${m.nazwa}" za ${m.cenaGRV} GRV.`);
        return res.json({ success: true, modul: m.id, zaplacono: m.cenaGRV, przelew, ...wynik });
    } catch (err) {
        return res.status(err instanceof BladGrv ? err.status : 400).json({ success: false, message: err.message });
    }
});

app.delete('/api/moduly/:id/subskrypcja', async (req, res) => {
    try {
        const wezel = String(req.query.wezel || '');
        if (!wezel) return res.status(400).json({ success: false, message: 'Wymagany „wezel".' });
        return res.json({ success: true, ...(await anulujSubskrypcje(ANTIGRAVITY_DIR, req.params.id, wezel)) });
    } catch (err) { return res.status(400).json({ success: false, message: err.message }); }
});

// ── Wyprawy ───────────────────────────────────────────────────────────────────

app.get('/api/wyprawy', async (req, res) => {
    try {
        return res.json({ success: true, wyprawy: await listaWypraw(ANTIGRAVITY_DIR) });
    } catch (err) { return res.status(500).json({ success: false, message: err.message }); }
});

app.post('/api/wyprawy', async (req, res) => {
    try {
        const wyprawa = await dodajWyprawe(ANTIGRAVITY_DIR, req.body ?? {});
        console.log(`[Universa] 🚀 Nowa wyprawa „${wyprawa.nazwa}" (cel ${wyprawa.celGRV} GRV) od ${wyprawa.autor}.`);
        return res.json({ success: true, wyprawa });
    } catch (err) { return res.status(400).json({ success: false, message: err.message }); }
});

app.delete('/api/wyprawy/:id', async (req, res) => {
    try {
        return res.json({ success: true, wyprawa: await usunWyprawe(ANTIGRAVITY_DIR, req.params.id) });
    } catch (err) { return res.status(400).json({ success: false, message: err.message }); }
});

/** Wpłata na wyprawę: przelew GRV, potem zapis. Licznik urośnie sam z sumy. */
app.post('/api/wyprawy/:id/wplac', async (req, res) => {
    const { wezel, grv } = req.body ?? {};
    const kwota = Math.floor(Number(grv) || 0);
    if (!wezel) return res.status(400).json({ success: false, message: 'Wymagany „wezel".' });
    if (!(kwota > 0)) return res.status(400).json({ success: false, message: 'Kwota musi być większa od zera.' });
    try {
        const wyprawy = await listaWypraw(ANTIGRAVITY_DIR);
        const w = wyprawy.find(x => x.id === req.params.id);
        if (!w) return res.status(404).json({ success: false, message: `Wyprawa „${req.params.id}" nie istnieje.` });

        const przelew = await przelejGrv(wezel, SKARBIEC_GRV, kwota);
        const wpis = await zapiszWplate(ANTIGRAVITY_DIR, { wyprawa: w.id, wezel, grv: kwota });
        const po = (await listaWypraw(ANTIGRAVITY_DIR)).find(x => x.id === w.id);
        console.log(`[Universa] 💫 ${wezel} wpłacił ${kwota} GRV na „${w.nazwa}" (${po.zebraneGRV}/${w.celGRV}).`);
        return res.json({ success: true, wpis, przelew, wyprawa: po });
    } catch (err) {
        return res.status(err instanceof BladGrv ? err.status : 400).json({ success: false, message: err.message });
    }
});

// ── ⚡ MODEL CONTEXT PROTOCOL (MCP SKILLBOARD & REGISTRY 0.00G) ─────────────
const MCP_REGISTRY_PATH = path.join(ANTIGRAVITY_DIR || process.cwd(), '.vault-0.00g', 'mcp-registry.json');
let mcpRegistryCache = null;

async function loadMcpRegistry() {
    if (mcpRegistryCache) return mcpRegistryCache;
    try {
        await fs.mkdir(path.dirname(MCP_REGISTRY_PATH), { recursive: true });
        const data = await fs.readFile(MCP_REGISTRY_PATH, 'utf8');
        mcpRegistryCache = JSON.parse(data);
        return mcpRegistryCache;
    } catch (e) {
        mcpRegistryCache = {
            version: '0.00G',
            activeSkills: ['postgres-mcp', 'sqlite-vault-mcp', 'github-ops-mcp', 'docker-sentinel-mcp', 'filesystem-core-mcp', 'terminal-exec-mcp', 'puppeteer-scraper-mcp', 'brave-search-mcp', 'youtube-transcript-mcp', 'ollama-matrix-mcp', 'ffmpeg-sonic-mcp'],
            customSkills: [],
            agentBindings: {
                klaudiusz: ['postgres-mcp', 'sqlite-vault-mcp', 'github-ops-mcp', 'filesystem-core-mcp', 'terminal-exec-mcp', 'puppeteer-scraper-mcp', 'brave-search-mcp', 'ollama-matrix-mcp', 'ffmpeg-sonic-mcp'],
                bob: ['sqlite-vault-mcp', 'filesystem-core-mcp', 'youtube-transcript-mcp', 'ollama-matrix-mcp', 'ffmpeg-sonic-mcp'],
                ostry: ['github-ops-mcp', 'sentry-anomaly-mcp', 'filesystem-core-mcp', 'terminal-exec-mcp', 'ollama-matrix-mcp'],
                mechanik: ['postgres-mcp', 'redis-cache-mcp', 'github-ops-mcp', 'docker-sentinel-mcp', 'sentry-anomaly-mcp', 'filesystem-core-mcp', 'terminal-exec-mcp', 'ollama-matrix-mcp'],
                archiwista: ['postgres-mcp', 'sqlite-vault-mcp', 'filesystem-core-mcp', 'puppeteer-scraper-mcp', 'brave-search-mcp', 'youtube-transcript-mcp', 'ollama-matrix-mcp'],
                wezyr: ['docker-sentinel-mcp', 'brave-search-mcp', 'ollama-matrix-mcp']
            },
            updatedAt: new Date().toISOString()
        };
        return mcpRegistryCache;
    }
}

/**
 * Skille, ktore MAJA realna implementacje po stronie mostu. Reszta rejestru to
 * karty w katalogu — moga byc podpiete pozniej do prawdziwych serwerow MCP,
 * ale dzis nic nie wykonaja i endpoint /execute mowi to wprost (501).
 * Dopisujac tu nowy skill, dopisz tez jego obsluge w /api/mcp/execute.
 */
const MCP_REALNE = ['filesystem-core-mcp', 'terminal-exec-mcp', 'katedra-puls-mcp', 'muzyka-otakos-mcp', 'sumienie-mcp', 'graphify-mcp'];

/**
 * Sekrety nie wychodza przez MCP. `read_file` czytal cokolwiek — a `list_directory`
 * pokazywal w katalogu mostu `.env`, `.env.local` i `.anthropic_key.env`.
 * Blokada dziala na nazwie pliku, wiec lapie tez kopie typu `.env.backup`.
 */
const MCP_PLIKI_ZAKAZANE = /(^\.env)|(\.env$)|(\.env\.)|key|secret|token|credential|password|haslo|\.pem$|\.pfx$|id_rsa|vault/i;

function mcpWolnoCzytac(sciezka) {
    const nazwa = path.basename(String(sciezka));
    return !MCP_PLIKI_ZAKAZANE.test(nazwa);
}

async function saveMcpRegistry(data) {
    mcpRegistryCache = data;
    try {
        await fs.mkdir(path.dirname(MCP_REGISTRY_PATH), { recursive: true });
        await fs.writeFile(MCP_REGISTRY_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.warn('[MCP Bridge] Nie udało się zapisać mcp-registry.json:', e.message);
    }
}

app.get('/api/mcp/status', async (req, res) => {
    try {
        const reg = await loadMcpRegistry();
        return res.json({
            success: true,
            online: true,
            activeCount: reg.activeSkills?.length || 0,
            totalAvailable: 15,
            transport: 'STDIO / HTTP / SSE (0.00G)',
            timestamp: new Date().toISOString()
        });
    } catch (e) {
        return res.json({ success: true, online: true, activeCount: 11, totalAvailable: 15, transport: 'STDIO' });
    }
});

app.get('/api/mcp/skills', async (req, res) => {
    try {
        const reg = await loadMcpRegistry();
        return res.json({
            success: true,
            activeSkills: reg.activeSkills || [],
            customSkills: reg.customSkills || [],
            agentBindings: reg.agentBindings || {}
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/mcp/activate', async (req, res) => {
    try {
        const { skillId, command, transport, env, customConfig } = req.body || {};
        if (!skillId) return res.status(400).json({ success: false, message: 'Wymagane skillId.' });
        const reg = await loadMcpRegistry();
        if (!reg.activeSkills.includes(skillId)) {
            reg.activeSkills.push(skillId);
            reg.updatedAt = new Date().toISOString();
            await saveMcpRegistry(reg);
        }
        console.log(`[MCP Bridge] ⚡ Skill [${skillId}] aktywowany w Moście (${transport || 'stdio'}).`);
        return res.json({
            success: true,
            skillId,
            status: 'active',
            message: `Skill ${skillId} został pomyślnie podpięty do Mostu 0.00G!`
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/mcp/deactivate', async (req, res) => {
    try {
        const { skillId } = req.body || {};
        if (!skillId) return res.status(400).json({ success: false, message: 'Wymagane skillId.' });
        const reg = await loadMcpRegistry();
        reg.activeSkills = (reg.activeSkills || []).filter(id => id !== skillId);
        reg.updatedAt = new Date().toISOString();
        await saveMcpRegistry(reg);
        console.log(`[MCP Bridge] 🔌 Skill [${skillId}] odłączony.`);
        return res.json({ success: true, skillId, status: 'inactive' });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/mcp/assign', async (req, res) => {
    try {
        const { skillId, agentId, assigned } = req.body || {};
        if (!skillId || !agentId) return res.status(400).json({ success: false, message: 'Wymagane skillId i agentId.' });
        const reg = await loadMcpRegistry();
        reg.agentBindings = reg.agentBindings || {};
        reg.agentBindings[agentId] = reg.agentBindings[agentId] || [];
        if (assigned) {
            if (!reg.agentBindings[agentId].includes(skillId)) reg.agentBindings[agentId].push(skillId);
        } else {
            reg.agentBindings[agentId] = reg.agentBindings[agentId].filter(id => id !== skillId);
        }
        reg.updatedAt = new Date().toISOString();
        await saveMcpRegistry(reg);
        console.log(`[MCP Bridge] 🤖 Agent [${agentId}] ${assigned ? 'podpięty pod' : 'odpięty od'} [${skillId}].`);
        return res.json({ success: true, skillId, agentId, assigned });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/mcp/execute', async (req, res) => {
    const { skillId, toolName, arguments: toolArgs } = req.body || {};
    if (!skillId || !toolName) {
        return res.status(400).json({ success: false, message: 'Wymagane skillId oraz toolName.' });
    }
    console.log(`[MCP Bridge] 🧪 Wywołanie narzędzia MCP: ${skillId} -> ${toolName}`, toolArgs);

    try {
        // ══ PRAWDZIWY SERWER MCP — graphify (JSON-RPC przez stdio) ═══════════
        // Pierwszy skill w Skillboardzie, który NIE jest handlerem wpisanym w most,
        // tylko rozmową z zewnętrznym serwerem MCP jego własnym protokołem.
        if (skillId === 'graphify-mcp') {
            const exe = process.platform === 'win32' ? 'graphify-mcp.exe' : 'graphify-mcp';
            const sciezka = path.join(os.homedir(), '.local', 'bin', exe);
            const graf = path.join(process.cwd(), 'graphify-out', 'graph.json');
            const polaczenie = mcpPolaczenie('graphify', sciezka, [graf], { cwd: process.cwd() });
            if (toolName === 'tools/list') {
                return res.json({ success: true, result: { tools: await polaczenie.listaNarzedzi() } });
            }
            const wynik = await polaczenie.wywolaj(toolName, toolArgs);
            return res.json({ success: true, result: wynik });
        }

        // Obsługa specyficznych narzędzi lokalnych
        if (skillId === 'filesystem-core-mcp') {
            if (toolName === 'list_directory') {
                const target = toolArgs?.path || '.';
                const files = await fs.readdir(path.resolve(target));
                return res.json({ success: true, result: { path: target, entries: files.slice(0, 50) } });
            }
            if (toolName === 'read_file') {
                const target = toolArgs?.path || 'package.json';
                if (!mcpWolnoCzytac(target)) {
                    return res.status(403).json({
                        success: false,
                        message: `Odmowa: "${path.basename(target)}" wygląda na plik z sekretem. MCP nie wydaje kluczy ani .env.`,
                    });
                }
                const content = await fs.readFile(path.resolve(target), 'utf8');
                return res.json({ success: true, result: { path: target, preview: content.slice(0, 1000), totalBytes: content.length } });
            }
        }

        if (skillId === 'terminal-exec-mcp') {
            const rawCmd = toolArgs?.command || 'git status -s';
            // Ten sam sanitizer, co /api/mcp/execute pomijal, a trzy inne endpointy
            // wykonujace komendy uzywaja. Bez niego wklejony prompt powloki albo
            // sztuczka ze znacznikiem szly prosto do execAsync.
            const san = ShellSanitizer.sanitizeShellCommand(rawCmd);
            const cmd = san.command ?? san.cmd ?? san.sanitized ?? rawCmd;
            try {
                const { stdout, stderr } = await execAsync(cmd, { cwd: process.cwd(), timeout: 10000 });
                return res.json({ success: true, result: { command: cmd, stdout, stderr, exitCode: 0, sanitizer: san.notes ?? [] } });
            } catch (err) {
                return res.json({ success: true, result: { command: cmd, error: err.message, exitCode: 1, sanitizer: san.notes ?? [] } });
            }
        }

        // ══ SKILLE KLAUDIUSZA — realne, nie karty w katalogu ══════════════════

        // 💓 PULS KATEDRY — jeden strzal, pelna diagnoza wezla.
        // Powstal z tej sesji: szukanie, dlaczego muzyka liczy 7h, wymagalo recznego
        // sprawdzania mostu, Ollamy, ComfyUI, VRAM-u i COMMITU (nie WorkingSet!).
        if (skillId === 'katedra-puls-mcp') {
            const zywy = async (url, ms = 1500) => {
                try {
                    const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
                    const r = await fetch(url, { signal: c.signal }); clearTimeout(t);
                    return r.ok;
                } catch { return false; }
            };
            const [ollama, comfy] = await Promise.all([
                zywy(`${OLLAMA_BASE}/api/tags`), zywy(`${COMFY_BASE}/object_info`, 2500),
            ]);
            let modeleLlm = [];
            try {
                const r = await fetch(`${OLLAMA_BASE}/api/ps`);
                modeleLlm = (await r.json()).models?.map(m => ({ nazwa: m.name, gb: +(m.size / 1e9).toFixed(2) })) ?? [];
            } catch { /* Ollama spi */ }
            const wolneMb = Math.round(os.freemem() / 1e6);
            const calyMb = Math.round(os.totalmem() / 1e6);
            let muzyka = null;
            try { muzyka = await muzykaModeleStatus(); } catch { /* katalog nieosiagalny */ }

            return res.json({
                success: true,
                result: {
                    most: { port: PORT, uptimeS: Math.round(process.uptime()) },
                    ollama: { online: ollama, zaladowane: modeleLlm },
                    comfyui: { online: comfy, base: COMFY_BASE },
                    pamiec: {
                        wolneGb: +(wolneMb / 1024).toFixed(2),
                        calyGb: +(calyMb / 1024).toFixed(2),
                        // Ostrzezenie zmierzone w tej sesji: 8.7 GB encoder + ~2 GB torch.
                        starczyNaMuzyke: wolneMb > 11000,
                    },
                    muzyka: muzyka ? { gotowaRodzina: muzyka.gotowaRodzina, naDyskuGb: +(muzyka.bajtyNaDysku / 1e9).toFixed(2) } : null,
                    werdykt: [
                        ollama ? null : 'Ollama nie odpowiada — Orb zamilknie.',
                        comfy ? null : 'ComfyUI nie działa — muzyka i obraz nie policzą.',
                        wolneMb < 4000 ? `Mało wolnej pamięci (${(wolneMb / 1024).toFixed(1)} GB) — zwolnij model Ollamy: keep_alive 0.` : null,
                        modeleLlm.some(m => /gemma4:latest/.test(m.nazwa)) ? 'Uwaga: wisi gemma4:latest, ta która wywala Ollamę na tej maszynie.' : null,
                    ].filter(Boolean),
                },
            });
        }

        // 🎵 BIBLIOTEKA DZWIEKU — co realnie lezy w _OtakOs_Muzyka.
        if (skillId === 'muzyka-otakos-mcp') {
            const szukaj = String(toolArgs?.query ?? '').toLowerCase();
            let pliki = [];
            try {
                pliki = (await getAudioFilesRecursive(MUSIC_DIR)) ?? [];
            } catch { /* brak katalogu */ }
            const wynik = [];
            for (const pelna of pliki) {
                const nazwa = path.basename(pelna);
                if (szukaj && !nazwa.toLowerCase().includes(szukaj)) continue;
                let bajty = 0;
                try { bajty = (await fs.stat(pelna)).size; } catch { /* zniknal */ }
                wynik.push({ nazwa, mb: +(bajty / 1e6).toFixed(2), sciezka: path.relative(MUSIC_DIR, pelna) });
            }
            wynik.sort((a, b) => a.nazwa.localeCompare(b.nazwa));
            return res.json({
                success: true,
                result: {
                    katalog: MUSIC_DIR,
                    znaleziono: wynik.length,
                    lacznieMb: +(wynik.reduce((s, x) => s + x.mb, 0)).toFixed(1),
                    utwory: wynik.slice(0, 60),
                },
            });
        }

        // 🪞 SUMIENIE KATEDRY — skaner atrap. NAJBARDZIEJ TEO Z TYCH SKILLI.
        // Powod istnienia: w tej samej sesji dwa razy trafilismy na kod, ktory
        // UDAWAL dzialanie — petla setTimeout wypisujaca fałszywe "DiT Step 12/30"
        // i endpoint MCP zwracajacy status SUCCESS na `DROP TABLE`. Oba przeszly
        // build i tsc na zielono. Zielony build nie znaczy, ze funkcja istnieje.
        // Ten skill szuka wlasnie takich rzeczy — jest narzedziem zasady
        // "zero z dupy" z CLAUDE.md, zamienionym w kod.
        if (skillId === 'sumienie-mcp') {
            const cel = toolArgs?.path;
            if (!cel) return res.status(400).json({ success: false, message: 'Podaj "path" — plik albo katalog do zbadania.' });
            const TROPY = [
                // Kolejnosc dowolna: `onProgress({percentage})` czesto stoi PRZED `setTimeout`,
                // a pierwsza wersja wzorca wymagala setTimeout na poczatku i to przepuszczala.
                { id: 'falszywy-postep', re: /(setTimeout[\s\S]{0,160}(percentage|progress|procent|krok))|((percentage|onProgress|procent)[\s\S]{0,160}setTimeout)/i, opis: 'Pętla z setTimeout udająca postęp — telemetria bez obliczeń.' },
                { id: 'zawsze-sukces', re: /status:\s*['"`](SUCCESS|OK|SUKCES)['"`]/i, opis: 'Zaszyty na sztywno SUCCESS — sprawdź, czy cokolwiek się wykonało.' },
                { id: 'pomyslnie', re: /(przetworzy[lł]o|wykonano|zakończono)\s+(dane\s+)?pomyślnie/i, opis: 'Deklaracja sukcesu w treści, nie w wyniku.' },
                // Slowo-klucz moze stac PRZED albo PO Math.random() — `const loss = Math.random()`
                // to najczestszy uklad, a pierwsza wersja tego wzorca go przepuszczala.
                { id: 'losowe-dane', re: /(Math\.random\(\)[\s\S]{0,60}(loss|score|confidence|wynik|postep|progress))|((loss|score|confidence|wynik|postep|progress)[\s\S]{0,60}Math\.random\(\))/i, opis: 'Math.random() podstawiony pod metrykę — dane z kapelusza.' },
                { id: 'placeholder-media', re: /soundhelix|placeholder\.com|via\.placeholder|example\.com\/(audio|video)/i, opis: 'Zewnętrzny placeholder udający wytworzony materiał.' },
                { id: 'symulator', re: /\b(symulator|simulator|udaje|fake|mock)\b/i, opis: 'Nazwane wprost: symulacja. Sprawdź, czy nie jest podana jako funkcja.' },
                { id: 'dlug', re: /\b(TODO|FIXME|HACK|XXX)\b/, opis: 'Dług zapisany w kodzie.' },
            ];
            const ROZSZERZENIA = /\.(ts|tsx|js|jsx|mjs|cjs|py)$/i;
            const pelna = path.resolve(cel);
            const doZbadania = [];
            const st = await fs.stat(pelna);
            if (st.isDirectory()) {
                const wejscia = await fs.readdir(pelna, { withFileTypes: true });
                for (const w of wejscia) {
                    if (w.isFile() && ROZSZERZENIA.test(w.name)) doZbadania.push(path.join(pelna, w.name));
                }
            } else doZbadania.push(pelna);

            const znaleziska = [];
            for (const plik of doZbadania.slice(0, 40)) {
                let tresc = '';
                try { tresc = await fs.readFile(plik, 'utf8'); } catch { continue; }
                const linie = tresc.split(/\r?\n/);
                // Okno 4 linii, nie pojedyncza linia: atrapy rozkladaja sie w pionie.
                // `setTimeout` bywa o dwie linie nizej niz `percentage`, a skan linia-po-linii
                // taki uklad przepuszczal (wykryte przy testowaniu tego skilla na probce).
                const OKNO = 4;
                for (const t of TROPY) {
                    const zgloszone = new Set();
                    for (let i = 0; i < linie.length; i++) {
                        const okno = linie.slice(i, i + OKNO).join('\n');
                        const traf = okno.match(t.re);
                        if (!traf) continue;
                        // Numer linii liczymy od MIEJSCA TRAFIENIA w oknie, nie od jego poczatku —
                        // inaczej raport wskazywal linie o kilka wyzej niz faktyczna atrapa.
                        const przesuniecie = okno.slice(0, traf.index).split('\n').length - 1;
                        const nrLinii = i + przesuniecie;
                        // Nachodzace okna trafiaja to samo miejsce — zglaszamy raz.
                        if ([...zgloszone].some((z) => Math.abs(nrLinii - z) < OKNO)) continue;
                        zgloszone.add(nrLinii);
                        znaleziska.push({
                            plik: path.relative(process.cwd(), plik),
                            linia: nrLinii + 1,
                            trop: t.id,
                            opis: t.opis,
                            fragment: (linie[nrLinii] ?? '').trim().slice(0, 140),
                        });
                    }
                }
            }
            return res.json({
                success: true,
                result: {
                    zbadano: doZbadania.length,
                    znaleziono: znaleziska.length,
                    // Puste znaleziska NIE znacza "kod uczciwy" — to heurystyka, nie dowod.
                    werdykt: znaleziska.length === 0
                        ? 'Brak trafień heurystyki. To nie jest dowód uczciwości kodu — tylko brak znanych wzorców atrapy.'
                        : `${znaleziska.length} miejsc do obejrzenia okiem. Każde trafienie wymaga oceny człowieka.`,
                    znaleziska: znaleziska.slice(0, 80),
                },
            });
        }

        // ── UCZCIWA ODMOWA ────────────────────────────────────────────────────
        // Tu byl "domyslny simulator", ktory KAZDEMU narzedziu odpowiadal
        // status: 'SUCCESS' i "przetworzylo dane pomyslnie". Na zapytanie
        // `DROP TABLE wszystko` do nieistniejacej bazy tez odpowiadal SUKCESEM.
        // To jest dokladnie "z dupy" z CLAUDE.md — i grozne, bo Suweren moglby
        // uwierzyc, ze destrukcyjna operacja przeszla.
        // Skill bez realnego backendu ma powiedziec, ze go nie ma. Kropka.
        return res.status(501).json({
            success: false,
            skillId,
            tool: toolName,
            status: 'NIEZAIMPLEMENTOWANE',
            message: `Skill "${skillId}" jest w rejestrze, ale nie ma podpiętego serwera MCP — most nie wykona "${toolName}".`,
            hint: 'Realnie wykonują się tylko te skille, które mają implementację po stronie mostu. '
                + `Obecnie: ${MCP_REALNE.join(', ')}. Resztę trzeba podpiąć do prawdziwego serwera MCP (stdio/sse/http).`,
            realneSkille: MCP_REALNE,
        });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

// ── 🕸️ MODUŁ WIEDZY — Katedra czyta własne katalogi i dane (Graphify) ────────
//
// Archiwista Wiedzy (KnowledgeGraphService) trzyma REJESTR USTEREK — 12 węzłów
// typu FAULT. To co innego niż wiedza o katalogach. Ta trasa dokłada brakujące:
// deterministyczny graf kodu, dokumentów, schematów SQL i configów Katedry,
// liczony lokalnie przez AST — bez LLM, bez wektorów, bez chmury.
//
// ⚠️ graph.json ma ~14 MB. NIE wystawiamy go — most oddaje raport, wyniki zapytań
// i wizualizację. Kto chce surowy graf, bierze go z dysku.
const WIEDZA_KATALOG = path.join(process.cwd(), 'graphify-out');

/**
 * pipx kładzie graphify.exe w ~/.local/bin, którego NIE MA w PATH (pipx sam o tym
 * ostrzega przy instalacji). Most startuje z PATH-em odziedziczonym po .bat,
 * więc gołe „graphify" by nie zadziałało. Szukamy po kolei.
 */
let _graphifyCache;
async function znajdzGraphify() {
    if (_graphifyCache !== undefined) return _graphifyCache;
    try {
        await execAsync('graphify --version', { timeout: 15000, windowsHide: true });
        return (_graphifyCache = 'graphify');
    } catch { /* nie ma w PATH */ }
    const nazwa = process.platform === 'win32' ? 'graphify.exe' : 'graphify';
    const kandydat = path.join(os.homedir(), '.local', 'bin', nazwa);
    try {
        await fs.access(kandydat);
        return (_graphifyCache = `"${kandydat}"`);
    } catch { /* brak */ }
    return (_graphifyCache = null);
}

function brakGraphify(res) {
    return res.status(412).json({
        success: false,
        message: 'Graphify nie jest zainstalowany — modułu wiedzy nie ma czym policzyć.',
        hint: 'Zainstaluj: python -m pipx install graphifyy   (albo powiedz w konsoli: „zainstaluj repo graphify")',
    });
}

/** GET /api/wiedza/stan — czy graf istnieje, jak duży, kiedy liczony. Bez zmyślania. */
app.get('/api/wiedza/stan', async (req, res) => {
    const bin = await znajdzGraphify();
    const plik = path.join(WIEDZA_KATALOG, 'graph.json');
    try {
        // Sam stat — 14 MB do RAM-u tylko po to, żeby powiedzieć „graf jest",
        // to marnotrawstwo. Liczby węzłów oddaje /api/wiedza/buduj przy liczeniu.
        const st = await fs.stat(plik);
        res.json({
            success: true,
            zainstalowany: Boolean(bin),
            graf: true,
            katalog: WIEDZA_KATALOG,
            rozmiarMB: +(st.size / 1e6).toFixed(1),
            policzony: st.mtime.toISOString(),
            raport: '/api/wiedza/raport',
        });
    } catch {
        res.json({
            success: true,
            zainstalowany: Boolean(bin),
            graf: false,
            katalog: WIEDZA_KATALOG,
            message: 'Grafu jeszcze nie ma — zbuduj przez POST /api/wiedza/buduj.',
        });
    }
});

/**
 * POST /api/wiedza/buduj — Body: { sciezka? }.
 * Domyślnie liczy Katedrę. `graphify update` NIE potrzebuje LLM — czysty AST.
 * Pierwszy przebieg na Katedrze to ~2 minuty; kolejne idą z cache i są szybsze.
 */
app.post('/api/wiedza/buduj', async (req, res) => {
    const bin = await znajdzGraphify();
    if (!bin) return brakGraphify(res);
    const zadana = String((req.body ?? {}).sciezka || '.').trim();
    // Ścieżkę trzymamy w granicach Katedry — moduł wiedzy ma opisywać JĄ,
    // a nie zwiedzać cały dysk na komendę z czatu.
    const cel = path.resolve(process.cwd(), zadana);
    if (!cel.startsWith(process.cwd())) {
        return res.status(403).json({
            success: false,
            message: `Odmowa: „${zadana}" leży poza Katedrą. Moduł wiedzy opisuje Katedrę, nie cały dysk.`,
        });
    }
    console.log(`[Wiedza] 🕸️ Buduję graf dla ${cel}…`);
    try {
        const { stdout, stderr } = await execAsync(`${bin} update "${cel}"`, {
            timeout: 1800000, windowsHide: true, maxBuffer: 20 * 1024 * 1024,
        });
        const ogon = String(stdout || '').trim().split('\n').slice(-8).join('\n');
        const liczby = /(\d+)\s+nodes,\s*(\d+)\s+edges,\s*(\d+)\s+communities/.exec(stdout || '');
        console.log(`[Wiedza] ✅ Graf gotowy.`);
        res.json({
            success: true,
            sciezka: cel,
            wezly: liczby ? Number(liczby[1]) : null,
            krawedzie: liczby ? Number(liczby[2]) : null,
            spolecznosci: liczby ? Number(liczby[3]) : null,
            wyjscie: ogon,
            ostrzezenia: String(stderr || '').trim().split('\n').slice(-5).join('\n'),
        });
    } catch (e) {
        console.error(`[Wiedza] ❌ ${e.message}`);
        res.status(500).json({ success: false, message: e.message, wyjscie: String(e.stdout || '').slice(-1500) });
    }
});

/** GET /api/wiedza/wyjasnij?wezel=X — czym jest węzeł i z czym sąsiaduje. */
app.get('/api/wiedza/wyjasnij', async (req, res) => {
    const bin = await znajdzGraphify();
    if (!bin) return brakGraphify(res);
    const wezel = String(req.query.wezel || '').trim();
    if (!wezel) return res.status(400).json({ success: false, message: 'Podaj ?wezel=nazwa.' });
    try {
        const san = ShellSanitizer.sanitizeShellCommand(wezel);
        const czysty = (san.command ?? san.cmd ?? san.sanitized ?? wezel).replace(/"/g, '');
        const { stdout } = await execAsync(
            `${bin} explain "${czysty}" --graph "${path.join(WIEDZA_KATALOG, 'graph.json')}"`,
            { timeout: 120000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 },
        );
        res.json({ success: true, wezel: czysty, opis: String(stdout || '').trim() });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message, wyjscie: String(e.stdout || '').slice(-800) });
    }
});

/** GET /api/wiedza/sciezka?a=X&b=Y — najkrótsza droga między dwoma węzłami. */
app.get('/api/wiedza/sciezka', async (req, res) => {
    const bin = await znajdzGraphify();
    if (!bin) return brakGraphify(res);
    const a = String(req.query.a || '').replace(/"/g, '').trim();
    const b = String(req.query.b || '').replace(/"/g, '').trim();
    if (!a || !b) return res.status(400).json({ success: false, message: 'Podaj ?a=…&b=…' });
    try {
        const { stdout } = await execAsync(
            `${bin} path "${a}" "${b}" --graph "${path.join(WIEDZA_KATALOG, 'graph.json')}"`,
            { timeout: 120000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 },
        );
        res.json({ success: true, od: a, do: b, sciezka: String(stdout || '').trim() });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message, wyjscie: String(e.stdout || '').slice(-800) });
    }
});

/** GET /api/wiedza/raport — GRAPH_REPORT.md (~170 KB, bezpieczny rozmiar). */
app.get('/api/wiedza/raport', async (req, res) => {
    try {
        const md = await fs.readFile(path.join(WIEDZA_KATALOG, 'GRAPH_REPORT.md'), 'utf8');
        res.type('text/markdown; charset=utf-8').send(md);
    } catch {
        res.status(404).json({ success: false, message: 'Brak raportu — zbuduj graf (POST /api/wiedza/buduj).' });
    }
});

// Wizualizacja (~490 KB) serwowana statycznie. graph.json (~14 MB) świadomie NIE.
app.get('/api/wiedza/graf.html', async (req, res) => {
    const plik = path.join(WIEDZA_KATALOG, 'graph.html');
    try { await fs.access(plik); res.sendFile(plik); }
    catch { res.status(404).json({ success: false, message: 'Brak wizualizacji — zbuduj graf.' }); }
});

// ── 🎞️ STUDIO MONTAŻU — OpenMontage dla Story V2 (AGPLv3, narzędzie osobne) ──
app.get('/api/montaz/stan', async (req, res) => {
    try {
        res.json({ success: true, ...(await stanMontazu()) });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

/** POST /api/montaz/backlot — odpal tablicę produkcji i POCZEKAJ aż odpowie. */
app.post('/api/montaz/backlot', async (req, res) => {
    try {
        const w = await odpalBacklot();
        res.json({ success: true, ...w });
    } catch (e) {
        res.status(500).json({
            success: false,
            message: e.message,
            hint: `Studio siedzi w ${SCIEZKA_STUDIA}. Ścieżkę zmienia OTAKOS_OPENMONTAGE.`,
        });
    }
});

// ── 🎒 POSIADANE AKTYWA — czego Suweren FAKTYCZNIE jest właścicielem ─────────
//
// ⚠️ ZNALEZIONY BŁĄD (2026-08-27): zakup w Marketplace PRZELEWAŁ GRV i nie
// zapisywał NICZEGO. Posiadanie żyło w `useState(false)` wewnątrz karty produktu,
// więc po odświeżeniu strony wracało na „niekupione" i ten sam produkt można było
// kupić w kółko. Kupiony moduł nie pojawiał się nigdzie — bo nie istniał żaden
// rejestr, z którego Dashboard, GRAVITON czy Universa mogłyby go odczytać.
//
// Zakup jest teraz JEDNĄ operacją po stronie mostu: sprawdź posiadanie →
// przelej GRV → zapisz właściciela. Front nie może być źródłem prawdy o tym,
// co ktoś ma.
const PLIK_POSIADANYCH = () => path.join(process.cwd(), '_OtakOs_Wymiar', 'posiadane.json');

async function wczytajPosiadane() {
    try { return JSON.parse(await fs.readFile(PLIK_POSIADANYCH(), 'utf8')); }
    catch { return { wersja: 1, aktywa: [] }; }
}
async function zapiszPosiadane(d) {
    await fs.mkdir(path.dirname(PLIK_POSIADANYCH()), { recursive: true });
    await fs.writeFile(PLIK_POSIADANYCH(), JSON.stringify(d, null, 2), 'utf8');
}

/** GET /api/market/posiadane?wezel= — co ten węzeł ma. Źródło dla Dashboard/GRAVITON/Universa. */
app.get('/api/market/posiadane', async (req, res) => {
    const wezel = req.query.wezel || null;
    const d = await wczytajPosiadane();
    const moje = wezel ? d.aktywa.filter(a => a.wlasciciel === wezel) : d.aktywa;
    res.json({
        success: true,
        aktywa: moje,
        lacznie: moje.length,
        wartoscGrv: moje.reduce((s, a) => s + (Number(a.zaplacono) || 0), 0),
    });
});

/**
 * POST /api/market/kup — Body: { id, wezel? }.
 * Atomowo: posiadanie → przelew → zapis. Każdy krok może odmówić i wtedy
 * NIC się nie dzieje: brak przelewu bez zapisu i brak zapisu bez przelewu.
 */
app.post('/api/market/kup', async (req, res) => {
    const { id } = req.body ?? {};
    const wezel = (req.body ?? {}).wezel || 'Mistrz Arkadiusz';
    if (!id) return res.status(400).json({ success: false, message: 'Brak id produktu.' });

    const m = await loadMarket();
    const produkt = m.products.find(p => p.id === id);
    if (!produkt) return res.status(404).json({ success: false, message: `Produkt „${id}" nie istnieje.` });

    // 1. Czy już to ma? Podwójny zakup był głównym objawem błędu.
    const d = await wczytajPosiadane();
    if (d.aktywa.some(a => a.produktId === id && a.wlasciciel === wezel)) {
        return res.status(409).json({
            success: false, code: 'JUZ_POSIADASZ',
            message: `„${produkt.name}" już należy do węzła ${wezel} — nie pobieram GRV drugi raz.`,
        });
    }

    // 2. Przelew (tylko gdy jest za co i nie jest to własny wyrób).
    const cena = Number(dynPriceGrv(produkt) ?? produkt.priceGrv) || 0;
    let przelew = null;
    if (cena > 0 && produkt.creator !== wezel) {
        try {
            przelew = await przelejGrv(wezel, produkt.creator, cena);
        } catch (e) {
            return res.status(e instanceof BladGrv ? e.status : 500).json({
                success: false, code: 'PRZELEW_ODRZUCONY', message: e.message,
            });
        }
    }

    // 3. Dopiero teraz zapis właściciela — po udanym przelewie, nie przed.
    const aktywo = {
        id: `own-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
        produktId: produkt.id, nazwa: produkt.name, modul: produkt.module,
        typ: produkt.type, wlasciciel: wezel, tworca: produkt.creator,
        zaplacono: cena, kiedy: new Date().toISOString(), payload: produkt.payload ?? null,
    };
    d.aktywa.push(aktywo);
    await zapiszPosiadane(d);

    await Szyna.nadaj({
        agent: 'kupiec', rodzaj: 'praca',
        tresc: `${wezel} nabył „${produkt.name}" za ${cena} GRV.`,
    });
    console.log(`[Market] 🎒 ${wezel} nabył „${produkt.name}" za ${cena} GRV.`);

    res.json({ success: true, aktywo, zaplacono: cena, przelew });
});

// ── 🛒 SYNCHRONIZACJA MARKETPLACE Z GLOBALNYM (otakos.wtf) ───────────────────
//
// Globalne oferty to ZRZUT DZIENNY: statyczny JSON serwowany przez otakos.wtf.
// Katedra pobiera go na żądanie i SCALA po `id` — ta sama oferta nie zdubluje
// się przy kolejnej synchronizacji, a lokalne głosy i daty utworzenia zostają.
//
// ⚠️ NIE KASUJEMY niczego lokalnego. Oferta, która zniknęła z globalnego pliku,
// zostaje w Katedrze — to węzeł Suwerena, nie replika serwera.
const MARKET_GLOBALNY = process.env.OTAKOS_MARKET_URL || 'https://otakos.wtf/market/oferty.json';

app.get('/api/market/global-info', (req, res) => {
    res.json({ success: true, zrodlo: MARKET_GLOBALNY, zmienna: 'OTAKOS_MARKET_URL' });
});

app.post('/api/market/sync', async (req, res) => {
    const zrodlo = (req.body ?? {}).zrodlo || MARKET_GLOBALNY;
    console.log(`[Market] 🛒 Synchronizacja z ${zrodlo}…`);
    let dane;
    try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 30000);
        const r = await fetch(zrodlo, { signal: ctrl.signal });
        clearTimeout(t);
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        dane = await r.json();
    } catch (e) {
        return res.status(502).json({
            success: false,
            message: `Nie pobrałem globalnych ofert: ${e.name === 'AbortError' ? 'przekroczony czas (30s)' : e.message}`,
            zrodlo,
            // ⚠️ otakos.wtf ma fallback SPA: BRAKUJĄCY plik NIE zwraca 404, tylko
            // index.html z kodem 200. Dlatego objawem braku deployu jest błąd
            // parsowania JSON („Unexpected token '<'"), a nie uczciwe 404.
            hint: String(e.message).includes('<')
                ? 'Dostałem HTML zamiast JSON. otakos.wtf ma fallback SPA, więc brakujący plik udaje 200 — to znaczy, że oferty NIE zostały jeszcze wdrożone na stronę.'
                : 'Sprawdź, czy otakos.wtf serwuje /market/oferty.json — plik jedzie z deployem strony.',
        });
    }

    const oferty = Array.isArray(dane?.oferty) ? dane.oferty : null;
    if (!oferty) {
        return res.status(422).json({
            success: false,
            message: 'Pobrany plik nie ma tablicy „oferty" — to nie jest zrzut Marketplace.',
            zrodlo,
        });
    }

    const m = await loadMarket();
    const poId = new Map(m.products.map(p => [p.id, p]));
    let nowych = 0, odswiezonych = 0;

    for (const o of oferty) {
        if (!o?.id || !o?.name) continue;                 // rekord bez kotwicy — pomijamy
        const stary = poId.get(o.id);
        if (stary) {
            // Scalamy OPIS I CENĘ, ale NIE głosy ani daty — te są lokalne.
            stary.name = o.name;
            stary.desc = o.desc ?? stary.desc;
            stary.priceGrv = Number(o.priceGrv) || 0;
            stary.module = o.module || stary.module;
            stary.type = o.type || stary.type;
            stary.creator = o.creator || stary.creator;
            stary.payload = o.payload ?? stary.payload;
            stary.zGlobalnego = true;
            odswiezonych++;
        } else {
            m.products.push({
                id: o.id, module: o.module || 'core', type: o.type || 'item',
                name: o.name, desc: o.desc || '', priceGrv: Number(o.priceGrv) || 0,
                creator: o.creator || 'otakos.wtf', votes: 0,
                createdAt: Date.now(), payload: o.payload ?? null, zGlobalnego: true,
            });
            nowych++;
        }
    }
    await saveMarket();

    await Szyna.nadaj({
        agent: 'kupiec', rodzaj: 'praca',
        tresc: `Synchronizacja z globalnym: ${nowych} nowych, ${odswiezonych} odświeżonych.`,
    });
    console.log(`[Market] 🛒 ${nowych} nowych, ${odswiezonych} odświeżonych (zrzut ${dane.zrzut ?? '?'}).`);

    res.json({
        success: true, zrodlo, nowych, odswiezonych,
        zrzut: dane.zrzut ?? null, wersja: dane.wersja ?? null,
        lacznie: m.products.length,
        uwaga: 'Nic lokalnego nie zostało skasowane — oferta zdjęta z globalnego zostaje w Twoim węźle.',
    });
});

// ── 🔧 KODEKS (Mechanik) — model, dziennik napraw, co wie i gdzie jest ────────
/** GET /api/mechanic/model — czym Mechanik faktycznie mieli. */
app.get('/api/mechanic/model', (req, res) => {
    res.json({
        success: true,
        model: modelMechanika(),
        domyslny: MODEL_DOMYSLNY,
        plik: path.join('_OtakOs_Wymiar', 'mechanik.json'),
    });
});

/** POST /api/mechanic/model {model} — przestaw rdzeń Mechanika (bez restartu mostu). */
app.post('/api/mechanic/model', async (req, res) => {
    const { model } = req.body ?? {};
    if (!model) return res.status(400).json({ success: false, message: 'Brak nazwy modelu.' });

    // Model-widmo sprawdzamy PRZED zapisem — inaczej Mechanik padłby dopiero
    // przy pierwszym zadaniu, w tle, gdzie Suweren tego nie zobaczy.
    try {
        const r = await fetch(`${OLLAMA_BASE}/api/tags`);
        const d = await r.json();
        const sa = (d.models || []).map(m => m.name);
        if (!sa.includes(model)) {
            return res.status(422).json({
                success: false,
                message: `Ollama nie zna modelu „${model}" — nie zapisuję.`,
                dostepne: sa,
            });
        }
    } catch {
        return res.status(503).json({ success: false, message: 'Ollama nie odpowiada — nie mogę sprawdzić modelu.' });
    }

    const ustawiony = ustawModelMechanika(model);
    await Szyna.nadaj({ agent: 'kodeks', rodzaj: 'ustawienie', tresc: `Rdzeń przestawiony na ${ustawiony}.` });
    res.json({ success: true, model: ustawiony });
});

/** GET /api/mechanic/dziennik?plik=&ile= — co Mechanik wdrożył, a co cofnął. */
app.get('/api/mechanic/dziennik', async (req, res) => {
    const wpisy = await Petla.historiaNapraw(req.query.plik || null, Number(req.query.ile) || 30);
    const wdrozone = wpisy.filter(w => w.wynik === 'wdrozone').length;
    const cofniete = wpisy.filter(w => w.wynik === 'cofniete').length;
    res.json({ success: true, wpisy, wdrozone, cofniete });
});

/** GET /api/mechanic/co-wiem — czym Mechanik dysponuje i gdzie to leży. */
app.get('/api/mechanic/co-wiem', async (req, res) => {
    const policz = async (katalog, filtr) => {
        try {
            const w = await fs.readdir(path.join(process.cwd(), katalog));
            return filtr ? w.filter(filtr).length : w.length;
        } catch { return 0; }
    };
    res.json({
        success: true,
        model: modelMechanika(),
        katalogi: {
            latki:   { sciezka: '_OtakOs_Wymiar/patches', ile: await policz('_OtakOs_Wymiar/patches', f => f.endsWith('.md')) },
            migawki: { sciezka: '_OtakOs_Kopie/naprawy',  ile: await policz('_OtakOs_Kopie/naprawy') },
            kopie:   { sciezka: '_OtakOs_Kopie/components', ile: await policz('_OtakOs_Kopie/components') },
        },
        trasy: [
            'GET  /api/mechanic/queue',
            'POST /api/mechanic/apply   (migawka → weryfikacja → cofka)',
            'POST /api/mechanic/reject/:id',
            'GET  /api/mechanic/patch/:id',
            'GET  /api/mechanic/dziennik',
        ],
        zasada: 'Mechanik NIE commituje. Proponuje łatkę, Suweren zatwierdza, pętla weryfikuje i cofa.',
    });
});

// ── 🚌 SZYNA ZDARZEŃ AGENTÓW — fundament WORKPalace i rozmów między TeOgochi ──
app.post('/api/szyna/zdarzenie', async (req, res) => {
    const { agent, rodzaj, tresc, zadanie, dane } = req.body ?? {};
    if (!agent || !tresc) {
        return res.status(400).json({ success: false, message: 'Wymagane: agent oraz tresc.' });
    }
    const z = await Szyna.nadaj({ agent, rodzaj, tresc, zadanie, dane });
    res.json({ success: true, zdarzenie: z });
});

/** GET /api/szyna/zdarzenia?agent=&ile= — ogon dziennika. */
app.get('/api/szyna/zdarzenia', (req, res) => {
    res.json({
        success: true,
        zdarzenia: Szyna.ostatnie({ agent: req.query.agent || null, ile: Number(req.query.ile) || 100 }),
        pracuja: Szyna.ktoPracuje(),
    });
});

/** GET /api/szyna/strumien — SSE. Żywy podgląd dla WORKPalace. */
app.get('/api/szyna/strumien', (req, res) => {
    res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
        'Access-Control-Allow-Origin': '*',
    });
    res.write(': szyna otwarta\n\n');
    const odepnij = Szyna.sluchaj(res);
    // Puls co 25 s — bez niego pośrednicy zamykają bezczynne połączenie.
    const puls = setInterval(() => { try { res.write(': puls\n\n'); } catch { /* zerwane */ } }, 25000);
    req.on('close', () => { clearInterval(puls); odepnij(); });
});

/**
 * POST /api/szyna/pytanie — jeden agent pyta drugiego.
 *
 * Most jest tu ŚWIADOMIE GŁUPIĄ RURĄ: persona i model przychodzą z frontu, bo to
 * tam żyje katalog gatunków (lib/teogochiGatunki.ts). Dublowanie go po stronie
 * mostu skończyłoby się dwoma źródłami prawdy, które się rozjadą.
 * Pytanie i odpowiedź lądują na szynie — WORKPalace widzi rozmowę.
 */
app.post('/api/szyna/pytanie', async (req, res) => {
    const { odKogo, doKogo, pytanie, model, persona } = req.body ?? {};
    if (!odKogo || !doKogo || !pytanie) {
        return res.status(400).json({ success: false, message: 'Wymagane: odKogo, doKogo, pytanie.' });
    }
    const silnik = model || process.env.OTAKOS_MODEL || 'gemma4:e2b';
    await Szyna.nadaj({ agent: odKogo, rodzaj: 'pytanie', tresc: `→ ${doKogo}: ${pytanie}` });

    try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 300000);
        const r = await fetch(`${OLLAMA_BASE}/api/generate`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
            body: JSON.stringify({
                model: silnik,
                system: persona || `Jesteś agentem „${doKogo}" w Katedrze OtakOS. Odpowiadaj po polsku, krótko i konkretnie.`,
                prompt: `Pyta Cię agent „${odKogo}".\n\n${pytanie}`,
                stream: false, options: { temperature: 0.7 },
            }),
        });
        clearTimeout(t);
        if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
        const d = await r.json();
        const odpowiedz = String(d.response || '').trim();
        await Szyna.nadaj({ agent: doKogo, rodzaj: 'odpowiedz', tresc: `→ ${odKogo}: ${odpowiedz}` });
        res.json({ success: true, odpowiedz, model: silnik });
    } catch (e) {
        const powod = e.name === 'AbortError' ? 'Ollama nie zdążyła (300s).' : e.message;
        await Szyna.nadaj({ agent: doKogo, rodzaj: 'blad', tresc: `nie odpowiedział: ${powod}` });
        res.status(500).json({ success: false, message: powod });
    }
});

// ── 🎬 ANIMACJE — wspólny silnik dla App V2 i Story V2 (HyperFrames, Apache 2.0) ──
app.get('/api/animacja/stan', async (req, res) => {
    const s = await stanAnimacji();
    res.json({
        success: true, ...s,
        silnikNazwa: 'HyperFrames (Apache 2.0)',
        telemetria: 'wyłączona na sztywno (HYPERFRAMES_NO_TELEMETRY=1, DO_NOT_TRACK=1)',
        gotowy: s.silnik && s.ffmpeg,
    });
});

/** POST /api/animacja/z-projektu — Body: { projekt, id?, sekundNaElement? }. Projekt = JSON z App V2. */
app.post('/api/animacja/z-projektu', async (req, res) => {
    const { projekt, id, sekundNaElement, szer, wys } = req.body ?? {};
    if (!projekt || !Array.isArray(projekt.elements)) {
        return res.status(400).json({ success: false, message: 'Body musi mieć { projekt: { elements: [...] } }.' });
    }
    try {
        const html = zProjektuAppV2(projekt, { sekundNaElement, szer, wys });
        const w = await renderuj(id || 'projekt-app-v2', html);
        res.json({ success: true, ...w, url: `/api/animacja/plik/${w.id}` });
    } catch (e) {
        console.error('[Animacje] ❌', e.message);
        res.status(500).json({ success: false, message: e.message });
    }
});

/** POST /api/animacja/renderuj — Body: { id, html }. Dla Story V2 i ręcznych kompozycji. */
app.post('/api/animacja/renderuj', async (req, res) => {
    const { id, html } = req.body ?? {};
    if (!html || !String(html).includes('data-composition-id')) {
        return res.status(400).json({
            success: false,
            message: 'Body musi mieć { html } z elementem niosącym data-composition-id.',
        });
    }
    try {
        const w = await renderuj(id || 'kompozycja', String(html));
        res.json({ success: true, ...w, url: `/api/animacja/plik/${w.id}` });
    } catch (e) {
        console.error('[Animacje] ❌', e.message);
        res.status(500).json({ success: false, message: e.message });
    }
});

/** GET /api/animacja/plik/:id — najnowszy MP4 danego projektu, strumieniowo. */
app.get('/api/animacja/plik/:id', async (req, res) => {
    const slug = String(req.params.id).replace(/[^a-z0-9-]/gi, '');
    const katalog = path.join(KATALOG_PROJEKTOW, slug, 'renders');
    try {
        const mp4 = (await fs.readdir(katalog)).filter(w => w.endsWith('.mp4')).sort();
        if (!mp4.length) throw new Error('brak renderu');
        res.type('video/mp4').sendFile(path.join(katalog, mp4[mp4.length - 1]));
    } catch {
        res.status(404).json({ success: false, message: `Brak renderu dla „${slug}".` });
    }
});

// ── 🎨 WIEDZA PROJEKTOWA — korpus wzorców front-endu dla agentów App V2 ──────
// Źródło: greatfrontend/awesome-front-end-system-design (klon w _OtakOs_Wiedza/).
// Czytane deterministycznie, bez modelu i bez sieci — patrz services/WiedzaDesign.js.
app.get('/api/wiedza/design/tematy', async (req, res) => {
    try {
        const tematy = await wczytajKorpus();
        res.json({
            success: true,
            liczba: tematy.length,
            tematy: tematy.map(t => ({
                id: t.id, nazwa: t.nazwa, kategoria: t.kategoria,
                przyklady: t.przyklady, zrodel: t.liczbaZrodel,
            })),
        });
    } catch (e) {
        res.status(404).json({
            success: false,
            message: `Brak korpusu wiedzy projektowej: ${e.message}`,
            hint: `Sklonuj go do ${SCIEZKA_KORPUSU.replace(/README\.md$/, '')}`,
        });
    }
});

/** GET /api/wiedza/design/temat?id=chat-app — pełny wpis ze wszystkimi źródłami. */
app.get('/api/wiedza/design/temat', async (req, res) => {
    try {
        const tematy = await wczytajKorpus();
        const t = tematy.find(x => x.id === String(req.query.id || '').trim());
        if (!t) return res.status(404).json({ success: false, message: 'Nie ma takiego tematu.', dostepne: tematy.map(x => x.id) });
        res.json({ success: true, temat: t, brief: brief(t, 99) });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

/**
 * GET /api/wiedza/design/dopasuj?opis=... — po to istnieje cały ten moduł.
 * Agent App V2 pyta „co Suweren chce zbudować", a most oddaje gotowy brief
 * do wstrzyknięcia w instrukcję systemową. Zero tokenów po drodze.
 */
app.get('/api/wiedza/design/dopasuj', async (req, res) => {
    const opis = String(req.query.opis || '').trim();
    if (!opis) return res.status(400).json({ success: false, message: 'Podaj ?opis=…' });
    try {
        const trafienia = await dopasuj(opis, Number(req.query.ile) || 2);
        res.json({
            success: true,
            opis,
            trafienia: trafienia.map(t => ({
                id: t.temat.id, nazwa: t.temat.nazwa, kategoria: t.temat.kategoria,
                punkty: t.punkty, zrodel: t.temat.liczbaZrodel, brief: brief(t.temat, 6),
            })),
            // Uczciwie: brak trafienia to normalny wynik, nie awaria.
            brief: trafienia.length ? trafienia.map(t => brief(t.temat, 6)).join('\n\n') : '',
        });
    } catch (e) {
        res.status(500).json({ success: false, message: e.message });
    }
});

// ── 🧰 SKILLE ZEWNĘTRZNE — instalacja WYŁĄCZNIE z białej listy ────────────────
//
// Suweren chce mówić do konsoli „Klaudi, zainstaluj to repro" i mieć skill.
// Wygodne — i dlatego niebezpieczne: czat wystawiony Kwantowym Tunelem na telefon
// stałby się przyciskiem „uruchom dowolny kod z internetu na maszynie Suwerena".
//
// DLATEGO: czat NIE PODAJE adresu. Czat podaje IDENTYFIKATOR z białej listy.
// Adres repo i DOKŁADNA komenda instalacyjna są wpisane w pliku po stronie dysku,
// który zmienia tylko Suweren. Nieznane id = odmowa z powodem, zero klonowania.
//
// Biała lista: _OtakOs_Wymiar/skille-biala-lista.json
const SKILLE_LISTA = path.join(process.cwd(), '_OtakOs_Wymiar', 'skille-biala-lista.json');
// UWAGA: to NIE jest SKILLE_DIR z linii ~5187. Tamten to TeO_Skille — własne
// skille Katedry. Ten wskazuje katalog skilli Claude Code w domu Suwerena.
const CC_SKILLE_DIR = path.join(os.homedir(), '.claude', 'skills');

/** Wpisy fabryczne — używane, gdy pliku jeszcze nie ma. */
const SKILLE_DOMYSLNE = [
    {
        id: 'gstack',
        nazwa: 'gstack (Garry Tan)',
        repo: 'https://github.com/garrytan/gstack.git',
        setup: './setup --host claude --prefix',
        wymaga: ['git', 'bun'],
        opis: '53 komendy /gstack-* dla Claude Code: przegląd kodu, QA, wydania, planowanie.',
    },
];

async function wczytajBialaListe() {
    try {
        const s = await fs.readFile(SKILLE_LISTA, 'utf8');
        const d = JSON.parse(s);
        return Array.isArray(d.skille) ? d.skille : SKILLE_DOMYSLNE;
    } catch {
        return SKILLE_DOMYSLNE;
    }
}

/**
 * Skrypty setup skilli to bash, a execAsync na Windowsie idzie przez cmd.exe,
 * który na „./setup" odpowiada „'.' is not recognized". Zmierzone, nie zgadnięte.
 * Szukamy więc basha: najpierw w PATH, potem obok gita (Git for Windows go wozi).
 */
async function znajdzBash() {
    if (process.platform !== 'win32') return null;      // POSIX odpala skrypt wprost
    try {
        await execAsync('bash --version', { timeout: 8000, windowsHide: true });
        return 'bash';
    } catch { /* brak w PATH — szukamy dalej */ }
    try {
        const { stdout } = await execAsync('git --exec-path', { timeout: 8000, windowsHide: true });
        // …/Git/mingw64/libexec/git-core → …/Git/bin/bash.exe
        const korzen = path.resolve(stdout.trim(), '..', '..', '..');
        const kandydat = path.join(korzen, 'bin', 'bash.exe');
        await fs.access(kandydat);
        return `"${kandydat}"`;
    } catch { /* nie ma */ }
    return null;
}

/** GET /api/skille/biala-lista — co Suweren dopuścił do instalacji. */
app.get('/api/skille/biala-lista', async (req, res) => {
    const skille = await wczytajBialaListe();
    res.json({
        success: true,
        skille,
        plik: SKILLE_LISTA,
        uwaga: 'Instalowane są WYŁĄCZNIE te pozycje. Nowe repo dopisuje Suweren do tego pliku — nie czat.',
    });
});

/** GET /api/skille/zainstalowane — co realnie leży na dysku (nie co obiecano). */
app.get('/api/skille/zainstalowane', async (req, res) => {
    try {
        const wpisy = await fs.readdir(CC_SKILLE_DIR, { withFileTypes: true });
        res.json({ success: true, katalog: CC_SKILLE_DIR, skille: wpisy.filter(w => w.isDirectory()).map(w => w.name) });
    } catch (e) {
        res.json({ success: true, katalog: CC_SKILLE_DIR, skille: [], message: `Katalog skilli nie istnieje jeszcze (${e.code}).` });
    }
});

/**
 * POST /api/skille/instaluj — Body: { id }.
 * Klonuje i uruchamia setup TYLKO dla pozycji z białej listy.
 */
app.post('/api/skille/instaluj', async (req, res) => {
    const id = String((req.body ?? {}).id || '').trim().toLowerCase();
    const skille = await wczytajBialaListe();
    const wpis = skille.find(s => s.id === id);

    if (!wpis) {
        return res.status(403).json({
            success: false,
            message: `„${id || '(puste)'}" nie jest na białej liście — nie instaluję.`,
            hint: `Dopuszczone: ${skille.map(s => s.id).join(', ') || '(lista pusta)'}. `
                + `Nowe repo dopisz ręcznie do ${SKILLE_LISTA} — czat nie może tego zrobić za Ciebie i to jest celowe.`,
            dopuszczone: skille.map(s => s.id),
        });
    }

    // Narzędzia sprawdzamy PRZED klonowaniem — inaczej zostaje 40MB śmieci
    // i setup, który i tak wyjdzie z błędem w pięćdziesiątej linii.
    for (const narzedzie of wpis.wymaga || []) {
        try { await execAsync(`${narzedzie} --version`, { timeout: 10000, windowsHide: true }); }
        catch {
            return res.status(412).json({
                success: false,
                message: `Brak „${narzedzie}" w PATH — instalacja „${wpis.id}" nie ruszy.`,
                hint: narzedzie === 'bun' ? 'Zainstaluj: npm install -g bun' : `Zainstaluj ${narzedzie} i spróbuj ponownie.`,
            });
        }
    }

    const cel = path.join(CC_SKILLE_DIR, wpis.id);
    console.log(`[Skille] 📦 Instaluję „${wpis.id}" z ${wpis.repo} → ${cel}`);

    try {
        await fs.mkdir(CC_SKILLE_DIR, { recursive: true });
        // Nie każdy skill to repo do sklonowania. graphify jedzie z PyPI przez pipx
        // i sam się rejestruje — wpis bez pola `repo` znaczy „tylko uruchom setup".
        let klon = '(brak — wpis bez repo, sam setup)';
        if (wpis.repo) {
            await fs.rm(cel, { recursive: true, force: true });
            ({ stdout: klon } = await execAsync(
                `git clone --single-branch --depth 1 ${wpis.repo} "${cel}"`,
                { timeout: 600000, windowsHide: true },
            ));
        }
        const bash = await znajdzBash();
        if (process.platform === 'win32' && !bash) {
            return res.status(412).json({
                success: false, id: wpis.id,
                message: 'Nie znalazłem basha — skrypt setup nie ma czym się uruchomić.',
                hint: 'Zainstaluj Git for Windows (wozi bash.exe) albo dodaj bash do PATH.',
            });
        }
        const komenda = bash ? `${bash} -lc "${wpis.setup.replace(/"/g, '\\"')}"` : wpis.setup;
        // Wpisy bez `repo` odpalamy w KATEDRZE, nie w katalogu skilli — dzięki temu
        // ich setup może wołać skrypty instalacyjne trzymane w _OtakOs_Wymiar/skille/.
        const { stdout, stderr } = await execAsync(komenda, {
            cwd: wpis.repo ? cel : process.cwd(),
            timeout: 900000, windowsHide: true, maxBuffer: 10 * 1024 * 1024,
        });
        const ogon = (s) => String(s || '').split('\n').slice(-25).join('\n');
        console.log(`[Skille] ✅ „${wpis.id}" zainstalowany.`);
        res.json({
            success: true,
            id: wpis.id,
            katalog: wpis.repo ? cel : CC_SKILLE_DIR,
            klon: ogon(klon),
            setup: ogon(stdout),
            ostrzezenia: ogon(stderr),
            uwaga: 'Skille Claude Code ładują się przy starcie sesji — odpal Claude na nowo, żeby je zobaczyć.',
        });
    } catch (e) {
        console.error(`[Skille] ❌ „${wpis.id}": ${e.message}`);
        res.status(500).json({
            success: false,
            id: wpis.id,
            message: `Instalacja „${wpis.id}" padła: ${e.message}`,
            wyjscie: String(e.stdout || '').split('\n').slice(-20).join('\n'),
            blad: String(e.stderr || '').split('\n').slice(-20).join('\n'),
        });
    }
});

app.post('/api/mcp/add-custom', async (req, res) => {
    try {
        const customSkill = req.body || {};
        const reg = await loadMcpRegistry();
        reg.customSkills = reg.customSkills || [];
        reg.customSkills.push(customSkill);
        if (!reg.activeSkills.includes(customSkill.id)) {
            reg.activeSkills.push(customSkill.id);
        }
        await saveMcpRegistry(reg);
        return res.json({ success: true, skill: customSkill });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

// ── ⚡ DEEPSEEK-HARNESS & MULTI-FRAME ROUTES ─────────────────────────────────
app.post('/api/harness/run', async (req, res) => {
    try {
        const { goal, frame, model, maxIterations, smartRalphMode } = req.body || {};
        if (!goal) {
            return res.status(400).json({ success: false, message: 'Brak celu zadania (goal).' });
        }
        const result = await deepseekHarness.runHarness({ goal, frame, model, maxIterations, smartRalphMode });
        return res.json(result);
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

const handleHarnessStatus = (req, res) => {
    try {
        const runId = req.params.runId;
        const status = deepseekHarness.getStatus(runId);
        if (!status) {
            return res.status(404).json({ success: false, message: 'Nie znaleziono przebiegu harness.' });
        }
        return res.json({ success: true, run: status });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
};
app.get('/api/harness/status', handleHarnessStatus);
app.get('/api/harness/status/:runId', handleHarnessStatus);

const handleHarnessCancel = (req, res) => {
    try {
        const runId = req.params.runId;
        const ok = deepseekHarness.cancelRun(runId);
        return res.json({ success: ok, message: ok ? 'Przebieg anulowany.' : 'Brak aktywnego przebiegu do anulowania.' });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
};
app.post('/api/harness/cancel', handleHarnessCancel);
app.post('/api/harness/cancel/:runId', handleHarnessCancel);

app.get('/api/harness/frames', (req, res) => {
    try {
        return res.json({ success: true, ...deepseekHarness.getFrames() });
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

app.post('/api/harness/frame/switch', (req, res) => {
    try {
        const { frame } = req.body || {};
        const result = deepseekHarness.switchFrame(frame);
        return res.json(result);
    } catch (e) {
        return res.status(500).json({ success: false, message: e.message });
    }
});

// ── TASK COMPLETION HANDLER ──────────────────────────────────────────────────
/**
 * NOWA LOGIKA: Zamiast wywoływania processKnowledgeGraph(task),
 * emitujemy zdarzenie, które zostanie obsłużone przez wewnętrzną kolejkę Service.
 */
function handleTaskCompletion(completedTask) {
    if (completedTask && completedTask.status === 'DONE') {
        // DECOUPLING: Zamiast blokować wątek główny, dodajemy zadanie do kolejki Archiwisty.
        KnowledgeGraphService.getInstance().emitTaskDoneEvent(completedTask);
    }
}

const httpServer = app.listen(PORT, () => {
    console.log(`================================================`);
    console.log(` 🔌 Wiesław nasłuchuje na porcie ${PORT}`);
    console.log(`================================================`);
    console.log(` 📦 WRITE_FILE | READ_FILE | LIST_DIRECTORY`);
    console.log(` 🎵 GET_LOCAL_PLAYLIST | GET /music/* (stream)`);
    console.log(` ⚡ EXEC_OLLAMA_CLI — Lokalny LLM przez Ollama CLI`);
    console.log(` ⬇️ PULL_MODEL — Pobieranie modeli w tle`);
    console.log(` 🔧 MechanicService — Agent Mechanik (co 3 min)`);
    console.log(` 🕸️  KnowledgeGraphService — Archiwista Wiedzy`);
    console.log(`================================================`);
    console.log(` 👉 Muzyka: _OtakOs_Muzyka/`);
    console.log(` 🛰️  CORS: każdy origin (Kwantowy Tunel). Kanały lokalne: ${KNOWN_ORIGINS.length}`);
    console.log(` 🧠 LLM: POST /api/bridge/execute`);
    console.log(` 🧠 POST /api/claude  ← Claude proxy (SSE)`);
    console.log(` 🔵 POST /api/gemini  ← Gemini proxy (SSE)`);
    console.log(` 🎨 MCP_UI_BUILD      ← gotowy do akcji!`);
    console.log(` ⚡ EXEC_SYSTEM — Surowy Terminal (Raw Exec)`);
    console.log(` 🔧 GET  /api/mechanic/queue`);
    console.log(` 🔧 POST /api/mechanic/enqueue`);
    console.log(` 🔧 GET  /api/mechanic/patch/:id`);
    console.log(` 🔧 POST /api/mechanic/apply`);
    console.log(` 🔧 POST /api/mechanic/reject/:id`);
    console.log(` 🕸️  GET  /api/kg/nodes`);
    console.log(` ☢️  POST /api/chaos/inject`);
    console.log(`================================================`);

    // ── 🔧 Agent Mechanik — skan kolejki co 3 minuty ─────────────────────
    // Lock (_isRunning) w MechanicService gwarantuje brak nakładania wywołań.
    const MECHANIC_INTERVAL_MS = 180_000; // 3 minuty
    setInterval(async () => {
        await MechanicService.getInstance().processPendingTasks();
    }, MECHANIC_INTERVAL_MS);

    console.log(`[Mechanik] ⏰ Harmonogram: processPendingTasks() co ${MECHANIC_INTERVAL_MS / 1000}s.`);

    // ── 🎙️ Agent Impresario — procesor zadań co 15 sekund ────────────────
    // Szybszy interwał bo to symulacja — widoczny postęp na dashboardzie.
    const IMPRESARIO_INTERVAL_MS = 15_000; // 15 sekund
    setInterval(async () => {
        await ImpresarioService.getInstance().processNextJob();
    }, IMPRESARIO_INTERVAL_MS);

    console.log(`[Impresario] ⏰ Harmonogram: processNextJob() co ${IMPRESARIO_INTERVAL_MS / 1000}s.`);
    console.log(` 🎙️  GET  /api/impresario/status`);
    console.log(` 🎙️  GET  /api/impresario/queue`);
    console.log(` 🎙️  POST /api/impresario/enqueue         (filePath wymagane)`);
    console.log(` 🎙️  POST /api/impresario/upload/:id       (YouTube OAuth2 streaming)`);
    console.log(` 🎙️  POST /api/impresario/export/spotify/:id (DistroKid paczka)`);
    console.log(` 🎙️  POST /api/impresario/vault/update`);
    console.log(` 💬  GET  /api/tost/messages                (Historia zaszyfrowana)`);
    console.log(` 💬  POST /api/tost/send                   (Wyślij → Gemma4 LOCAL TeO)`);
    console.log(` 💬  DELETE /api/tost/messages             (Wyczyść historię)`);
    console.log(` 🔗  POST /api/tost/p2p/init               (Generuj Szmaragdowy Token)`);
    console.log(` 🔗  GET  /api/tost/p2p/stream/:token      (SSE Tunel P2P)`);
    console.log(` 🔗  POST /api/tost/p2p/message/:token     (Relay wiadomości P2P)`);
    console.log(` 🧽  POST /api/laundry/sanitize            (Pralka: EXIF/ICC/XMP scrubber)`);
    console.log(` 🏛️  POST /api/agent/rada-decompose        (Rada: dekompozycja → sesja izolowana)`);
    console.log(` 🤖  GET  /api/auth/google                  (OAuth2 placeholder)`);
    console.log(` 🤖  POST /api/impresario/secrets/youtube   (Zapis kluczy API)`);
    console.log(` 🤖  POST /api/auth/google/simulate         (Gemini Agent stub)`);
    console.log(` 🎥  WS   /api/rtmp-relay                   (Katedra → ffmpeg → RTMP/YouTube)`);
    console.log(` 🔴  WS   /api/recorder                     (Katedra → plik .webm na dysku)`);
    console.log(` 🎥  GET  /api/studio/status | POST /api/studio/rtmp-key`);
    console.log(` 🏢  GET  /api/business/list                (Twoje Biznesy: karty + bilans GRV)`);
    console.log(` 🏢  POST /api/business/create | PATCH/DELETE /api/business/:id`);
    console.log(` 💰  POST /api/business/sluzba              (Służba → Oddech → GRV z pieczęcią)`);
    console.log(` 📜  GET  /api/business/ledger              (Live Orders: księga zdarzeń)`);
    console.log(` ☎️   GET  /api/business/telefonia           (czy przewód Twilio jest DROŻNY)`);
    console.log(` ☎️   POST /api/business/dial                (domyślnie PRÓBA; realne = proba:false + potwierdzenie:true)`);
    console.log(` 🎙️  GET  /api/voice/profiles | POST | DELETE /api/voice/profiles/:id`);
    console.log(` 🔌  GET  /api/voice/mcp                    (przewody Voice/Audio: podpiety vs sterownik)`);
    console.log(` 🗣️  POST /api/voice/speak                  (klon lokalny | Kokoro | ElevenLabs)`);
    console.log(` 💾  POST /api/voice/render                 (mowa → plik w _OtakOs_Voice/)`);
    console.log(` 🧬  GET  /api/voice/elevenlabs/glosy        (lista głosów konta ElevenLabs)`);
    console.log(` 🌀  GET/POST/DELETE /api/tunel             (Kwantowy Tunel — publiczny adres)`);
    console.log(` 🔴  WS   /api/voice/stream                 (rozmowa dwustronna, Twilio Media Streams)`);
    console.log(` 📡  GET  /api/voice/live                   (SSE: transkrypcja, latencja, GRV)`);
    console.log(` ✋  POST /api/voice/live/:callSid/przejmij | /oddaj | /rozlacz`);
    console.log(` 📞  POST /api/voice/incoming               (webhook Twilio — podpis WYMAGANY)`);

    // 🛡️ Strażnik VRAM - Tacos Guard
    initTacosGuard();

    // 🚌 Szyna: wczytujemy ogon dziennika, żeby WORKPalace po restarcie mostu
    // nie zaczynał od pustki i nie sugerował, że agenci nic nigdy nie robili.
    Szyna.wczytajOgon().then(ile => {
        if (ile) console.log(`[Szyna] 🚌 Wczytano ${ile} zdarzeń z dziennika.`);
        else console.log('[Szyna] 🚌 Dziennik pusty — czekam na pierwszy meldunek agenta.');
    });
});

// ── 🎥 STUDIO — kanały WebSocket wpięte w ten sam serwer HTTP ────────────────
// /api/rtmp-relay → ffmpeg → RTMP (koniec głuchoty transmisji)
// /api/recorder   → fizyczny plik .webm na dysku Suwerena
attachStudioRelay(httpServer, { ffmpegPath });
// 🔴 Rozmowa dwustronna — /api/voice/stream (Twilio Media Streams, Etap 3)
attachLiveAudio(httpServer, ZALEZNOSCI_ROZMOWY);
attachGoscStudio(httpServer);

// ⚠️ STRAŻNIK GNIAZD NICZYICH — MUSI być wpięty JAKO OSTATNI.
// Node woła WSZYSTKIE nasłuchy 'upgrade', więc żaden z serwisów nie może
// niszczyć „nieznanych" ścieżek — zabiłby kanał sąsiada (dokładnie to robił
// StudioRelay z kanałem gościa). Każdy serwis oznacza swoje żądanie flagą,
// a tutaj sprzątamy tylko to, czego nikt nie przygarnął.
httpServer.on('upgrade', (req, socket) => {
    if (!req.__wsObsluzone) {
        console.warn(`[WS] ⛔ Gniazdo bez właściciela: ${req.url}`);
        socket.destroy();
    }
});
