import unreal

def materialize_genesis_override():
    # Subsystems
    actor_subsystem = unreal.EditorActorSubsystem()
    
    # 1. Setup World: Darkness (Cyber-Zodiac)
    # Find and disable Directional Light (Sun)
    all_actors = unreal.EditorLevelLibrary.get_all_level_actors()
    for actor in all_actors:
        if actor.get_class().get_name() == 'DirectionalLight':
            light_comp = actor.get_component_by_class(unreal.DirectionalLightComponent)
            if light_comp:
                light_comp.set_intensity(0.0)

    # 2. Neon Materialization (0.00G Glow)
    # Neon 1: Mystic Violet
    neon_violet = actor_subsystem.spawn_actor_from_class(unreal.PointLight, unreal.Vector(-200, 200, 100))
    violet_comp = neon_violet.get_component_by_class(unreal.PointLightComponent)
    violet_comp.set_light_color(unreal.LinearColor(0.5, 0.0, 1.0, 1.0))
    violet_comp.set_intensity(5000.0)

    # Neon 2: Digital Cyan
    neon_cyan = actor_subsystem.spawn_actor_from_class(unreal.PointLight, unreal.Vector(200, -200, 100))
    cyan_comp = neon_cyan.get_component_by_class(unreal.PointLightComponent)
    cyan_comp.set_light_color(unreal.LinearColor(0.0, 1.0, 1.0, 1.0))
    cyan_comp.set_intensity(5000.0)

    # 3. Constructor's Desk (Terminal)
    desk = actor_subsystem.spawn_actor_from_class(unreal.Cube, unreal.Vector(0, 0, 0))
    unreal.EditorLevelLibrary.set_actor_scale(desk, unreal.Vector(2.0, 1.0, 0.75))
    
    # Terminal Text (TextRender)
    terminal_text = actor_subsystem.spawn_actor_from_class(unreal.TextRenderActor, unreal.Vector(0, 0, 120))
    text_comp = terminal_text.get_component_by_class(unreal.TextRenderComponent)
    text_comp.set_text("KATEDRA OtakOS – Wymiar 0.00G (V_ZERO)")
    text_comp.set_text_color(unreal.Color(0, 1, 1))

    # 4. TeO Trust Tablets (Monumental Parchments)
    trust_text = "Ósemka na boku to nieskończoność Energu Źródła (8=∞). Energia Służy, nie panuje."
    tablet = actor_subsystem.spawn_actor_from_class(unreal.TextRenderActor, unreal.Vector(500, 0, 150))
    tablet_comp = tablet.get_component_by_class(unreal.TextRenderComponent)
    tablet_comp.set_text(trust_text)
    tablet_comp.set_text_color(unreal.Color(1, 0, 0)) # Red Seal SHA-256
    tablet_comp.set_world_rotation(unreal.Rotator(0, 90, 0))

    # 5. AETHER & NeuralMap (Floating Nodes)
    for i in range(5):
        node = actor_subsystem.spawn_actor_from_class(unreal.Sphere, unreal.Vector(i*100 - 200, 0, 500))
        unreal.EditorLevelLibrary.set_actor_scale(node, unreal.Vector(0.2, 0.2, 0.2))
        # Add glow to node
        node_light = actor_subsystem.spawn_actor_from_class(unreal.PointLight, node.get_actor_location())
        node_light.get_component_by_class(unreal.PointLightComponent).set_light_color(unreal.LinearColor(0, 1, 1, 1))

    # 6. The Golden Toast (Interdimensional Portal)
    toast = actor_subsystem.spawn_actor_from_class(unreal.Cube, unreal.Vector(0, 0, 1000))
    unreal.EditorLevelLibrary.set_actor_scale(toast, unreal.Vector(1.0, 0.5, 0.3))
    # Gold color simulation via light
    toast_light = actor_subsystem.spawn_actor_from_class(unreal.PointLight, toast.get_actor_location())
    toast_light.get_component_by_class(unreal.PointLightComponent).set_light_color(unreal.LinearColor(1.0, 0.84, 0.0, 1.0))

    # Save Project (Simulated Ctrl+S)
    unreal.EditorSavingLibrary.save_current_level()

materialize_genesis_override()