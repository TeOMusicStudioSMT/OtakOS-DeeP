import unreal

def materialize_genesis_override():
    # Subsystems
    actor_subsystem = unreal.EditorActorSubsystem()
    
    # 1. DARKNESS: Kill the daylight
    all_actors = unreal.EditorLevelLibrary.get_all_level_actors()
    for actor in all_actors:
        if isinstance(actor, unreal.DirectionalLight):
            actor.set_actor_label("Sun_Disabled")
            component = actor.get_component_by_class(unreal.LightComponent)
            component.set_editor_property('intensity', 0.0)

    # 2. NEONS: Materialize Cyber-Zodiac Lights
    # Neon 1: Mystic Violet
    neon_violet = actor_subsystem.spawn_actor_from_class(unreal.PointLight, unreal.Vector(200, 200, 100))
    neon_violet.set_actor_label("Neon_Violet_00G")
    comp_v = neon_violet.get_component_by_class(unreal.PointLightComponent)
    comp_v.set_editor_property('light_color', unreal.Color(0.5, 0.0, 1.0, 1.0))
    comp_v.set_editor_property('intensity', 5000.0)

    # Neon 2: Digital Cyan
    neon_cyan = actor_subsystem.spawn_actor_from_class(unreal.PointLight, unreal.Vector(-200, -200, 100))
    neon_cyan.set_actor_label("Neon_Cyan_00G")
    comp_c = neon_cyan.get_component_by_class(unreal.PointLightComponent)
    comp_c.set_editor_property('light_color', unreal.Color(0.0, 1.0, 1.0, 1.0))
    comp_c.set_editor_property('intensity', 5000.0)

    # 3. FOUNDATIONS: Constructor's Desk & Terminal (Represented by Cubes/Text)
    desk = actor_subsystem.spawn_actor_from_class(unreal.StaticMeshActor, unreal.Vector(0, 0, 0))
    desk.set_actor_label("Desk_Constructor")
    
    terminal_text = actor_subsystem.spawn_actor_from_class(unreal.TextRenderActor, unreal.Vector(0, 0, 80))
    terminal_text.set_actor_label("Terminal_OtakOS")
    terminal_text.set_editor_property('text', "KATEDRA OtakOS – Wymiar 0.00G (V_ZERO)")

    # 4. TRUST VAULT: Monumental Tablets
    trust_tablet = actor_subsystem.spawn_actor_from_class(unreal.TextRenderActor, unreal.Vector(500, 0, 150))
    trust_tablet.set_actor_label("Trust_Tablet_SHA256")
    trust_tablet.set_editor_property('text', "8=∞. Energia Służy, nie panuje.")
    trust_tablet.set_editor_property('text_color', unreal.Color(1.0, 0.0, 0.0, 1.0))

    # 5. AETHER: NeuralMap & Golden Toast
    neural_map = actor_subsystem.spawn_actor_from_class(unreal.PointLight, unreal.Vector(0, 0, 1000))
    neural_map.set_actor_label("NeuralMap_AGI")
    comp_n = neural_map.get_component_by_class(unreal.PointLightComponent)
    comp_n.set_editor_property('light_color', unreal.Color(0.0, 1.0, 1.0, 1.0))
    comp_n.set_editor_property('intensity', 10000.0)

    golden_toast = actor_subsystem.spawn_actor_from_class(unreal.StaticMeshActor, unreal.Vector(1000, 1000, 1200))
    golden_toast.set_actor_label("Golden_Toast_Portal")

    # Save Action
    unreal.EditorLevelLibrary.save_current_level()

materialize_genesis_override()