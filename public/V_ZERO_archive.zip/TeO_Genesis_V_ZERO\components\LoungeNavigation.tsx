/**
 * 🧭 LoungeNavigation.tsx
 *
 * Główny pasek nawigacji TeOnauta.
 * 5 pierwszoplanowych przycisków + schowany panel "Więcej (...)"
 * z glassmorphism dropdownem dla rzadziej używanych sekcji.
 *
 * @author BoB & TeO
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MoreHorizontal, EyeOff } from 'lucide-react';
import {
    ChartBarIcon,
    AppIcon,
    UserCircleIcon,
    MortarBoardIcon,
    ShieldCheckIcon,
    MarketIcon,
    WalletIcon,
    BrainChipIcon,
    TrophyIcon,
} from './icons';
import { useAtomValue } from 'jotai';
import { resonanceColorAtom, RESONANCE_THEMES } from '../store/personalization';
import { cn } from '../lib/helpers';
import { canAccess, currentTier, requiredPillar } from '../lib/tiers';

type View =
    | 'dashboard'
    | 'projects'
    | 'teo-market'
    | 'identity'
    | 'academy'
    | 'field-control'
    | 'profile'
    | 'graviton-wallet'
    | 'cobots'
    | 'kuznia'
    | 'crew-club'
    | 'teolab'
    | 'robotics'
    | 'sonic'
    | 'kancelaria'
    | 'trust'
    | 'pralka'
    | 'kompas'
    | 'mcp-skillboard'
    | 'twoje-biznesy';

interface LoungeNavigationProps {
    activeView: View;
    onViewChange: (view: View) => void;
    onToggleZen?: () => void;
}

// ── 5 głównych pozycji zawsze widocznych ──────────────────────────────
// ⚠️ Klub i GRAVITON ZESZŁY z paska (żyją dalej w panelu „Więcej"). Ich miejsca
// zajęły: Tryb Zen — bo używa się go często, a był schowany trzy kliknięcia głębiej —
// oraz TeOgochi, czyli dawne Co-Bots. Pasek ma 5 miejsc i to są te, po które
// Suweren sięga najczęściej.
const PRIMARY_NAV: { id: View; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard',  label: 'Dashboard',  icon: <ChartBarIcon /> },
    { id: 'projects',   label: 'Universes',  icon: <AppIcon /> },
    { id: 'cobots',     label: '🥚 TeOgochi', icon: <BrainChipIcon /> },
    { id: 'teo-market', label: 'TeO Market', icon: <MarketIcon /> },
];

// ── Pozycje schowane w panelu "Więcej" ────────────────────────────────
/**
 * ⚠️ MENU „…" W GRUPACH, NIE JEDNA ŚCIANA (2026-09-11). Szesnaście pozycji bez
 * porządku — Suweren: „przejrzyj menu, zobacz, które panele pasują do działu-kafelka;
 * jak pasują, to tam je przenieś, a jak już tam są, to usuń z menu; resztę spiąć w grupy".
 *
 * Wypadło: „TeO Arcade Forge" — Games Studio ma już własny Forge (Multi-Engine), a to,
 * czego mu brakowało („Wykuj świat": plan craftu, zasilenie wyspy, skrypt UE z modelu),
 * przejechało tam jako zakładka. Hubowa kopia wpinała jeszcze Reżysera i Księgarnię
 * Skilli, które mają swoje domy w Story i Marketplace — tych nie przenosiliśmy.
 *
 * Grupa „Działy w budowie" to poczekalnia: Twoje Biznesy, giełda, Ted Trader,
 * Kupiec i biznesowe Oko pójdą do planowanego Freedom Studio; Kolektor Soniczny
 * czeka na Music V2, który go jeszcze nie ma.
 */
type GrupaMenu = 'departamenty' | 'sciezka' | 'ekonomia' | 'rdzen';

const GRUPY: { id: GrupaMenu; nazwa: string }[] = [
    { id: 'departamenty', nazwa: 'Działy w budowie' },
    { id: 'sciezka',      nazwa: 'Tożsamość i ścieżka' },
    { id: 'ekonomia',     nazwa: 'Ekonomia GRV' },
    { id: 'rdzen',        nazwa: 'Rdzeń i tarcza' },
];

const MORE_NAV: { id: View; label: string; icon: React.ReactNode; desc: string; grupa: GrupaMenu }[] = [
    // ── Działy w budowie — kandydaci do własnych kafelków ──
    { id: 'twoje-biznesy', label: '🏢 TWOJE BIZNESY', icon: <span className="text-base">🏢</span>, desc: 'Rejestr działalności, głos agentów, Służba w GRV → Freedom Studio', grupa: 'departamenty' },
    { id: 'sonic',         label: 'Kolektor Soniczny', icon: <span className="text-base">🎼</span>, desc: 'Zbiór wektorów z własnej muzyki (Filar I)', grupa: 'departamenty' },
    { id: 'teolab',        label: 'TeO Lab',        icon: <span className="text-base">🧪</span>, desc: 'Symulator Agro i pipeline RadioSMT (Filar II)', grupa: 'departamenty' },
    { id: 'robotics',      label: 'OtakOS Robotics', icon: <span className="text-base">🚜</span>, desc: 'Garaż: Agro Traktorek i flota (Filar II)', grupa: 'departamenty' },
    // ── Tożsamość i ścieżka ──
    { id: 'identity',      label: 'Identity',      icon: <UserCircleIcon />,  desc: 'Karta tożsamości Suwerena', grupa: 'sciezka' },
    { id: 'trust',         label: 'TeO Trust',      icon: <span className="text-base">🏛️</span>, desc: 'Certyfikat Beneficjenta — punkt startowy', grupa: 'sciezka' },
    { id: 'kompas',        label: 'Kompas Suwerena', icon: <span className="text-base">🧭</span>, desc: 'Mapa gry Odkrywania — od Karmy do Miłości 2.0', grupa: 'sciezka' },
    { id: 'pralka',        label: 'Pralka Kompasji', icon: <span className="text-base">🤍</span>, desc: 'Sumienie energetyczne — uzdrawia, nie karze (Filar I)', grupa: 'sciezka' },
    { id: 'academy',       label: 'Academy',        icon: <MortarBoardIcon />, desc: 'Quantum Compass & nauka', grupa: 'sciezka' },
    { id: 'crew-club',     label: '🏆 Klub',        icon: <TrophyIcon />,      desc: 'Załoga, rankingi i wspólne wyprawy', grupa: 'sciezka' },
    // ── Ekonomia ──
    { id: 'graviton-wallet', label: 'GRAVITON',     icon: <WalletIcon />,      desc: 'Portfel GRV — saldo, księga, oddech', grupa: 'ekonomia' },
    // ── Rdzeń i tarcza ──
    { id: 'kuznia',        label: '🔨 KUŹNIA MODELI', icon: <span className="text-base">🔨</span>, desc: 'Wagi z dysku → rdzeń w Ollamie, ze ścieżką zadania', grupa: 'rdzen' },
    { id: 'mcp-skillboard',label: '⚡ MCP SKILLBOARD', icon: <span className="text-base font-bold text-cyan-400">⚡</span>, desc: 'Centralny rejestr skilli i narzędzi MCP (0.00G Protocol)', grupa: 'rdzen' },
    { id: 'field-control', label: 'Field Control',  icon: <ShieldCheckIcon />, desc: 'Tarcza Pola i bezpieczeństwo', grupa: 'rdzen' },
    { id: 'kancelaria',    label: 'Kancelaria 0.00G', icon: <span className="text-base">⚖️</span>, desc: 'Tarcza prawna: licencje, prawa, zgodność (Filar II)', grupa: 'rdzen' },
];

// ── Komponent ─────────────────────────────────────────────────────────
export const LoungeNavigation: React.FC<LoungeNavigationProps> = ({
    activeView,
    onViewChange,
    onToggleZen,
}) => {
    const resonanceColor = useAtomValue(resonanceColorAtom);
    const theme = RESONANCE_THEMES[resonanceColor];
    const tier = currentTier(); // 🏛️ FILAR — bramkuje dostęp do widoków

    const [isMoreOpen, setIsMoreOpen] = useState(false);
    const moreRef = useRef<HTMLDivElement>(null);

    // Zamknij dropdown po kliknięciu poza nim
    useEffect(() => {
        const handleOutside = (e: MouseEvent) => {
            if (moreRef.current && !moreRef.current.contains(e.target as Node)) {
                setIsMoreOpen(false);
            }
        };
        if (isMoreOpen) document.addEventListener('mousedown', handleOutside);
        return () => document.removeEventListener('mousedown', handleOutside);
    }, [isMoreOpen]);

    // Czy aktywny widok jest schowany w "Więcej"?
    const isMoreActive = MORE_NAV.some(item => item.id === activeView);

    const handleMoreItemClick = (view: View) => {
        onViewChange(view);
        setIsMoreOpen(false);
    };

    return (
        <nav className="relative z-[100] mb-6 w-full max-w-5xl mx-auto flex items-center justify-center gap-1 md:gap-1.5 p-2 bg-slate-900/60 border border-slate-700/50 rounded-full backdrop-blur-lg">

            {/* ── Godło FILARU ──────────────────────────────────────── */}
            <div title={`${tier.name.pl} · ${tier.title.pl}`}
                className="shrink-0 hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono mr-1"
                style={{ color: tier.color, border: `1px solid ${tier.color}55`, background: `${tier.color}14` }}>
                🏛️ {tier.title.pl}
            </div>

            {/* ── Główne przyciski ──────────────────────────────────── */}
            {PRIMARY_NAV.map(item => {
                const locked = !canAccess(item.id, tier);
                return (
                <button
                    key={item.id}
                    onClick={() => { if (!locked) onViewChange(item.id); }}
                    disabled={locked}
                    title={locked ? `Odblokujesz na Filarze ${requiredPillar(item.id)}` : item.label}
                    className={cn(
                        'relative flex-1 md:flex-none flex items-center justify-center gap-2',
                        'px-3 py-2 rounded-full text-sm font-bold transition-all duration-300',
                        locked
                            ? 'opacity-40 cursor-not-allowed text-slate-500'
                            : activeView === item.id
                                ? `${theme.tw.bg} text-slate-900 shadow-lg ${theme.tw.shadow}`
                                : 'bg-transparent text-slate-300 hover:bg-slate-700/50 hover:text-white'
                    )}
                >
                    <div className="w-5 h-5 shrink-0 flex items-center justify-center">{locked ? '🔒' : item.icon}</div>
                    <span className="hidden md:inline whitespace-nowrap">{item.label}</span>
                </button>
            );})}

            {/* 🧘 TRYB ZEN — piąte miejsce na pasku, po Klubie.
                Renderowany OSOBNO, bo to przełącznik (callback), a nie widok:
                nie ma swojego `View`, więc nie może wejść do PRIMARY_NAV. */}
            <button
                onClick={() => onToggleZen?.()}
                title="Tryb Zen — ukryj interfejs, zostaw samą sferę"
                className={cn(
                    'relative flex-1 md:flex-none flex items-center justify-center gap-2',
                    'px-3 py-2 rounded-full text-sm font-bold transition-all duration-300',
                    'bg-transparent text-slate-300 hover:bg-slate-700/50 hover:text-white',
                )}
            >
                <div className="w-5 h-5 shrink-0 flex items-center justify-center">
                    <EyeOff className="w-4 h-4" />
                </div>
                <span className="hidden md:inline whitespace-nowrap">Tryb Zen</span>
            </button>

            {/* ── Separator ─────────────────────────────────────────── */}
            <div className="w-px h-6 bg-slate-700/60 shrink-0 mx-1" />

            {/* ── Przycisk "Więcej (...)" z dropdownem ──────────────── */}
            <div className="relative shrink-0" ref={moreRef}>
                <button
                    onClick={() => setIsMoreOpen(prev => !prev)}
                    className={cn(
                        'flex items-center gap-2 px-3 py-2 rounded-full text-sm font-bold',
                        'transition-all duration-300 select-none',
                        isMoreOpen || isMoreActive
                            ? `${theme.tw.bg} text-slate-900 shadow-lg ${theme.tw.shadow}`
                            : 'bg-transparent text-slate-400 hover:bg-slate-700/50 hover:text-white'
                    )}
                >
                    {/* Wskaźnik aktywnego widoku z "Więcej" */}
                    {isMoreActive && !isMoreOpen && (
                        <motion.span
                            layoutId="more-active-dot"
                            className="w-1.5 h-1.5 rounded-full bg-current"
                        />
                    )}
                    <MoreHorizontal className="w-5 h-5" />
                </button>

                {/* ── Panel glassmorphism ───────────────────────────── */}
                <AnimatePresence>
                    {isMoreOpen && (
                        <motion.div
                            key="more-dropdown"
                            initial={{ opacity: 0, y: -10, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0,   scale: 1    }}
                            exit={{   opacity: 0, y: -10, scale: 0.95 }}
                            transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
                            className={cn(
                                'absolute right-0 top-full mt-2 z-[110]',
                                'w-64 rounded-2xl p-2',
                                'bg-slate-950/90 backdrop-blur-2xl',
                                'border border-slate-700/60',
                                'shadow-2xl shadow-black/60',
                            )}
                            style={{
                                // Delikatna poświata akcentu
                                boxShadow: '0 0 0 1px rgba(100,116,139,0.4), 0 25px 50px rgba(0,0,0,0.6)',
                            }}
                        >
                            {/* Nagłówek panelu */}
                            <div className="px-3 py-2 mb-1">
                                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">
                                    Moduły Katedry
                                </p>
                            </div>

                            {/* Pozycje — w grupach; nagłówek grupy to nie przycisk */}
                            {GRUPY.map((g) => (
                                <React.Fragment key={g.id}>
                                    <p className="px-3 pt-2 pb-1 text-[9px] font-bold text-slate-600 uppercase tracking-[0.18em]">{g.nazwa}</p>
                                    {MORE_NAV.filter((i) => i.grupa === g.id).map((item, idx) => {
                                const locked = !canAccess(item.id, tier);
                                return (
                                <motion.button
                                    key={item.id}
                                    onClick={() => { if (!locked) handleMoreItemClick(item.id); }}
                                    disabled={locked}
                                    title={locked ? `Odblokujesz na Filarze ${requiredPillar(item.id)}` : item.desc}
                                    initial={{ opacity: 0, x: -8 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: idx * 0.045, duration: 0.18 }}
                                    className={cn(
                                        'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl',
                                        'text-sm font-medium transition-all duration-200 text-left',
                                        locked ? 'opacity-40 cursor-not-allowed text-slate-500' :
                                        activeView === item.id
                                            ? `bg-gradient-to-r ${theme.tw.bg} text-slate-900 shadow-md`
                                            : 'text-slate-300 hover:bg-slate-700/60 hover:text-white'
                                    )}
                                >
                                    {/* Ikona */}
                                    <div className={cn(
                                        'w-8 h-8 rounded-lg flex items-center justify-center shrink-0',
                                        activeView === item.id
                                            ? 'bg-black/20'
                                            : 'bg-slate-800/80'
                                    )}>
                                        <div className="w-4 h-4 flex items-center justify-center">{locked ? '🔒' : item.icon}</div>
                                    </div>

                                    {/* Tekst */}
                                    <div className="flex flex-col min-w-0">
                                        <span className="font-bold text-sm leading-tight">
                                            {item.label}
                                        </span>
                                        <span className={cn(
                                            'text-[10px] leading-tight truncate',
                                            activeView === item.id ? 'text-black/60' : 'text-slate-500'
                                        )}>
                                            {item.desc}
                                        </span>
                                    </div>

                                    {/* Aktywny wskaźnik */}
                                    {activeView === item.id && (
                                        <motion.div
                                            layoutId="more-item-indicator"
                                            className="ml-auto w-1.5 h-1.5 rounded-full bg-current shrink-0"
                                        />
                                    )}
                                </motion.button>
                            );})}
                                </React.Fragment>
                            ))}

                            {/* Separator */}
                            <div className="mx-3 my-2 h-px bg-slate-700/50" />

                            {/* Tryb Zen */}
                            <motion.button
                                onClick={() => { onToggleZen?.(); setIsMoreOpen(false); }}
                                initial={{ opacity: 0, x: -8 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: MORE_NAV.length * 0.045, duration: 0.18 }}
                                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:bg-slate-700/60 hover:text-white transition-all duration-200"
                            >
                                <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-slate-800/80 shrink-0">
                                    <EyeOff className="w-4 h-4" />
                                </div>
                                <div className="flex flex-col">
                                    <span className="font-bold text-sm leading-tight">Tryb Zen</span>
                                    <span className="text-[10px] text-slate-500 leading-tight">
                                        Ukryj interfejs — tylko sfera
                                    </span>
                                </div>
                            </motion.button>

                            {/* Dekoracyjny gradient u dołu panelu */}
                            <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-b-2xl bg-gradient-to-r from-transparent via-slate-600/40 to-transparent" />
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </nav>
    );
};

export default LoungeNavigation;
